import { axiosInstance, baseURL } from "./AxiosInstance";
import { ApiConfigGenerator } from "./ApiConfigGenerator";

class Api {
  Get = async (
    url: string,
    needAuth: boolean = true,
    type: string = "",
    defaultUrl: boolean = true,
    params?: any
  ) => {
    let config = ApiConfigGenerator(type, needAuth);
    return await axiosInstance({
      method: "get",
      url: defaultUrl ? `${baseURL}${url}` : url,
      params,
      paramsSerializer: { indexes: true },
      ...config,
    });
  };

  Post = async (
    url: string,
    data: any,
    needAuth: boolean = true,
    type: string = "",
    defaultUrl: boolean = true
  ) => {
    let config = ApiConfigGenerator(type, needAuth);
    return await axiosInstance({
      method: "post",
      url: defaultUrl ? `${baseURL}${url}` : url,
      data,
      ...config,
    });
  };

  Delete = async (
    url: string,
    data: any = null,
    needAuth: boolean = true,
    type: string = "",
    defaultUrl: boolean = true
  ) => {
    const config = ApiConfigGenerator(type, needAuth);
    return await axiosInstance({
      method: "delete",
      url: defaultUrl ? `${baseURL}${url}` : url,
      data,
      ...config,
    });
  };
}

export default new Api();
