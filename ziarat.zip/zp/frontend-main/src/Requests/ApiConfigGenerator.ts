import Keys from '../Storage/NameSpace';
import Storage from '../Storage/';
import { getCookie } from 'cookies-next';

export const ApiConfigGenerator = (type = '', needAuth = true) => {
  let config = {};
  if (needAuth === true) {
    if (type === 'xlsx' || type === 'pdf') {
      config = {
        responseType: 'blob',
        headers: {
          'Content-Type': 'application/json;charset=UTF-8',
          Authorization: `Bearer ${getCookie(Keys.token)}`,
        },
      };
    } else if (type === 'form-data') {
      config = {
        headers: {
          'Content-Type': 'multipart/form-data',
          Authorization: `Bearer ${getCookie(Keys.token)}`,
        },
      };
    } else {
      config = {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${getCookie(Keys.token)}`,
        },
      };
    }
  } else {
    if (type === 'login') {
      config = {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      };
    } else if (type === 'form-data') {
      config = {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      };
    } else {
      config = {
        headers: {
          'Content-Type': 'application/json',
        },
      };
    }
  }
  return config;
};