import axios from "axios";
import Storage from "../Storage";
import Keys from "../Storage/NameSpace";
import Toast from "../Shared/Kit/Toast";
import RoutePaths from "@/Utils/RoutePaths";
import { getCookie, deleteCookie } from "cookies-next";

interface exceptionTypes {
  errorMessage: string;
}

export let inRefresh = false;
let requestList = [];
export const baseURL = process.env.NEXT_PUBLIC_API_URL_ROOT;

export const isNoIndex = process.env.NEXT_PUBLIC_NO_INDEX === "true";

export const axiosInstance = axios.create({
  baseURL,
});

axiosInstance.interceptors.request.use(
  function (config) {
    return config;
  },
  (error) => Promise.reject(error)
);

axiosInstance.interceptors.response.use(
  (response) => {
    if (response.data.isSuccess === false) {
      if (response.data.errors && response.data.errors.length !== 0) {
        response.data.errors.map((each: exceptionTypes) => {
          Toast.error(each.errorMessage);
        });
      }
      return response;
    } else {
      return response;
    }
  },
  (error) => {
    // debugger
    const { config } = error;
    const originalRequest = config;

    if (error && error.code === "ERR_NETWORK") {
      Toast.error("لطفاً اتصال اینترنت را بررسی نمایید");
      return new Promise((resolve, reject) => {});
    }

    if (error.response && error.response.status === 401) {
      const isAuthRequest =
        originalRequest.url?.includes("/auth/login") ||
        originalRequest.url?.includes("/auth/send-otp") ||
        originalRequest.url?.includes("/auth/verify") ||
        originalRequest?.metadata?.skipRedirect === true;

      if (!isAuthRequest) {
        window.location.replace(RoutePaths.login);
        deleteCookie(Keys.token);

        if (!inRefresh) {
          // Token refresh logic
        }

        const retryOrigReq = new Promise((resolve, reject) => {
          subscribeTokenRefresh(() => {
            originalRequest.headers["Authorization"] =
              "Bearer " + getCookie(Keys.token);
            resolve(axiosInstance(originalRequest));
          });
        });
        return retryOrigReq;
      } else {
        return Promise.reject(error);
      }
    } else {
      return Promise.reject(error);
    }
  }
);

const subscribeTokenRefresh = (request: any) => {
  requestList.push(request);
};
