import Row from "@/Shared/Kit/Row";
import styled from "styled-components";

export const MainContainer = styled(Row)`
  margin: 20px 0;
  padding: 0 150px !important;
  /* max-width: 1440px; */
  .breadcrumb {
    margin-bottom: 10px;
  }
  @media (max-width: ${props => props.theme.lg}) {
    padding: 0 100px !important;
  }

  @media (min-width: ${props => props.theme.xl}) {
    padding: 0 0 !important;
    max-width: 1440px;
  }

  @media (max-width: ${props => props.theme.xs}) {
    padding: 0 20px !important;
  }
`