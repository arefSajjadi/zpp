import { Form, FormContainer } from "./styles";
import { Formik } from "formik";
import Select from "@/Shared/Kit/FromElements/Select";
import { FormRow } from "@/Shared/Kit/FromElements/FormStyles";
// import Calendar from "@/Shared/Kit/FromElements/Calendar";
import { PrimaryButton } from "@/Shared/Kit/Button/PrimaryButton";
import DateInput from "@/Shared/DateInput";
import FormHandlers from "@/Utils/FormHandlers";
import PassengersDialog from "../PassengersDialog";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { selectHome } from "@/Redux/Home/Selectors";
import { SearchTourSchema } from "@/Validations/SearchTourSchema";
import persian_to_english_number from "@/Utils/persianToEnglishNumber";
import { useRouter } from "next/router";
import LocationIcon from "@/Assets/Icons/LocationIcon";
import Input from "@/Shared/Kit/FromElements/Input";

// const Calendar = dynamic(() => import("@/Shared/Kit/FromElements/Calendar"));

interface Props {
  setShowForm?: (...args: any) => void;
  tourDefaultCity?: boolean;
}
const SelectTourBox: React.FC<Props> = (props) => {
  const { setShowForm, tourDefaultCity = false } = props;
  const router = useRouter();
  const [showPassengers, setShowPassengers] = useState(false);
  const [sourceCityTitle, setSourceCityTitle] = useState("");
  const [sourceCityId, setSourceCityId] = useState<number | undefined>(
    undefined
  );
  const [defaultSourceCity, setDefaultSourceCity] = useState<number | null>(
    null
  );
  const { sourceProvince, adultCount, babyCount, childCount } =
    useSelector(selectHome);

  const desCityOption = [
    {
      id: 1,
      title: "عتبات عالیات",
    },
  ];

  useEffect(() => {
    if (tourDefaultCity) {
      const srcCity = sourceProvince.find((province) => {
        return province.slug === "tehran";
      });
      if (srcCity) {
        setDefaultSourceCity(srcCity?.id);
        setSourceCityTitle(srcCity?.slug);
      }
    } else {
      const srcCity = sourceProvince.find((province) => {
        return province.slug === router.query?.source?.toString().split("-")[1];
      });
      if (srcCity) {
        setDefaultSourceCity(srcCity?.id);
        setSourceCityTitle(srcCity?.slug);
      }
    }
  }, [sourceProvince]);

  const handleSubmit = (values: any, action: any) => {
    const searchData = {
      adult: adultCount,
      child: childCount,
      baby: babyCount,
      total: adultCount + babyCount + childCount,
      date: persian_to_english_number(values.date).split("/").join("-"),
    };
    setShowPassengers(false);
    setShowForm && setShowForm(false);
    router.push({
      pathname: `/tours/karbala/from-${sourceCityTitle}`,
      query: searchData,
    });
  };

  return (
    <FormContainer>
      <Formik
        initialValues={{
          sourceCity: defaultSourceCity ? defaultSourceCity : null,
          destinationCity: 1,
          date: router.query.date ? router.query.date : "",
        }}
        enableReinitialize={true}
        validationSchema={SearchTourSchema}
        onSubmit={(values, action) => {
          handleSubmit(values, action);
        }}
      >
        {(formik) => (
          <Form onSubmit={formik.handleSubmit} className="form">
            <FormRow
              xl={16}
              xs={24}
              minHeight="60px"
              className="form-row sourceAndDesContainer"
            >
              <Select
                label="مبدا"
                name="sourceCity"
                OptionsIcon={LocationIcon}
                havePadding={true}
                readOnly={true}
                error={
                  formik.touched.sourceCity ? formik.errors.sourceCity : null
                }
                onSelect={(selected: any, name: any) => {
                  FormHandlers.onSelect(selected, name, formik, () => {
                    setSourceCityTitle(selected.slug);
                    setSourceCityId(selected.id);
                  });
                }}
                columns={[
                  {
                    displayTitle: "name",
                    headerTitle: "",
                    size: 1,
                  },
                ]}
                displayTitle="name"
                options={sourceProvince}
                size="sm"
                value={formik.values.sourceCity}
                className="sourceInput"
                InputIcon={LocationIcon}
                iconProps={{ color: "#767676" }}
              />

              <Input
                className="destinationInput"
                label="مقصد"
                name="destinationCity"
                size="sm"
                onBlur={() => {}}
                onChange={(e: any) => {}}
                value={desCityOption[0].title}
                disabled={true}
              />
            </FormRow>
            <FormRow xl={8} xs={24} minHeight="60px">
              <DateInput
                formik={formik}
                label="تاریخ (اختیاری)"
                name="date"
                cityId={sourceCityId ?? (defaultSourceCity || undefined)}
              />
            </FormRow>
            {/* <FormRow xl={6} xs={24} minHeight="60px">
              <PassengersDialog
                setShow={setShowPassengers}
                show={showPassengers}
              />
            </FormRow> */}

            <PrimaryButton
              color="primary"
              size="sm"
              width="91px"
              title="جستجو"
              type="submit"
              isCurve={true}
              className="searchBtn"
            />
          </Form>
        )}
      </Formik>
    </FormContainer>
  );
};

export default SelectTourBox;
