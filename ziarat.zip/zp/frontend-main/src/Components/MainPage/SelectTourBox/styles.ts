import Col from "@/Shared/Kit/Col";
import Row from "@/Shared/Kit/Row";
import styled from "styled-components";

export const FormContainer = styled(Row)`
  flex-wrap: nowrap;
  
  margin-top: 30px;
  .rmdp-ep-shadow {
    position: absolute;
    display: none !important;
  }
  .rmdp-shadow {
    box-shadow: none;
    border: 1px solid ${(props) => props.theme.gray200};
  }
  .form {
    flex-wrap: nowrap;
    gap: 1rem;
    align-items: flex-start;
  }
  .form-row {
    flex-wrap: nowrap;
  }
  .rmdp-calendar {
    padding: 0 15px 15px !important;
  }
  .sourceInput {
    input {
      border-radius: 0 10px 10px 0;
    }
  }
  .destinationInput {
    input {
      border-radius: 10px 0 0 10px;
    }
  }
  @media (max-width: ${(props) => props.theme.xs}) {
    flex-direction: column;
    .searchBtn {
      width: 100% !important;
    }

    .sourceAndDesContainer {
      flex-direction: column;
      gap: 1rem;
      .sourceInput {
        input {
          border-radius: 10px;
        }
      }
      .destinationInput {
        input {
          border-radius: 10px;
        }
      }
    }

    // mobile date picker
    .rmdp-calendar-container-mobile {
      background-color: ${(props) => props.theme.white};
      border-radius: 20px;
      height: calc(100vh);
      bottom: 0px !important;
      top: 150px !important;

      .rmdp-mobile.rmdp-wrapper {
        top: 335px !important;
      }
      .rmdp-calendar {
        padding: 0 20px !important;
      }
      .rmdp-wrapper {
        padding: 0 20px !important;
        border: none;
        width: 100%;
      }
      .rmdp-calendar {
        width: 100%;
      }
      .rmdp-day-picker > div {
        width: 100%;
      }

      .rmdp-action-buttons {
        justify-content: center;
        gap: 20px;
      }
      .rmdp-border-top {
        border-top: none;
      }
      .rmdp-top-class {
        border-bottom: none !important;
        border-top: 1px solid ${(props) => props.theme.gray100} !important;
        margin: 0;
      }
      .close-btn {
        position: absolute;
        top: -30px;
        left: 50px;
        background-color: ${(props) => props.theme.white};
        border: none;
        /* rotate: 180deg; */
      }
    }
  }
`;

export const Form = styled.form`
  display: flex;
  width: 100%;
  justify-content: flex-start;
  @media (max-width: ${(props) => props.theme.xs}) {
    flex-direction: column;
  }
`;
