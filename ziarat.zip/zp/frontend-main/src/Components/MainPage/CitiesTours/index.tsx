import React from "react";
import {
  CitiesContainer,
  CitiesToursContainer,
  CitiesTourWrapper,
  EachItemContainer,
} from "./styles";
import TehranVector from "@/Assets/Icons/CitiesVectors/TehranVector";
import MashhadVector from "@/Assets/Icons/CitiesVectors/MashhadVector";
import YazdVector from "@/Assets/Icons/CitiesVectors/YazdVector";
import IsfahanVector from "@/Assets/Icons/CitiesVectors/IsfahanVector";
import ShirazVector from "@/Assets/Icons/CitiesVectors/ShirazVector";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";
import { addSeparator } from "@/Utils/Separator";
import { LargeLabel } from "@/Shared/Kit/Typography/Label";
import { XLargeHeading, XXLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import TabrizVector from "@/Assets/Icons/CitiesVectors/TabrizVector";
import { selectHome } from "@/Redux/Home/Selectors";
import Link from "next/link";

const cityImages: { [key: string]: React.FC } = {
  tehran: TehranVector,
  isfahan: IsfahanVector,
  mashhad: MashhadVector,
  shiraz: ShirazVector,
  tabriz: TabrizVector,
};

const cityUrl: { [key: string]: string } = {
  tehran: "/tours/karbala/from-tehran",
  isfahan: "/tours/karbala/from-isfahan",
  mashhad: "/tours/karbala/from-mashhad",
  shiraz: "/tours/karbala/from-shiraz",
  tabriz: "/tours/karbala/from-tabriz",
};

const CitiesTours = () => {
  const theme = useSelector(selectTheme);
  const { popularProvince } = useSelector(selectHome);

  function getCityImage(cityName: string) {
    const slug = cityName.toLowerCase();
    return cityImages[slug] || "";
  }

  function getCityUrl(cityName: string) {
    const slug = cityName.toLowerCase();
    return cityUrl[slug] || "";
  }

  return (
    <CitiesTourWrapper>
      {popularProvince?.length > 0 && (
        <CitiesToursContainer>
          <XLargeHeading className="title" color={theme.primary300}>
            مسیر های پرتردد
          </XLargeHeading>
          <CitiesContainer>
            {popularProvince?.map((item) => {
              const Icon = getCityImage(item.slug);
              return (
                <EachItemContainer key={item?.id}>
                  <Icon />
                  <Link href={getCityUrl(item.slug)}>
                    <LargeLabel className="link">{`تور کربلا از ${item.name}`}</LargeLabel>
                  </Link>

                  <SmallParagraph className="pricePragraph">
                    <span>از</span>
                    {addSeparator(item.cost)}
                    <span>تومان</span>
                  </SmallParagraph>
                </EachItemContainer>
              );
            })}
          </CitiesContainer>
        </CitiesToursContainer>
      )}
    </CitiesTourWrapper>
  );
};

export default CitiesTours;
