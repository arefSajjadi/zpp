import Col from "@/Shared/Kit/Col";
import Row from "@/Shared/Kit/Row";
import styled from "styled-components";

export const CitiesTourWrapper = styled(Row)`
  @media (max-width: ${(props) => props.theme.xs}) {
    padding: 0px 20px 0 0;
  }
`;

export const CitiesToursContainer = styled(Col)`
  margin: 30px 0;
  padding: 30px;
  flex-wrap: nowrap;
  border: ${(props) => `1px solid ${props.theme.gray400}`};
  border-radius: 30px;
  background-color: ${(props) => props.theme.white};

  .title {
    font-size: 28px;
    line-height: 44px;
    margin-bottom: 30px;
  }
  @media (max-width: ${(props) => props.theme.xs}) {
    padding: 30px 10px;
    border-radius: 0 30px 30px 0;
  }
`;

export const CitiesContainer = styled(Row)`
  flex-wrap: nowrap;
  @media (max-width: ${(props) => props.theme.xs}) {
    overflow-x: auto;
  }
`;

export const EachItemContainer = styled(Col)`
  .link {
    cursor: pointer;
  }
  .pricePragraph {
    font-weight: 900;
    span {
      color: ${(props) => props.theme.gray400};
      margin: 0 5px;
      font-weight: normal;
    }
  }
`;
