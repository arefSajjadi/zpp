import React from "react";
import {
  IconContainer,
  ImageContainer,
  RightCol,
  Section4Container,
  Section4Wrapper,
  SocialMediaContainer,
} from "./styles";
import {
  LargeDisplay,
  MediumDisplay,
  XLargeDisplay,
} from "@/Shared/Kit/Typography/Display";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import Col from "@/Shared/Kit/Col";
import { XSmallParagraph } from "@/Shared/Kit/Typography/Paragraph";
import { XSmallLabel } from "@/Shared/Kit/Typography/Label";
import EttaIcon from "@/Assets/Icons/EttaIcon";
import BaleIcon from "@/Assets/Icons/BaleIcon";
import InstagramIcon from "@/Assets/Icons/InstagramIcon";
import TelegramIcon from "@/Assets/Icons/TelegramIcon";
import Row from "@/Shared/Kit/Row";
import Image from "next/image";
import Pattern from "@/Components/Pattern";
import RightPattern from "@/Assets/Icons/RightPattern";
import LeftPattern from "@/Assets/Icons/LeftPattern";
import Link from "next/link";

const Section4 = () => {
  const theme = useSelector(selectTheme);

  const socialMedia = [
    {
      id: 1,
      title: "ایتا",
      tag: "@ziarat.co",
      icon: EttaIcon,
      src: "https://eitaa.com/ziaratco",
    },
    {
      id: 2,
      title: "بله",
      tag: "@ziarat.co",
      icon: BaleIcon,
      src: "https://ble.ir/ziaratco",
    },
      {
          id: 3,
          title: "تلگرام",
          tag: "@ziaratco",
          icon: TelegramIcon,
          src: "https://telegram.me/ziaratco",
      },
    {
      id: 3,
      title: "اینستاگرام",
      tag: "@ziarat.co",
      icon: InstagramIcon,
      src: "https://www.instagram.com/ziarat.co?igsh=MXU4dXJxZHJvNTM2cA==",
    },
  ];
  return (
    <Section4Wrapper>
      <Section4Container>
        <Pattern
          right="0px"
          borderRadius="0 30px 30px 0"
          width="40%"
          icon={RightPattern}
        />
        <RightCol xl={12} xs={24}>
          <MediumDisplay className="followUs" color={theme.white}>
            ما را در فضای مجازی دنبال کنید
          </MediumDisplay>

          <SocialMediaContainer>
            {/*<Col className="ourAddress">*/}
            {/*  <XSmallLabel color={theme.white}>@ziarat.co</XSmallLabel>*/}
            {/*  <XSmallParagraph color={theme.white}>آدرس ما</XSmallParagraph>*/}
            {/*</Col>*/}
            {socialMedia.map((item) => {
              const Icon = item.icon;
              return (
                <Link target="_blnak" href={item.src} key={item.id}>
                  <Row className="eachItemContainer">
                    <IconContainer>
                      <Icon />
                    </IconContainer>
                    <Col className="contentContainer">
                      <XSmallParagraph color={theme.white}>
                        {item.title}
                      </XSmallParagraph>
                      {/* <XSmallLabel color={theme.white}>{item.tag}</XSmallLabel> */}
                    </Col>
                  </Row>
                </Link>
              );
            })}
          </SocialMediaContainer>
        </RightCol>
        <ImageContainer xl={8}>
          <Image alt="" src={"/Images/MainPage/mobile.png"} fill />
        </ImageContainer>
        <Pattern
          left="0px"
          borderRadius="30px 0 0 30px"
          width="40%"
          icon={LeftPattern}
        />
      </Section4Container>
    </Section4Wrapper>
  );
};

export default Section4;
