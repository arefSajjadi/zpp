import Col from "@/Shared/Kit/Col";
import Row from "@/Shared/Kit/Row";
import { HexToRgba } from "@/Utils/HexToRgba";
import styled from "styled-components";


export const Section4Wrapper = styled(Row)`
        @media (max-width: ${props => props.theme.xs}) {
        padding: 0 20px;
    }
`

export const Section4Container = styled(Row)`
    background-color: ${props => props.theme.primary500};
    border-radius: 30px;
    position: relative;
    overflow: visible;
    height: 383px;
    flex-wrap: nowrap;
    justify-content: flex-start;
    margin-top: 130px;
    margin-bottom: 20px;

        
    @media (max-width: ${props => props.theme.xs}) {
        height: 200px;
        margin-top: 16px;
        overflow: hidden;

        svg {
            height: 100%;
        }

        .patternContainer:last-child {
            top: -30px;
        }
    }
`

export const RightCol = styled(Col)`
    padding: 46px 46px 46px 0;
    gap: 26px;
    z-index: 1;
    align-items: flex-start;
    .followUs {
        max-width: 392px;
        font-size: 38px;
        line-height: 65px;
    }

    @media (max-width: ${props => props.theme.xs}) {
        padding: 20px;
        gap: 0px;
        height: 100%;
        justify-content: space-between;
        .followUs {
            font-size: 22px;
        }
    }
`

export const ImageContainer = styled(Row)`
    height: 484px;
    max-width: 400px;
    position: absolute;
    bottom: 0px;
    left: 10%;
    z-index: 2;
    bottom: 0;
    
    @media (max-width: ${props => props.theme.xs}) {
        height: 100px;
        width: 100px;
        left: -20px;
        overflow: hidden;
    }

`

export const SocialMediaContainer = styled(Row)`
    background-color: ${props => HexToRgba(props.theme.white ,.5)};
    padding: 20px;
    gap: 20px;
    border-radius: 20px;
    width: max-content;
    .ourAddress {
        display: none;
    }
    .eachItemContainer {
        flex-wrap: nowrap;
        width: max-content;
        gap: 20px;
        .contentContainer {
            align-items: flex-start;
            @media (max-width: ${props => props.theme.xs}) {
      display: none;

    }
        }
    }
    @media (max-width: ${props => props.theme.xs}) {
        width: max-content;
        .contentContainer {
            @media (max-width: ${props => props.theme.xs}) {
                    display: none;
            }
        }
        padding: 12px;
        align-self: flex-start;
        .ourAddress {
            display: flex;
            width: max-content;
        }
    }
`

export const IconContainer = styled(Row)`
    background-color: ${props => props.theme.white};
    padding: 10px;
    border-radius: 50%;
    justify-content: center;
     width: 49px;
    height: 49px; 
    svg {
        fill: ${props => props.theme.primary600} !important;
    }
    path {
        fill: ${props => props.theme.primary600} !important;
    }

    @media (max-width: ${props => props.theme.xs}) {
       padding: 5px;
        width: 40px;
        height: 40px;
        svg {
        width: 20px;
        height: 20px;
    }
    }
`