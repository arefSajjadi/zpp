import Col from "@/Shared/Kit/Col";
import styled from "styled-components";

export const Section5Container = styled(Col)`
  margin-bottom: 20px;

  .logoContainer {
    display: none;
  }
  .firstContentContainer {
    flex-wrap: nowrap;
    justify-content: space-between;
  }

  .textContainer {
    align-items: flex-start;
    gap: 20px;
    h1 {
      font-size: 40px;
      line-height: 55px;
    }

    p {
      text-align: justify;
    }
  }

  .secondContentContainer {
    p {
      text-align: justify;
    }

    margin-top: 10px;
  }

  @media (max-width: ${(props) => props.theme.xs}) {
    padding: 0 20px;
      margin-bottom: 16px;

    .logoContainer {
      display: flex;
      justify-content: center;
      margin-bottom: 30px;
    }
    .imageContainer {
      display: none;
    }
  }
`;
