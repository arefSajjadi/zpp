import React from "react";
import { Section5Container } from "./styles";
import Row from "@/Shared/Kit/Row";
import Col from "@/Shared/Kit/Col";
import {XLargeHeading, XXLargeHeading} from "@/Shared/Kit/Typography/Heading";
import { XSmallParagraph } from "@/Shared/Kit/Typography/Paragraph";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import LogoIcon3 from "@/Assets/Icons/LogoIcon3";
import Link from "next/link";

const Section5 = () => {
  const theme = useSelector(selectTheme);
  return (
    <Section5Container>
      <Row className="logoContainer">
        <LogoIcon3 />
      </Row>
      <Row xl={24} className="firstContentContainer">
        <Col xl={16} xs={24} className="textContainer">
          <XLargeHeading color={theme.primary500}>
            رسم زیارت، اولین سامانه رزرو آنلاین تور کربلا
          </XLargeHeading>
          <XSmallParagraph>
            رسم زیارت، اولین سامانه رزرو آنلاین سفرهای زیارتی در ایران است که
            تحول نوینی را در حوزه سفر‌های عتبات عالیات ایجاد کرده است. این
            سامانه، زیرمجموعه شرکت آوای رسم سفر است که به‌عنوان کارگزار رسمی
            سازمان حج و زیارت با شماره مجوز 57171 در حوزه سفر‌های زیارتی فعالیت
            می‌کند. در سامانه جامع رسم زیارت، امکانی فراهم شده است تا متقاضیان
            به آسان‌ترین شکل ممکن بتوانند در کاروان‌های زیارتی ثبت‌نام کنند. شما
            در این سامانه، با مشاهده کاروان‌های ارائه‌شده سازمان حج و زیارت و
            مقایسه ویژگی‌ها و خدمات آنها، می‌توانید نسبت به رزرو تور مدنظر خود
            اقدام کنید.
          </XSmallParagraph>
        </Col>
        <Col xl={8} className="imageContainer">
          <LogoIcon3 />
        </Col>
      </Row>

      <Row className="secondContentContainer">
        <XSmallParagraph>
          تمرکز اصلی سامانه رسم زیارت، بر روی{" "}
          <Link href={"/tours/karbala"}> تور کربلا و نجف</Link> است. در این
          سامانه، با انتخاب شهر مبدأ و بازه زمانی مدنظرتان برای سفر، لیست
          تور‌های کربلا سازمان حج و زیارت را مشاهده خواهید کرد. سپس برنامه سفر،
          خدمات و امکانات هتل‌های اسکان را بررسی کرده و درنهایت تور دلخواهتان را
          انتخاب می‌کنید. مقایسه آسان قیمت‌ها، اطلاع از تقارن با مناسبت‌های
          مذهبی، فیلتر تور‌ها براساس نوع سفر (زمینی و هوایی) و تعداد روز‌های
          اسکان در سامانه رسم زیارت به‌راحتی امکان‌پذیر شده است.
        </XSmallParagraph>
      </Row>
    </Section5Container>
  );
};

export default Section5;
