import Col from "@/Shared/Kit/Col";
import Row from "@/Shared/Kit/Row";
import styled from "styled-components";

export const PassengersDialogContainer = styled(Col)`
  z-index: 6;
  cursor: pointer;
  position: relative;
`;

export const PassengersInput = styled(Row)`
  height: 44px;
  padding: 10px;
  border-radius: 10px;
  border: 1px solid ${(props) => props.theme.gray300};
  transition: all 0.2s ease;
  p {
    font-size: 16px;
    color: ${(props) => props.theme.black};
  }
  @media (max-width: ${(props) => props.theme.lg}) {
    height: 40px;
  }

  @media (max-width: ${(props) => props.theme.sm}) {
    height: 50px;
  }
`;

interface ChooseBoxType {
  show: boolean;
}
export const ChooseBox = styled(Col)<ChooseBoxType>`
  opacity: ${(props) => (props.show ? 1 : 0)};
  visibility: ${(props) => (props.show ? "visible" : "hidden")};
  transition: all 0.2s ease;
  background-color: ${(props) => props.theme.white};
  padding: 10px;
  width: 275px;
  position: absolute;
  top: 50px;
  border: 1px solid ${(props) => props.theme.primary200};
  border-radius: 10px;
  gap: 10px;

  .eachBox:nth-child(3) {
    border-bottom: none !important;
  }

  @media (max-width: ${(props) => props.theme.xs}) {
    border: none;
    width: 100%;
    padding: 20px;
    position: relative;
  }
`;

export const EachBox = styled(Col)`
  border-bottom: 1px solid ${(props) => props.theme.gray500};
  padding-bottom: 10px;

  .firstRow,
  .secondRow {
    justify-content: space-between;
  }

  .secondRow {
    button {
      height: 25px;
      div {
        font-size: 24px;
      }
    }
  }
`;
