import { SmallLabel } from "@/Shared/Kit/Typography/Label";
import {
  ChooseBox,
  EachBox,
  PassengersDialogContainer,
  PassengersInput,
} from "./styles";
import {
  LargeParagraph,
  XSmallParagraph,
} from "@/Shared/Kit/Typography/Paragraph";
import { useDispatch, useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import Row from "@/Shared/Kit/Row";
import { OutlineButton } from "@/Shared/Kit/Button/OutlineButton";
import { selectHome } from "@/Redux/Home/Selectors";
import { PrimaryButton } from "@/Shared/Kit/Button/PrimaryButton";
import { AppDispatch } from "@/Redux/store";
import { setPassengersCount } from "@/Redux/Home/HomeSlice";
import { useEffect } from "react";
import useIsMobile from "@/Utils/Responsive";
import Modal from "@/Shared/Kit/Modal";

import TwoUserIcon from "@/Assets/Icons/TwoUserIcon";

interface Props {
  show: boolean;
  setShow: any;
  showInput?: boolean;
  push?: any;
}
const PassengersDialog: React.FC<Props> = (props) => {
  const { show, push, setShow, showInput = true } = props;
  const theme = useSelector(selectTheme);
  const dispatch = useDispatch<AppDispatch>();
  const { adultCount, babyCount, childCount } = useSelector(selectHome);
  const responsive = useIsMobile();
  const items: {
    id: number;
    title: string;
    des: string;
    type: "adult" | "child" | "baby";
  }[] = [
    {
      id: 1,
      title: "بزرگسال",
      des: "۱۲ سال به بالا",
      type: "adult",
    },
    {
      id: 2,
      title: "کودک",
      des: "2 تا 12 سال",
      type: "child",
    },
    {
      id: 3,
      title: "نوزاد",
      des: "0 تا 2 سال",
      type: "baby",
    },
  ];

  const addClick = (type: "adult" | "child" | "baby") => {
    if (type === "adult") {
      dispatch(
        setPassengersCount({
          adultCount: adultCount + 1,
        })
      );
      push &&
        push({
          firstName: "",
          lastName: "",
          nationalCode: "",
          mobile: "",
          birthMonth: "",
          birthDay: "",
          birthYear: "",
          ageLevel: "adult",
        });
    } else if (type === "child") {
      dispatch(
        setPassengersCount({
          childCount: childCount + 1,
        })
      );
      push &&
        push({
          firstName: "",
          lastName: "",
          nationalCode: "",
          mobile: "",
          birthMonth: "",
          birthDay: "",
          birthYear: "",
          ageLevel: "child",
        });
    } else if (type === "baby") {
      dispatch(
        setPassengersCount({
          babyCount: babyCount + 1,
        })
      );
      push &&
        push({
          firstName: "",
          lastName: "",
          nationalCode: "",
          mobile: "",
          birthMonth: "",
          birthDay: "",
          birthYear: "",
          ageLevel: "baby",
        });
    }
  };

  const removeClick = (type: "adult" | "child" | "baby") => {
    if (type === "adult" && adultCount > 0) {
      dispatch(
        setPassengersCount({
          adultCount: adultCount - 1,
        })
      );
    } else if (type === "child" && childCount > 0) {
      dispatch(
        setPassengersCount({
          childCount: childCount - 1,
        })
      );
    } else if (type === "baby" && babyCount > 0) {
      dispatch(
        setPassengersCount({
          babyCount: babyCount - 1,
        })
      );
    }
  };

  const handleConfirm = () => {
    closeDialog();
  };

  useEffect(() => {
    const handlePopState = () => {
      if (show) {
        setShow(false);
      }
    };

    window.addEventListener("popstate", handlePopState);

    return () => {
      window.removeEventListener("popstate", handlePopState);
    };
  }, [show]);

  const openDialog = () => {
    window.history.pushState({ modalOpen: true }, "");
    setShow(true);
  };

  const closeDialog = () => {
    setShow(false);

    if (window.history.state && window.history.state.modalOpen) {
      window.history.back();
    }
  };

  return (
    <PassengersDialogContainer>
      {showInput && (
        <PassengersInput onClick={openDialog}>
          <span style={{ marginLeft: "0.25rem", height: "20px" }}>
            <TwoUserIcon color={"#767676"} />
          </span>
          <XSmallParagraph color={theme.gray600}>
            <span>{"مسافران"}</span>
          </XSmallParagraph>
          <span style={{ marginRight: "auto", color: "#767676" }}>
            {childCount + adultCount + babyCount + " زائر"}
          </span>
        </PassengersInput>
      )}

      {responsive === "mobile" ? (
        <Modal
          height="60vh"
          headerTitle="مسافران"
          size="xs"
          visible={show}
          onClose={closeDialog}
        >
          <ChooseBox show={show} className="chooseBox">
            {items.map((item) => {
              return (
                <EachBox key={item.id}>
                  <Row className="firstRow">
                    <SmallLabel>{item.title}</SmallLabel>
                    <XSmallParagraph color={theme.gray500}>
                      {item.des}
                    </XSmallParagraph>
                  </Row>
                  <Row className="secondRow">
                    <OutlineButton
                      color="primary"
                      size="xs"
                      width="25px"
                      title="-"
                      onClick={() => removeClick(item.type)}
                      type="button"
                      disabled={
                        item.type === "adult"
                          ? adultCount <= 1
                            ? true
                            : false
                          : item.type === "child"
                          ? childCount <= 0
                            ? true
                            : false
                          : babyCount <= 0
                          ? true
                          : false
                      }
                    />
                    <LargeParagraph>
                      {item.type === "adult"
                        ? adultCount
                        : item.type === "child"
                        ? childCount
                        : babyCount}
                    </LargeParagraph>
                    <OutlineButton
                      color="primary"
                      size="xs"
                      width="25px"
                      title="+"
                      onClick={() => addClick(item.type)}
                      type="button"
                      disabled={
                        item.type === "adult"
                          ? adultCount >= 10
                            ? true
                            : false
                          : item.type === "child"
                          ? childCount >= 3
                            ? true
                            : false
                          : babyCount >= 3
                          ? true
                          : false
                      }
                    />
                  </Row>
                </EachBox>
              );
            })}

            <PrimaryButton
              size="sm"
              title="تایید"
              color="primary"
              width="100%"
              onClick={handleConfirm}
              isCurve={true}
              type="button"
            />
          </ChooseBox>
        </Modal>
      ) : (
        <ChooseBox show={show} className="chooseBox">
          {items.map((item) => {
            return (
              <EachBox className="eachBox" key={item.id}>
                <Row className="firstRow">
                  <SmallLabel>{item.title}</SmallLabel>
                  <XSmallParagraph color={theme.gray500}>
                    {item.des}
                  </XSmallParagraph>
                </Row>
                <Row className="secondRow">
                  <OutlineButton
                    color="primary"
                    size="xs"
                    width="25px"
                    title="-"
                    onClick={() => removeClick(item.type)}
                    type="button"
                    disabled={
                      item.type === "adult"
                        ? adultCount <= 1
                          ? true
                          : false
                        : item.type === "child"
                        ? childCount <= 0
                          ? true
                          : false
                        : babyCount <= 0
                        ? true
                        : false
                    }
                  />
                  <LargeParagraph>
                    {item.type === "adult"
                      ? adultCount
                      : item.type === "child"
                      ? childCount
                      : babyCount}
                  </LargeParagraph>
                  <OutlineButton
                    color="primary"
                    size="xs"
                    width="25px"
                    title="+"
                    onClick={() => addClick(item.type)}
                    type="button"
                    disabled={
                      item.type === "adult"
                        ? adultCount >= 10
                          ? true
                          : false
                        : item.type === "child"
                        ? childCount >= 3
                          ? true
                          : false
                        : babyCount >= 3
                        ? true
                        : false
                    }
                  />
                </Row>
              </EachBox>
            );
          })}

          <PrimaryButton
            size="sm"
            title="تایید"
            color="primary"
            width="100%"
            onClick={handleConfirm}
            isCurve={true}
            type="button"
          />
        </ChooseBox>
      )}
    </PassengersDialogContainer>
  );
};

export default PassengersDialog;
