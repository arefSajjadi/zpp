import React from "react";
import styled from "styled-components";

export const MainPageWrapper = styled.main`
  display: flex;
  direction: rtl;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  box-sizing: border-box;
  line-height: 1.6;
  width: 100%;
  padding: 0 150px !important;
  max-width: 2220px;

  @media (max-width: ${props => props.theme.lg}) {
    padding: 0 100px !important;
  }

  @media (min-width: ${(props) => props.theme.xl}) {
    padding: 0 150px !important;
  }

  @media (max-width: ${props => props.theme.xs}) {
    padding: 0 0px !important;
  }
`;