

import Col from "@/Shared/Kit/Col";
import Row from "@/Shared/Kit/Row";
import styled from "styled-components";



export const Section6Container = styled(Row)`
    gap: 50px;
    margin-bottom: 20px;
    align-items: flex-start;
    @media (max-width: ${props => props.theme.xs}) {
        padding: 0 20px;
    }

`

interface Section6ContainerProps {
    source: string;
}
export const ImageContainer = styled(Row)<Section6ContainerProps>`
    background-image: url(${props => props.source});
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    height: 652px;
    border-radius: 30px;
    padding: 50px;
    align-items: flex-end;
    justify-content: flex-start;
    position: relative;

    .faq {
        width: 50%;
    }

    @media (max-width: ${props => props.theme.xs}) {
        display: none;
    }

`

export const AccordionsContainer = styled(Col)`
    padding:  30px 0;
    gap: 15px;
    min-height: 652px;
    justify-content: flex-start;
`