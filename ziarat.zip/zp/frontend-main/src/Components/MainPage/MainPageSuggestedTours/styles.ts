import Col from "@/Shared/Kit/Col";
import Row from "@/Shared/Kit/Row";
import styled from "styled-components";

export const MainContainer = styled(Col)`
  .title {
    font-size: 28px;
    line-height: 44px;
    margin-bottom: 30px;
  }

  @media (max-width: ${(props) => props.theme.xs}) {
    padding: 0 20px;
  }
`;

export const SliderContainer = styled(Row)``;
