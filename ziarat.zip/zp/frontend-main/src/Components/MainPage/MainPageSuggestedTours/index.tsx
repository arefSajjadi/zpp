import SuggestedTours from "@/Components/SuggestedTours";
import { MainContainer, SliderContainer } from "./styles";
import { XSmallDisplay } from "@/Shared/Kit/Typography/Display";
import { XLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";

const MainPageSuggestedTours = () => {
  const theme = useSelector(selectTheme)
    return ( 
       <MainContainer>
        <XLargeHeading className="title" color={theme.primary300}>
          کاروان های پیشنهادی
        </XLargeHeading>
        <SliderContainer>

            <SuggestedTours showBtn={true} />
        </SliderContainer>
       </MainContainer> 
     );
}
 
export default MainPageSuggestedTours;