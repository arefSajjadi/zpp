import Row from "@/Shared/Kit/Row";
import styled from "styled-components";


export const OurPropertiesContainer = styled(Row)`
   
    justify-content:center;
`

export const EachItemContainer = styled(Row)`
    flex-wrap: nowrap;

    gap:30px;
    width: max-content;
    padding: 20px 10px;
    .titleParagraph {
        font-weight: 900;
    };
   
    &>div {
        align-items: flex-start;
    }
`