import React from "react";
import { EachItemContainer, OurPropertiesContainer } from "./styles";
import LicenseIcon from "@/Assets/Icons/OurPropertiesIcons/LicenseIcon";
import MasqueIcon from "@/Assets/Icons/OurPropertiesIcons/MasqueIcon";
import SupportIcon from "@/Assets/Icons/OurPropertiesIcons/SupportIcon";
import MapIcon from "@/Assets/Icons/OurPropertiesIcons/MapIcon";
import Col from "@/Shared/Kit/Col";
import { LargeParagraph, SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";

const OurProperties = () => {
    const theme = useSelector(selectTheme)
    const properties = [
        {
            id: 1,
            icon: LicenseIcon,
            title: "مجوز رسمی",
            description:"مجوز رسمی از سازمان حج و زیارت "
        },
        {
            id: 2,
            icon: MasqueIcon,
            title: "اولین سامانه آنلاین زیارتی",
            description:"اولین سامانه آنلاین زیارتی در ایران"
        },
        {
            id: 3,
            icon: SupportIcon, 
            title: "مشاوره و پشتیبانی",
            description:"پشتیبانی قبل، حین و بعد از سفر"
        },
        {
            id: 4,
            icon: MapIcon,
            title: "سفر از سراسر ایران",
            description:"سفر های زیارتی از سراسر ایران"
        },
    ]
    return ( 
        <OurPropertiesContainer>
            {
                properties.map((property) => {
                    const Icon = property.icon;
                    return(
                        <EachItemContainer key={property?.id}>
                            <Icon />
                            <Col>
                                <LargeParagraph className="titleParagraph" color={theme.primary500}>
                                    {property.title}
                                </LargeParagraph>
                                <LargeParagraph color={theme.gray400}>
                                    {property.description}
                                </LargeParagraph>
                            </Col>
                            
                        </EachItemContainer>
                    )
                })
            }

        </OurPropertiesContainer>
     );
}
 
export default OurProperties;