import Col from "@/Shared/Kit/Col";
import Row from "@/Shared/Kit/Row";
import styled from "styled-components";
import banner_img from "../../../../public/Images/MainPage/banner.png";

export const MainContainer = styled(Col)`

    position: relative;
  .suggestedToursBtn {
    border-radius: 8px;
    &:hover {
    };
    div {
      color: ${(props) => props.theme.black} !important;
    };
    svg {
      fill: ${(props) => props.theme.black} !important;
      rotate: 90deg;
    };
  };
`;

interface ContentContainerProps {
  mode?: "tour" | "hotel" | "normal"
  backgroundImageUrl?: string;
}
export const ContentContainer = styled(Col)<ContentContainerProps>`
  gap: 35px;
  align-items: flex-start;
  padding: ${props => props.mode === "tour" ? "36px 100px 100px 100px" : "76px 100px 100px 100px"};
    //background-color: ${props => props.theme.secondary100};
  background: linear-gradient(to left, rgba(0, 0, 0, 0.82), rgba(255, 255, 255, 0)),
  url(${props => props.backgroundImageUrl ?? "/Images/MainPage/banner.webp"});
  background-size: cover;
  background-position: bottom;
  border-radius: 0 0 30px 30px;

  h1 {
    font-weight: bolder;
    font-weight: 900;
    color: white;
    font-size: ${props => props.mode === "tour" ? "28px" : "28px"};
  }
;

  h2 {
    font-weight: 400;
    color: white;
    font-size: 24px;
  }
;

  @media (max-width: ${props => props.theme.xs}) {
    padding: ${props => props.mode === "tour" ? "36px 10px 100px 10px" :props.mode === "hotel" ? "76px 10px 100px 10px":"76px 10px 50px 10px"};
    background: linear-gradient(to top, rgba(0, 0, 0, 0.82), rgba(255, 255, 255, 0)),
    url(${props => props.backgroundImageUrl ?? "/Images/MainPage/banner.webp"});
    background-size: cover;
    background-position: bottom;
    border-radius: 0 0 0 0;
    

    h1 {
      font-weight: 900;
      color: white;
      font-size: ${props => props.mode === "tour" ? "28px" : "28px"};
      align-self: center;
    }
    h2 {
      font-weight: 400;
      color: white;
      font-size: 20px;
      align-self: center;
    }
  ;
  }
`;
