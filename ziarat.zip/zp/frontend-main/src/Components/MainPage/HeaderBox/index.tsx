import React, { useState } from "react";
import { ContentContainer, MainContainer } from "./styles";
import { XLargeHeading, XXLargeHeading } from "@/Shared/Kit/Typography/Heading";
import SearchBox from "@/Components/SearchBox";
interface Props {
  showTab?: boolean;
  title?: string;
  description?: string;
  showContent?: boolean;
  mode?: "tour" | "hotel";
  havePosition?: boolean;
  cancelHandler?: (...args: any) => void;
  hotelDefaultCity?: 1 | 2 | 3;
  tourDefaultCity?: boolean;
}
const HeaderBox: React.FC<Props> = (props) => {
  const {
    tourDefaultCity = false,
    mode = "tour",
    hotelDefaultCity,
    cancelHandler,
    havePosition = true,
    showTab = false,
    description,
    showContent = false,
    title,
  } = props;

  const tabConfig = [
    {
      id: 1,
      title: {
        fa: "تور",
        en: "tour",
      },
      disabled: false,
      src: "/",
    },
    {
      id: 2,
      title: {
        fa: "هتل",
        en: "hotel",
      },
      disabled: false,
      src: "/hotel",
    },
  ];

  const [selectedTab, setSelectedTab] = useState<"tour" | "hotel">(mode);

  const onChangeTab = (tabItem: any) => {
    setSelectedTab(tabItem?.title.en);
  };

  return (
    <MainContainer>
      {showContent && (
        <ContentContainer mode={mode}>
          {title && <XXLargeHeading>{title}</XXLargeHeading>}
          {description && <XLargeHeading>{description}</XLargeHeading>}
        </ContentContainer>
      )}

      <SearchBox
        showTabs={showTab}
        onChangeTab={onChangeTab}
        selectedTab={selectedTab}
        tabItemConfig={tabConfig}
        mode={mode}
        withLink={true}
        havePosition={havePosition}
        cancelHandler={cancelHandler}
        hotelDefaultCity={hotelDefaultCity}
        tourDefaultCity={tourDefaultCity}
      />
    </MainContainer>
  );
};

export default HeaderBox;
