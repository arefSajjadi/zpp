import Row from "@/Shared/Kit/Row";
import styled from "styled-components";


export const Section2Container = styled(Row)`
height: 250px;
        .swiper {
        width: 100% !important;
        height: 100%;
        display: flex;
        overflow: hidden;
    }
    .swiper-wrapper {
        width: 100% !important;
        transition-timing-function: linear !important;
        display: flex;
   height: 100%;
    }
    .swiper-slide {
       
        position: relative;
    }

    .swiperWithArrowWrapper {
        flex-wrap: nowrap;
        position: relative;
        background-color: ${props => props.theme.white};
        border-radius: 20px;
        border: 1px solid ${props => props.theme.gray600};
        .pervBtn {
        height: 30px;
        background-color: ${props => props.theme.white};

        border-radius: 0px 14px 14px 0px;
        height: auto;
    }
    .nextBtn {
        height: 30px;
        background-color: ${props => props.theme.white};
        border-radius: 14px 0 0 14px;
        /* border: 1px solid ${props => props.theme.gray600}; */
        height: auto;
        svg {
            rotate: 180deg;
        }
    }
    }
`