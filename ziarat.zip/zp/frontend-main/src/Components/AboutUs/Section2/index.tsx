import { Swiper, SwiperSlide } from "swiper/react";
import { Section2Container } from "./styles";
import { Autoplay } from "swiper/modules";
import Image from "next/image";

const Section2 = () => {

    const list = [
        {
            id: 1,
            src: '/Images/AboutUs/firstImage.svg'
        },
        {
            id: 2,
            src: '/Images/AboutUs/firstImage.svg'
        },
        {
            id: 3,
            src: '/Images/AboutUs/firstImage.svg'
        },
        {
            id: 4,
            src: '/Images/AboutUs/firstImage.svg'
        },

    ]
    return ( 
        <Section2Container>
        <Swiper
            spaceBetween={20}
            slidesPerView={4}

            loop={true}
            autoplay={{
              delay: 0,
              // disableOnInteraction: false,
            }}
            speed={10000}
            modules={[Autoplay]}
          >
            {list.map((each, index) => {
              return (
                <SwiperSlide key={each?.id}>
                    <Image 
                        src={each.src}
                        alt="image"
                        fill
                    />
                </SwiperSlide>
              );
            })}
          </Swiper>
        </Section2Container>
     );
}
 
export default Section2;