import Image from "next/image";
import { ContentContainer, ImageContainer, Section3Container } from "./styles";
import { LargeHeading, XLargeHeading, XXLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { XSmallParagraph } from "@/Shared/Kit/Typography/Paragraph";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";

const Section3 = () => {
    const theme = useSelector(selectTheme)
    return ( 
        <Section3Container>
            <ContentContainer xl={9}>
                <XLargeHeading color={theme.primary300}>
                ارائه دهنده ی تورهای زیارتی عتبات عالیات
                </XLargeHeading>
                <XSmallParagraph color={theme.gray600}>
                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است، و برای شرایط فعلی تکنولوژی مورد نیاز، و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد، کتابهای زیادی در شصت و سه درصد گذشته حال و آینده، شناخت فراوان جامعه و متخصصان را می طلبد، تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص طراحان خلاقی، و فرهنگ پیشرو در زبان فارسی ایجاد کرد، در این صورت می توان امید داشت که تمام و دشواری موجود در ارائه راهکارها، و شرایط سخت تایپ به پایان رسد و زمان مورد نیاز شامل حروفچینی دستاوردهای اصلی، و جوابگوی سوالات پیوسته اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد.لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است، و برای شرایط فعلی تکنولوژی مورد نیاز، و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد، کتابهای زیادی در شصت و سه درصد گذشته حال و آینده، شناخت فراوان جامعه و متخصصان را می طلبد، تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای 
                </XSmallParagraph>
            </ContentContainer>
            <ImageContainer xl={12}>
                <Image 
                    alt="image"
                    src={"/Images/AboutUs/firstImage.svg"}
                    fill
                />
            </ImageContainer>
        </Section3Container>
     );
}
 
export default Section3;