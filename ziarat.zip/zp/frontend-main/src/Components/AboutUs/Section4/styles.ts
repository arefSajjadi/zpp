import Col from "@/Shared/Kit/Col";
import Row from "@/Shared/Kit/Row";
import styled from "styled-components";


export const Section4Container = styled(Row)`
    gap: 80px;
    padding: 0 200px;
    justify-content: center;

`

export const ImageContainer = styled(Row)`
    position:relative;
    height: 363px;
`

export const ContentContainer = styled(Col)`
    gap: 100px;
    align-items: flex-start;
    p {
        text-align: justify;
    }
`