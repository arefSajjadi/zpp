import Image from "next/image";
import { ContentContainer, ImageContainer, Section6Container } from "./styles";
import { LargeHeading, XLargeHeading, XXLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { LargeParagraph, XSmallParagraph } from "@/Shared/Kit/Typography/Paragraph";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import { SmallLabel } from "@/Shared/Kit/Typography/Label";
import Col from "@/Shared/Kit/Col";

const Section6 = () => {
    const theme = useSelector(selectTheme)
    return ( 
        <Section6Container>

            <ImageContainer xl={4}>
                <Image 
                    alt="image"
                    src={"/Images/AboutUs/firstImage.svg"}
                    fill
                />
            </ImageContainer>
            <ContentContainer xl={18}>
                <Col className="titleContainer">
                <XLargeHeading color={theme.primary300}>
                مدیر اجرایی
                </XLargeHeading>
                <LargeParagraph color={theme.primary300}>
                    محمد سوری
                </LargeParagraph>
                </Col>
                <XSmallParagraph color={theme.gray600}>
                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است، و برای شرایط فعلی تکنولوژی مورد نیاز، و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد، کتابهای زیادی در شصت و سه درصد گذشته حال و آینده، شناخت فراوان جامعه و متخصصان را می طلبد، تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص طراحان خلاقی، و فرهنگ پیشرو در زبان فارسی ایجاد کرد، در این صورت می توان امید داشت که تمام و دشواری موجود در ارائه راهکارها، و شرایط سخت تایپ به پایان رسد و زمان مورد نیاز شامل حروفچینی دستاوردهای اصلی، و جوابگوی سوالات پیوسته اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد.لورم ایپسوم متن ساختگی با تولید
                </XSmallParagraph>
            </ContentContainer>
        </Section6Container>
     );
}
 
export default Section6;