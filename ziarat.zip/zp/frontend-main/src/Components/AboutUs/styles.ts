import Col from "@/Shared/Kit/Col";
import styled from "styled-components";


export const MainContainer = styled(Col)`
    gap: 150px;
    margin-top: 50px;

 
`


export const MainWrapper = styled(Col)`

    .breadcrumb {
        margin-top: 50px;
        padding: 0 200px;
    }
`