

import React from 'react';
import { Section1Container } from './styles';
import { LargeHeading, XXLargeHeading } from '@/Shared/Kit/Typography/Heading';
import { useSelector } from 'react-redux';
import { selectTheme } from '@/Redux/App/Selectors';
import { XSmallParagraph } from '@/Shared/Kit/Typography/Paragraph';

const Section1 = () => {
    const theme = useSelector(selectTheme)
    return ( 
        <Section1Container>
            <XXLargeHeading className="title" color={theme.primary300}>
            <span> درباره </span> رسم زیارت
            </XXLargeHeading>
            <XSmallParagraph color={theme.gray600}>
            لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است، و برای شرایط 
            </XSmallParagraph>
        </Section1Container>
     );
}
 
export default Section1;
