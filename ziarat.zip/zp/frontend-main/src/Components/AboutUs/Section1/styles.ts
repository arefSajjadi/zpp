import Col from "@/Shared/Kit/Col";
import styled from "styled-components";

export const Section1Container = styled(Col)`
  padding: 0 200px;
  gap: 30px;
  .title {
    span {
      opacity: 0.8;
    }
  }

  p {
      max-width: 430px;
      text-align: center;
      }
`;
