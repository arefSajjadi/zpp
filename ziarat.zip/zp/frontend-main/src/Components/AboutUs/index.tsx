import React from 'react';
import { MainContainer, MainWrapper } from './styles';
import Section1 from './Section1';
import Section2 from './Section2';
import Section3 from './Section3';
import Section4 from './Section4';
import Section5 from './Section5';
import Section6 from './Section6';
import Breadcrumb from '../Breadcrumb/Breadcrumb';
import Row from '@/Shared/Kit/Row';
import useIsMobile from "@/Utils/Responsive";

const AboutUs = () => {
    const responsive = useIsMobile()
    const BreadcrumbList = [
        {
          src:`/about-us`,
          name:`درباره ما`
        },
      ]
    return ( 
        <MainWrapper>
            <Row xl={22} className='breadcrumb'>
                {responsive !== "mobile" && <Breadcrumb BreadcrumbList={BreadcrumbList} />}
            </Row>
        <MainContainer>
            <Section1 />
            <Section2 />
            <Section3 />
            <Section4 />
            <Section5 />
            <Section6 />
        </MainContainer>
        </MainWrapper>
     );
}
 
export default AboutUs;
