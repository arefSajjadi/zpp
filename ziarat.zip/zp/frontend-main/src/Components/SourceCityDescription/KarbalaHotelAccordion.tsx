import React from "react";
import { AccordionWrapper } from "./styles";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import ToggleTab from "@/Shared/Kit/ToggleTab";

const KarbalaHotelAccordion = () => {
  const theme = useSelector(selectTheme);

  const toggleItems = [
    {
      id: 1,
      title: "هتل های کربلا برای ایرانیان کدام است؟",
      description: `تنوع هتل‌ها در کربلا بسیار زیاد است و اکثر این هتل‌ها برای اسکان زائران ایرانی مناسب هستند. هتل الاماره، هتل کورال، هتل الماس، هتل الریان و هتل برج‌الاماره ازجمله هتل های کربلا برای ایرانیان هستند.`,
    },
    {
      id: 2,
      title: "قیمت هتل در کربلا چقدر است؟",
      description: `بسته به درجه کیفی هتل، قیمت هتل‌ها تعیین می‌شود. البته در شرایط پیک تردد، قیمت هر شب هتل در کربلا متفاوت خواهد بود. از این رو، برای اطلاع از نرخ روز قیمت هتل در کربلا نزدیک حرم، یا کارشناسان رسم زیارت، تماس بگیرید.`,
    },
    {
      id: 3,
      title: "برای رزرو هتل چه مدارکی لازم است؟",
      description: `شما با ارائه تصویر پاسپورت خود و همراهانتان به کارشناسان رسم زیارت، می‌توانید مراحل رزرو هتل کربلا را تکمیل کنید.`,
    },
    {
      id: 4,
      title: "هتل های ارزان کربلا نزدیک حرم کدامند؟",
      description: `هتل‌های خیام، جبل‌الصفا، دارالبیضا، الماس شرق و یعسوب‌الدین از جمله هتل ‌های ارزان کربلا نزدیک حرم هستند که فاصله آن‌ها تا صحن مطهر کمتر از ۱۰ دقیقه است.`,
    },
    {
      id: 5,
      title: "مزایای رزرو هتل کربلا از رسم زیارت چیست؟",
      description: `رسم زیارت با ارائه فهرست کامل هتل‌های کربلا، شرایطی فراهم کرده است تا زائران بتوانند با مقایسه قیمت، بررسی امکانات و انتخاب درجه هتل، مناسب‌ترین گزینه را رزرو کنند.`,
    },
  ];
  return (
    <AccordionWrapper>
      {toggleItems.map((item) => (
        <ToggleTab key={item.id} item={item} name={`name${item.id}`} />
      ))}
    </AccordionWrapper>
  );
};

export default KarbalaHotelAccordion;
