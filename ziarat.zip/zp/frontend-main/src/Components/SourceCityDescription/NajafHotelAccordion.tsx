import React from "react";
import { AccordionWrapper } from "./styles";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import ToggleTab from "@/Shared/Kit/ToggleTab";

const NajafHotelAccordion = () => {
  const theme = useSelector(selectTheme);

  const toggleItems = [
    {
      id: 1,
      title: "هتل های ارزان نجف نزدیک حرم کدامند؟",
      description: `از جمله هتل ‌های ارزان نجف نزدیک حرم می‌توان به هتل الاخضر، هتل قائم و هتل خان الذهب اشاره کرد که همگی فاصله‌ای کمتر از ۱۰ دقیقه تا حرم دارند.`,
    },
    {
      id: 2,
      title: "مزایای رزرو هتل نجف از رسم زیارت چیست؟",
      description: `با رسم زیارت می‌توانید هتل دلخواه خود را به‌صورت آنلاین رزرو کرده، قیمت‌ها را مقایسه کنید و از پشتیبانی کارشناسان در تمام مراحل سفر بهره‌مند شوید.`,
    },
    {
      id: 3,
      title: "بهترین زمان برای رزرو هتل در نجف چه زمانی است؟",
      description: `فصل‌های کم‌مسافر مانند پاییز و زمستان بهترین زمان رزرو هتل در نجف به شمار می‌روند که نرخ اقامت پایین‌تر و ظرفیت خالی هتل‌ها بیشتر است.`,
    },
  ];
  return (
    <AccordionWrapper>
      {toggleItems.map((item) => (
        <ToggleTab key={item.id} item={item} name={`name${item.id}`} />
      ))}
    </AccordionWrapper>
  );
};

export default NajafHotelAccordion;
