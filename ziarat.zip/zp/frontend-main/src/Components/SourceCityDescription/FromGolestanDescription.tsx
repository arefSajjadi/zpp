import { Blur, DescriptionContainer } from "./styles";
import Head from "next/head";
import { useState } from "react";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import { LargeHeading, XLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";

const FromGolestanDescription = () => {
  const [showAll, setShowAll] = useState(false);
  return (
    <>
      {/* <Head>
        <title>تور کربلا از گلستان | زمینی - رسم زیارت</title>
        <meta
          name="description"
          content="تور کربلا از گلستان ⚡ زیارت کربلا، نجف، کاظمین و سامرا ❗ اقامت هتل همراه با صبحانه، نهار، شام | زیر نظر سازمان حج و زیارت"
        />
        <link
          rel="canonical"
          href="https://ziarat.co/tours/karbala/from-golestan"
        />
        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
        <meta name="enamad" content="850460"/>
      </Head> */}

      <DescriptionContainer showAll={showAll}>
        <XLargeHeading>راهنمای تور کربلا از گلستان</XLargeHeading>
        <SmallParagraph>
          استان گلستان از استان هایی شمالی ایران می باشد که تاریخچه غنی و با
          قدمتی دارد. مرکز استان گلستان، گرگان بوده و جمعیت بیشتری از مردم را از
          آن خود کرده است. مردم استان گلستان، مردمی بسیار مهربان، مهمان نواز و
          معتقد هستند؛ که هرسال به سفرهای زیارتی از جمله تور کربلا از گلستان می
          پردازند. در ادامه این مطلب به شرایط و اطلاعات تور کربلا از گلستان، از
          جمله: تورهای هوایی کربلا از گلستان هوایی، تورهای کربلا از گلستان
          زمینی، قیمت تور کربلا ازگلستان زمینی و هوایی، تور اقساطی کربلا از
          گلستان، ایرلاین های تور کربلا از گلستان و … خواهیم پرداخت.
        </SmallParagraph>
        <XLargeHeading>
          تور کربلا از گلستان، از چه مرزهایی امکان پذیر است؟
        </XLargeHeading>
        <SmallParagraph>
          تور کربلا از گلستان زمینی، از مرز مهران اجرا می شود. شما با اتوبوس تور
          به سمت شهرستان مهران حرکت می کنید و پس از عبور از مرز، وارد عراق می
          شوید.
        </SmallParagraph>
        <XLargeHeading>تور کربلا از گلستان چند روزه است؟</XLargeHeading>
        <SmallParagraph>
          در حال حاضر تمامی تورهای کربلا از گلستان به صورت ۷ شب و ۸ روزه انجام
          می شوند.
        </SmallParagraph>
        <XLargeHeading>
          با رزرو تور کربلا از گلستان در چه شهرهایی اقامت می کنیم؟
        </XLargeHeading>
        <SmallParagraph>
          شما با رزرو تور ۷ شب و ۸ روزه کربلا از گلستان، ۳ شب در شهر نجف اشرف، ۳
          شب در کربلا معلی، ۱ شب در کاظمین و به صورت عبوری در سامرا اقامت خواهید
          کرد.
        </SmallParagraph>
        <XLargeHeading>قیمت تور کربلا از گلستان زمینی</XLargeHeading>
        <SmallParagraph>
          شروع قیمت کربلا از گلستان زمینی در سامانه زیارت، از ۶/۵۰۰/۰۰۰ تومان می
          باشد؛ که در پکیج اقتصادی تور کربلا از گلستان قرار دارد.
        </SmallParagraph>
        <XLargeHeading>قیمت تورکربلا از گلستان هوایی</XLargeHeading>
        <SmallParagraph>
          در حال حاضر تور کربلا از گلستان هوایی در سایت ها موجود نیست؛ اما شما
          می توانید برای اطلاع از به روز رسانی موجودی تورهای کربلا از گلستان
          هوایی، با کارشناسان سفر سامانه زیارت، تماس حاصل فرمایید.
        </SmallParagraph>
        <XLargeHeading>قیمت تور کربلا از گلستان برای کودکان</XLargeHeading>
        <SmallParagraph>
          قیمت تور کربلا از گلستان برای ۲ تا ۱۲ سال: نرخ این نوع تور برای
          خردسالان ۲ تا ۱۲ سال، تنها ۸۰ درصد نرخ تور بزرگسالان و افراد عادی است.
        </SmallParagraph>
        <SmallParagraph>
          قیمت تور کربلا از گلستان زمینی برای کودک زیر ۲ سال: نرخ این تور برای
          آنان به صورت رایگان می باشد.
        </SmallParagraph>
        <SmallParagraph>
          قیمت تور کربلا از گلستان هوایی برای کودکان زیر ۲ سال: نرخ تور هوایی
          زیر ۲ سال برای آنان، تنها ۱۰ درصد از نرخ تور افراد عادی و بزرگسال است.
        </SmallParagraph>
        <XLargeHeading>تور اقساطی کربلا از گلستان</XLargeHeading>
        <SmallParagraph>
          تورهای اقساطی کربلا در بعضی زمان موجود می شوند؛ بنابراین اگر می خواهید
          به صورت اقساطی به کربلا سفر کنید، با ما تماس بگیرید، تا شما را از
          موجودی این نوع تورها مطلع نماییم.
        </SmallParagraph>
        <XLargeHeading>تور اقساطی کربلا از گلستان</XLargeHeading>
        <LargeHeading>بهترین هتل های نجف در تور کربلا از گلستان</LargeHeading>
        <SmallParagraph>
          هتل مدینه العطا نجف، هتل قصر العرب نجف و هتل ورده النجف.
        </SmallParagraph>
        <LargeHeading>
          بهترین هتل های کربلا در تور کربلا از گلستان زمینی و هوایی
        </LargeHeading>
        <SmallParagraph>
          هتل جابر کربلا، هتل جواهر کربلا و هتل ریحانه کربلا.
        </SmallParagraph>
        <LargeHeading>
          بهترین هتل های کاظمین در تور کربلا از گلستان هوایی و زمینی
        </LargeHeading>
        <SmallParagraph>
          هتل سراج المنیر کاظمین، هتل قصر الکاظمیه کاظمین و هتل قرطاج (جنه
          الباقر) کاظمین.
        </SmallParagraph>
        <XLargeHeading>رزرو تور کربلا از گلستان با سامانه زیارت</XLargeHeading>
        <SmallParagraph>
          سامانه زیارت با چندین سال سابقه در زمینه فروش تورهای عتبات عالیات می
          تواند بهترین و ارزان ترین تور کربلا از گلستان را با شرایط مورد نظر و
          درخواستی شما رزرو و تقدیم شما نماید. برای رزرو تور کربلا از گلستان، با
          کارشناسان ما تماس بگیرید.
        </SmallParagraph>

        {!showAll && <Blur />}

        <GhostButton
          title={showAll ? "بستن" : "مشاهده بیشتر"}
          size="sm"
          color="gray"
          icon={ArrowDownIcon}
          width="180px"
          iconPosition="left"
          onClick={() => {
            setShowAll((perv) => !perv);
          }}
          className="moreBtn"
        />
      </DescriptionContainer>
    </>
  );
};

export default FromGolestanDescription;
