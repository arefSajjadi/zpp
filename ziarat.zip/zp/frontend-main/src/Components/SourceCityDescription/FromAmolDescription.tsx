import { Blur, DescriptionContainer } from "./styles";
import Head from "next/head";
import { useState } from "react";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";
import { LargeHeading, XLargeHeading } from "@/Shared/Kit/Typography/Heading";

const FromAmolDescription = () => {

  const [showAll ,setShowAll] = useState(false)
  return (
    <>
    {/* <Head>
      <title>تور کربلا از آمل | زمینی -رسم زیارت</title>
      <meta name="description" content="تور کربلا از آمل ⚡ زیارت کربلا،نجف،کاظمین و سامرا | ترانسفر +بیمه مسافرتی +زیارت دوره +مدیر و مداح | پشتیبانی 24 ساعته" />
      <link rel="canonical" href="https://ziarat.co/tours/karbala/from-amol"/>
      <meta name="google-site-verification" content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk" />
      <meta name="enamad" content="850460"/>
    </Head> */}
   
    <DescriptionContainer showAll={showAll}>
      <XLargeHeading>
         
         راهنمای تور کربلا از آمل
         </XLargeHeading>
         <SmallParagraph>
           شهر آمل بعد از تهران، دومین شهری است که بیشترین سفر با تور کربلا را
           دارد؛ زیرا مردم این شهر بسیار معتقد و مذهبی هستند و ارادت خاصی به امام
           حسین (ع) دارند. در ادامه این مطلب از سامانه زیارت عضو سازمان حج و زیارت،
           به شرایط و چگونگی تور کربلا از آمل اعم از : تور کربلا هوایی از آمل، تور
           کربلا زمینی از آمل، قیمت تور کربلا زمینی و هوایی از آمل، هتل های تور
           کربلا از آمل، ایرلاین های تور کربلا از آمل هواییمی پردازیم؛ تا آملی های
           عزیز سفری رضایت بخش و آگاهانه به کشور عراق داشته باشند.
         </SmallParagraph>
         <XLargeHeading>
           تور کربلا از آمل، از طریق چه مرزهایی انجام می پذیرد؟
         </XLargeHeading>
         <SmallParagraph>
           تور زمینی کربلا از آمل، از طریق مرز مهران انجام می شود؛ به طوری که شما
           به استفاده از اتوبوس ۵۰ یا ۲۵ نفره وی آی پی تور، همراه با هم گروهی ها و
           مدیر کاروان به سمت مرز حرکت می کنید و پس از تایید گذرنامه، وارد کشور
           عراق می شوید.
         </SmallParagraph>
         <XLargeHeading>تور کربلا از آمل چند روزه است؟</XLargeHeading>
         <SmallParagraph>
           در حال حاضر تورهای کربلا از آمل به صورت ۷ شب و ۸ روزه می باشند.
         </SmallParagraph>
         <XLargeHeading>
           با رزرو تور کربلا از آمل در چه شهرهایی اقامت داریم؟
         </XLargeHeading>
         <SmallParagraph>
           پاسخ این سوال به مدت زمان تور کربلا از آمل شما بستگی دارد. در تور ۷ شب و
           ۸ روزه آمل به کربلا، شما ۳ شب در نجف، ۴ شب در کربلا و به صورت عبوری نیز
           در کاظمین و سامرا اقامت خواهید کرد. قابل ذکر است که این تورها ممکن است
           یک روز جا به جایی داشته باشند.
         </SmallParagraph>
         <XLargeHeading>
           با تور کربلا از آمل از چه مکان هایی بازدید می کنیم؟
         </XLargeHeading>
         <SmallParagraph>
           در تور کربلا از آمل هوایی و زمینی سامانه زیارت، شما از آرامگاه ملکوتی
           امیرالمومنین (ع)، مسجد کوفه، قبرستان وادی السلام، مسجد سهله، مسجد حنانه،
           کاظمین، حرم امام کاظم (ع)، سامرا، آرامگاه طفلان مسلم، تل زینبیه، خیمه
           گاه اهل بیت (ع)، موزه امام حسین (ع)، موزه حضرت عباس (ع)، حرم امام حسین و
           حضرت عباس (ع)، ارامگاه سید محمد، قبر مختار ثقفی بازدید خواهید کرد.
         </SmallParagraph>
         <XLargeHeading>قیمت تور کربلا از آمل زمینی</XLargeHeading>
         <SmallParagraph>
           شروع قیمت تور کربلا از آمل زمینی در سامانه زیارت عضو سازمان حج و زیارت،
           از ۶/۷۶۰/۰۰۰ تومان می باشد. برای رزرو تور کربلا ارزان از آمل، با
           کارشناسان سامانه زیارت تماس حاصل فرمایید.
         </SmallParagraph>
   
         <XLargeHeading>
           قیمت تور کربلا از آمل برای کودکان و خردسالان
         </XLargeHeading>
         <SmallParagraph>
           قیمت تور کربلا از آمل برای خردسالان ۲ تا ۱۲ سال: شامل ۸۰ درصد نرخ
           بزرگسالان می شود.
         </SmallParagraph>
         <SmallParagraph>
           قیمت تور کربلا از آمل زمینی برای کودک زیر ۲ سال: فقط شامل پرداخت هزینه
           بیمه می شود.
         </SmallParagraph>
         <SmallParagraph>
           قیمت تور کربلا از آمل هوایی برای کودک زیر ۲ سال: تنها شامل ۱۰ درصد از
           نرخ بزرگسالان می باشد.
         </SmallParagraph>
         <XLargeHeading>
           هتل های کربلا و هتل های نجف در تور کربلا از آمل
         </XLargeHeading>
         <LargeHeading> بهترین هتل های نجف تور کربلا از آمل </LargeHeading>
         <SmallParagraph>
            هتل خیام نجف، هتل مباهله
           نجف و هتل نسیم الفرات نجف.
         </SmallParagraph>
         <LargeHeading> بهترین هتل های کربلا تور کربلا از آمل </LargeHeading>
         <SmallParagraph>
           هتل کربلا الدولی،
           هتل خیام کربلا و هتل ریحانه کربلا.
         </SmallParagraph>
         <XLargeHeading>
           رزرو تور کربلا از آمل ارزان با رسم زیارت
         </XLargeHeading>
         <SmallParagraph>
           سامانه زیارت بهترین و ارزان ترین تورهای کربلا از آمل را به مسافران و
           زائران تقدیم می کند.
         </SmallParagraph>
         <SmallParagraph>
           برای رزرو تور کربلا از آمل و اطلاعات بیشتر از این تور، با کارشناسان سفر
           تماس بگیرید.
         </SmallParagraph>

{
    !showAll &&
      <Blur />
}

      <GhostButton 
        title={ showAll ? "بستن" : "مشاهده بیشتر"}
        size="sm"
        color="gray"
        icon={ArrowDownIcon}
        width="180px"
        iconPosition="left"
        onClick={() => {setShowAll(perv => !perv)}}
        className="moreBtn"
      />
    </DescriptionContainer>
    </>
  );
};

export default FromAmolDescription;
