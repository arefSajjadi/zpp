import React from "react";
import { AccordionWrapper } from "./styles";
import ToggleTab from "@/Shared/Kit/ToggleTab";

const KadhimiyaHotelAccordion = () => {
  const toggleItems = [
    {
      id: 1,
      title: "هتل های ارزان کاظمین نزدیک حرم کدامند؟",
      description: `هتل برج الضامن، هتل قلعه الکاظمیه و هتل سراج المنیر از هتل‌ های ارزان کاظمین نزدیک حرم هستند که در فاصله کمتر از ۵ دقیقه تا صحن مطهر قرار دارند.`,
    },
    {
      id: 2,
      title: "مزایای رزرو هتل کاظمین از رسم زیارت چیست؟",

      description: `رسم زیارت با ارائه اطلاعات دقیق از موقعیت و خدمات هتل‌ها، امکان رزرو متنوع‌ترین هتل‌ های کاظمین را با پشتیبانی ۲۴ ساعته برای زائران فراهم کرده است.`,
    },
    {
      id: 3,
      title: "قیمت هتل در کاظمین چقدر است؟",
      description: `با توجه به زمان سفر، نوع هتل و همچنین مدت زمان اقامت در کاظمین قیمت هتل‌ها متغیر است.`,
    },
  ];
  return (
    <AccordionWrapper>
      {toggleItems.map((item) => (
        <ToggleTab key={item.id} item={item} name={`name${item.id}`} />
      ))}
    </AccordionWrapper>
  );
};

export default KadhimiyaHotelAccordion;
