import { Blur, DescriptionContainer, UlContainer } from "./styles";
import Head from "next/head";
import { useState } from "react";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import { LargeHeading, XLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";
import FromKarajAccordion from "./FromKarajAccordion";

const FromKarajDescription = () => {
  const [showAll, setShowAll] = useState(false);
  return (
    <>
      {/* <Head>
        <title>تور کربلا از کرج | هوایی و زمینی - رسم زیارت</title>
        <meta
          name="description"
          content="تور کربلا از کرج⚡اقامت 7شب | حرکت همه روزه | تضمین بهترین قیمت ❗ اقامت هتل درجه الف نزدیک حرم | پشتیبانی 24 ساعته"
        />
        <link
          rel="canonical"
          href="https://ziarat.co/tours/karbala/from-karaj"
        />
        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
        <meta name="enamad" content="850460"/>
      </Head> */}

      <DescriptionContainer showAll={showAll}>
        <XLargeHeading>
          در تور زمینی کرج از کدام مرزها عبور می‌کنیم؟
        </XLargeHeading>
        <SmallParagraph>
          کاروان‌های شهر کرج معمولاً مرز مهران را برای عبور انتخاب می‌کنند.
        </SmallParagraph>
        <XLargeHeading>قیمت تور زمینی کربلا از کرج چقدر ‌است؟</XLargeHeading>
        <SmallParagraph>
          هزینه سفر بستگی به شاخص‌های مختلفی نظیر تعداد روز اقامت، درجه کیفی
          هتل‌های اسکان و وسیله نقلیه اعزامی دارد. عمده کاروان‌های حج و زیارت، ۷
          شبی هستند؛ اما با توجه به درخواست زائران برای کمتر شدن هزینه اسکان و
          زمان سفر، تعداد روزهای سفر با تور کربلا زمینی از کرج متنوع شده است؛
          یعنی گزینه‌های سفر به‌صورت ۷ شب اقامت تا بدون اقامت با زیارت عبوری، در
          اختیار مسافران قرار گرفته است تا کسانی که زمان و هزینه محدود‌تری دارند
          هم، بتوانند بدون نگرانی، به عتبات عالیات مشرف شوند. ازطرفی دیگر هتل‌
          محل اقامت زائران تأثیر مهمی در تعیین قیمت کاروان کربلا از کرج دارد. با
          فرض اسکان در هتل‌های ۳ ستاره و درجه متوسط، قیمت تور زمینی کربلا از کرج
          با اتوبوس vip به شرح زیر است:
        </SmallParagraph>
        <UlContainer>
          <li> بدون اقامت و عبوری: بین ۴ تا ۵ میلیون تومان</li>
          <li> ۳ و ۴ شب اقامت: بین ۹ تا 10 میلیون تومان</li>
          <li> ۵ شب اقامت: بین ۱۱ تا 12 میلیون تومان</li>
          <li> ۶ و ۷ شب اقامت: بین ۱۳ تا 15 میلیون تومان</li>
        </UlContainer>
        <XLargeHeading>قیمت تور کربلا هوایی از کرج چقدر است؟</XLargeHeading>
        <SmallParagraph>
          معمولاً در تور کربلا کرج هوایی، زائران را از فرودگاه امام خمینی‌(ره)
          به عراق اعزام می‌کنند. البته ممکن است در برخی اوقات سال، فرودگاه پیام
          نیز، میزبان مسافران کاروان زیارتی کربلا در کرج باشد.
        </SmallParagraph>
        <SmallParagraph>
          هزینه سفر با تور هوایی کربلا از کرج، از ۲۶ میلیون تومان آغاز می‌شود.
          این هزینه برای کاروان‌هایی است که در هتل‌های سطح کیفی متوسط و ۳ ستاره
          اسکان دارند و به‌صورت ۷ شب برگزار می‌شوند.
        </SmallParagraph>
        <XLargeHeading>
          هزینه تور کربلا از کرج برای کودکان و خردسالان چقدر است‌؟
        </XLargeHeading>
        <SmallParagraph>
          هزینه کاروان‌های کربلا برای کودکان زیر ۱۲ سال، شامل تخفیف می‌شود؛
          به‌طوری‌که هزینه زائران بین ۲ تا ۱۲ سال در سفرهای زمینی و هوایی حدود ۱
          میلیون تومان کمتر از قیمت اصلی تور است. برای زائران نوزاد زیر ۲ سال
          نیز، قیمت کاروان، تنها شامل هزینه بیمه می‌شود که هزینه آن بین
          1/500/000 تا 2/000/000 می شود.
        </SmallParagraph>
        <XLargeHeading>
          برنامه تور زیارتی کربلا از کرج به چه صورت است؟
        </XLargeHeading>
        <SmallParagraph>
          برنامه زیارتی کاروان کربلا از کرج، بستگی به تعداد روزهای اقامت در
          کربلا دارد. کاروان‌هایی که به‌صورت ۷ یا ۶ شب برگزار می‌شوند، معمولاً ۳
          شب در نجف و ۳ شب در کربلا اسکان دارند؛ در کاروان‌های ۷شبی، یک شب در
          کاظمین هم اقامت خواهند داشت. از آن طرف در کاروان‌های ۶ شبی، نیمی از یک
          شبانه‌روز به زیارت دوره حرم کاظمین، حرم عسکریین و امامزاده سیدمحمد
          اختصاص پیدا می‌کند.
        </SmallParagraph>
        <XLargeHeading>
          کیفیت هتل‌های کاروان زیارتی کربلا از کرج چگونه است‌؟
        </XLargeHeading>
        <SmallParagraph>
          معمولاً هتل‌های ۲ تا ۴ ستاره برای اسکان زائران در تور زیارتی کربلا از
          کرج، رزرو می‌شود. هتل‌هایی نظیر خیام نجف، بیان نجف، جابر کربلا،
          ابراج‌الشرق کربلا و ابراج کربلا.
        </SmallParagraph>

        <XLargeHeading>نحوه رزرو تور کربلا از کرج</XLargeHeading>
        <SmallParagraph>
          ثبت نام کاروان کربلا از کرج، در رسم زیارت آسان شده است. کافی است
          براساس امکانات و تاریخ دلخواهتان برای سفر، یک گزینه را انتخاب کنید.
          سپس با وارد کردن تلفن همراه و اطلاعات نام و تاریخ تولد مسافران،
          اطلاعات ثبت‌نامتان را تکمیل کنید. سپس با پرداخت آنلاین هزینه تور، در
          کاروان مدنظرتان ثبت‌نام کنید.
        </SmallParagraph>

        <SmallParagraph>
          همچنین خبر خوش اینکه شرایط پرداخت اقساطی هزینه کاروان، در رسم زیارت
          فراهم شده است؛ با توجه به تغییرات این شرایط در طول سال، می‌توانید جهت
          اطلاع از جزئیات برگزاری تور کربلا اقساطی کرج با کارشناسان رسم زیارت
          تماس بگیرید.
        </SmallParagraph>

        <FromKarajAccordion />

        {!showAll && <Blur />}
        <GhostButton
          title={showAll ? "بستن" : "مشاهده بیشتر"}
          size="sm"
          color="gray"
          icon={ArrowDownIcon}
          width="180px"
          iconPosition="left"
          onClick={() => {
            setShowAll((perv) => !perv);
          }}
          className="moreBtn"
        />
      </DescriptionContainer>
    </>
  );
};

export default FromKarajDescription;
