import Col from "@/Shared/Kit/Col";
import Row from "@/Shared/Kit/Row";
import styled from "styled-components";

interface DescriptionContainerProps {
  showAll?: boolean;
}
export const DescriptionContainer = styled(Col)<DescriptionContainerProps>`
  height: ${(props) => (props.showAll ? "max-content" : "400px")};
  overflow: ${(props) => (props.showAll ? "visible" : "hidden")};
  transition: height 0.5s ease;
  justify-content: flex-start;
  align-items: flex-start;
  position: relative;
  a {
    color: #007bff;
    font-weight: bold;
    text-decoration: none;

    &:hover {
      text-decoration: underline;
    }
  }

  h1,
  h2,
  h3 {
    margin-top: 2rem;
    color: ${(props) => props.theme.gray800};
  }

  > p {
    text-align: justify;
    margin-top: 8px;
    color: ${(props) => props.theme.gray700};
  }

  .moreBtn {
    position: absolute;
    bottom: ${(props) => (props.showAll ? "-30px" : "0px")};
    z-index: 2;
    left: 0;
    right: 0;
    margin: 0 auto;

    svg {
      rotate: ${(props) => (props.showAll ? "180deg" : "none")};
      width: 14px;
      height: 14px;
    }
  }
`;

export const Blur = styled(Row)`
  height: 50px;
  position: absolute;
  bottom: 0;
  filter: drop-shadow(20px -20px 20px #f8f8f8);
  background-color: #f8f8f8;
`;

export const AccordionWrapper = styled(Row)`
  padding: 20px 0;
  gap: 15px;

  justify-content: flex-start;
`;

export const UlContainer = styled.ul`
  display: flex;
  flex-direction: column;

  list-style: disc;

  li {
    direction: rtl;
    font-size: 14px !important;
    margin-top: 0.5rem;
    color: ${(props) => props.theme.gray700};
    > span {
      font-weight: bold;
    }
  }
`;
