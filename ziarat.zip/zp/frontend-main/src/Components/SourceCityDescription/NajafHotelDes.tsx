import { LargeHeading, XLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { Blur, DescriptionContainer, UlContainer } from "./styles";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";
import { useState } from "react";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import Link from "next/link";
import NajafHotelAccordion from "./NajafHotelAccordion";
import { XXLargeHeadingStyle } from "@/Shared/Kit/Typography/Heading/styles";

const NajafHotelDes = () => {
  const [showAll, setShowAll] = useState(false);
  return (
    <DescriptionContainer showAll={showAll}>
      <SmallParagraph>
        نجف یکی از مهم‌ترین مقاصد سفرهای زیارتی در عراق است و انتخاب محل اقامت
        مناسب، بخش مهمی از این سفر به‌شمار می‌آید. با رزرو هتل های نجف نزدیک حرم
        امیرالمومنین (ع)، دسترسی شما به حرم آسان‌تر می‌شود و می‌توانید در مدت
        اقامت خود، تجربه‌ای بهتر داشته باشید. برای رزرو هتل نجف در سامانه رسم
        زیارت، فهرست کاملی از <Link href="/hotel"> هتل‌ های عراق </Link> زیر نظر
        سازمان حج و زیارت با قیمت‌های متنوع در دسترس است تا به راحتی گزینه
        موردنظر خود را رزرو کنید.
      </SmallParagraph>
      <XLargeHeading>رزرو هتل های نجف با رسم زیارت</XLargeHeading>
      <SmallParagraph>
        رسم زیارت به‌عنوان یکی از مراجع رسمی برگذار کننده{" "}
        <Link href="/tours/karbala/from-tehran"> تور کربلا </Link>
        زیر نظر سازمان حج و زیارت، امکان رزرو هتل در نجف را با بهترین قیمت و
        اطمینان کامل برای زائران فراهم کرده است. برای رزرو هتل در نجف وارد سایت
        رسم زیارت شوید، گزینه هتل را انتخاب کرده و در بخش شهر نام نجف را وارد
        کنید. در ادامه، با مشاهده فهرست هتل‌ها، می‌توانید جزئیات مربوط به
        موقعیت، امکانات و تصاویر هر هتل را بررسی نمایید.
      </SmallParagraph>
      <SmallParagraph>
        پس از مقایسه گزینه‌ها، با کارشناسان رسم زیارت تماس بگیرید تا ضمن دریافت
        مشاوره، از ظرفیت خالی و شرایط رزرو هتل دلخواه خود مطلع شوید. کارشناسان
        با استعلام آخرین وضعیت اقامتگاه‌ها، شما را در انتخاب بهترین گزینه متناسب
        با بودجه و نیازتان راهنمایی خواهند کرد.
      </SmallParagraph>
      <SmallParagraph>
        پس از نهایی شدن انتخاب هتل، رزرو شما در تاریخ مورد نظر و با خدمات
        درخواستی ثبت می‌شود. در پایان، با پرداخت هزینه اقامت، واچر هتل نجف توسط
        کارشناسان رسم زیارت در کوتاه‌ترین زمان برای شما ارسال خواهد شد.
      </SmallParagraph>
      <LargeHeading>بهترین هتل های نجف نزدیک حرم</LargeHeading>
      <SmallParagraph>
        بسیاری از زائران ترجیح می‌دهند در هتل‌ های نجف نزدیک حرم امام علی (ع)
        اقامت داشته باشند تا بدون نیاز به وسیله نقلیه، در هر ساعت از شبانه‌روز
        به زیارت بروند. این هتل‌ها در محدوده مرکزی شهر واقع شده و دسترسی آسانی
        به بازارهای سنتی و اماکن زیارتی دارند.
      </SmallParagraph>
      <SmallParagraph>
        چند نمونه از بهترین هتل‌های نجف نزدیک حرم عبارتند از:
      </SmallParagraph>

      <UlContainer>
        <li>
          <Link href="/hotel/najaf-hotel/qasr-aldur">هتل قصرالدر نجف</Link>
        </li>
        <li>هتل جارالامیر نجف</li>
        <li>هتل برج‌المولی نجف</li>
        <li>هتل اغنار نجف</li>
        <li>هتل نخله نجف</li>
        <li>هتل ارض السهله نجف</li>
        <li>هتل زمزم ۲ نجف</li>
      </UlContainer>
      <LargeHeading>هتل های ۵ ستاره نجف</LargeHeading>
      <SmallParagraph>
        هتل‌ های پنج ‌ستاره نجف بالاترین سطح خدمات و امکانات اقامتی را برای
        زائران فراهم می‌کنند و در
        <Link href="/tours/karbala/vip"> تورهای لوکس کربلا </Link>
        قابل رزرو هستند. این هتل‌ها با فضاهای لوکس، پرسنل آموزش‌دیده و موقعیت
        مکانی مناسب، انتخابی ایده‌آل برای اقامت‌های خانوادگی یا زیارتی هستند.{" "}
      </SmallParagraph>

      <SmallParagraph>
        از جمله بهترین هتل‌ های ۵ ستاره نجف می‌توان به موارد زیر اشاره کرد:
      </SmallParagraph>
      <Link href="/tours/karbala/vip"></Link>

      <UlContainer>
        <li>
          <Link href="/hotel/najaf-hotel/najaf-do">هتل نجف دو نجف</Link>
        </li>
        <li>هتل گرانادا نجف</li>
        <li>هتل نسیم النجف</li>
        <li>هتل رویال ایگل نجف</li>
        <li>هتل قصر الخورنق نجف</li>
        <li>هتل کوثر نجف</li>
      </UlContainer>
      <SmallParagraph>
        امکاناتی مانند رستوران بین‌المللی، کافی‌شاپ، استخر، سالن ورزشی و خدمات
        ۲۴ ساعته از ویژگی‌های متمایز این هتل‌هاست.
      </SmallParagraph>
      <LargeHeading>هتل های ۴ ستاره نجف</LargeHeading>
      <SmallParagraph>
        هتل‌های ۴ ستاره نجف تعادل کاملی بین کیفیت خدمات و قیمت دارند و برای
        زائرانی که به‌دنبال اقامت راحت با هزینه مناسب هستند، گزینه‌ای ایده‌آل
        محسوب می‌شوند. این هتل‌ها معمولا امکاناتی مانند صبحانه بوفه، نظافت
        روزانه، پرسنل فارسی‌زبان، اینترنت رایگان و سرویس‌های بهداشتی ایرانی و
        فرنگی ارائه می‌دهند.
      </SmallParagraph>
      <SmallParagraph>برخی از هتل‌های ۴ ستاره نجف:</SmallParagraph>
      <UlContainer>
        <li>هتل المقام نجف</li>
        <li>هتل قصرالضیافه نجف</li>
        <li>هتل النهرین نجف</li>
        <li>هتل المحاسن نجف</li>
        <li>هتل الاغنار نجف</li>
        <li>هتل بردی نجف</li>
      </UlContainer>
      <XLargeHeading>قیمت هتل در نجف</XLargeHeading>
      <SmallParagraph>
        قیمت هتل نجف به عواملی مانند درجه کیفی، خدمات ارائه‌شده، فاصله تا حرم و
        زمان سفر بستگی دارد. در ایام خاص مذهبی مانند ماه محرم، صفر و نیمه شعبان،
        نرخ اقامت افزایش می‌یابد. در فصل‌های کم‌سفر مانند پاییز و زمستان
        می‌توانید رزرو هتل نجف را با قیمت کمتر انجام دهید. برای اطلاع از قیمت
        روز هتل در نجف نزدیک حرم، کافی است وارد سامانه رسم زیارت شوید یا با
        کارشناسان پشتیبانی تماس بگیرید.
      </SmallParagraph>
      <LargeHeading>هتل های ارزان و اقتصادی نجف</LargeHeading>
      <SmallParagraph>
        اگر قصد دارید در سفر زیارتی خود هزینه‌ها را مدیریت کنید، هتل ‌های ارزان
        نجف انتخاب مناسبی هستند. این هتل‌ها خدمات پایه اما استانداردی را برای
        اقامت زائران فراهم می‌کنند.
      </SmallParagraph>
      <SmallParagraph>
        از جمله هتل ‌های اقتصادی نجف می‌توان به گزینه‌های زیر اشاره کرد:
      </SmallParagraph>
      <UlContainer>
        <li>هتل قائم نجف</li>
        <li>هتل الاخضر نجف</li>
        <li>هتل خان الذهب نجف</li>
      </UlContainer>
      <XLargeHeading>مزایای رزرو هتل نجف در رسم زیارت</XLargeHeading>
      <UlContainer>
        <li>امکان رزرو تمام هتل های زیر نظر سازمان حج و زیارت در نجف</li>
        <li>تضمین بهترین قیمت برای رزرو هتل ارزان یا لوکس</li>
        <li>امکان فیلتر براساس درجه هتل‌ها</li>
        <li>مشاهده تصاویر واقعی و فاصله تا حرم برای هر هتل</li>
        <li>مشاوره و پشتیبانی کامل توسط کارشناسان رسم زیارت</li>
      </UlContainer>
      <NajafHotelAccordion />

      {!showAll && <Blur />}

      <GhostButton
        title={showAll ? "بستن" : "مشاهده بیشتر"}
        size="sm"
        color="gray"
        icon={ArrowDownIcon}
        width="180px"
        iconPosition="left"
        onClick={() => {
          setShowAll((perv) => !perv);
        }}
        className="moreBtn"
      />
    </DescriptionContainer>
  );
};

export default NajafHotelDes;
