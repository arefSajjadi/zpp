import React from "react";
import { AccordionWrapper } from "./styles";
import { LargeDisplay } from "@/Shared/Kit/Typography/Display";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import ToggleTab from "@/Shared/Kit/ToggleTab";
import Pattern from "@/Components/Pattern";
import LeftPattern from "@/Assets/Icons/LeftPattern";

const IraqHotelAccordion = () => {
  const theme = useSelector(selectTheme);

  const toggleItems = [
    {
      id: 1,
      title: "برای رزرو هتل در عراق، چه مدارکی لازم است؟",
      description: `رزرو هتل در عراق، صرفاً با ارائه پاسپورت و اسامی افراد، امکان‌پذیر است.`,
    },
    {
      id: 2,
      title: "چگونه هتل‌های عراق را در سایت رسم زیارت، رزرو کنیم؟",
      description: `شما با مشاهده لیست هتل‌های عراق در سامانه رسم زیارت، به‌سادگی می‌توانید اقدام به مقایسه میان هتل‌ها کنید. سپس هتل‌های مدنظر خود برای اقامت را به کارشناسان مربوطه اعلام می‌کنید. پس از استعلام قیمت و بررسی ظرفیت و امکان اقامت، مراحل دریافت اطلاعات رزرو و پرداخت هزینه انجام می‌شود تا محل اسکان شما در شهر‌های زیارتی عراق، قطعی شود.`,
    },
  ];
  return (
    <AccordionWrapper>
      {toggleItems.map((item) => (
        <ToggleTab key={item.id} item={item} name={`name${item.id}`} />
      ))}
    </AccordionWrapper>
  );
};

export default IraqHotelAccordion;
