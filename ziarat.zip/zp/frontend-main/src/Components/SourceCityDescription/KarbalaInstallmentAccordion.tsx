import React from "react";
import { AccordionWrapper } from "./styles";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import ToggleTab from "@/Shared/Kit/ToggleTab";

const KarbalaInstallmentAccordion = () => {
  const theme = useSelector(selectTheme);

  const toggleItems = [
    {
      id: 1,
      title: "آیا برای رزرو تور قسطی نیاز به معرفی ضامن کارمند داریم؟",
      description:
        "خیر، یکی از بزرگترین مزیت‌های طرح ما این است که شما برای ثبت‌نام و پرداخت اقساطی هیچ نیازی به معرفی ضامن ندارید و تنها با ارائه چک صیادی معتبر می‌توانید ثبت‌نام کنید.",
    },
    {
      id: 2,
      title: "تعداد اقساط و سود تعلق گرفته به باقی‌مانده مبلغ چقدر است؟",
      description:
        "باقی‌مانده هزینه تور طی ۴ قسط از شما دریافت می‌شود. سود در نظر گرفته شده برای این تسهیلات بسیار ناچیز بوده و تنها ۲ درصد به مبلغ باقی‌مانده اضافه خواهد شد.",
    },
    {
      id: 3,
      title: "آیا کیفیت هتل و غذای مسافران اقساطی با مسافران نقدی تفاوت دارد؟",
      description:
        "به هیچ وجه. تمامی زائران در یک کاروان هستند و از خدمات کاملاً یکسان شامل هتل‌های درجه یک، غذای آشپزخانه مرکزی و ترانسفر مشابه استفاده می‌کنند. نوع پرداخت تأثیری در کیفیت خدمات ندارد.",
    },
    {
      id: 4,
      title: "در چه روزهایی امکان رزرو تور به صورت اقساطی وجود ندارد؟",
      description:
        "در ایام پیک و مناسبت‌های خاص مذهبی مانند عید نوروز، عرفه، نیمه شعبان و اربعین، به دلیل پر شدن سریع ظرفیت کاروان‌ها، امکان فروش اقساطی وجود ندارد و فروش فقط نقدی است.",
    },
    {
      id: 5,
      title: "اولین چک قسط چه زمانی باید پاس شود؟",
      description:
        "سررسید اولین قسط شما یک ماه پس از تاریخ رزرو تور و انجام قرارداد خواهد بود. این تنفس یک‌ماه به شما کمک می‌کند تا با آرامش بیشتری هزینه‌های سفر خود را جلو ببرید.",
    },
  ];
  return (
    <AccordionWrapper>
      {toggleItems.map((item) => (
        <ToggleTab key={item.id} item={item} name={`name${item.id}`} />
      ))}
    </AccordionWrapper>
  );
};

export default KarbalaInstallmentAccordion;
