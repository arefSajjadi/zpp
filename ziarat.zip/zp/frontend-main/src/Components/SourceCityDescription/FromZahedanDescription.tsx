import { Blur, DescriptionContainer } from "./styles";
import Head from "next/head";
import { useState } from "react";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import { LargeHeading, XLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";

const FromZahedanDescription = () => {
  const [showAll, setShowAll] = useState(false);
  return (
    <>
      {/* <Head>
        <title>تور کربلا از زاهدان | هوایی و زمینی - رسم زیارت</title>
        <meta
          name="description"
          content="تور کربلا از زاهدان ⚡ اقامت 7 شب | زیارت نجف،کربلا، کاظمین و سامرا ❗ اقامت هتل نزدیک حرم همراه با وعده غذایی | زیرنظر سازمان حج و زیارت"
        />
        <link
          rel="canonical"
          href="https://ziarat.co/tours/karbala/from-zahedan"
        />
        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
        <meta name="enamad" content="850460"/>
      </Head> */}

      <DescriptionContainer showAll={showAll}>
        <XLargeHeading>راهنمای تور کربلا از زاهدان</XLargeHeading>
      </DescriptionContainer>
    </>
  );
};

export default FromZahedanDescription;
