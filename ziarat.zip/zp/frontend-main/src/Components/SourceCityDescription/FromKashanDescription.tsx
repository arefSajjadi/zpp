import { Blur, DescriptionContainer } from "./styles";
import Head from "next/head";
import { useState } from "react";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import { LargeHeading, XLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";

const FromKashanDescription = () => {
  const [showAll, setShowAll] = useState(false);
  return (
    <>
      {/* <Head>
        <title>تور کربلا از کاشان | هوایی و زمینی - رسم زیارت</title>
        <meta
          name="description"
          content="تور کربلا از کاشان ⚡ ارائه بهترین خدمات سفر : اقامت هتل نزدیک حرم + زیارت دوره + بیمه مسافرتی + ترانسفر | پشتیبانی 24 ساعته"
        />
        <link
          rel="canonical"
          href="https://ziarat.co/tours/karbala/from-kashan"
        />
        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
        <meta name="enamad" content="850460"/>
      </Head> */}

      <DescriptionContainer showAll={showAll}>
        <XLargeHeading>راهنمای تور کربلا از کاشان</XLargeHeading>
        <SmallParagraph>
          کاشان شهری تاریخی و با قدمت در استان اصفهان می باشد که مردمان مذهبی و
          معتقد زیادی دارد. افراد با ایمان شهر کاشان سعی می کنند که حداقل سالی
          یک بار را به سفرهای زیارتی از جمله تورکربلا از کاشان بپردازند، تا
          ارادت خالصانه خود را به اهل بیت (ع) نشان دهند. هدف مردم کاشان برای
          رزرو تور کربلا از کاشان هوایی و زمینی، این است که امام حسین (ع) و حضرت
          عباس (ع) در کربلا، امام علی (ع) در نجف و امام موسی کاظم (ع) را در
          کاظمین زیارت کنند و دل های خود را پاک نمایند.
        </SmallParagraph>
        <XLargeHeading>
          تور کربلا از کاشان زمینی، از طریق چه مرزهایی امکان پذیر است؟
        </XLargeHeading>
        <SmallParagraph>
          رزرو تور کربلا از کاشان زمینی، با مرز مهران امکان پذیر است؛ چنان که
          مسافران تور کربلا از کاشان زمینی همراه کاروان و با اتوبوس ویژه تور به
          سمت مرز مهران حرکت می کنند و پس از ارائه گذرنامه خود، وارد کشور عراق
          می شوند.
        </SmallParagraph>
        <XLargeHeading>
          آیا تور کربلا از کاشان هوایی قابل انجام است؟
        </XLargeHeading>
        <SmallParagraph>
          خیر؛ شهر کاشان فرودگاه بین المللی ای ندارد؛ پس نمی توانید به طور
          مستقیم از مبدا کاشان به تور کربلا از کاشان بپردازید. اما اگر می خواهید
          تور کربلا از کاشان هوایی را رزرو کنید، باید به نزدیک ترین شهری که
          فرودگاه بین المللی دارد مراجعه کنید.
        </SmallParagraph>
        <XLargeHeading>تور کربلا از کاشان چند روزه است؟</XLargeHeading>
        <SmallParagraph>
          در حال حاضر، تورهای کربلا از کاشان به صورت ۶ شب و ۷ روز، و ۷ شب و ۸
          روز برگزار می شوند.
        </SmallParagraph>
        <XLargeHeading>
          با رزرو تور کربلا از کاشان، در چه شهرهایی اقامت می کنیم؟
        </XLargeHeading>
        <SmallParagraph>
          پاسخ این سوال به مدت زمان و روزهای تور کربلا از کاشان شما بستگی دارد.
        </SmallParagraph>
        <SmallParagraph>
          در تور ۶ شب و ۷ روز کاشان به کربلا، شما ۲ شب در نجف، ۴ شب در کربلا، و
          به صورت عبوری در کاظمین و سامرا اقامت خواهید کرد؛ و در تور ۷ شب و ۸
          روز نیز، ۳ شب در نجف اشرف، ۳ شب در کربلا معلی، ۱ شب در کاظمین و به
          صورت عبوری در سامرا اقامت خواهید داشت. البته قابل ذکر است که ممکن است
          در حین تور، برنامه روزها جا به جایی داشته باشد.
        </SmallParagraph>
        <XLargeHeading>
          بعد از رزرو تور کربلا از کاشان، از چه مکان هایی بازدید می کنیم؟
        </XLargeHeading>
        <SmallParagraph>
          زیارت از حرم امام علی (ع)، امام حسین (ع) و حضرت عباس (ع) که از مهم
          ترین و حتمی ترین بازدید های تورهای کربلا از کاشان می باشد؛ اما غیر از
          آنها، شما با رزرو تور زمینی و هوایی کربلا از کاشان در سامانه زیارت، می
          توانید از بازدید آرامگاه سید محمد، مسلم بن عقیل، طفلان مسلم و مختار
          ثقفی؛ مساجد کوفه، حنانه و سهله، خیمه گاه اهل بیت (ع)، موزه امام حسین
          (ع)، تل زینبیه، موزه حضرت ابوالفضل (ع)، رود فرات نیز استفاده کنید.
        </SmallParagraph>
        <XLargeHeading>قیمت تور کربلا از کاشان زمینی</XLargeHeading>
        <SmallParagraph>
          شروع قیمت تور کربلا از کاشان زمینی در سامانه رسم زیارت سازمان حج،
          از ۶/690/۰۰۰ تومان می باشد. برای رزرو تور کربلا از کاشان زمینی ارزان و
          به صرفه، با کارشناسان سایت رسم زیارت تماس حاصل فرمایید؛ تا رزرو تور
          عتبات عالیات شما را انجام دهند.
        </SmallParagraph>
        <XLargeHeading>
          قیمت تور کربلا از کاشان برای کودک و خردسال
        </XLargeHeading>
        <SmallParagraph>
          قیمت تور کربلا از کاشان، در سایت رسم زیارت و برای خردسال ۲ تا ۱۲
          سال: تنها شامل ۸۰ درصد نرخ تور کربلا از کاشان برای بزرگسالان است.
        </SmallParagraph>
        <SmallParagraph>
          قیمت تور کربلا از کاشان زمینی برای کودک زیر ۲ سال: فقط شامل پرداخت
          هزینه بیمه می شود.
        </SmallParagraph>
        <SmallParagraph>
          قیمت تور کربلا از کاشان هوایی برای سن پایین تر از ۲ سال: تنها شامل ۱۰
          درصد نرخ تور کربلا از کاشان هوایی برای بزرگسالان است.
        </SmallParagraph>
        <XLargeHeading>
          هتل های کربلا، هتل های نجف و هتل های کاظمین در تور کربلا از کاشان
        </XLargeHeading>
        <LargeHeading>بهترین هتل های کاظمین در تور کربلا از کاشان</LargeHeading>
        <SmallParagraph>
            هتل قلعه کاظمیه، هتل قصر الکاظمیه و هتل سراج المنیر.
        </SmallParagraph>
        <LargeHeading>
          ارزان ترین هتل های کربلا در تور کربلا از کاشان
        </LargeHeading>
        <SmallParagraph>
          هتل برج الاغا، هتل زهور الحسین و هتل سفیر کربلا.
        </SmallParagraph>
        <LargeHeading>
          ارزان ترین هتل های نجف در تور کربلا از کاشان
        </LargeHeading>
        <SmallParagraph>هتل الاخضر، هتل ذوالفقار و هتل النهرین.</SmallParagraph>
        <XLargeHeading>رزرو تور کربلا از کاشان با سایت رسم زیارت</XLargeHeading>
        <SmallParagraph>
          سایت رسم زیارت، تورهای عتبات و عالیات خود را در بهترین شرایط خدماتی و
          با بهترین کاروان های زیارتی ارائه می دهد. اگر قصد رزرو تور کربلا از
          کاشان ارزان را دارید؛ برای اطلاع بیشتر از این نوع تورها، با کارشناسان
          رسم زیارت تماس حاصل فرمایید.
        </SmallParagraph>

        {!showAll && <Blur />}

        <GhostButton
          title={showAll ? "بستن" : "مشاهده بیشتر"}
          size="sm"
          color="gray"
          icon={ArrowDownIcon}
          width="180px"
          iconPosition="left"
          onClick={() => {
            setShowAll((perv) => !perv);
          }}
          className="moreBtn"
        />
      </DescriptionContainer>
    </>
  );
};

export default FromKashanDescription;
