import { Blur, DescriptionContainer } from "./styles";
import Head from "next/head";
import { useState } from "react";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import { LargeHeading, XLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";

const FromArakDescription = () => {

  const [showAll ,setShowAll] = useState(false)
  return (
    <>
    {/* <Head>
    <title>تور کربلا از اراک | زمینی - رسم زیارت</title>
    <meta name="description" content="تور کربلا از اراک ⚡ اقامت در هتل های 4 ستاره و 5 ستاره نزدیک حرم ❗ زیرنظر سازمان حج و زیارت | پشتیبانی 24 ساعته"/>
    <meta name="google-site-verification" content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk" />
    <link rel="canonical" href="https://ziarat.co/tours/karbala/from-arak"/>
    <meta name="enamad" content="850460"/>
    </Head> */}
   
    <DescriptionContainer showAll={showAll}>
    <XLargeHeading>
         
         راهنمای تورکربلا از اراک
         </XLargeHeading>
         <SmallParagraph>
           مردمان شهر اراک هر سال در مناسبت ها و یا در ایام مختلف، به عتبات عالیات
           سفر می کنند. سایت رسم زیارت؛ برای مردمان شهر اراک تورهای هوایی و زمینی
           با خدمات ویژه زیر نظر سازمان حج و زیارت ارائه می دهد.
         </SmallParagraph>
         <XLargeHeading>
           از چه مرزهایی تور کربلا از اراک امکان پذیر است؟
         </XLargeHeading>
         <SmallParagraph>
           تور زمینی کربلا دو سر زمینی از طریق مرز مهران انجام می گیرد که از طریق
           اتوبوس هایی که جزو خدمات تور می باشد به صورت رفت و برگشت انجام می گیرد.
         </SmallParagraph>
         <XLargeHeading>
           رزرو تورکربلا از اراک هوایی، به چه صورت است؟
         </XLargeHeading>
         <SmallParagraph>
           در حال حاضر تور کربلا از اراک هوایی به صورت مستقیم وجود ندارد. برای
           اطلاعات بیشتر درباره تور کربلا از اراک می توانید با تماس با سایت رسم
           زیارت با کارشناسان سفر مشاوره نمایید.
         </SmallParagraph>
         <XLargeHeading>تور کربلا از اراک چند روزه است ؟</XLargeHeading>
         <SmallParagraph>
           مدت اقامت تور کربلا از اراک  به صورت ۷ شب و ۸ روز است.
         </SmallParagraph>
         <XLargeHeading>
           با رزرو تورکربلا از اراک، در چه مکان های اقامت داریم؟
         </XLargeHeading>
         <SmallParagraph>
           با توجه به این که تعداد اقامت و شهر های اقامت بستگی به شرایط تور و زمان
           تور دارد.
         </SmallParagraph>
         <SmallParagraph>
           تورهای ۶ شب و ۷ روز به این صورت است که ۲ شب در نجف و ۴ شب در کربلا اقامت
           است و زیارت کاظمین و سامرا به صورت عبوری انجام خواهد شد. تورهای ۷ شب و ۸
           روز هم به صورت ۳ شب نجف ، ۳شب کربلا، ۱شب کاظمین اقامت است و زیارت سامرا
           به صورت زیارت عبوری است.
         </SmallParagraph>
         <XLargeHeading>
           قیمت تور کربلا زمینی از اراک به چه صورت است؟
         </XLargeHeading>
         <SmallParagraph>
           شروع قیمت تورهای کربلا از اراک زمینی از 6/124/۰۰۰ تومان است.
         </SmallParagraph>
         <XLargeHeading>
           قیمت تور کربلا از اراک برای کودکان و خردسالان به چه صورت است؟
         </XLargeHeading>
         <SmallParagraph>
           تورهای کربلا از اراک برای کودکان ۲ تا ۱۲ سال : ۸۰ درصد هزینه بزرگسالان
           را شامل می شود.
         </SmallParagraph>
         <SmallParagraph>
           تور کربلا از اراک زمینی برای کودکان زیر ۲ سال: فقط شامل هزینه بیمه می
           شود.
         </SmallParagraph>
         <SmallParagraph>
           تور کربلا از اراک هوایی برای کودکان زیر ۲ سال:  تنها ۱۰ درصد قیمت تور
           هوایی بزرگسالان را شامل می شود.
         </SmallParagraph>
         <XLargeHeading>
           هتل های کربلا، هتل های کاظمین و هتل های نجف تور کربلا از اراک:
         </XLargeHeading>
         <SmallParagraph>
           سایت زیارت؛ همواره در تورها از هتل های با کیفیت و درجه یک کربلا، نجف و
           کاظمین برخوردار است. که به معرفی هتل ها می پردازیم:
         </SmallParagraph>
         <LargeHeading> هتل های کاظمین عبارت اند از </LargeHeading>
         <SmallParagraph>
            هتل سراج المنیر کاظمین ،هتل
           قصر الکاظمیه کاظمین هتل فدک الزهرا
         </SmallParagraph>
         <LargeHeading> هتل های نجف عبارت اند از </LargeHeading>
         <SmallParagraph>
           هتل ریحانه المصطفی نجف ,هتل
           برکات الاحورا نجف هتل ورده النجف نجف
         </SmallParagraph>
         <LargeHeading> هتل های کربلا عبارت اند از </LargeHeading>
         <SmallParagraph>
            هتل ضیوف الرحیم کربلا، هتل
           مهجه کربلا، هتل صحار کربلا
         </SmallParagraph>
         <XLargeHeading>
           رزرو تور کربلا از اراک از سایت رسم زیارت
         </XLargeHeading>
         <SmallParagraph>
           مردمان عزیز شهر اراک می توانند برای رزرو تور کربلا با سایت رسم زیارت
           تماس حاصل نمایند تا کارشناسان مجرب سفر، شما را در رابطه با تور مورد نظر
           خود راهنمایی نمایند.
         </SmallParagraph>

{
    !showAll &&
      <Blur />
}

      <GhostButton 
        title={ showAll ? "بستن" : "مشاهده بیشتر"}
        size="sm"
        color="gray"
        icon={ArrowDownIcon}
        width="180px"
        iconPosition="left"
        onClick={() => {setShowAll(perv => !perv)}}
        className="moreBtn"
      />
    </DescriptionContainer>
    </>
  );
};

export default FromArakDescription;
