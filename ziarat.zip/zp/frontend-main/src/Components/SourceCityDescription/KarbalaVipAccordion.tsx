import React from "react";
import { AccordionWrapper } from "./styles";
import ToggleTab from "@/Shared/Kit/ToggleTab";

const KarbalaVipAccordion = () => {
  const toggleItems = [
    {
      id: 1,
      title: "بهترین هتل های 5 ستاره تور لوکس کربلا کدام اند؟",
      description:
        "هتل‌های عباس، الفردوس، سفیر، وارث و زمزم در کربلا و همچنین هتل‌های دار الضیافه، مووِنپیک، سلام و میلینیوم در نجف از بهترین گزینه‌های اقامت برای تورهای لوکس محسوب می‌شوند که امکانات پیشرفته و دسترسی آسان به حرم‌ها را دارند.",
    },
    {
      id: 2,
      title: "چه زمانی برای سفر به کربلا مناسب‌تر است؟",
      description:
        "اگر به دنبال سفری آرام‌تر هستید، اواخر بهار، اوایل پاییز و اواسط زمستان گزینه‌های مناسبی هستند. اما اگر می‌خواهید در مناسبت‌های مذهبی خاص مانند اربعین، محرم یا نیمه شعبان حضور داشته باشید، باید زودتر رزرو کنید.",
    },
    {
      id: 3,
      title: "تفاوت تورهای لوکس زمینی و هوایی در چیست؟",
      description:
        "تورهای هوایی سریع و راحت هستند اما هزینه بیشتری دارند. تورهای زمینی اقتصادی‌تر بوده و امکان بازدید از مسیر را دارند. انتخاب بین این دو بستگی به بودجه، زمان و اولویت‌های شما دارد.",
    },
  ];
  return (
    <AccordionWrapper>
      {toggleItems.map((item) => (
        <ToggleTab key={item.id} item={item} name={`name${item.id}`} />
      ))}
    </AccordionWrapper>
  );
};

export default KarbalaVipAccordion;
