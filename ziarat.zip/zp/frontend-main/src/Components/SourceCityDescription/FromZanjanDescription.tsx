import { Blur, DescriptionContainer } from "./styles";
import Head from "next/head";
import { useState } from "react";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import { LargeHeading, XLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";

const FromZanjanDescription = () => {
  const [showAll, setShowAll] = useState(false);
  return (
    <>
      {/* <Head>
        <title>تور کربلا از زنجان | زمینی - رسم زیارت</title>
        <meta
          name="description"
          content="تور کربلا از زنجان ⚡ اقامت 7 شب | زیارت نجف، کربلا، کاظمین و سامرا | پشتیبانی 24 ساعته | مشاوره تور : 43000109 -021"
        />
        <link
          rel="canonical"
          href="https://ziarat.co/tours/karbala/from-zanjan"
        />
        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
          <meta name="enamad" content="850460"/>
      </Head> */}

      <DescriptionContainer showAll={showAll}>
        <XLargeHeading>راهنمای تور کربلا از زنجان</XLargeHeading>
        <SmallParagraph>
          سایت زیارت برای مردمان شهر زنجان که در ایام شهادت ها و مناسبت ها و
          ایام محرم و اربعین به کربلا سفر می کنند؛ کاروان های زمینی و هوایی
          عتبات عالیات را برای شهر زنجان اجرا می کند.
        </SmallParagraph>
        <XLargeHeading>
          تور کربلا از زنجان زمینی از چه مرزی امکان پذیر است؟
        </XLargeHeading>
        <SmallParagraph>
          تور کربلا از زنجان زمینی، ازطریق مرز مهران اجرا می شود که با اتوبوس
          هایی که جزو خدمات تور است به سمت مهران حرکت می کند.
        </SmallParagraph>
        <XLargeHeading>تور کربلا از زنجان هوایی قابل اجرا است؟</XLargeHeading>
        <SmallParagraph>
          تورهای کربلا از زنجان هوایی از طریق فرودگاه بین المللی زنجان به سمت
          نجف صورت می گیرد.
        </SmallParagraph>
        <XLargeHeading>مدت تور کربلا از زنجان به چه صورت است؟</XLargeHeading>
        <SmallParagraph>
          تورهای کربلا از زنجان به دو صورت ۶ شب و ۷ شب قابل اجرا می باشد.
        </SmallParagraph>
        <SmallParagraph>
          تور کربلا از زنجان ۶ شب و ۷ روز به این صورت می باشد که :
        </SmallParagraph>
        <SmallParagraph>
          ۳ شب نجف، ۳ شب کربلا،۱ شب کاظمین و سامرا به صورت زیارت عبوری است.
        </SmallParagraph>
        <SmallParagraph>
          تورهای ۷ شب و ۸ روز به این صورت است : ۳ شب نجف، ۳ شب کربلا، ۱شب کاظمین
          اقامت است و سامرا به صورت زیارت عبوری است.
        </SmallParagraph>
        <XLargeHeading>قیمت تور کربلا از زنجان زمینی چگونه است؟</XLargeHeading>
        <SmallParagraph>
          شروع قیمت تورهای کربلا از زنجان زمینی در سایت زیارت، از ۶/۵۲۵/۰۰۰
          تومان می باشد.
        </SmallParagraph>
        <XLargeHeading>قیمت تور کربلا از زنجان هوایی چگونه است؟</XLargeHeading>
        <SmallParagraph>
          تو کربلا از زنجان هوایی که از طریق فرودگاه بین المللی زنجان صورت می
          گیرد. برای اطلاع از قیمت تورهای کربلا از زنجان هوایی با سایت زیارت
          تماس بگیرید.
        </SmallParagraph>
        <XLargeHeading>
          هزینه تور کربلا از زنجان برای کودک و بزرگسال به چه صورت است؟
        </XLargeHeading>
        <SmallParagraph>
          قیمت تور کربلا از زنجان هوایی برای کودکان زیر دو سال:ده درصد قیمت تور
          برای بزرگسالان بالای ۱۲ سال است.
        </SmallParagraph>
        <SmallParagraph>
          قیمت تور کربلا از زنجان زمینی برای کودکان زیر دو سال: فقط شامل هزینه
          بیمه می باشد.
        </SmallParagraph>
        <SmallParagraph>
          قیمت تور کربلا از زنجان هوایی و تور کربلا از زنجان زمینی برای سنین ۲
          تا ۱۲ سال : فقط ۸۰ درصد قیمت تور افراد بزرگسال بالای ۱۲ است.
        </SmallParagraph>
        <SmallParagraph>
          در نظر داشته باشید که خدماتی که به کودکان ارائه می شود همانند خدمات
          بزرگسالان است و هیچ تفاوتی در ارائه خدمات وجود ندارد.
        </SmallParagraph>
        <XLargeHeading>
          هتل های کربلا، هتل های نجف و هتل های کاظمین کدام هستند؟
        </XLargeHeading>
        <LargeHeading>بهترین هتل های نجف:</LargeHeading>
        <SmallParagraph>هتل انوار الصادق الامین نجف</SmallParagraph>
        <SmallParagraph>هتل برکات الحوراء نجف</SmallParagraph>
        <LargeHeading>بهترین هتل های کربلا:</LargeHeading>
        <SmallParagraph>هتل نورالساطع کربلا</SmallParagraph>
        <SmallParagraph>هتل ضیوف الرحیم کربلا</SmallParagraph>
        <LargeHeading>بهترین هتل های کاظمین:</LargeHeading>
        <SmallParagraph>هتل فدک الزهرا کاظمین</SmallParagraph>
        <XLargeHeading>
          بهترین سفرهای زیارتی را با سایت زیارت داشته باشید
        </XLargeHeading>
        <SmallParagraph>
          مردمان عزیز زنجان؛ می توانند برای رزرو و خرید تور عتبات عالیات از
          زنجان با سامانه زیارت تماس گرفته تا از مشاوره کارشناسان سفر بهره مند
          شوید.
        </SmallParagraph>

        {!showAll && <Blur />}

        <GhostButton
          title={showAll ? "بستن" : "مشاهده بیشتر"}
          size="sm"
          color="gray"
          icon={ArrowDownIcon}
          width="180px"
          iconPosition="left"
          onClick={() => {
            setShowAll((perv) => !perv);
          }}
          className="moreBtn"
        />
      </DescriptionContainer>
    </>
  );
};

export default FromZanjanDescription;
