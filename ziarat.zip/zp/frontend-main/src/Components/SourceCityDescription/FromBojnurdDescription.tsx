
import { Blur, DescriptionContainer } from "./styles";
import Head from "next/head";
import { useState } from "react";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import { XLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";



const FromBojnurdDescription = () => {

  const [showAll ,setShowAll] = useState(false)
  return (
    <>
    {/* <Head>
    <title>تور کربلا از بجنورد | زمینی - رسم زیارت </title>
        <meta
          name="description"
          content="تور کربلا از بجنورد | اقامت در هتل های 4 ستاره و 5 ستاره نزدیک حرم | زیر تظر سازمان حج و زیارت | پشتیبانی 24 ساعته"
        />
        <link
          rel="canonical"
          href="https://ziarat.co/tours/karbala/from-bojnurd"
        />
        <meta name="enamad" content="850460"/>
    <meta name="google-site-verification" content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk" />
    </Head> */}
   
    <DescriptionContainer showAll={showAll}>
    <XLargeHeading>
           
           راهنمای تور کربلا از بجنورد
           </XLargeHeading>
           <SmallParagraph>
             بجنورد، یکی از شهرهای خراسان شمالی هست که مردم آن در ایام مختلف سال به
             سفر با تور کربلا می پردازند. تور کربلا از بجنورد در سامانه حج و زیارت
             برقرار است و توسط رسم زیارت که عضوی از این سازمان است نیز ، به فروش
             میرسد.
           </SmallParagraph>
           <XLargeHeading>
             تور کربلا از بجنورد زمینی از چه مرزی امکان پذیر است؟
           </XLargeHeading>
           <SmallParagraph>
             تور زمینی کربلا از بجنورد نیز همانند اکثر مبدا های دیگر، از مرز مهران
             انجام می پذیرد و حدود 19 ساعت طول می کشد تا به خاک عراق برسید .
           </SmallParagraph>
           <XLargeHeading>
             تور کربلا از بجنورد هوایی به چه صورت است؟
           </XLargeHeading>
           <SmallParagraph>
             در حال حاضر هیچ کاروان هوایی از مبدا بجنورد موجود نمی باشد؛ بنابراین
             اگر قصد دارید سفر بجنورد به کربلا شما به صورت هوایی باشد، باید از
             استان های هم جوار خود که دارای فرودگاه بین المللی هستند اقدام نمایید.
           </SmallParagraph>
           <XLargeHeading>
             تور کربلا از بجنورد چند روزه است؟
           </XLargeHeading>
           <SmallParagraph>
             اکثر کاروان های عتبات عالیات از مبدا بجنورد، 7 شبه هستند و با احتساب
             طول راه رفت و برگشت، حدود 9 روز به طول می انجامند . در این کاروان های
             بجنورد به کربلا، معمولا 3 شب را در نجف، 3 شب کربلا و یک شب را در
             کاظمین سپری خواهید کرد .
           </SmallParagraph>
           <XLargeHeading>
             قیمت تور کربلا از بجنورد زمینی چگونه است؟
           </XLargeHeading>
           <SmallParagraph>
             در حال حاضر و در مرداد ماه سال 1403، شروع قیمت تورهای کربلا از بجنورد
             5/990/000 تومان می باشد و با توجه به ایام و شرایط مختلف، متغیر خواهد
             بود .
           </SmallParagraph>
           <XLargeHeading>
             قیمت تور کربلا از بجنورد هوایی چگونه است؟
           </XLargeHeading>
           <SmallParagraph>
             از آنجایی که کاروان هوایی از مبدا بجنورد به عراق وجود ندارد، امکان
             بازگو کردن هزینه تور کربلا هوایی از بجنورد نمی باشد. اما شروع قیمت
             تورهای هوایی کربلا سازمان حج و زیارت در تابستان 1403 از 13/200/000
             تومان است .
           </SmallParagraph>
           <XLargeHeading>
             هزینه تور کربلا از بجنورد برای کودک و بزرگسال به چه صورت است؟
           </XLargeHeading>
           <SmallParagraph>
             هزینه تور کربلا سازمان حج و زیارت از بجنورد برای کودکان زیر دو سال
             تنها شامل هزینه بیمه است که در سفرهای زمینی 200 هزارتومان و در سفرهای
             هوایی 1/500/000 تومان می باشد .
           </SmallParagraph>
           <XLargeHeading>
             هتل های کربلا، هتل های نجف و هتل های کاظمین در این تور کدام هستند؟
           </XLargeHeading>
           <SmallParagraph>
             اسامی هتل های کربلا از بجنورد که در حال حاضر ارائه می شوند به شرح زیر
             است:
           </SmallParagraph>
           <SmallParagraph>
             هتل های نجف از بجنورد: مدینه العطا، اطیاب و الورود السیاحی
           </SmallParagraph>
           <SmallParagraph>
             کربلا: رتاج، نور ثریا و دره الحسین
           </SmallParagraph>
           <SmallParagraph>کاظمین: قصر راوند</SmallParagraph>
   
           <XLargeHeading>
             رسم زیارت، اولین سایت رزرو آنلاین تورهای کربلا در ایران
           </XLargeHeading>
           <SmallParagraph>
             شما می توانید تورهای کربلا از بجنورد را با مشاهده در قسمت کاروان های
             شهر بجنورد سامانه زیارت که عضوی از سازمان حج و زیارت است رزرو نمایید و
             سفری امن و معنوی را تجربه نمایید .
           </SmallParagraph>

{
    !showAll &&
      <Blur />
}

      <GhostButton 
        title={ showAll ? "بستن" : "مشاهده بیشتر"}
        size="sm"
        color="gray"
        icon={ArrowDownIcon}
        width="180px"
        iconPosition="left"
        onClick={() => {setShowAll(perv => !perv)}}
        className="moreBtn"
      />
    </DescriptionContainer>
    </>
  );
};

export default FromBojnurdDescription;
