import { Blur, DescriptionContainer } from "./styles";
import Head from "next/head";
import { useState } from "react";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import { LargeHeading, XLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";


const FromArdabilDescription = () => {

  const [showAll ,setShowAll] = useState(false)
  return (
    <>
    {/* <Head>
    <title>تور کربلا از اردبیل | هوایی و زمینی - رسم زیارت</title>
    <meta name="description" content="تور کربلا از اردبیل ⚡ زیارت کربلا، کاظمین، نجف و سامرا | بهترین خدمات به همراه بیمه مسافرتی، مدیر، مداح ❗ پشتیبانی 24 ساعته"  />
    <meta name="google-site-verification" content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk" />
    <meta name="enamad" content="850460"/>
    <link rel="canonical" href="https://ziarat.co/tours/karbala/from-ardabil"/>
    </Head> */}
   
    <DescriptionContainer showAll={showAll}>
    <XLargeHeading>
         
         راهنمای تور کربلا از اردبیل
         </XLargeHeading>
         <SmallParagraph>
           مردمان ترک زبان شهر اردبیل هر سال در مناسبت ها مانند دیگر عاشقان امام
           حسین به زیارت امامان معصوم در شهر کربلا، نجف، کاظمین و سامرا سفر می
           کنند. سایت رسم زیارت برای مردمان عاشق حسینی شهر اردبیل؛ کاروان کربلا را
           به صورت هوایی و زمینی اجرا می کند.
         </SmallParagraph>
         <XLargeHeading>
           تور کربلا از اردبیل زمینی از طریق چه مرزی امکان پذیر است؟
         </XLargeHeading>
         <SmallParagraph>
           تور کربلا از اردبیل زمینی، از مرز مهران اجرا می شود. مسافران با اتوبوسی
           که از خدمات تور کربلا از اردبیل می باشد، به مرز مهران می روند.
         </SmallParagraph>
         <XLargeHeading>تور کربلا از اردبیل هوایی</XLargeHeading>
         <SmallParagraph>
           تور کربلا هوایی برای کسانی که می خواهند سفر راحت تری داشته باشند با مدت
           زمان کمتری در راه باشند تور کربلا هوایی گزینه مناسبی است. برای سفر به
           کربلا پرواز مستقیمی به کربلا وجود ندارد که باید از طریق فرودگاه بین
           الملل اردبیل به نجف انجام می گیرد.
         </SmallParagraph>
         <XLargeHeading>
           تور کربلا از اردبیل چند روزه است؟
         </XLargeHeading>
         <SmallParagraph>
           تورهای کربلا از اردبیل به صورت تورهای ۶ شب و ۷ روز، ۷ شب و ۸ روز از طریق
           هوایی و زمینی اجرا می شود. تورهای ۶ شب و ۷ روز به این صورت است : ۳ شب
           نجف، ۳ شب کربلا، کاظمین و سامرا به صورت زیارت عبوری است. و یا به صورت ۲
           شب نجف، ۴ شب کربلا، کاظمین و سامرا به صورت زیارت عبوری است تورهای ۷ شب و
           ۸ روز به این صورت است : ۳ شب نجف، ۳ شب کربلا،  ۱شب کاظمین و سامرا به
           صورت زیارت عبوری است. و یا به صورت ۲ شب نجف، ۴ شب کربلا،  ۱شب کاظمین
            اقامت است و سامرا به صورت زیارت عبوری است
         </SmallParagraph>
         <XLargeHeading>
           قیمت تور کربلا از اردبیل زمینی چگونه است؟
         </XLargeHeading>
         <SmallParagraph>
           شروع قیمت تورهای کربلا از اردبیل زمینی در سایت زیارت، از 5/690/۰۰۰
           تومان می باشد.
         </SmallParagraph>
         <XLargeHeading>
           قیمت تور کربلا از اردبیل هوایی چگونه است؟
         </XLargeHeading>
         <SmallParagraph>
           شروع قیمت تورهای کربلا از اصفهان هوایی در سایت زیارت، از ۱۰/۶۵۴/۰۰۰ هزار
           تومان می باشد.
         </SmallParagraph>
         <XLargeHeading>
           قیمت تور کربلا از اصفهان برای کودکان
         </XLargeHeading>
         <SmallParagraph>
           در حال حاضر تورهای هوایی وجود ندارد در صورت نیاز شما می توانید با سامانه
           رسم زیارت تماس بگیرید و با شرایط درخواستی تان با کارشناسان سفر مشاوره
           داشته باشید.
         </SmallParagraph>
         <XLargeHeading>
           هزینه تور کربلا از اردبیل برای کودک و بزرگسال به چه صورت است؟
         </XLargeHeading>
         <SmallParagraph>
           قیمت تور کربلا از اردبیل هوایی برای کودکان زیر دو سال: ده درصد قیمت تور
           برای بزرگسالان بالای ۱۲ سال است.
         </SmallParagraph>
         <SmallParagraph>
           قیمت تور کربلا از اردبیل زمینی برای کودکان زیر دو سال:  فقط شامل هزینه
           بیمه می باشد.
         </SmallParagraph>
         <SmallParagraph>
           قیمت تور کربلا از اردبیل هوایی و تور کربلا از اردبیل زمینی برای سنین ۲
           تا ۱۲ سال : فقط ۸۰ درصد قیمت تور افراد بزرگسال بالای ۱۲ است.
         </SmallParagraph>
         <SmallParagraph>
           توجه داشته باشید که با وجود این قیمت ها، به کودکان هم مانند بزرگسالان
           خدمات برابر ارائه می شود و هیچ کمبود و کاستی در تور آن ها وجود ندارد.
         </SmallParagraph>
         <XLargeHeading>
           هتل های کربلا، هتل های نجف و هتل های کاظمین کدام هستند؟
         </XLargeHeading>
         <SmallParagraph>
           سایت رسم زیارت هتل های تور های کربلا از اردبیل خود را به این صورت ارائه
           می دهد:
         </SmallParagraph>
         <LargeHeading>بهترین هتل های نجف:</LargeHeading>
         <SmallParagraph>هتل طوی نجف</SmallParagraph>
         <SmallParagraph>هتل مباهله نجف</SmallParagraph>
         <SmallParagraph>هتل نسیم الفرات نجف</SmallParagraph>
         <SmallParagraph>هتل انوار الصادق الامین نجف</SmallParagraph>
         <LargeHeading>بهترین هتل های کربلا:</LargeHeading>
         <SmallParagraph>هتل نورالساطع کربلا</SmallParagraph>
         <SmallParagraph>هتل جنه الکوثر کربلا</SmallParagraph>
         <SmallParagraph>هتل ایلاف الحدیث کربلا</SmallParagraph>
         <LargeHeading>بهترین هتل های کاظمین:</LargeHeading>
         <SmallParagraph>هتل فدک الزهرا کاظمین</SmallParagraph>
         <XLargeHeading>
           تجربه بهترین زیارت عتبات عالیات، با سایت رسم زیارت
         </XLargeHeading>
         <SmallParagraph>
           مردمان ترک زبان اردبیلی عزیز، می توانید برای رزرو تور کربلا از اردبیل،
           با سامانه رسم زیارت تماس حاصل فرمایید؛ تا با مشاوره کارشناسان سفر
           بتوانید با کیفیت ترین و ارزان ترین تور های کربلا از اردبیل را انتخاب
           نمایید.
         </SmallParagraph>

{
    !showAll &&
      <Blur />
}

      <GhostButton 
        title={ showAll ? "بستن" : "مشاهده بیشتر"}
        size="sm"
        color="gray"
        icon={ArrowDownIcon}
        width="180px"
        iconPosition="left"
        onClick={() => {setShowAll(perv => !perv)}}
        className="moreBtn"
      />
    </DescriptionContainer>
    </>
  );
};

export default FromArdabilDescription;
