import { Blur, DescriptionContainer } from "./styles";
import Head from "next/head";
import { useState } from "react";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import { LargeHeading, XLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";

const FromUrmiaDescription = () => {
  const [showAll, setShowAll] = useState(false);
  return (
    <>
      {/* <Head>
        <title>تور کربلا از ارومیه | زمینی - رسم زیارت</title>
        <meta
          name="description"
          content="تور کربلا از ارومیه ⚡ بهترین قیمت با زیارت نجف، کربلا، کاظمین و سامرا | هتل درجه الف نزدیک حرم | پشتیبانی 24 ساعته"
        />
        <link
          rel="canonical"
          href="https://ziarat.co/tours/karbala/from-urmia"
        />
        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
        <meta name="enamad" content="850460"/>
      </Head> */}

      <DescriptionContainer showAll={showAll}>
        <XLargeHeading>راهنمای تور کربلا از ارومیه</XLargeHeading>
        <SmallParagraph>
          سایت رسم زیارت، برای ترک زبانان شهر ارومیه، کاروان های زیارتی کربلا به
          صورت هوایی و زمینی را اجرا می کند تا تمام عاشقان بتوانند این شهرهای
          زیارتی را زیارت کنند.
        </SmallParagraph>
        <XLargeHeading>
          تور کربلا از ارومیه زمینی از چه مرزی امکان پذیر است؟
        </XLargeHeading>
        <SmallParagraph>
          تورهای کربلا از ارومیه زمینی، از مرز مهران اجرا می شود که از طریق
          اتوبوس که جزو خدمات تورهای زمینی است به سمت مهران حرکت می کنند.
        </SmallParagraph>
        <XLargeHeading>تور کربلا از ارومیه هوایی به چه صورت است؟</XLargeHeading>
        <SmallParagraph>
          برای سفر به کربلا پرواز مستقیمی به کربلا وجود ندارد که باید از طریق
          فرودگاه بین المللی شهید باکری ارومیه به نجف انجام می گیرد. .
        </SmallParagraph>
        <XLargeHeading>تور کربلا از ارومیه چند روزه است؟</XLargeHeading>
        <SmallParagraph>
          تورهای کربلا از ارومیه به صورت تورهای  ۷ شب و ۸ روز از طریق هوایی و
          زمینی اجرا می شود. تورهای ۷ شب و ۸ روز به این صورت است : ۳ شب نجف، ۳
          شب کربلا،  ۱شب کاظمین و سامرا به صورت زیارت عبوری است. و یا به صورت ۲
          شب نجف، ۴ شب کربلا،  ۱شب کاظمین اقامت است و سامرا به صورت زیارت عبوری
          است.
        </SmallParagraph>
        <XLargeHeading>قیمت تور کربلا از ارومیه زمینی چگونه است؟</XLargeHeading>
        <SmallParagraph>
          شروع قیمت تورهای کربلا از ارومیه زمینی در سایت رسم زیارت، از 6/266/۰۰۰
          تومان می باشد.
        </SmallParagraph>
        <XLargeHeading>قیمت تور کربلا از ارومیه هوایی چگونه است؟</XLargeHeading>
        <SmallParagraph>
          برای اطلاع از قیمت تورهای کربلا از ارومیه هوایی می توانید با سامانه
          رسم زیارت تماس گرفته تا کارشناسان سفر شما را راهنمایی بفرمایند.
        </SmallParagraph>
        <XLargeHeading>
          هزینه تور کربلا از ارومیه برای کودک و بزرگسال به چه صورت است؟
        </XLargeHeading>
        <SmallParagraph>
          ده درصد قیمت تور برای بزرگسالان بالای ۱۲ سال است.
        </SmallParagraph>
        <SmallParagraph>
          قیمت تور کربلا از ارومیه زمینی برای کودکان زیر دو سال:  فقط شامل هزینه
          بیمه می باشد.
        </SmallParagraph>
        <SmallParagraph>
          قیمت تور کربلا از از ارومیه هوایی برای سنین ۲ تا ۱۲ سال : فقط ۸۰ درصد
          قیمت تور افراد بزرگسال بالای ۱۲ است.
        </SmallParagraph>
        <SmallParagraph>
          در نظر داشته باشید که خدماتی که به کودکان ارائه می شود همانند خدمات
          بزرگسالان است و هیچ تفاوتی در ارائه خدمات وجود ندارد.
        </SmallParagraph>
        <XLargeHeading>
          هتل های کربلا، هتل های نجف و هتل های کاظمین کدام هستند؟
        </XLargeHeading>
        <SmallParagraph>
          هتل های محل اقامت قطعا برای همه زائران حائز اهمیت است. به همین دلیل
          تمامی هتل ها به صورت تایید شده سازمان حج و زیارت است که با بهترین
          کیفیت و بهترین خدمات را ارائه می دهند.
        </SmallParagraph>
        <LargeHeading>بهترین هتل های نجف</LargeHeading>
        <SmallParagraph>هتل انوار الصادق الامین نجف</SmallParagraph>
        <LargeHeading>بهترین هتل های کربلا</LargeHeading>
        <SmallParagraph>هتل نورالساطع کربلا</SmallParagraph>
        <LargeHeading>بهترین هتل های کاظمین</LargeHeading>
        <SmallParagraph>هتل فدک الزهرا کاظمین</SmallParagraph>
        <XLargeHeading>
          سفرهای زیارتی خود را با سامانه رسم زیارت رزرو کنید
        </XLargeHeading>
        <SmallParagraph>
          مردمان ترک زبان عزیز، می توانید برای رزرو تور کربلا از مبدا خود ، با
          سامانه رسم زیارت  تماس حاصل فرمایید.
        </SmallParagraph>

        {!showAll && <Blur />}

        <GhostButton
          title={showAll ? "بستن" : "مشاهده بیشتر"}
          size="sm"
          color="gray"
          icon={ArrowDownIcon}
          width="180px"
          iconPosition="left"
          onClick={() => {
            setShowAll((perv) => !perv);
          }}
          className="moreBtn"
        />
      </DescriptionContainer>
    </>
  );
};

export default FromUrmiaDescription;
