import React from "react";
import { AccordionWrapper } from "./styles";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import ToggleTab from "@/Shared/Kit/ToggleTab";

const FromKarajAccordion = () => {
  const theme = useSelector(selectTheme);

  const toggleItems = [
    {
      id: 1,
      title: "تور کربلا با قطار از کرج چگونه است‌؟",
      description:
        "سفر مستقیم از کرج به کربلا با قطار میسر نیست. سازمان‌ حج و زیارت نیز فقط از شهر مشهد کاروان‌های کربلا با قطار تا کرمانشاه را ارائه کرده است که زائران این کاروان‌ها نیز، باقی مسیر در کشور عراق را با اتوبوس طی می‌کنند.",
    },
    {
      id: 2,
      title: "از کرج تا کربلا با اتوبوس چند ساعت راه است‌؟",
      description:
        "فاصله کرج تا مهران ۷۸۰ کیلومتر و فاصله مهران تا کربلا ۲۸۰ کیلومتر است؛ درمجموع با احتساب توقف در مسیر و مدت زمان عبور از مرز، از کرج تا کربلا با اتوبوس، ۱۸ ساعت راه است.",
    },
    {
      id: 3,
      title: "چه مدارکی برای رزرو تور کربلا از کرج لازم است ؟",
      description: "گذرنامه با حداقل شش ماه اعتبار نیاز است.",
    },
    {
      id: 4,
      title: "خدمات تور کربلا رسم زیارت چیست‌؟",
      description:
        "رسم زیارت به‌عنوان یکی از کارگزاران حج و زیارت، از ۲۲ نقطه کشور کاروان‌های حج و زیارت را در اختیار زائران قرار می‌دهد. از جمله خدمات تور کربلا رسم زیارت : راهنمایی کامل و پشتیبانی از قبل تا پس‌از سفر، بیمه مسافرتی ، اقامت هتل با وعده های غذایی ، زیارت های دوره ای و مداح و مدیر کاروان می باشد. ",
    },
  ];
  return (
    <AccordionWrapper>
      {toggleItems.map((item) => (
        <ToggleTab key={item.id} item={item} name={`name${item.id}`} />
      ))}
    </AccordionWrapper>
  );
};

export default FromKarajAccordion;
