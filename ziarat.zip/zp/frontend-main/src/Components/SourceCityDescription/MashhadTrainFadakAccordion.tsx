import React from "react";
import { AccordionWrapper } from "./styles";
import ToggleTab from "@/Shared/Kit/ToggleTab";

const MashhadTrainFadakAccordion = () => {
  const toggleItems = [
    {
      id: 1,
      title: "آیا امکان لغو یا تغییر تاریخ رزرو وجود دارد؟",
      description:
        "بله، شما می‌توانید تا ۷۲ ساعت قبل از حرکت قطار، درخواست لغو یا تغییر تاریخ بدهید. البته بر اساس قوانین، ممکن است جریمه‌ای اعمال شود.",
    },
    {
      id: 2,
      title: "آیا کودکان زیر ۶ سال نیاز به بلیط جداگانه دارند؟",
      description:
        "خیر، کودکان زیر ۶ سال در صورتی که از صندلی جداگانه استفاده نکنند، نیازی به خرید بلیط ندارند.",
    },
    {
      id: 3,
      title: "امکانات هتل‌های همکار چه مواردی را شامل می‌شود؟",
      description:
        "هتل‌های همکار شامل صبحانه رایگان، اینترنت وای‌فای، سرویس نظافت روزانه و دسترسی به امکانات رفاهی مانند سالن ورزشی و استخر هستند.",
    },
    {
      id: 4,
      title: "آیا در قطار فدک امکان حمل چمدان سنگین وجود دارد؟",
      description:
        "بله، هر مسافر می‌تواند تا ۳۰ کیلوگرم بار به همراه داشته باشد. برای بار اضافی، هزینه جداگانه‌ای دریافت می‌شود.",
    },
    {
      id: 5,
      title: "چگونه می‌توانم از تخفیف‌های ویژه مطلع شوم؟",
      description:
        "شما می‌توانید با کارشناسان آوای سفر تماس بگیرید تا از تخفیف‌های ویژه و پیشنهادات لحظه آخری ما مطلع شوید.",
    },
  ];
  return (
    <AccordionWrapper>
      {toggleItems.map((item) => (
        <ToggleTab key={item.id} item={item} name={`name${item.id}`} />
      ))}
    </AccordionWrapper>
  );
};

export default MashhadTrainFadakAccordion;
