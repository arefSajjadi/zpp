import { Blur, DescriptionContainer } from "./styles";
import Head from "next/head";
import { useState } from "react";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import { LargeHeading, XLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";

const FromQazvinDescription = () => {
  const [showAll, setShowAll] = useState(false);
  return (
    <>
      {/* <Head>
      <title>تور کربلا از قزوین | زمینی - رسم زیارت</title>
        <meta name="description" content="تور کربلا از قزوین ⚡ اقامت در هتل های درجه الف | بهترین خدمات به همراه مدیر و مداح ❗زیرنظر سازمان حج و زیارت"  />
        <link rel="canonical" href="https://ziarat.co/tours/karbala/from-qazvin"/>
        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
        <meta name="enamad" content="850460"/>
      </Head> */}

      <DescriptionContainer showAll={showAll}>
      <XLargeHeading>
         
         راهنمای تور کربلا از قزوین
         </XLargeHeading>
         <SmallParagraph>
           شهر قزوین نیز یکی دیگر از شهرهای با تمدن و کهن ایران است که دسترسی کربلا
           از قزوین بپردازند؛ و اهل بیت را زیارت نمایند. در ادامه به شرایط خوبی به
           شهرهای شمالی، جنوبی و غربی دارد. این شهر بناهای تاریخی زیادی از جمله
           قلعه تاریخی الموت را در خود جای داده است. مردم این شهر، به زبان پارسی و
           با کمی لهجه قزوینی به صحبت می پردازند. افراد مذهبی زیادی در شهر قزوین
           وجود دارد که سعی می کنند حداقل سالی یک بار را به سفرهای زیارتی چون تور و
           اطلاعات تورهای کربلا از قزوین، از جمله: تورهای کربلا از قزوین، قیمت
           تورهای کربلا از قزوین، تور اقساطی کربلا از قزوین، تور اقتصادی کربلا از
           قزوین و … می پردازیم؛ و شما قزوینی های عزیز را برای سفر با تور کربلا از
           قزوین آماده نماییم.
         </SmallParagraph>
         <XLargeHeading>
           تور کربلا از قزوین، از چه مرزهایی انجام می شود؟
         </XLargeHeading>
         <SmallParagraph>
           تور کربلا از قزوین زمینی ، از مرز مهران اجرا شده؛ و شما با با ترانسفر،
           به سمت مرز مهران رفته و سپس وارد خاک عراق می شوید.
         </SmallParagraph>
         <XLargeHeading>تور کربلا از قزوین چند روز است؟</XLargeHeading>
         <SmallParagraph>
           در حال حاضر، تورهای کربلا از قزوین به صورت ۶ شب و ۷ روزه و همچنین ۷ شب و
           ۸ روزه برگزار می شوند.
         </SmallParagraph>
         <XLargeHeading>
           با رزرو تور کربلا از قزوین به چه شهرهایی می رویم؟
         </XLargeHeading>
         <SmallParagraph>
           شما در تور ۶ شب و ۷ روز قزوین به کربلا، ۳ شب در نجف، ۳ شب کربلا و به
           صورت عبوری نیز در کاظمین و سامرا اقامت خواهید کرد؛ اما در تور ۷ شب و ۸
           روزه کربلا به قزوین، شما ۳ شب در نجف، ۳ شب در کربلا، ۱ شب کاظمین و به
           صورت عبوری در سامرا اقامت می کنید.
         </SmallParagraph>
         <XLargeHeading>قیمت تور کربلا از قزوین زمینی</XLargeHeading>
         <SmallParagraph>
           شروع قیمت تور کربلا از قزوین زمینی در سامانه زیارت از ۵/۵۴۸/۰۰۰ تومان می
           باشد.
         </SmallParagraph>
         <XLargeHeading>قیمت تور کربلا از قزوین هوایی</XLargeHeading>
         <SmallParagraph>
           شروع قیمت تور کربلا از قزوین هوایی ۷ شب و ۸ روزه در سایت زیارت، از
           ۱۱/۴۰۰/۰۰۰ تومان می باشد؛ برای رزرو تور کربلا از قزوین با هواپیما، به
           وبسایت زیارت مراجعه فرمایید.
         </SmallParagraph>
         <XLargeHeading>
           قیمت تور کربلا از قزوین برای خردسالان
         </XLargeHeading>
         <SmallParagraph>
           قیمت تور کربلا از قزوین برای سنین ۲ تا ۱۲ سال: تنها شامل ۸۰ درصد نرخ
           بزرگسالان.
         </SmallParagraph>
         <SmallParagraph>
           قیمت تور کربلا از قزوین زمینی برای سنین زیر ۲ سال: کاملا رایگان.
         </SmallParagraph>
         <SmallParagraph>
           قیمت تور کربلا از قزوین هوایی برای کودکان در سنین زیر ۲ سال: تنها ۱۰
           درصد نرخ تور بزرگسالان.
         </SmallParagraph>
         <SmallParagraph>
           برای اطلاع از قیمت تور کربلا ، با ما در تماس باشید.
         </SmallParagraph>
         <XLargeHeading>
           هتل های کربلا، هتل های نجف و کاظمین، در تور کربلا از قزوین
         </XLargeHeading>
         <LargeHeading>بهترین هتل های نجف در تور کربلا از قزوین</LargeHeading>
         <SmallParagraph>
            هتل فصول نجف، هتل ام ابیها
           نجف، هتل دیار کریم نجف و هتل نسیم الفرات نجف.
         </SmallParagraph>
         <SmallParagraph>
            هتل بدرالهواشم
           کربلا، هتل رضوان کربلا، هتل نهرالجنه کربلا و هتل جنه الکوثر کربلا.
         </SmallParagraph>
         <LargeHeading>بهترین هتل های کاظمین در تور کربلا از قزوین</LargeHeading>
         <SmallParagraph>
           هتل فدک الزهرا کاظمین، هتل
           زهره المصطفی کاظمین و هتل تاج کاظمین.
         </SmallParagraph>
         <XLargeHeading>رزرو تور کربلا از قزوین با زیارت</XLargeHeading>
         <SmallParagraph>
           اگر قزوینی هستید و قصد سفر با تور کربلا از قزوین را دارید، به شما
           اطمینان می دهیم رزرو تور از ما برای شما بسیار سودمند خواهد بود.
           کارشناسان ما با بررسی خواسته ها و شرایط شما، بهترین تورهای کربلا از
           قزوین را تقدیم حضور شما می کنند.
         </SmallParagraph>

        {!showAll && <Blur />}

        <GhostButton
          title={showAll ? "بستن" : "مشاهده بیشتر"}
          size="sm"
          color="gray"
          icon={ArrowDownIcon}
          width="180px"
          iconPosition="left"
          onClick={() => {
            setShowAll((perv) => !perv);
          }}
          className="moreBtn"
        />
      </DescriptionContainer>
    </>
  );
};

export default FromQazvinDescription;
