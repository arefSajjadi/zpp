import React from "react";
import { AccordionWrapper } from "./styles";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import ToggleTab from "@/Shared/Kit/ToggleTab";

const KarbalaGroundAccordion = () => {
  const theme = useSelector(selectTheme);

  const toggleItems = [
    {
      id: 1,
      title: "تور زمینی کربلا رسم زیارت از کدام شهرها اجرا می‌شود؟",
      description: `تورهای زمینی ما از شهرهای مختلفی مانند تهران، مشهد، تبریز، اصفهان، شیراز، اهواز، کرمانشاه و بسیاری از شهرهای دیگر برگزار می‌شود. برای اطلاع از جزئیات بیشتر با کارشناسان ما تماس بگیرید.`,
    },
    {
      id: 2,
      title: "مدت زمان سفر زمینی به کربلا چقدر است؟",
      description: `بسته به مبدا حرکت و نوع تور، مدت زمان سفر متفاوت است. تورهای ۳ روزه، ۴ روزه و ۵ روزه از گزینه‌های موجود هستند که می‌توانید متناسب با برنامه خود انتخاب کنید.`,
    },
    {
      id: 3,
      title: "آیا در تورهای زمینی امکان توقف در شهرهای دیگر عراق وجود دارد؟",
      description: `بله، اکثر تورهای زمینی شامل توقف در شهرهای مقدس مسیر مانند نجف، کاظمین و سامرا هستند. برنامه دقیق هر تور را می‌توانید از کارشناسان ما دریافت کنید.`,
    },
  ];
  return (
    <AccordionWrapper>
      {toggleItems.map((item) => (
        <ToggleTab key={item.id} item={item} name={`name${item.id}`} />
      ))}
    </AccordionWrapper>
  );
};

export default KarbalaGroundAccordion;
