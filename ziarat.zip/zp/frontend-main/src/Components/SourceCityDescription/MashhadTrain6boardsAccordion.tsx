import React from "react";
import { AccordionWrapper } from "./styles";
import ToggleTab from "@/Shared/Kit/ToggleTab";

const MashhadTrain6boardsAccordion = () => {
  const toggleItems = [
    {
      id: 1,
      title: "آیا در قطارهای ۶ تخته مشهد، امکان انتخاب همسفر وجود دارد؟",
      description:
        "خیر، در قطارهای ۶ تخته شما نمی‌توانید همسفران خود را انتخاب کنید. اگر به صورت گروهی سفر می‌کنید، بهتر است تمام ۶ جای کوپه را رزرو کنید تا با هم باشید.",
    },
    {
      id: 2,
      title: "چند ساعت قبل از حرکت قطار باید در ایستگاه حاضر شوم؟",
      description:
        "توصیه می‌شود حداقل یک ساعت قبل از حرکت قطار در ایستگاه حاضر شوید. این زمان برای انجام تشریفات و پیدا کردن واگن و کوپه خود کافی است.",
    },
    {
      id: 3,
      title: "تفاوت تور فولبرد با تور معمولی چیست؟",
      description:
        "در تور معمولی فقط صبحانه سرو می‌شود اما در تور فولبرد هر سه وعده غذایی شامل صبحانه، ناهار و شام در هتل برای شما فراهم است.",
    },
    {
      id: 4,
      title: "آیا امکان کنسلی تور مشهد با قطار 6 تخته وجود دارد؟",
      description:
        "بله، اما بسته به زمان کنسلی، جریمه‌ای از مبلغ پرداختی کسر خواهد شد. هرچه زودتر تور را کنسل کنید، جریمه کمتری پرداخت می‌کنید. قوانین دقیق را از مشاوران رسم سفر بپرسید.",
    },
  ];
  return (
    <AccordionWrapper>
      {toggleItems.map((item) => (
        <ToggleTab key={item.id} item={item} name={`name${item.id}`} />
      ))}
    </AccordionWrapper>
  );
};

export default MashhadTrain6boardsAccordion;
