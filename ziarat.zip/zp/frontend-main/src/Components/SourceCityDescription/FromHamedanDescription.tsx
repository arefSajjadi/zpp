import { Blur, DescriptionContainer } from "./styles";
import Head from "next/head";
import { useState } from "react";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import { LargeHeading, XLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";

const FromHamedanDescription = () => {
  const [showAll, setShowAll] = useState(false);
  return (
    <>
      {/* <Head>
        <title>تور کربلا از همدان | زمینی - رسم زیارت</title>
        <meta
          name="description"
          content="تور کربلا از همدان ⚡ تضمین بهترین قیمت ❗ بهترین خدمات سفر: اقامت در هتل نزدیک حرم + ترانسفر + بیمه مسافرتی | زیرنظر سازمان حج و زیارت"
        />
        <link
          rel="canonical"
          href="https://ziarat.co/tours/karbala/from-hamedan"
        />
        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
        <meta name="enamad" content="850460"/>
      </Head> */}

      <DescriptionContainer showAll={showAll}>
        <XLargeHeading>راهنمای تور کربلا از همدان</XLargeHeading>
        <SmallParagraph>
          همیشه مردم مسلمان و شیعه ایرن، استقبال گرمی از تورهای زیارتی دارند؛
          تور کربلا از همدان هم یکی از این تورهای زیارتی پر طرفدار است؛ و هرساله
          از مبدا همدان نیز، تعداد زیادی رزرو برای تورهای کربلا از همدان داریم.
          در این مطلب به شرایط و چگونگی تور کربلا از همدان، مثل قیمت تور کربلا
          از همدان، قیمت تور کربلا از همدان زمینی، هتل های کربلا از همدان و … می
          پردازیم؛ تا همدانی های عزیز بتوانند بدون دردسر و با آشنایی کامل، رزرو
          تور کربلا از همدان را انجام دهند.
        </SmallParagraph>
        <XLargeHeading>
          تور کربلا از همدان، از طریق چه مرزی راحت تر است؟
        </XLargeHeading>
        <SmallParagraph>
          تورکربلا از همدان زمینی، از طریق مرز مهران انجام می شود؛ زیرا استان
          همدان به شهرستان مهران بسیار نزدیک می باشد شما پس از طی کردن حدودا ۳
          ساعت به مرز مهران می رسید و پس از تحویل گذرنامه، وارد خاک عراق می
          شوید.
        </SmallParagraph>
        <XLargeHeading>تور کربلا از همدان چند روزه است؟</XLargeHeading>
        <SmallParagraph>
          در حال حاضر همه تورهای کربلا از همدان به صورت 7 شب و 8 روز انجام می
          شوند.
        </SmallParagraph>
        <XLargeHeading>
          با رزرو تور کربلا از همدان، در کدام شهرها اقامت می کنیم؟
        </XLargeHeading>
        <SmallParagraph>
          شما همدانی های عزیز، بعد از رزرو تور کربلا از همدان ۶ شب و ۷ روزه خود،
          ۳ شب در نجف اشرف، ۳ شب در کربلای معلی و به صورت عبوری در کاظمین سامرا
          اقامت خواهید کرد.
        </SmallParagraph>
        <XLargeHeading>قیمت تور زمینی کربلا از همدان</XLargeHeading>
        <SmallParagraph>
          شروع قیمت تور کربلا از همدان زمینی در سایت زیارت، از 6/000/۰۰۰ تومان
          می باشد. برای رزرو تور کربلا از همدان زمینی با قطار و اتوبوس، با
          کارشناسان سفر سامانه رسم زیارت تماس بگیرید.
        </SmallParagraph>
        <XLargeHeading>قیمت تور کربلا از همدان هوایی</XLargeHeading>
        <SmallParagraph>
          متاسفانه در حال حاضر هیچ تور کربلا از همدان به صورت هوایی در سایت ها
          موجود نمی باشد؛ اما می توانید با مراجعه به سایت رسم زیارت یا تماس با
          ما، از به روز رسانی موجودی تور کربلا از همدان هوایی، مطلع شوید.
        </SmallParagraph>
        <XLargeHeading>
          قیمت تور کربلا از همدان زمینی و هوایی برای خردسالان
        </XLargeHeading>
        <SmallParagraph>
          قیمت تور کربلا از همدان زمینی و هوایی برای خردسال ۲ تا ۱۲ سال: نرخ
          بلیط برای سنین ۲ تا ۱۲، تنها ۸۰ درصد نرخ بلیط تور کربلا از همدان
          بزرگسالان می باشد. قیمت تور کربلا از همدان هوایی برای نوزاد تا ۲ سال:
          نرخ بلیط برای این دسته از افراد، تنها ۱۰ درصد قیمت بلیط بزرگسالان است.
          قیمت تور کربلا از همدان زمینی برای نوزاد تا ۲ سال: برای نوزادان و
          کودکان تا دوسال رایگان می باشد.
        </SmallParagraph>
        <XLargeHeading>
          هتل های کربلا، هتل های نجف و هتل های کاظمین کدامند؟
        </XLargeHeading>
        <LargeHeading>بهترین هتل های نجف در تور کربلا از همدان</LargeHeading>
        <SmallParagraph>
          هتل ایوان نجف، هتل  الدله نجف و هتل مباهله نجف.
        </SmallParagraph>
        <LargeHeading>بهترین هتل های کاظمین در تورکربلا از همدان</LargeHeading>
        <SmallParagraph>
          هتل زهره المصطفی کاظمین، هتل تاج کاظمین و هتل دُر قصر الکاظمیه کاظمین.
        </SmallParagraph>
        <LargeHeading>بهترین هتل های کربلا در تورکربلا از همدان</LargeHeading>
        <SmallParagraph>
          هتل جبل المروه کربلا، هتل رضوان کربلا و هتل ایلاف الحدیث کربلا.
        </SmallParagraph>
        <XLargeHeading>رزرو تور کربلا از همدان با سایت رسم زیارت</XLargeHeading>
        <SmallParagraph>
          سامانه رسم زیارت که اولین و بزرگترین سایت فروش تورهای زیارتی در ایران
          می باشد، بهترین تورهای کربلا از همدان را با بهترین شرایط و طبق خواسته
          تان، به شما همدانی های عزیز ارائه می کند. برای رزرو تور کربلا از همدان
          با ما تماس بگیرید.
        </SmallParagraph>

        {!showAll && <Blur />}

        <GhostButton
          title={showAll ? "بستن" : "مشاهده بیشتر"}
          size="sm"
          color="gray"
          icon={ArrowDownIcon}
          width="180px"
          iconPosition="left"
          onClick={() => {
            setShowAll((perv) => !perv);
          }}
          className="moreBtn"
        />
      </DescriptionContainer>
    </>
  );
};

export default FromHamedanDescription;
