import { Blur, DescriptionContainer } from "./styles";
import Head from "next/head";
import { useState } from "react";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import { LargeHeading, XLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";

const FromRashtDescription = () => {
  const [showAll, setShowAll] = useState(false);
  return (
    <>
      {/* <Head>
        <title>تور کربلا از رشت | زمینی - رسم زیارت</title>
        <meta
          name="description"
          content="تور کربلا از رشت ⚡ اقامت هتل 4 ستاره و 5 ستاره نزدیک حرم | اقامت 7 شب | زیر نظر سازمان حج و زیارت | پشتیبانی 24 ساعته"
        />
        <link
          rel="canonical"
          href="https://ziarat.co/tours/karbala/from-rasht"
        />
        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
        <meta name="enamad" content="850460"/>
      </Head> */}

      <DescriptionContainer showAll={showAll}>
        <XLargeHeading>راهنمای تور کربلا از رشت</XLargeHeading>
        <SmallParagraph>
          رشت شهری زیبا و سرسبز در استان گیلان است. این شهر افراد مذهبی و معتقد
          زیادی دارد که هر سال در زمان های مختلف از سال به سفرهای زیارتی از جمله
          تور کربلا از رشت می پردازند. در ادامه این مطلب از سامانه زیارت، به
          چگونگی و شرایط تورهای کربلا از رشت، اعم از: قیمت تور کربلا از رشت، هتل
          های تور کربلا از رشت می پردازیم؛ تا شما رشتی های دوست داشتنی، سفری
          آگاهانه و معنوی به کربلا معلی و نجف اشرف داشته باشید.
        </SmallParagraph>
        <XLargeHeading>
          تور کربلا از رشت زمینی، از طریق چه مرزهایی انجام می پذیرد؟
        </XLargeHeading>
        <SmallParagraph>
          تور کربلا از رشت زمینی، از طریق مرز مهران انجام می پذیرد و شما با
          استفاده از اتوبوس ویژه تور کربلا از رشت با اتوبوس، به سمت این مرز حرکت
          می کنید و بعد از چند ساعت به کشور عراق خواهید رسید.
        </SmallParagraph>
        <XLargeHeading>تور کربلا از رشت چند روزه است؟</XLargeHeading>
        <SmallParagraph>
          جواب این سوال نیز به مدت زمان تور شما بستگی دارد. در تور ۷ شب و و ۸
          روزه کربلا از رشت، شما عزیزان ۳ شب در کربلا، ۳ شب در نجف، ۱ شب در
          کاظمین و به صورت عبوری در سامرا اقامت خواهید داشت؛ البته ممکن است یک
          روز جا به جایی اتفاق افتد.
        </SmallParagraph>
        <XLargeHeading>
          با رزرو تور کربلا از رشت، از چه جاهایی بازدید می کنیم؟
        </XLargeHeading>
        <SmallParagraph>
          در تور کربلا از رشت سایت زیارت، شما از حرم امام حسین (ع)، حضرت عباس
          (ع)، امام علی (ع)، امام موسی کاظم (ع)، مسجد کوفه، مسجد سهله، موزه امام
          حسین و موزه حضرت ابوالفضل (ع)، خیمه گاه اهل بیت (س)، آرامگاه طفلان
          مسلم، مسجد حنانه، آرامگاه سید محمد، تل زنبیه بازدید خواهید کرد.
        </SmallParagraph>
        <XLargeHeading>قیمت تور کربلا از رشت زمینی</XLargeHeading>
        <SmallParagraph>
          شروع قیمت تور کربلا از رشت زمینی در سایت زیارت زیر نظر سازمان حج و
          زیارت، از ۶/۵۷۸/۰۰۰ تومان می باشد. برای رزرو تور کربلا ارزان از رشت با
          کاروان، با کانترهای سامانه زیارت تماس بگیرید.
        </SmallParagraph>
        <XLargeHeading>قیمت تور کربلا از رشت هوایی</XLargeHeading>
        <SmallParagraph>
          شروع قیمت تور کربلا از رشت به صورت هوایی در سایت زیارت زیر نظر سازمان
          حج و زیارت، از ۱۳/۰۰۰/۰۰۰ تومان می باشد. برای رزرو تور کربلا ارزان از
          رشت با کاروان، با کانترهای سامانه زیارت تماس بگیرید
        </SmallParagraph>
        <XLargeHeading>
          قیمت تور کربلا از رشت برای کودکان و بزرگسالان
        </XLargeHeading>
        <SmallParagraph>
          قیمت تور کربلا از رشت برای خردسالان ۲ تا ۱۲ سال: تنها ۸۰ درصد نرخ تور
          بزرگسالان است.
        </SmallParagraph>
        <SmallParagraph>
          قیمت تور کربلا از رشت زمینی برای کودکان زیر دو سال: تنها شامل پرداخت
          هزینه بیمه است.
        </SmallParagraph>
        <XLargeHeading>
          هتل های کربلا، هتل های نجف و هتل های کاظمین در تور کربلا از رشت
        </XLargeHeading>
        <SmallParagraph>
          سامانه زیارت در تورهای عتبات و عالیات خود، بهترین هتل ها را ارائه می
          دهد، تا اقامتی خوش را برای زائرین محترم رقم بزند.
        </SmallParagraph>
        <LargeHeading>بهترین هتل های کربلا در تور کربلا از رشت </LargeHeading>
        <SmallParagraph>
          هتل برج الریاحین کربلا، هتل جنه الهدی کربلا و هتل جابر کربلا.
        </SmallParagraph>
        <LargeHeading>بهترین هتل های کاظمین در تور کربلا از رشت </LargeHeading>
        <SmallParagraph>
          هتل سراج المنیر کاظمین، هتل فدک الزهرا کاظمین و هتل قصر الکاظمیه
          کاظمین.
        </SmallParagraph>
        <SmallParagraph>هتل فدک الزهرا کاظمین</SmallParagraph>
        <LargeHeading>بهترین هتل های نجف در تور کربلا از رشت </LargeHeading>
        <SmallParagraph>
          هتل نور العباس نجف، هتل السامی نجف و هتل زمزم نجف.
        </SmallParagraph>
        <XLargeHeading>رزرو تور کربلا از رشت ارزان با سایت زیارت</XLargeHeading>
        <SmallParagraph>
          سامانه زیارت که زیر نظر سازمان حج و زیارت می باشد، بهترین و ارزان ترین
          تورهای کربلا از رشت را به مسافرین تحویل می دهد. برای رزرو تور کربلا از
          رشت با کاروان، و کسب اطلاعات بیشتر از این نوع تور، با کانترهای سامانه
          زیارت تماس حاصل فرمایید.
        </SmallParagraph>

        {!showAll && <Blur />}

        <GhostButton
          title={showAll ? "بستن" : "مشاهده بیشتر"}
          size="sm"
          color="gray"
          icon={ArrowDownIcon}
          width="180px"
          iconPosition="left"
          onClick={() => {
            setShowAll((perv) => !perv);
          }}
          className="moreBtn"
        />
      </DescriptionContainer>
    </>
  );
};

export default FromRashtDescription;
