import React from "react";
import { AccordionWrapper } from "./styles";
import ToggleTab from "@/Shared/Kit/ToggleTab";

const FromQomAccordion = () => {
  const toggleItems = [
    {
      id: 1,
      title: "کیفیت هتل ها در تورهای کربلا از قم چگونه است؟",
      description:
        "هتل‌های متنوعی، از ۵ ستاره تا گزینه‌های درجه ۳ و ارزان در کاروان‌های کربلا از قم دیده می‌شود؛ با این حال، جهت پایین آمدن هزینه‌ها، هتل‌های اقتصادی زیادی در میان گزینه‌های انتخابی زائران وجود دارد.",
    },
    {
      id: 2,
      title: "تور کربلا از قم اقساطی چگونه است ؟",
      description:
        "شرایط پرداخت قسطی در رسم زیارت، اخیراً در دسترس زائران قرار گرفته است؛ البته این شرایط تورهای اقساطی در ایام مختلف سال متفاوت است؛ از این رو بهتر است برای اطلاع از آخرین وضعیت برگزاری تور کربلا از قم اقساطی، با کارشناسان رسم زیارت تماس بگیرید.",
    },
  ];
  return (
    <AccordionWrapper>
      {toggleItems.map((item) => (
        <ToggleTab key={item.id} item={item} name={`name${item.id}`} />
      ))}
    </AccordionWrapper>
  );
};

export default FromQomAccordion;
