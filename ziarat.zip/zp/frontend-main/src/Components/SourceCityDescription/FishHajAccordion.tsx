import React from "react";
import { AccordionWrapper } from "./styles";
import { LargeDisplay } from "@/Shared/Kit/Typography/Display";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import ToggleTab from "@/Shared/Kit/ToggleTab";
import Pattern from "@/Components/Pattern";
import LeftPattern from "@/Assets/Icons/LeftPattern";
import { SUPPORT_PHONE } from "@/config/constants";

const FishHajAccordion = () => {
  const theme = useSelector(selectTheme);

  const toggleItems = [
    {
      id: 1,
      title: "قیمت فیش حج چقدر است ؟",
      description: `قیمت فیش حج به نوع آن یعنی عمره و یا تمتع بودن آن بستگی دارد. همچنین الویت های بالاتر یعنی 1 تا 300 در عمره و قبل از سال 86 در تمتع قیمت بالاتری نسبت به سایر الویت ها دارد. جهت اطلاع دقیق از قیمت فیش خود با شماره ${SUPPORT_PHONE} تماس حاصل فرمایید`,
    },
    {
      id: 2,
      title: "مدارک لازم برای نقل و انتقال فیش حج ؟",
      description: `شما برای نقل و انتقال فیش حج به اصل کارت ملی، شناسنامه، مدارک محل سکونت انتقال دهنده و انتقال گیرنده نیاز دارید و فرایند نقل و انتقال آن در دفاتر زیارتی تحت نظر سازمان حج مانند پلتفرم رسم زیارت به صورت حضوری قابل انجام است.`,
    },
  ];
  return (
    <AccordionWrapper>
      {toggleItems.map((item) => (
        <ToggleTab key={item.id} item={item} name={`name${item.id}`} />
      ))}
    </AccordionWrapper>
  );
};

export default FishHajAccordion;
