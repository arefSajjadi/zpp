import { Blur, DescriptionContainer } from "./styles";
import Head from "next/head";
import { useState } from "react";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import { LargeHeading, XLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";

const FromYasojDescription = () => {
  const [showAll, setShowAll] = useState(false);
  return (
    <>
      {/* <Head>
        <title>تور کربلا از یاسوج | زمینی - رسم زیارت</title>
        <meta
          name="description"
          content="تور کربلا از یاسوج ⚡ زیارت کربلا، نجف، کاظمین و سامرا | پشتیبانی 24 ساعته ❗ زیرنظر سازمان حج و زیارت | شماره تماس :4300109 -021"
        />
        <link
          rel="canonical"
          href="https://ziarat.co/tours/karbala/from-yasuj"
        />
        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
          <meta name="enamad" content="850460"/>
      </Head> */}

      <DescriptionContainer showAll={showAll}>
        <XLargeHeading>راهنمای تور کربلا از یاسوج</XLargeHeading>
        <SmallParagraph>
          مردمان یاسوج همانند مردمان دیگر شهر های ایران همواره به شهر های زیارتی
          کربلا و نجف و کاظمین ؛ در ایام مناسبتی و یا در ایام اربعین و محرم سفر
          می کنند.
        </SmallParagraph>
        <XLargeHeading>
          از چه مرزهایی تور کربلا از یاسوج امکان پذیر است؟
        </XLargeHeading>
        <SmallParagraph>
          تور کربلا دو سر زمینی از طریق مرز شلمچه انجام می گیرد که از طریق
          اتوبوس هایی که جزو خدمات تور .می باشد صورت می گیرد
        </SmallParagraph>
        <XLargeHeading>
          رزرو تورکربلا از یاسوج هوایی، به چه صورت است؟
        </XLargeHeading>
        <SmallParagraph>
          فرودگاه بین المللی یاسوج، پرواز مستقیمی به کربلا وجود ندارد. برای همین
           تمام پروازها از یاسوج به نجف صورت می گیرد.
        </SmallParagraph>
        <XLargeHeading>تور کربلا از یاسوج چند روزه است ؟</XLargeHeading>
        <SmallParagraph>
          مدت اقامت تور کربلا از یاسوج به صورت ۷ شب و ۸ روز است. تعداد شب های
          اقامت در شهر های نجف و کربلا به شرایط تور و تاریخ تور بستگی دارد؛
          معمولا در  بیشتر تورها ۳شب نجف و ۳ شب کربلا ۱شب کاظمین  اقامت دارد و
           زیارت سامرا هم به صورت عبوری است.
        </SmallParagraph>
        <XLargeHeading>
          قیمت تور کربلا از یاسوج زمینی به چه صورت است؟
        </XLargeHeading>
        <SmallParagraph>
          شروع قیمت تورهای کربلا از یاسوج زمینی در اسفند ماه از 5/600/۰۰۰ تومان
          است.
        </SmallParagraph>
        <XLargeHeading>قیمت تور کربلا از تبریز هوایی چقدر است؟</XLargeHeading>
        <SmallParagraph>
          ارزان ترین قیمت تور کربلا از تبریز هوایی از ۱۲/۳۷۰/۰۰۰ شروع می شود.
        </SmallParagraph>
        <XLargeHeading>
          قیمت تور کربلا از یاسوج برای کودکان و خردسالان به چه صورت است؟
        </XLargeHeading>
        <SmallParagraph>
          تور کربلا از یاسوج برای کودکان ۲ تا ۱۲ سال : ۸۰ درصد هزینه بزرگسالان
          را شامل می شود.
        </SmallParagraph>
        <SmallParagraph>
          تور کربلا از یاسوج زمینی برای کودکان زیر ۲ سال: فقط شامل هزینه بیمه می
          شود.
        </SmallParagraph>
        <SmallParagraph>
          تور کربلا از یاسوج هوایی برای کودکان زیر ۲ سال:  تنها ۱۰ درصد قیمت تور
          هوایی بزرگسالان را شامل می شود.
        </SmallParagraph>
        <XLargeHeading>
          هتل های کربلا، هتل های کاظمین و هتل های نجف تور کربلا از یاسوج:
        </XLargeHeading>
        <SmallParagraph>
          سایت رسم زیارت همواره در کاروان های زمینی و هوایی کربلا؛ هتل های درجه
          یک را تدارک دیده است. که تمامی هتل ها خدمات زیادی را برای زائرین فراهم
          می کنند.
        </SmallParagraph>
        <LargeHeading> بهترین هتل های کاظمین </LargeHeading>
        <SmallParagraph>
          هتل بستان نجف، هتل خیام نجف، هتل اسطوره نجف
        </SmallParagraph>
        <LargeHeading> بهترین هتل های نجف </LargeHeading>
        <SmallParagraph>هتل الماس نجف ,هتل ورده النجف نجف</SmallParagraph>
        <LargeHeading> بهترین هتل های کربلا </LargeHeading>
        <SmallParagraph> هتل صفار کربلا، هتل شمس کربلا</SmallParagraph>
        <XLargeHeading>رزرو تور کربلا از یاسوج</XLargeHeading>
        <SmallParagraph>
          مردمان عزیز شهر یاسوج می توانند تور کربلا از یاسوج را از سایت رسم
          زیارت رزرو کنند و همچنین می توانند با تماس با سایت رسم زیارت از
          راهنمایی و مشاوره کارشناسان بهره مند شوند.
        </SmallParagraph>

        {!showAll && <Blur />}

        <GhostButton
          title={showAll ? "بستن" : "مشاهده بیشتر"}
          size="sm"
          color="gray"
          icon={ArrowDownIcon}
          width="180px"
          iconPosition="left"
          onClick={() => {
            setShowAll((perv) => !perv);
          }}
          className="moreBtn"
        />
      </DescriptionContainer>
    </>
  );
};

export default FromYasojDescription;
