import { Blur, DescriptionContainer } from "./styles";
import Head from "next/head";
import { useState } from "react";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import { LargeHeading, XLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";

const FromSemnanDescription = () => {
  const [showAll, setShowAll] = useState(false);
  return (
    <>
      {/* <Head>
        <title>تور کربلا از سمنان | زمینی - رسم زیارت</title>
        <meta
          name="description"
          content="تور کربلا از سمنان ⚡ بهترین خدمات سفر : اقامت هتل درجه الف ❗ زیارت دوره +بیمه مسافرتی +ترانسفر + مداح و مدیر"
        />
        <link
          rel="canonical"
          href="https://ziarat.co/tours/karbala/from-semnan"
        />
        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
        <meta name="enamad" content="850460"/>
      </Head> */}

      <DescriptionContainer showAll={showAll}>
        <XLargeHeading>راهنمای تور کربلا از سمنان</XLargeHeading>
        <SmallParagraph>
          استان سمنان یکی از استان های مذهبی کشور است که هر ساله در ایام محرم و
          یا اربعین جمعیت زیادی از این استان راهی کربلا می شوند. سفرهای زیارتی
          بسیاری از شهر سمنان به کربلا انجام می شود. سایت زیارت ؛ تورهای کربلا
          از سمنان هوایی و زمینی را برای مردمان این شهر اجرا می کند.
        </SmallParagraph>
        <XLargeHeading>
          از چه مرزهایی تور کربلا از سمنان امکان پذیر است؟
        </XLargeHeading>
        <SmallParagraph>
          تور کربلا دو سر زمینی از طریق مرز مهران انجام می گیرد که از طریق
          اتوبوس هایی که جزو خدمات تور می باشد صورت می گیرد.
        </SmallParagraph>
        <XLargeHeading>
          رزرو تورکربلا از سمنان هوایی، به چه صورت است؟
        </XLargeHeading>
        <SmallParagraph>
          تور کربلا از سمنان هوایی از طریق فرودگاه سمنان قابل اجرا می باشد.
        </SmallParagraph>
        <XLargeHeading>
          مدت اقامت در تور کربلا از سمنان به چه صورت است؟
        </XLargeHeading>
        <SmallParagraph>
          مدت اقامت تور کربلا از سمنان به صورت ۷ شب و ۸ روز است.
        </SmallParagraph>
        <SmallParagraph>
          تعداد شب های اقامت در شهر های نجف و کربلا بستگی به تاریخ تور دارد که
          معمولا در بعضی تورها ۳شب نجف و ۳ شب کربلا ۱شب کاظمین و سامرا هم به
          صورت
        </SmallParagraph>
        <SmallParagraph>
          عبوری است ولی در بعضی تورهای دیگر ۴ شب نجف و ۳ شب اقامت است و زیارت
          کاظمین و سامرا به صورت عبوری است .
        </SmallParagraph>
        <XLargeHeading>قیمت تور کربلا از سمنان زمینی</XLargeHeading>
        <SmallParagraph>
          شروع قیمت کاروان های کربلا از سمنان زمینی از ۶/۴۱۸/۰۰۰ تومان است. لازم
          به ذکر است که قیمت ها در ایام مناسبتی متفاوت می باشد.
        </SmallParagraph>
        <XLargeHeading>قیمت تور کربلا از سمنان هوایی</XLargeHeading>
        <SmallParagraph>
          شروع قیمت تور های کربلا از سمنان هوایی از ۱۱/۳۹۵/۰۰۰ تومان می باشد.
        </SmallParagraph>
        <XLargeHeading>
          قیمت تور کربلا از سمنان برای کودکان و خردسالان چگونه محاسبه می شود؟
        </XLargeHeading>
        <SmallParagraph>
          معمولا برای تورهای هوایی و زمینی برای کودکان ۲ تا ۱۲ سال به این صورت
          است که ۸۰ درصد هزینه بزرگسالان را شامل می شود.
        </SmallParagraph>
        <SmallParagraph>
          قیمت تور کربلا از سمنان زمینی برای کودکان زیر ۲ سال: فقط شامل هزینه
          بیمه می شود.
        </SmallParagraph>
        <SmallParagraph>
          قیمت تور کربلا هوایی برای کودکان زیر ۲ سال: به این صورت است که تنها ۱۰
          درصد قیمت تور هوایی بزرگسالان را شامل می شود.
        </SmallParagraph>
        <XLargeHeading>
          هتل های کربلا، هتل های کاظمین و هتل های نجف تور کربلا از سمنان:
        </XLargeHeading>
        <SmallParagraph>
          اقامت در بهترین هتل یکی از مواردی است که برای زائران حائز اهمیت است.
          سایت زیارت در کاروان های زمینی و هوایی کربلا همواره بهترین و با کیفیت
          ترین هتل ها در شهر های نجف، کربلا و کاظمین را تدارک دیده است.
        </SmallParagraph>
        <LargeHeading>هتل های کاظمین عبارت اند از:</LargeHeading>
        <SmallParagraph>هتل قصر الکاظمیه کاظمین</SmallParagraph>
        <SmallParagraph>هتل سراج المنیر کاظمین</SmallParagraph>
        <SmallParagraph>هتل فدک الزهرا کاظمین</SmallParagraph>
        <LargeHeading>هتل های نجف عبارت اند از :</LargeHeading>
        <SmallParagraph>هتل طوی نجف،</SmallParagraph>
        <SmallParagraph>هتل قصر العرب نجف</SmallParagraph>
        <SmallParagraph>هتل نسیم الفرات نجف</SmallParagraph>
        <SmallParagraph>هتل قصر الملوک نجف</SmallParagraph>
        <SmallParagraph>هتل نخله نجف</SmallParagraph>
        <SmallParagraph>هتل ساحل نجف</SmallParagraph>
        <LargeHeading>هتل های کربلا عبارت اند از:</LargeHeading>
        <SmallParagraph>هتل جابر کربلا</SmallParagraph>
        <SmallParagraph>هتل برج الریاحین کربلا</SmallParagraph>
        <SmallParagraph>هتل جابر کربلا</SmallParagraph>
        <SmallParagraph>هتل الدولی کربلا</SmallParagraph>
        <SmallParagraph>هتل لولوه البحر</SmallParagraph>
        <XLargeHeading>رزرو تور کربلا از سمنان</XLargeHeading>
        <SmallParagraph>
          تجربه بهترین سفر زیارتی را با کاروان های عتبات عالیات سایت زیارت داشته
          باشید. عزیزان سمنانی می توانید با سایت زیارت تماس گرفته و با کارشناسان
          سفر مشاوره و رزرو خود را انجام دهید.
        </SmallParagraph>

        {!showAll && <Blur />}

        <GhostButton
          title={showAll ? "بستن" : "مشاهده بیشتر"}
          size="sm"
          color="gray"
          icon={ArrowDownIcon}
          width="180px"
          iconPosition="left"
          onClick={() => {
            setShowAll((perv) => !perv);
          }}
          className="moreBtn"
        />
      </DescriptionContainer>
    </>
  );
};

export default FromSemnanDescription;
