import {useState} from "react";


const NullDescription = () => {

  const [showAll, setShowAll] = useState(false);
  return (
   <></>
  );
};

export default NullDescription;
