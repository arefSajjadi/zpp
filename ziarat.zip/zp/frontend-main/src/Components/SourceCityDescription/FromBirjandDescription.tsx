import { Blur, DescriptionContainer } from "./styles";
import Head from "next/head";
import { useState } from "react";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import { LargeHeading, XLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";



const FromBirjandDescription = () => {

  const [showAll ,setShowAll] = useState(false)
  return (
    <>
    {/* <Head>
    <title>تور کربلا از بیرجند | زمینی - رسم زیارت</title>
      <meta name="description" content="تور کربلا از بیرجند ⚡اقامت در هتل 4 ستاره و 5ستاره نزدیک حرم ❗ زیرنظر سازمان حج و زیارت | پشتیبانی 24 ساعته"/>
      <meta name="enamad" content="850460"/>
      <link rel="canonical" href="https://ziarat.co/tours/karbala/from-birjand"/>
    <meta name="google-site-verification" content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk" />
    </Head> */}
   
    <DescriptionContainer showAll={showAll}>
    <XLargeHeading>
         
         راهنمای تور کربلا از بیرجند
         </XLargeHeading>
         <SmallParagraph>
           تور کربلا از بیرجند، همواره یکی از محبوب ترین و پر رزرو ترین تورها در
           بین مردم بیرجند بوده است؛ و هر ساله افراد زیادی را به کربلا معلی راهی می
           کند. شهر بیرجند، شهری تاریخی است که سازه های زرتشتی و دوران قاجار آن را
           با تمدن و زیبا نموده است؛ این شهر قدیمی مردمان مذهبی و معتقد زیادی را در
           دل خود جای داده است. در ادامه این مطلب از سایت زیارت، به نکات و شرایط
           تورهای کربلا از بیرجند، از جمله: قیمت تور کربلا از بیرجند هوایی، قیمت
           تورکربلا از بیرجند زمینی ، هتل های تور کربلا از بیرجند خواهیم پرداخت، تا
           شما بیرجندی های عزیز با آگاهی کامل راهی کربلا شوید.
         </SmallParagraph>
         <XLargeHeading>
           تور کربلا از بیرجند، از طریق چه مرزهایی برگزار می شود؟
         </XLargeHeading>
         <SmallParagraph>
           تور کربلا از بیرجند زمینی، از مرز مهران برگزار می شود؛ به طوری که شما
           نخست با ترانسفر زمینی تور به شهرستان مهران می روید و پس از ارائه
           پاسپورت، وارد خاک عراق می شوید.
         </SmallParagraph>
         <XLargeHeading>
           تور کربلا از بیرجند چند روزه است؟
         </XLargeHeading>
         <SmallParagraph>
           در حال حاضر، تمامی تورهای کربلا از بیرجند به صورت ۷ شب و ۸ روزه برگزار
           می شوند.
         </SmallParagraph>
         <XLargeHeading>
           با رزرو تور کربلا از بیرجند، در کدام شهرها اقامت خواهیم داشت؟
         </XLargeHeading>
         <SmallParagraph>
           شما با رزرو تور کربلا از بیرجند ۷ شب و ۸ روزه، ۳ شب در نجف، ۳ شب در
           کربلا، ۱ شب در کاظمین و به صورت عبوری در سامرا اقامت می کنید.
         </SmallParagraph>
         <XLargeHeading>قیمت تور کربلا از بیرجند زمینی</XLargeHeading>
         <SmallParagraph>
           تورهای کربلا از بیرجند، متاسفانه به دلیل دور بودن از مرز، کمی گران تر
           هستند؛ اما ما در سایت خود ارزان ترین تورهای کربلا از بیرجند را به شما
           عزیزان ارائه می دهیم. شروع قیمت تور کربلا از بیرجند زمینی در اسفند ماه
           سامانه زیارت، از ۸/۴۸۹/۰۰۰ تومان می باشد. برای رزرو تور کربلا از بیرجند
           زمینی، به سایت رسم زیارت مراجعه، و یا با کارشناسان ما تماس حاصل فرمایید.
         </SmallParagraph>
         <XLargeHeading>
           قیمت تور کربلا از بیرجند برای کودک
         </XLargeHeading>
         <SmallParagraph>
           قیمت تور کربلا از بیرجند برای ۲ تا ۱۲ سال: نرخ برای این سنین، تنها ۸۰
           درصد نرخ بلیط بزرگسالان می باشد.
         </SmallParagraph>
         <SmallParagraph>
           قیمت تور کربلا از بیرجند زمینی برای زیر ۲ سال: نرخ برای این سنین به صورت
           کاملا رایگان می باشد.
         </SmallParagraph>
         <SmallParagraph>
           قیمت تور کربلا از بیرجند هوایی برای زیر ۲ سال: نرخ بلیط برای تور کربلا
           از بیرجند با هواپیما زیر ۲ سال، تنها ۱۰ درصد نرخ بلیط بزرگسالان است. 
         </SmallParagraph>
         <XLargeHeading>
           هتل های نجف، کربلا و هتل های کاظمین برای تور کربلا از بیرجند
         </XLargeHeading>
         <SmallParagraph>
           سامانه زیارت سعی دارد بهترین هتل ها را در تورهای خود بگنجاند، از بین هتل
           ها تور کربلا زمینی و هوایی از بیرجند، می توانیم به موارد زیر اشاره کنیم:
         </SmallParagraph>
         <LargeHeading>ارزان ترین هتل نجف در تور کربلا از بیرجند</LargeHeading>
         <SmallParagraph>
            هتل طوی، هتل الدله و هتل فصول
           نجف.
         </SmallParagraph>
         <LargeHeading>ارزان ترین هتل کربلا در تور کربلا از بیرجند</LargeHeading>
         <SmallParagraph>
            هتل ضیوف الاسدی، هتل
           بدرالهواشم و هتل ایلاف الحدیث کربلا.
         </SmallParagraph>
         <LargeHeading>ارزان ترین هتل کاظمین در تورهای کربلا از بیرجند</LargeHeading>
         <SmallParagraph>
            هتل فدک الزهرا، هتل
           قرطاج و هتل تاج کاظمین. 
         </SmallParagraph>
         <XLargeHeading>
           رزرو تور کربلا از بیرجند با رسم زیارت
         </XLargeHeading>
         <SmallParagraph>
           سامانه رسم زیارت با کیفیت ترین و بهترین تورهای کربلا از بیرجند را به شما
           تقدیم خواهد کرد. برای رزرو تور کربلا از بیرجند خود، می توانید هم به صورت
           آنلاین و هم به صورت حضوری، تور خود را رزرو نمایید.
         </SmallParagraph>

{
    !showAll &&
      <Blur />
}

      <GhostButton 
        title={ showAll ? "بستن" : "مشاهده بیشتر"}
        size="sm"
        color="gray"
        icon={ArrowDownIcon}
        width="180px"
        iconPosition="left"
        onClick={() => {setShowAll(perv => !perv)}}
        className="moreBtn"
      />
    </DescriptionContainer>
    </>
  );
};

export default FromBirjandDescription;
