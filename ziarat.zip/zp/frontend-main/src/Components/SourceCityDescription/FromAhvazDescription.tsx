import { Blur, DescriptionContainer } from "./styles";
import Head from "next/head";
import { useState } from "react";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";
import { XLargeHeading } from "@/Shared/Kit/Typography/Heading";

const FromAhvazDescription = () => {

  const [showAll ,setShowAll] = useState(false)
  return (
    <>
      {/* <Head>
        <title>تور کربلا از اهواز | زمینی - رسم زیارت</title>
        <meta
          name="description"
          content="تور کربلا از اهواز ⚡زیارت نجف، کربلا، کاظمین و سامرا ❗ هتل های درجه الف به همراه صبحانه، نهار، شام | زیرنظر سازمان حج و زیارت"
        />
          <meta name="google-site-verification" content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk" />
          <meta name="enamad" content="850460"/>
        <link
          rel="canonical"
          href="https://ziarat.co/tours/karbala/from-ahvaz"
        />
      </Head> */}
   
    <DescriptionContainer showAll={showAll}>
      <XLargeHeading>
           
           راهنمای تور کربلا از اهواز
         </XLargeHeading>
         <SmallParagraph>
           مردم مذهبی اهواز نیز همانند مردم دیگر ایران، هرساله در زمان اربعین یا
           مناسبت های دیگر، با تور کربلا به سمت کشور عراق سفر می کنند تا مراقد
           محترم و پاک امام حسین (ع)، حضرت ابوالفضل (ع)، حضرت علی (ع)، امام موسی
           کاظم (ع) را زیارت کنند و عشق خود را اثبات نمایند.
         </SmallParagraph>
         <XLargeHeading>
           تور کربلا از اهواز زمینی، از طریق چه مرزهایی امکان پذیر است؟
         </XLargeHeading>
         <SmallParagraph>
           رزرو تور کربلا از اهواز زمینی، با مرز شلمچه امکان پذیر است؛ به دلیل
           نزدیک تر بودن و دسترسی بهتر، مناسب تر می باشد. مسافران با اتوبوس تور
           به سمت مرز شلمچه حرکت می کنند و پس از رد شدن از مرز، به سمت نجف می
           روند.
         </SmallParagraph>
         <XLargeHeading>
           تور کربلا از اهواز چند روزه است؟
         </XLargeHeading>
         <SmallParagraph>
           در حال حاضر، تورهای کربلا از اهواز و خوزستان به صورت ۶ شب برگزار می
           شود؛ بنابراین شما با رزرو تور ارزان کربلا از اهواز، ۳ شب در نجف، ۳ شب
           در کربلا و به صورت عبوری در کاظمین و سامرا نیز اقامت خواهید کرد لازم
           به ذکر است که اگر تور کربلا از اهواز خود را، از سامانه زیارت رزرو
           نمایید، می توانید از خدمات زیارت دوره( قبر مختار ثقفی، دو طفل مسلم،
           مسلم بن عقیل، مساجد کوفه، سهله، حنانه و …)  در تور کربلا بهره مند
           شوید.
         </SmallParagraph>
         <XLargeHeading>
           قیمت تور کربلا از اهواز زمینی به چه صورت است؟
         </XLargeHeading>
         <SmallParagraph>
           در سامانه زیارت؛ قیمت تورکربلا از اهواز زمینی، 5/740/۰۰۰ تومان است؛ که
           زیر نظر سازمان حج و زیارت ارائه می گردد.
         </SmallParagraph>
         <XLargeHeading>
           هزینه تور کربلا از اهواز برای خردسالان و کوکان چگونه است؟
         </XLargeHeading>
         <SmallParagraph>
           در حالت کلی، قیمت تورهای کربلا از اهواز به موقعیت و شرایط تور بستگی
           دارد؛ ما نیز در حالت کلی قیمت ها برای کودکان و خردسالان را بازگو می
           کنیم:
         </SmallParagraph>
         <SmallParagraph>
           قیمت تور کربلا از اهواز زمینی برای کودکان زیر ۲ سال: فقط شامل پرداخت
           هزینه بیمه می شود.
         </SmallParagraph>
         <SmallParagraph>
           قیمت تور کربلا از اهواز زمینی برای خردسالان ۲ تا ۱۲ سال: تنها ۸۰ درصد
           نرخ تور کربلا بزرگسالان را شامل می شود.
         </SmallParagraph>
         <SmallParagraph>
           لازم به ذکر است که خدمات تور کربلا از اهواز زمینی، برای کودکان نیز
           همانند بزرگسالان برابر است؛ و ارزان تر بودن آن به ارائه کمتر خدمات
           برای آنان وابسته نیست.
         </SmallParagraph>
         <XLargeHeading>
           اگر تور کربلا از اهواز را رزرو کنیم، در چه شهرهایی اقامت خواهیم داشت؟
         </XLargeHeading>
         <SmallParagraph>
           بستگی به این دارد که شرایط تور شما چگونه و چند روزه باشد؛ اما ما در
           اینجا به شرایط تور کربلا از اهواز در سامانه رسم زیارت می پردازیم.
         </SmallParagraph>
         <SmallParagraph>
           تور کربلا از اهواز ۷ شب و ۸ روز : ۳ شب اقامت در نجف، ۳ شب کربلا، ۱ شب
           کاظمین و زیارت سامرا به صورت عبوری و همچنین زیارت دوره می باشد.
         </SmallParagraph>
         <SmallParagraph>
           تور کربلا از اهواز ۶ شب و ۷ روز : ۲ شب اقامت در نجف، ۳ شب کربلا، ۱ شب
           کاظمین و به صورت عبوری نیز در شهر سامرا و زیارت دوره؛ و  بعضی پکیج های
           تور ها هم به صورت : ۳ شب نجف، ۳ شب کربلا و به صورت عبوری در کاظمین و
           سامرا می باشد.
         </SmallParagraph>
         <XLargeHeading>
           هتل های نجف، هتل های کاظمین و هتل های کربلا در تور کربلا از اهواز
         </XLargeHeading>
         <SmallParagraph>
           سایت زیارت، هتل های تور کربلا خود را به شرح ذیل معرفی می نماید:
         </SmallParagraph>
         <SmallParagraph> بهترین هتل های نجف </SmallParagraph>
         <SmallParagraph>
            هتل السامی نجف، هتل الرسل نجف، هتل الماس نجف.
         </SmallParagraph>
         <SmallParagraph> بهترین هتل های کاظمین </SmallParagraph>
         <SmallParagraph>
            هتل سراج المنیر کاظمین، هتل فدک الزهرا کاظمین، هتل قصر الکاظمیه
           کاظمین.
         </SmallParagraph>
         <SmallParagraph> بهترین هتل های کربلا </SmallParagraph>
         <SmallParagraph>
            هتل کربلا الدولی کربلا، هتل اطلس کربلا، هتل المیالی کربلا.
         </SmallParagraph>
         <XLargeHeading>
           رزرو تور کربلا از اهواز، با سامانه رسم زیارت
         </XLargeHeading>
         <SmallParagraph>
           عزیزان اهوازی و خوزستانی که قصد سفر به کربلا با تور کربلا از اهواز را
           دارند، می توانند با مراجعه به سامانه رسم زیارت ، تور کربلا از اهواز
           خود را با شرایط درخواستی خود رزرو نمایند.
         </SmallParagraph>

{
    !showAll &&
      <Blur />
}

      <GhostButton 
        title={ showAll ? "بستن" : "مشاهده بیشتر"}
        size="sm"
        color="gray"
        icon={ArrowDownIcon}
        width="180px"
        iconPosition="left"
        onClick={() => {setShowAll(perv => !perv)}}
        className="moreBtn"
      />
    </DescriptionContainer>
    </>
  );
};

export default FromAhvazDescription;
