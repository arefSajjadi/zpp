import {
  LargeHeading,
  XLargeHeading,
  XXLargeHeading,
} from "@/Shared/Kit/Typography/Heading";
import { Blur, DescriptionContainer, UlContainer } from "./styles";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";
import { useState } from "react";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import Link from "next/link";
import KadhimiyaHotelAccordion from "./KadhimiyaHotelAccordion";
import { SUPPORT_PHONE } from "@/config/constants";

const KadhimiyaHotelDes = () => {
  const [showAll, setShowAll] = useState(false);

  return (
    <DescriptionContainer showAll={showAll}>
      <SmallParagraph>
        کاظمین یکی از شهرهای زیارتی مهم عراق در شمال بغداد به شمار می‌رود که
        به‌دلیل وجود حرم امام موسی کاظم (ع) و امام جواد (ع)، همواره میزبان
        زائران بسیاری از سراسر جهان است. در کنار جنبه زیارتی، کاظمین شهری پویا
        با بازارهای سنتی، خیابان‌های قدیمی و مسیرهای دسترسی آسان از بغداد محسوب
        می‌شود. برای اقامت در این شهر، سامانه رسم زیارت به‌عنوان مرجع رسمی رزرو
        اقامتگاه‌های زیارتی کشور عراق زیر نظر سازمان حج و زیارت، امکان مشاهده و
        رزرو تمامی هتل ‌های کاظمین را فراهم کرده است.
      </SmallParagraph>
      <XLargeHeading>رزرو هتل های کاظمین با رسم زیارت</XLargeHeading>
      <SmallParagraph>
        سم زیارت امکان رزرو هتل در کاظمین را با تنوع بالا و قیمت‌های رقابتی برای
        زائران فراهم کرده است. چه به‌دنبال بهترین هتل ‌های کاظمین باشید و چه
        بخواهید در هتل ‌های ارزان نزدیک حرم اقامت کنید، رسم زیارت مجموعه‌ای
        متنوع از اقامتگاه‌ها را متناسب با بودجه و نیاز شما ارائه می‌دهد.
      </SmallParagraph>
      <SmallParagraph>
        برای رزرو هتل در کاظمین کافی است وارد صفحه رزرو
        <Link href="/hotel"> هتل های عراق </Link> در سایت رسم زیارت شوید و در
        بخش شهر، کاظمین را انتخاب کنید. به این ترتیب، فهرست هتل‌‌ها با اطلاعات
        کامل در اختیار شما قرار می‌گیرد. برای انتخاب آسانتر می‌توانید درجه هتل
        را از قسمت فیلترها مشخص نمایید. با کلیک روی گزینه «مشاهده جزئیات هتل»
        امکان دسترسی به تمام اطلاعات مربوط به آن اقامتگاه برای شما فراهم شده
        است.
      </SmallParagraph>
      <SmallParagraph>
        پس از انتخاب هتل، می‌توانید با کارشناسان رسم زیارت تماس بگیرید.
        کارشناسان ما با استعلام آخرین ظرفیت‌ها، شما را در فرایند انتخاب هتل
        موردنظرتان راهنمایی کرده و پس از ثبت رزرو و پرداخت هزینه، واچر هتل را در
        کوتاه‌ترین زمان برایتان ارسال می‌کنند.
      </SmallParagraph>
      <LargeHeading>بهترین هتل های کاظمین نزدیک حرم</LargeHeading>
      <SmallParagraph>
        با رزرو
        <Link href="/tours/karbala/from-tehran"> تور زیارت کربلا </Link>و انتخاب
        هتل‌ های نزدیک حرم کاظمین با موقعیت عالی و امکانات رفاهی مناسب، شرایطی
        را برای خود رقم می‌زنید تا در کوتاه‌ترین زمان و بدون نیاز به وسیله نقلیه
        بتوانید به زیارت بروید. فاصله این هتل‌ها تا حرم معمولا کمتر از 10 دقیقه
        پیاده‌روی است و دسترسی آسانی به بازارها و اماکن زیارتی دیگر نیز دارند.
      </SmallParagraph>
      <SmallParagraph>
        برخی از بهترین هتل‌ های کاظمین نزدیک حرم عبارتند از:
      </SmallParagraph>
      <UlContainer>
        <li>هتل قصرالکاظمیه کاظمین</li>
        <li>هتل خفاجی کاظمین</li>
        <li>هتل انوار الکاظمیه کاظمین</li>
        <li>هتل فضوه الشیخ کاظمین</li>
      </UlContainer>
      <LargeHeading>هتل های 4 ستاره کاظمین</LargeHeading>
      <SmallParagraph>
        اگر به دنبال خدمات باکیفیت و در عین حال قیمت مناسب هتل در کاظمین هستید،
        هتل های 4 ستاره گزینه مناسبی به شمار می‌روند. این هتل‌ها با فاصله کوتاه
        تا حرم، فضای تمیز و خدمات مناسب، از پرطرفدارترین اقامتگاه‌ها در میان
        زائران ایرانی به‌شمار می‌آیند.
      </SmallParagraph>
      <SmallParagraph>
        برخی از هتل‌ های ۴ ستاره محبوب در کاظمین عبارتند از:
      </SmallParagraph>
      <UlContainer>
        <li>هتل جوهره شومان کاظمین</li>
        <li>هتل بلدالامین کاظمین</li>
        <li>هتل قائم کاظمین</li>
      </UlContainer>
      <LargeHeading>هتل های 3 ستاره کاظمین</LargeHeading>
      <SmallParagraph>
        هتل‌ های سه ستاره در کاظمین با ارائه خدمات پایه اما استاندارد، گزینه‌ای
        اقتصادی و مناسب برای زائرانی هستند که به‌دنبال اقامت راحت و
        مقرون‌به‌صرفه در نزدیکی حرم هستند. این هتل‌ها دارای اتاق‌های تمیز، تهویه
        مطبوع، اینترنت و سرویس نظافت هستند و فاصله کمی تا حرم مطهر دارند.
      </SmallParagraph>
      <SmallParagraph>
        برخی از پرطرفدارترین هتل های کاظمین عبارتند از:
      </SmallParagraph>
      <UlContainer>
        <li>هتل برج الضامن کاظمین</li>
        <li>هتل قلعه الکاظمیه کاظمین</li>
        <li>هتل سراج المنیر کاظمین</li>
      </UlContainer>
      <XLargeHeading>قیمت هتل در کاظمین</XLargeHeading>
      <SmallParagraph>
        قیمت هتل ‌های کاظمین بسته به سطح خدمات، موقعیت مکانی و زمان سفر متفاوت
        است. در ایام خاص مانند نیمه شعبان، اربعین و ماه رمضان، نرخ اقامت در هتل
        ‌ها افزایش می‌یابد. به‌طور میانگین، هزینه اقامت در هتل کاظمین با توجه به
        نوع هتل و مدت زمان اقامت متغیر است.
      </SmallParagraph>
      <SmallParagraph>
        برای اطلاع از قیمت روز هتل در کاظمین و مشاهده ظرفیت‌های خالی، می‌توانید
        وارد سامانه رسم زیارت شوید یا با کارشناسان پشتیبانی تماس بگیرید.{" "}
      </SmallParagraph>

      <Link href={`tel:${SUPPORT_PHONE}`}>{SUPPORT_PHONE}</Link>
      <LargeHeading>هتل های ارزان و اقتصادی کاظمین</LargeHeading>
      <SmallParagraph>
        اگر به‌دنبال اقامت اقتصادی هستید، هتل ‌های ارزان کاظمین گزینه‌ای مناسب
        برای شما هستند. این هتل‌ها در عین قیمت مناسب، خدماتی قابل قبول از جمله
        تهویه مطبوع، نظافت روزانه، اینترنت بی‌سیم و دسترسی سریع به حرم را ارائه
        می‌دهند.
      </SmallParagraph>
      <SmallParagraph>
        چند نمونه از هتل ‌های ارزان کاظمین عبارتند از:
      </SmallParagraph>

      <UlContainer>
        <li>هتل العقیله کاظمین</li>
        <li>هتل ازهران کاظمین</li>
        <li>هتل جنه الباقر کاظمین</li>
      </UlContainer>
      <XLargeHeading>مزایای رزرو هتل کاظمین در رسم زیارت</XLargeHeading>
      <UlContainer>
        <li>امکان رزرو تمام هتل های زیر نظر سازمان حج و زیارت در کاظمین</li>
        <li>تضمین بهترین قیمت برای رزرو هتل ارزان یا لوکس</li>
        <li>امکان فیلتر براساس درجه هتل‌ها</li>
        <li>مشاهده تصاویر واقعی و فاصله تا حرم برای هر هتل</li>
        <li>مشاوره و پشتیبانی کامل توسط کارشناسان رسم زیارت</li>
      </UlContainer>

      <KadhimiyaHotelAccordion />

      {!showAll && <Blur />}

      <GhostButton
        title={showAll ? "بستن" : "مشاهده بیشتر"}
        size="sm"
        color="gray"
        icon={ArrowDownIcon}
        width="180px"
        iconPosition="left"
        onClick={() => {
          setShowAll((prev) => !prev);
        }}
        className="moreBtn"
      />
    </DescriptionContainer>
  );
};

export default KadhimiyaHotelDes;
