import Col from "@/Shared/Kit/Col";
import Row from "@/Shared/Kit/Row";
import styled from "styled-components";

export const FormContainer = styled(Row)`
  flex-wrap: nowrap;
  margin-top: 30px;
  .form {
    flex-wrap: nowrap;
    gap: 1rem;
    align-items: flex-start;
    flex-direction: row;
  }
  .form-row {
    flex-wrap: nowrap;
  }

  .sourceInput {
    input {
      border-radius: 0 10px 10px 0;
    }
  }
  .destinationInput {
    input {
      border-radius: 10px 0 0 10px;
    }
  }

  @media (max-width: ${(props) => props.theme.xs}) {
    .form {
      flex-direction: column;
    }
    .searchBtn {
      width: 100%;
    }
  }
`;

export const InputIconContainer = styled(Row)`
  gap: 10px;
  width: max-content;
  align-items: center;
  * {
    color: ${(props) => props.theme.gray600};
  }
  path {
    stroke: ${(props) => props.theme.gray600};
  }
`;
