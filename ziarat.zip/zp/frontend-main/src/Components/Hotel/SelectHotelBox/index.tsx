import Row from "@/Shared/Kit/Row";
import { FormContainer, InputIconContainer } from "./styles";
import { LargeParagraph } from "@/Shared/Kit/Typography/Paragraph";
import { Formik } from "formik";
import Select from "@/Shared/Kit/FromElements/Select";
import { Form, FormRow } from "@/Shared/Kit/FromElements/FormStyles";
// import Calendar from "@/Shared/Kit/FromElements/Calendar";
import dynamic from "next/dynamic";
import { PrimaryButton } from "@/Shared/Kit/Button/PrimaryButton";
import { XSmallLabel } from "@/Shared/Kit/Typography/Label";
import LocationIcon from "@/Assets/Icons/LocationIcon";
import FormHandlers from "@/Utils/FormHandlers";
import { useSelector } from "react-redux";
import { selectTourState } from "@/Redux/Tour/Selectors";
import { selectHome } from "@/Redux/Home/Selectors";
import { SearchHotelSchema } from "@/Validations/SearchHotelSchema";
import { useRouter } from "next/router";
import { useState } from "react";
import Input from "@/Shared/Kit/FromElements/Input";

interface Props {
  hotelDefaultCity?: 1 | 2 | 3;
}
const SelectHotelBox: React.FC<Props> = (props) => {
  const { hotelDefaultCity } = props;
  const router = useRouter();
  const [desSlug, setDesSlug] = useState<string>("");
  const desCities = [
    {
      id: 1,
      title: "کربلا",
      slug: "karbala",
    },
    {
      id: 2,
      title: "نجف",
      slug: "najaf",
    },
    {
      id: 3,
      title: "کاظمین",
      slug: "kadhimiya",
    },
  ];

  const submitHandler = (values: any, action: any) => {
    if (!desSlug) {
      const slug =
        hotelDefaultCity === 1
          ? "karbala"
          : hotelDefaultCity === 2
          ? "najaf"
          : "kadhimiya";
      setDesSlug(slug);
      return router.push(`/hotel/${slug}-hotel`);
    }
    router.push(`/hotel/${desSlug}-hotel`);
  };

  return (
    <FormContainer>
      <Formik
        initialValues={{
          country: "عراق",
          city: hotelDefaultCity ? hotelDefaultCity : null,
        }}
        enableReinitialize={true}
        validationSchema={SearchHotelSchema}
        onSubmit={(values, action) => {
          submitHandler(values, action);
        }}
      >
        {(formik) => (
          <Form onSubmit={formik.handleSubmit} className="form">
            <FormRow xl={12} xs={24} minHeight="60px" className="form-row">
              <Input
                label="کشور"
                name="country"
                size="sm"
                onBlur={() => {}}
                onChange={(e: any) => {}}
                value={formik.values.country}
                disabled={true}
              />
            </FormRow>
            <FormRow xl={12} xs={24} minHeight="60px" className="form-row">
              <Select
                label={"شهر"}
                OptionsIcon={LocationIcon}
                name="city"
                onSelect={(selected: any, name: string) =>
                  FormHandlers.onSelect(selected, name, formik, () => {
                    setDesSlug(selected.slug);
                  })
                }
                onClear={(name: any) => {
                  FormHandlers.onClear(name, formik);
                }}
                options={desCities}
                size="sm"
                error={formik.touched.city ? formik.errors.city : null}
                value={formik.values.city}
                InputIcon={LocationIcon}
                iconProps={{ color: "#767676" }}
                readOnly={true}
              />
            </FormRow>
            <PrimaryButton
              color="primary"
              size="sm"
              width="175px"
              title="جستجو"
              type="submit"
              isCurve={true}
              className="searchBtn"
            />
          </Form>
        )}
      </Formik>
    </FormContainer>
  );
};

export default SelectHotelBox;
