import Col from "@/Shared/Kit/Col";
import React from "react";
import styled from "styled-components";

interface Props {
  isSelectedFilterBtn?: boolean;
}

export const MainContainer = styled(Col)<Props>`
  gap: 10px;

  /* max-width: 312px; */
  justify-content: flex-start;

  .orderBySelect {
    background-color: ${(props) => props.theme.white};
  }

  .reserveByMobileContainer {
    background-color: ${(props) => props.theme.gray200};
    border-radius: 6px;
    padding: 8px 10px;
    justify-content: space-between;
    margin-top: 20px;
  }

  @media (max-width: ${(props) => props.theme.xs}) {
    .mobileFilterContainer {
      justify-content: flex-start;
      gap: 10px;
    }

    .mobileFilterBtn {
      path {
        stroke: ${(props) => props.theme.white};
      }
      background-color: ${(props) => props.theme.primary100};
      div {
        color: ${(props) => props.theme.primary600};
      }
      path {
        stroke: ${(props) => props.theme.primary600};
      }

      background-color: ${(props) =>
        !props.isSelectedFilterBtn
          ? props.theme.white
          : props.theme.primary100} !important;
      border: 1px solid
        ${(props) =>
          !props.isSelectedFilterBtn
            ? props.theme.gray200
            : props.theme.primary300} !important;
      white-space: nowrap;
      > div {
        color: ${(props) =>
          !props.isSelectedFilterBtn
            ? props.theme.gray600
            : props.theme.primary600} !important;
      }
      svg {
        path {
          stroke: ${(props) =>
            !props.isSelectedFilterBtn
              ? props.theme.gray600
              : props.theme.primary600} !important;
        }
      }
    }
    .cancelFilterBtn {
      svg {
        width: 14px;
        height: 14px;
      }
    }
  }
`;

export const FilterWrapper = styled(Col)`
  border: 1px solid ${(props) => props.theme.gray100};
  position: relative;
  border-radius: 10px;
  background-color: ${(props) => props.theme.white};
  border: 1px solid ${(props) => props.theme.gray100};
  .diactiveFilter {
    position: absolute;
    top: 10px;
    left: 20px;
    display: flex;
    justify-content: end;
  }

  .firstRow {
    justify-content: space-between;
  }

  .secondRow {
    margin: 15px 0 20px 0;
    gap: 5px;
  }

  .btnContainer {
    width: 50%;
  }

  .hotelsBtnContainer {
    width: 25%;

    .active {
      background-color: ${(props) => props.theme.primary100} !important;
    }
  }

  .travelTypeCol,
  .stayingTimeCol,
  .hotelType,
  .hotelFilter {
    align-items: flex-start;
    gap: 10px;
  }

  .travelTypeCol,
  .stayingTimeCol {
    margin-bottom: 15px;
  }

  .thirdRow,
  .fivthRow,
  .sixthRow {
    border: 1px solid ${(props) => props.theme.gray50};
    border-radius: 10px;
    justify-content: center;
    padding: 5px;
  }

  .forthRow {
    justify-content: space-between;
    background-color: ${(props) => props.theme.gray100};
    padding: 8px 10px 8px 10px;
    border-radius: 6px;
    margin: 15px 0;
  }
  .row {
    padding: 10px 20px;
    align-items: flex-start;
    gap: 10px;
    border-bottom: 1px solid ${(props) => props.theme.gray100};
  }
  .last-row {
    padding: 10px 20px;
    align-items: flex-start;
    gap: 10px;
  }
  .content-row {
    display: flex;
    gap: 10px;
  }

  @media (max-width: ${(props) => props.theme.xs}) {
    .confirmBtn {
      margin: 20px 20px 0;
      max-width:auto;
    }
    border: none;
  }
`;
