import React, { useRef, useState } from "react";
import { FilterWrapper, MainContainer } from "./styles";
import { useDispatch, useSelector } from "react-redux";

import Row from "@/Shared/Kit/Row";
import { selectTourState } from "@/Redux/Tour/Selectors";
import { selectTheme } from "@/Redux/App/Selectors";
import { OutlineButton } from "@/Shared/Kit/Button/OutlineButton";
import CrossIcon from "@/Shared/Kit/Icons/CrossIcon";
import { MediumParagraph } from "@/Shared/Kit/Typography/Paragraph";
import Col from "@/Shared/Kit/Col";
import useIsMobile from "@/Utils/Responsive";
import Modal from "@/Shared/Kit/Modal";
import { PrimaryButton } from "@/Shared/Kit/Button/PrimaryButton";
import FilterIcon from "@/Assets/Icons/FilterIcon";
import { GetHotels } from "@/Redux/Hotel/ApiFunction";
import { selectHotelState } from "@/Redux/Hotel/Selector";
import { setFilterProperties } from "@/Redux/Tour/TourSlice";

import DebouncedSearchForm from "@/Components/Hotel/HotelList/HotelFilter/DebouncedSearchInput";
import Checkbox from "@/Shared/Kit/FromElements/Checkbox";

interface Props {
  hotelCity: "karbala" | "kadhimiya" | "najaf";
}
const HotelFilter: React.FC<Props> = (props) => {
  const { hotelCity } = props;
  const theme = useSelector(selectTheme);
  const dispatch = useDispatch();
  const responsive = useIsMobile();
  const { hotelTypeList, hotelLevel, hotelName } = useSelector(selectTourState);
  const { hotelPage } = useSelector(selectHotelState);
  const [showModal, setShowModal] = useState(false);
  const [isActive, setIsActive] = useState(false);
  const [switchActivation, setSwitchActivation] = useState(false);

  const searchFormRef = useRef<any>(null);

  const onSwitchClick = () => {};

  const removeFiltersHandler = () => {
    dispatch(
      setFilterProperties({
        hotelLevel: null,
        hotelName: null,
      })
    );
    // reset hotel name component filter
    searchFormRef.current?.reset();
    GetHotels(dispatch, hotelCity, 10, 1, "replace");
  };

  // Hotel Type ------------------------------------------------
  const hotelTypeClick = (item: { id: number; title: string }) => {
    if (hotelLevel === item.title) {
      dispatch(
        setFilterProperties({
          hotelLevel: null,
        })
      );
      return GetHotels(dispatch, hotelCity, 10, 1, "replace");
    }
    dispatch(
      setFilterProperties({
        hotelLevel:
          item.title === "الف ویژه"
            ? "5"
            : item.title === "الف"
            ? "4"
            : item.title === "ب"
            ? "3"
            : "2",
      })
    );

    GetHotels(
      dispatch,
      hotelCity,
      10,
      1,
      "replace",
      item.title === "الف ویژه"
        ? "5"
        : item.title === "الف"
        ? "4"
        : item.title === "ب"
        ? "3"
        : "2",
      hotelName
    );
  };

  const handleHotelNameSearch = (value: string) => {
    if (value === "") {
      dispatch(
        setFilterProperties({
          hotelName: null,
        })
      );
      return GetHotels(dispatch, hotelCity, 10, 1, "replace", hotelLevel);
    }
    dispatch(
      setFilterProperties({
        hotelName: value,
      })
    );
    GetHotels(dispatch, hotelCity, 10, 1, "replace", hotelLevel, value);
  };

  return (
    <MainContainer isSelectedFilterBtn={!!(hotelLevel || hotelName)}>
      {responsive === "mobile" && (
        <Row className="mobileFilterContainer">
          <PrimaryButton
            color="primary"
            size="xs"
            width="85px"
            className="mobileFilterBtn"
            icon={FilterIcon}
            iconPosition="right"
            title="فیلتر ها"
            onClick={() => setShowModal(true)}
          />

          {(hotelLevel || hotelName) && (
            <OutlineButton
              width="100px"
              color="negative"
              size="xs"
              icon={CrossIcon}
              iconPosition="left"
              title="لغو فیلترها"
              onClick={removeFiltersHandler}
              type="button"
              className="cancelFilterBtn"
            />
          )}
        </Row>
      )}

      {responsive === "mobile" ? (
        <Modal
          visible={showModal}
          onClose={() => setShowModal(false)}
          headerTitle="فیلترها"
          height="70vh"
        >
          <Col>
            <FilterWrapper>
              <Col className="row">
                <MediumParagraph color={theme.gray600}>
                  جستجوی هتل
                </MediumParagraph>
                <DebouncedSearchForm
                  ref={searchFormRef}
                  setValue={handleHotelNameSearch}
                />
              </Col>
              <Col className="last-row">
                <MediumParagraph color={theme.gray600}>
                  درجه هتل
                </MediumParagraph>
                <Row className="content-row">
                  {hotelTypeList.map((item) => (
                    <Row key={item.id}>
                      <Checkbox
                        size={"xl"}
                        checked={String(item.id) === hotelLevel}
                        text={item.title}
                        onClick={() => {
                          hotelTypeClick(item);
                        }}
                      />
                    </Row>
                  ))}
                </Row>
              </Col>

              {/*<Row className="reserveByMobileContainer">*/}
              {/*  <XXSmallParagraph color={theme.gray800}>*/}
              {/*    امکان رزرو تلفنی*/}
              {/*  </XXSmallParagraph>*/}

              {/*  <Switch*/}
              {/*    isActive={isActive}*/}
              {/*    height="13px"*/}
              {/*    onClick={() => setIsActive((perv) => !perv)}*/}
              {/*    width="25px"*/}
              {/*    color={"primary"}*/}
              {/*  />*/}
              {/*</Row>*/}
              <PrimaryButton
                color="primary"
                size="sm"
                title="اعمال فیلتر"
                width="90%"
                className="confirmBtn"
                isCurve={true}
                onClick={() => setShowModal(false)}
              />
            </FilterWrapper>
          </Col>
        </Modal>
      ) : (
        <Col>
          <FilterWrapper>
            <Col className="row">
              <MediumParagraph color={theme.gray600}>
                جستجوی هتل
              </MediumParagraph>
              <DebouncedSearchForm
                ref={searchFormRef}
                setValue={handleHotelNameSearch}
              />
              {(hotelLevel || hotelName) && (
                <OutlineButton
                  width="100px"
                  color="negative"
                  size="xs"
                  icon={CrossIcon}
                  iconPosition="left"
                  title="لغو فیلترها"
                  onClick={removeFiltersHandler}
                  className="diactiveFilter"
                />
              )}
            </Col>
            <Col className="last-row">
              <MediumParagraph color={theme.gray600}>درجه هتل</MediumParagraph>
              <Row className="content-row">
                {hotelTypeList.map((item) => (
                  <Row key={item.id}>
                    <Checkbox
                      size={"xl"}
                      checked={String(item.id) === hotelLevel}
                      text={item.title}
                      onClick={() => {
                        hotelTypeClick(item);
                      }}
                    />
                  </Row>
                ))}
              </Row>
            </Col>

            {/*<Row className="reserveByMobileContainer">*/}
            {/*  <XXSmallParagraph color={theme.gray800}>*/}
            {/*    امکان رزرو تلفنی*/}
            {/*  </XXSmallParagraph>*/}

            {/*  <Switch*/}
            {/*    isActive={isActive}*/}
            {/*    height="13px"*/}
            {/*    onClick={() => setIsActive((perv) => !perv)}*/}
            {/*    width="25px"*/}
            {/*    color={"primary"}*/}
            {/*  />*/}
            {/*</Row>*/}
          </FilterWrapper>
        </Col>
      )}
    </MainContainer>
  );
};

export default HotelFilter;
