import HeaderBox from "@/Components/MainPage/HeaderBox";
import Layout from "@/Shared/Layout";
import { MainPageWrapper } from "./styles";
import IraqHotelDes from "../SourceCityDescription/IraqHotelDes";


export default function HotelComponent() {
  return (
    
      <MainPageWrapper>
        <HeaderBox
          description=""
          title="هتل های عراق"
          showContent={true}
          showTab={true}
          mode="hotel"
        />
        {/* <OurProperties />
        <CitiesTours />
        <MainPageSuggestedTours />
        <Section4 />
        <Section5 />
        <Section6 /> */}
        <IraqHotelDes />
      </MainPageWrapper>

  );
}

