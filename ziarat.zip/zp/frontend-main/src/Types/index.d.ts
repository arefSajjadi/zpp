
    export { };
    interface configTypes {
      urls: {
        apiUrl: string,
        soumaUrl: string,
        regSejamUrl: string,
        biometricAuthenticationLink: string
      },
      broker: {
        brokerTitle: string,
        brokerCode: string,
      },
      theme: {
        primary: {
          primary900: string,
          primary800: string,
          primary700: string,
          primary600: string,
          primary500: string,
          primary400: string,
          primary300: string,
          primary200: string,
          primary100: string,
          primary50: string,
        },
        secondary: {
          secondary900: string,
          secondary800: string,
          secondary700: string,
          secondary600: string,
          secondary500: string,
          secondary400: string,
          secondary300: string,
          secondary200: string,
          secondary100: string,
          secondary50: string,
        }
      },
      appSettings: {
        defaultMarketerCode: string
      },
    }

    declare global {
      interface Window {
        config: configTypes
      }
    } 
    