
    // import CryptoJS from 'crypto-js';
    import keys from './NameSpace';

    // let _key = import.meta.env.VITE_ENCRYPT_KEY

    // function encrypt(txt: string) {
    //   return CryptoJS.AES.encrypt(txt, _key)?.toString() || "";
    // }

    // function decrypt(txtToDecrypt: string) {
    //   try {
    //     return CryptoJS.AES.decrypt(txtToDecrypt, _key)?.toString(CryptoJS.enc.Utf8) || "";
    //   } catch (error) {
    //     return ""
    //   }
    // }

    class Storage {
      set(name: string, data: any) {
        const stringData = data ? JSON.stringify(data) : ""
        const encryptData = stringData ? stringData : ""
        return localStorage.setItem(name, encryptData);
      }
      get(name: string) {
        const stringData = localStorage.getItem(name)
        const decryptData = stringData ? stringData : ""
        const jsonData = stringData && decryptData ? JSON.parse(decryptData) : ""
        return jsonData;
      }
      remove(name: string) {
        return localStorage.removeItem(name);
      }
      removeAll() {
        return localStorage.clear();
      }
      logOut() {
        this.remove(keys.token);
      }
    }

    export default new Storage(); 
    