
    export default {
      token: 'token',
      mobileNumber: "mobileNumber"
    };    
    