import { selectAuth } from "@/Redux/Auth/Selectors";
import Modal from "@/Shared/Kit/Modal";
import { useDispatch, useSelector } from "react-redux";
import {
  CounterContainer,
  MainContainer,
  Section1Wrapper,
  Section2Wrapper,
} from "./styles";
import {
  LargeParagraph,
  MediumParagraph,
  SmallParagraph,
} from "@/Shared/Kit/Typography/Paragraph";
import { selectTheme } from "@/Redux/App/Selectors";
import { Formik, FormikHelpers } from "formik";
import { Form, FormRow } from "@/Shared/Kit/FromElements/FormStyles";
import Input from "@/Shared/Kit/FromElements/Input";
import FormHandlers from "@/Utils/FormHandlers";
import { PrimaryButton } from "@/Shared/Kit/Button/PrimaryButton";
import { LoginSchema, VerifyOtpSchema } from "@/Validations/LoginSchema";
import { useEffect, useState } from "react";
import Col from "@/Shared/Kit/Col";
import { AppDispatch } from "@/Redux/store";
import { setMobileNumber, setShowLoginModal } from "@/Redux/Auth/AuthSlice";
import CodeInput from "@/Shared/Kit/FromElements/CodeInput/CodeInput4";
import { SendOtp, VerifyOtp } from "@/Redux/Auth/ApiFunction";
import Toast from "@/Shared/Kit/Toast";
import { useRouter } from "next/router";
import Storage from "@/Storage";
import { selectTourState } from "@/Redux/Tour/Selectors";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import Row from "@/Shared/Kit/Row";
import ArrowIcon from "@/Assets/Icons/ArrowIcon";

const LoginModal = () => {
  const { showLoginModal, nextUrl } = useSelector(selectAuth);
  const { orderHistory } = useSelector(selectTourState);

  const theme = useSelector(selectTheme);
  const router = useRouter();
  const dispatch = useDispatch<AppDispatch>();
  const [phoneNumber, setPhoneNumber] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [index, setIndex] = useState<1 | 2>(1);
  const [expire, setExpire] = useState(60);

  useEffect(() => {
    if (expire > 0) {
      const timer = setTimeout(() => setExpire((prev) => prev - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [expire]);

  const closeHandler = () => {
    dispatch(setShowLoginModal(false));
  };

  const resendOtp = () => {
    if (phoneNumber) {
      SendOtp(dispatch, phoneNumber, () => setExpire(60));
    } else {
      Toast.error("شماره تماس یافت نشد");
    }
  };

  const submitHandler = (values: any, action: FormikHelpers<any>) => {
    setLoading(true);
    setPhoneNumber(values?.mobileNumber);

    SendOtp(
      dispatch,
      values.mobileNumber,
      () => {
        dispatch(setMobileNumber(values.mobileNumber));
        setIndex(2);
        setExpire(60);
        setLoading(false);
        Toast.success(`کد تایید به شماره ${values.mobileNumber} ارسال شد`);
      },
      (errorMessage?: string) => {
        setLoading(false);
        Toast.error(errorMessage || "ارسال کد با خطا مواجه شد");
        action.setFieldError(
          "mobileNumber",
          errorMessage || "شماره اشتباه است"
        );
      }
    );
  };

  const otpSubmitHandler = async (
    values: { otp: string },
    formikHelpers: FormikHelpers<{ otp: string }>
  ) => {
    setLoading(true);

    const successCallback = () => {
      Storage.set("orderHistory", orderHistory);
      dispatch(setShowLoginModal(false));
      router.push(nextUrl);
    };

    const failCallback = (errorMessage?: string) => {
      setLoading(false);
      formikHelpers.setFieldError(
        "otp",
        errorMessage || "کد وارد شده اشتباه است"
      );
    };

    if (phoneNumber) {
      VerifyOtp(
        dispatch,
        phoneNumber,
        values.otp,
        successCallback,
        failCallback
      );
    } else {
      setLoading(false);
      Toast.error("شماره تماس یافت نشد");
    }
  };

  return (
    <Modal
      visible={showLoginModal}
      onClose={closeHandler}
      height={index === 1 ? "250px" : "auto"}
      width="450px"
      headerTitle="ورود"
    >
      <MainContainer>
        {index === 1 ? (
          <Section1Wrapper>
            <Col className="contentContainer">
              <MediumParagraph color={theme.gray600}>
                برای ادامه شماره موبایل خود را وارد کنید
              </MediumParagraph>
            </Col>
            <Formik
              initialValues={{ mobileNumber: "" }}
              validationSchema={LoginSchema}
              onSubmit={submitHandler}
              enableReinitialize
            >
              {(formik) => (
                <Form className="form" onSubmit={formik.handleSubmit}>
                  <FormRow minHeight="60px">
                    <Input
                      label="شماره موبایل"
                      name="mobileNumber"
                      onBlur={(e: React.ChangeEvent<HTMLInputElement>) =>
                        FormHandlers.onBlur(e, formik)
                      }
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                        FormHandlers.onChange(e, formik)
                      }
                      size="sm"
                      value={formik.values.mobileNumber}
                      error={
                        formik.touched.mobileNumber
                          ? formik.errors.mobileNumber
                          : null
                      }
                    />
                  </FormRow>
                  <PrimaryButton
                    size="md"
                    width="100%"
                    color="primary"
                    title="تایید و دریافت کد"
                    loading={loading}
                    type="submit"
                    isCurve
                  />
                </Form>
              )}
            </Formik>
          </Section1Wrapper>
        ) : (
          <Section2Wrapper>
            <GhostButton
              width="40px"
              size="sm"
              color="gray"
              icon={ArrowIcon}
              className="pervPageBtn"
              onClick={() => setIndex(1)}
            />
            <Formik
              initialValues={{ otp: "" }}
              validationSchema={VerifyOtpSchema}
              onSubmit={otpSubmitHandler}
              enableReinitialize
            >
              {(formik) => (
                <Form className="form" onSubmit={formik.handleSubmit}>
                  <FormRow className="codeInputContainer" minHeight="50px">
                    <CodeInput
                      formik={formik}
                      name="otp"
                      className="inputBtn"
                      phoneNumber={phoneNumber}
                      formRowXl={19}
                      formRowLg={19}
                      formRowMd={19}
                      error={formik.errors.otp}
                    />
                  </FormRow>
                  <CounterContainer>
                    {expire > 0 ? (
                      <Row className="second">
                        <LargeParagraph>00:{expire}</LargeParagraph>
                        <SmallParagraph>مانده تا دریافت مجدد کد</SmallParagraph>
                      </Row>
                    ) : (
                      <GhostButton
                        color="gray"
                        size="sm"
                        width="80px"
                        title="ارسال مجدد"
                        onClick={resendOtp}
                        className="btn"
                      />
                    )}
                  </CounterContainer>
                  <PrimaryButton
                    size="md"
                    width="100%"
                    color="primary"
                    title="تایید"
                    loading={loading}
                    isCurve
                  />
                </Form>
              )}
            </Formik>
          </Section2Wrapper>
        )}
      </MainContainer>
    </Modal>
  );
};

export default LoginModal;
