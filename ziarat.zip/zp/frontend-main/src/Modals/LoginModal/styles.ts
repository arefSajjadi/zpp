import Col from "@/Shared/Kit/Col";
import styled from "styled-components";

export const MainContainer = styled(Col)`
  height: 100%;
`;

export const Section1Wrapper = styled(Col)`
  padding: 20px;
  height: 100%;
  justify-content: flex-start;
  .contentContainer {
    gap: 10px;
  }
  .form {
    margin-top: 15px;
  }
`;

export const Section2Wrapper = styled(Col)`
  position: relative;
  padding: 20px;
  height: 100%;
  justify-content: flex-start;
  .form {
    margin-top: 30px;
  }
  .pervPageBtn {
    position: absolute;
    right: 20px;
  }
  .text {
    margin-bottom: 20px !important;
  }
  .inputBtn {
    border-radius: 10px;
    width: 69px;
    height: 44px;
    border-color: ${(props) => props.theme.gray600};
  }
`;

export const CounterContainer = styled(Col)`
  .second {
    justify-content: center;
    width: max-content;
    padding: 8px 28px;
    flex-direction: column;
    :first-child {
      font-weight: bold;
      font-size: 20px;
    }
  }
  gap: 10px;
  margin-bottom: 20px;
  .btn {
    white-space: nowrap;
  }
`;
