import Col from "@/Shared/Kit/Col";
import Row from "@/Shared/Kit/Row";
import styled from "styled-components";

export const ModalWrapper = styled(Col)`
  .bict__modal__header {
    display: none;
  }

  .bict__modal__container {
    border-radius: 30px;

    @media (max-width: ${(props) => props.theme.sm}) {
      border-radius: 30px 30px 0 0;
      // height: 90vh;
    }
  }
`;

export const MainContainer = styled(Col)`
  margin-top: 20px;
  gap: 20px;
  @media (max-width: ${(props) => props.theme.xs}) {
    gap: 16px;
  }
`;

interface PaymentWaysContainerProps {
  pickedWay: "cash" | "melat";
}
export const PaymentWaysContainer = styled(Col)<PaymentWaysContainerProps>`
  gap: 20px;
  padding: 0 20px;
  .melatPaymentContainer {
    border: 1px solid
      ${(props) =>
        props.pickedWay === "melat"
          ? props.theme.primary400
          : props.theme.primary200};
  }
  .cashPaymentContainer {
    border: 1px solid
      ${(props) =>
        props.pickedWay === "cash"
          ? props.theme.primary400
          : props.theme.primary200};
  }

  @media (max-width: ${(props) => props.theme.xs}) {
    padding: 0 16px;
    gap: 16px;
  }
`;

export const CashPaymentContainer = styled(Row)`
  position: relative;
  border-radius: 10px;
  padding: 10px;
  border: 1px solid ${(props) => props.theme.primary200};

  .cashPaymentTitle {
    gap: 12px;
  }

  &:hover {
    cursor: pointer;
  }
`;

export const MelatPaymentContainer = styled(Col)`
  border-radius: 10px;
  padding: 10px;
  /* border: 1px solid ${(props) => props.theme.primary200}; */
  &:hover {
    cursor: pointer;
  }
`;

export const MelatFirstRow = styled(Row)`
  position: relative;
  justify-content: space-between;
  .titleContainer {
    width: max-content;
    gap: 12px;
  }

  .inquiryBtn {
    background-color: #f1f6ff;
    height: 27px !important;
    div {
      color: ${(props) => props.theme.primary300} !important;
      > div {
        width: 20px;
        height: 20px;
      }
    }
  }
`;

export const MelatHaveCreditContainer = styled(Col)`
  gap: 10px;
  .creditAmount {
    width: max-content;
    gap: 5px;
  }

  .creditFirstRow {
    justify-content: space-between !important;
    margin-top: 10px;
  }
`;

export const CreditAmountWrapper = styled(Row)`
  border: 1px solid ${(props) => props.theme.primary200};
  border-radius: 5px;
  padding: 5px 20px 5px 5px;
  flex-wrap: nowrap;
  justify-content: space-between;
  .form {
    flex-direction: row !important;
    justify-content: space-between;
    flex-wrap: nowrap;
    align-items: center;
    width: calc(100% - 60px);
  }

  .amount-form {
    flex-direction: row !important;
    justify-content: space-between !important;
    flex-wrap: nowrap;
    align-items: center;
    width: 100%;
    input {
      border-bottom: 1px solid ${(props) => props.theme.gray300};
      width: 120px;
    }

    .input-toman {
      width: max-content;
      gap: 5px;
    }
  }
  .inputContainer {
    width: 100%;
    flex-wrap: nowrap;
    gap: 5px;

    .bict__formGroup {
      width: max-content;
    }
    input {
      border: none !important;
      &:hover {
        border: none !important;
      }
    }
  }

  .second {
    border: 1px solid ${(props) => props.theme.gray200};
    justify-content: center;
    width: max-content;
    border-radius: 10px;
    padding: 5px 5px;
    height: 35px;
  }
`;

export const PaymentAmountContainer = styled(Col)`
  padding: 0 20px;

  .allAmountContainer {
    border-bottom: 1px dashed ${(props) => props.theme.gray500};
    padding-bottom: 20px;
    justify-content: space-between;
  }

  .amountContainer {
    justify-content: space-between;
    padding: 20px 0;
  }

  .amount {
    gap: 5px;
    width: max-content;
  }
  @media (max-width: ${(props) => props.theme.xs}) {
    padding: 0 16px;
    .allAmountContainer {
      padding-bottom: 10px;
    }
    .amountContainer {
      padding: 10px 0;
    }
  }
`;

export const BtnsContainer = styled(Row)`
  justify-content:space-between;
`;

export const SuccessCreditRegisterContainer = styled(Row)`
  justify-content: center;
  gap: 10px;
  background-color: ${(props) => props.theme.positive50};
  border-radius: 5px;
  padding: 5px;

  svg {
    path {
      fill: ${(props) => props.theme.positive300};
    }
  }
`;

export const ErrorWrapper = styled(Col)``;
export const ErrorBox = styled(Row)`
  p {
    color: ${(props) => props.theme.negative300};
  }
`;
