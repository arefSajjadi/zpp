import Modal from "@/Shared/Kit/Modal";
import {
  BtnsContainer,
  CashPaymentContainer,
  CreditAmountWrapper,
  ErrorBox,
  ErrorWrapper,
  MainContainer,
  MelatFirstRow,
  MelatHaveCreditContainer,
  MelatPaymentContainer,
  ModalWrapper,
  PaymentAmountContainer,
  PaymentWaysContainer,
  SuccessCreditRegisterContainer,
} from "./styles";
import Row from "@/Shared/Kit/Row";
import Image from "next/image";
import CashIcon from "@/Assets/Images/cash.svg";
import MelatIcon from "@/Assets/Images/melat.svg";
import { LargeHeading, XXSmallHeading } from "@/Shared/Kit/Typography/Heading";
import { useDispatch, useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import {
  SmallParagraph,
  XSmallParagraph,
  XXSmallParagraph,
} from "@/Shared/Kit/Typography/Paragraph";
import {
  LargeLabel,
  MediumLabel,
  SmallLabel,
} from "@/Shared/Kit/Typography/Label";
import { addSeparator, removeSeparator } from "@/Utils/Separator";
import { PrimaryButton } from "@/Shared/Kit/Button/PrimaryButton";
import { OutlineButton } from "@/Shared/Kit/Button/OutlineButton";
import Divider from "@/Shared/Kit/Divider";
import { useEffect, useState } from "react";
import Badge from "@/Shared/Badge";
import Input from "@/Shared/Kit/FromElements/Input";
import { Form, FormRow } from "@/Shared/Kit/FromElements/FormStyles";
import { Formik } from "formik";
import {
  MelatClubInquiry,
  MelatClubReducsCredit,
  MelatClubReducsTransactionCredit,
  MelatClubSendOtp,
} from "@/Redux/Order/ApiFunction";
import { selectOrder } from "@/Redux/Order/Selectors";
import { setMelatClubOtpTimer } from "@/Redux/Order/OrderSlice";
import CheckIcon from "@/Shared/Kit/Icons/CheckIcon2";
import FormHandlers from "@/Utils/FormHandlers";
import CodeInput6 from "@/Shared/Kit/FromElements/CodeInput/CodeInput6";
import Toast from "@/Shared/Kit/Toast";
import { convertCurrency } from "@/Utils/ConvertRialToToman";

interface Props {
  onClose: (...args: any) => void;
  onPaymentClick: (...args: any) => void;
  amount: number;
  setAmount: (...args: any) => void;
  orderId: number | null;
  mobileNumber?: string;
  transactionId?: number | null;
}
const CheckOrderModal: React.FC<Props> = (props) => {
  const {
    onClose,
    amount,
    setAmount,
    onPaymentClick,
    mobileNumber,
    orderId,
    transactionId,
  } = props;
  const theme = useSelector(selectTheme);
  const { melatClubOtpTimer } = useSelector(selectOrder);
  const dispatch = useDispatch();
  const [pickedWay, setPickedWay] = useState<"cash" | "melat">("cash");
  const [inquiryLoading, setInquiryLoading] = useState(false);
  const [creditStatus, setCreditStatus] = useState<
    "success" | "fail" | "unknown"
  >("unknown");
  const [initialCreditAmount, setInitialCreditAmount] = useState<number>(0);
  const [choosenCreditAmount, setChoosenCreditAmount] = useState<number>(0);
  const [creditRegistered, setCreditRegistered] = useState(false);
  const [showOtpBox, setShowOtpBox] = useState(false);
  useEffect(() => {
    if (melatClubOtpTimer > 0) {
      setTimeout(() => {
        dispatch(setMelatClubOtpTimer(melatClubOtpTimer - 1));
      }, 1000);
    }
  }, [melatClubOtpTimer]);

  const onWayClick = (type: "cash" | "melat") => {
    setPickedWay(type);
  };

  const inquiryHandler = () => {
    setInquiryLoading(true);

    const successCallback = (valid: boolean, credit: number) => {
      if (valid) {
        setCreditStatus("success");
        setInitialCreditAmount(convertCurrency(credit, "Rial", "Toman"));
      } else {
        setCreditStatus("fail");
      }
      setInquiryLoading(false);
    };
    if (mobileNumber && orderId) {
      MelatClubInquiry(orderId, mobileNumber, successCallback, () =>
        setInquiryLoading(false)
      );
    }
  };

  const [showError, setShowError] = useState(false);
  const [showSecondError, setShowSecondError] = useState(false);
  const [showThirdError, setShowThirdError] = useState(false);
  const [sendOtpLoading, setSendOtpLoading] = useState(false);
  const getOtpHandler = (values: any, action: any) => {
    setSendOtpLoading(true);
    if (mobileNumber && orderId) {
      const successCallback = (send: boolean, code: number) => {
        if (send) {
          const fixAmount = Number(removeSeparator(values.amount));
          setChoosenCreditAmount(fixAmount);
          setShowOtpBox(true);
        } else {
          Toast.error("خطا در ارسال کد");
        }
        setSendOtpLoading(false);
      };
      MelatClubSendOtp(dispatch, orderId, mobileNumber, successCallback, () =>
        setSendOtpLoading(false)
      );
    }
  };

  const [confirmLoading, setConfirmLoading] = useState(false);
  const confirmOtpHandler = (values: any, action: any) => {
    if (!values.otp || values.otp?.length != 6)
      return Toast.error("کد وارد شده صحیح نمی‌باشد");
    setConfirmLoading(true);
    if (choosenCreditAmount && mobileNumber && orderId) {
      const successCallback = () => {
        setCreditRegistered(true);
        setConfirmLoading(false);
        let finalAmount = amount - choosenCreditAmount;
        if (finalAmount < 0) finalAmount = 0;
        setAmount(finalAmount);
      };
      if (transactionId)
        MelatClubReducsTransactionCredit(
          transactionId,
          mobileNumber,
          amount < choosenCreditAmount
            ? convertCurrency(amount, "Toman", "Rial")
            : convertCurrency(choosenCreditAmount, "Toman", "Rial"),
          values.otp,
          successCallback,
          () => {
            setConfirmLoading(false);
            setCreditRegistered(false);
          }
        );
      else
        MelatClubReducsCredit(
          orderId,
          mobileNumber,
          amount < choosenCreditAmount
            ? convertCurrency(amount, "Toman", "Rial")
            : convertCurrency(choosenCreditAmount, "Toman", "Rial"),
          values.otp,
          successCallback,
          () => {
            setConfirmLoading(false);
            setCreditRegistered(false);
          }
        );
    }
  };

  const paymentHandler = () => {
    onPaymentClick(amount);
  };

  return (
    <ModalWrapper>
      <Modal
        width="500px"
        // height="70vh"
        visible={true}
        onClose={onClose}
        padding="0px 0px 20px 0px"
        closable={true}
      >
        <MainContainer>
          <PaymentWaysContainer pickedWay={pickedWay}>
            {!transactionId && (
              <CashPaymentContainer
                onClick={() => onWayClick("cash")}
                className="cashPaymentContainer"
              >
                <Row className="cashPaymentTitle">
                  <Image
                    width={20}
                    height={20}
                    src={CashIcon}
                    alt="پرداخت نقدی"
                  />
                  <XXSmallHeading color={theme.primary300}>
                    پرداخت نقدی
                  </XXSmallHeading>
                </Row>
              </CashPaymentContainer>
            )}

            <MelatPaymentContainer
              onClick={() => onWayClick("melat")}
              className="melatPaymentContainer"
            >
              <MelatFirstRow>
                <Row className="titleContainer">
                  <Image
                    width={20}
                    height={20}
                    src={MelatIcon}
                    alt="پرداخت سازمانی بانک ملت"
                  />
                  <XXSmallHeading color={theme.primary300}>
                    پرداخت سازمانی بانک ملت
                  </XXSmallHeading>
                </Row>
                {creditStatus == "success" ? (
                  <Badge type="success" />
                ) : creditStatus === "fail" ? (
                  <Badge type="fail" />
                ) : (
                  <PrimaryButton
                    title="استعلام"
                    color="primary"
                    className="inquiryBtn"
                    size="xs"
                    width="54px"
                    onClick={inquiryHandler}
                    loading={inquiryLoading}
                  />
                )}
              </MelatFirstRow>

              {creditStatus == "success" && (
                <MelatHaveCreditContainer>
                  <Row className="creditFirstRow">
                    <XSmallParagraph color={theme.gray600}>
                      اعتبار شما:
                    </XSmallParagraph>

                    <Row className="creditAmount">
                      <LargeLabel color={theme.primary500}>
                        {initialCreditAmount
                          ? addSeparator(initialCreditAmount)
                          : "-"}
                      </LargeLabel>
                      <XSmallParagraph color={theme.gray500}>
                        تومان
                      </XSmallParagraph>
                    </Row>
                  </Row>
                  <Row>
                    <XSmallParagraph color={theme.gray500}>
                      مقدار استفاده از اعتبار
                    </XSmallParagraph>
                  </Row>
                  <CreditAmountWrapper>
                    <Row className="inputContainer">
                      <Formik
                        initialValues={{
                          amount:
                            initialCreditAmount > amount
                              ? addSeparator(Math.floor(amount / 1000) * 1000)
                              : addSeparator(
                                  Math.floor(initialCreditAmount / 1000) * 1000
                                ),
                        }}
                        enableReinitialize={true}
                        isInitialValid={true}
                        validationSchema={""}
                        onSubmit={(values, action) => {
                          getOtpHandler(values, action);
                        }}
                      >
                        {(formik) => (
                          <Form
                            className="amount-form"
                            onSubmit={formik.handleSubmit}
                          >
                            <Row className="input-toman">
                              <Input
                                label=""
                                name="amount"
                                onChange={(e: any) =>
                                  FormHandlers.onChange_number(
                                    e,
                                    formik,
                                    (
                                      e: any,
                                      name: string,
                                      formattedValue: string,
                                      value: string
                                    ) => {
                                      if (initialCreditAmount < Number(value)) {
                                        if (!showError) {
                                          setShowError(true);
                                        }
                                      } else {
                                        if (showError) {
                                          setShowError(false);
                                        }
                                      }

                                      if (Number(value) > amount) {
                                        if (!showSecondError) {
                                          setShowSecondError(true);
                                        }
                                      } else {
                                        if (showSecondError) {
                                          setShowSecondError(false);
                                        }
                                      }

                                      if (Number(value) % 1000 !== 0) {
                                        if (!showThirdError) {
                                          setShowThirdError(true);
                                        }
                                      } else {
                                        if (showThirdError) {
                                          setShowThirdError(false);
                                        }
                                      }
                                    }
                                  )
                                }
                                size="xs"
                                onBlur={(e: any) =>
                                  FormHandlers.onBlur(e, formik)
                                }
                                value={formik.values.amount}
                                disabled={
                                  !!transactionId || melatClubOtpTimer > 0
                                }
                                // mask="9999999999"
                              />
                              <XSmallParagraph color={theme.gray300}>
                                تومان
                              </XSmallParagraph>
                            </Row>
                            {melatClubOtpTimer > 0 ? (
                              <Row className="second">
                                <XSmallParagraph>
                                  {melatClubOtpTimer} ثانیه
                                </XSmallParagraph>
                              </Row>
                            ) : (
                              <PrimaryButton
                                color="primary"
                                size="xs"
                                title="اعمال و دریافت کد"
                                width="95px"
                                loading={sendOtpLoading}
                                disabled={
                                  formik.values.amount == 0 ||
                                  showError ||
                                  showSecondError ||
                                  showThirdError
                                }
                              />
                            )}
                          </Form>
                        )}
                      </Formik>
                    </Row>
                  </CreditAmountWrapper>
                  {(showError || showSecondError || showThirdError) && (
                    <ErrorWrapper>
                      {showError && (
                        <ErrorBox>
                          <XSmallParagraph>
                            مبلغ وارد شده از میزان اعتبار نباید بیشتر شود
                          </XSmallParagraph>
                        </ErrorBox>
                      )}
                      {showSecondError && (
                        <ErrorBox>
                          <XSmallParagraph>
                            مبلغ وارد شده از مبلغ خرید نباید بیشتر شود
                          </XSmallParagraph>
                        </ErrorBox>
                      )}
                      {showThirdError && (
                        <ErrorBox>
                          <XSmallParagraph>
                            سه رقم آخر مبلغ وارد شده باید صفر باشد مانند
                            (100,000)
                          </XSmallParagraph>
                        </ErrorBox>
                      )}
                    </ErrorWrapper>
                  )}
                  {showOtpBox && (
                    <>
                      {creditRegistered ? (
                        <SuccessCreditRegisterContainer>
                          <CheckIcon />
                          <XSmallParagraph color={theme.positive300}>
                            مبلغ اعتبار اعمال شد
                          </XSmallParagraph>
                        </SuccessCreditRegisterContainer>
                      ) : (
                        <CreditAmountWrapper>
                          <XXSmallParagraph color={theme.gray400}>
                            کد دریافتی:
                          </XXSmallParagraph>

                          <Formik
                            initialValues={{
                              otp: "",
                            }}
                            enableReinitialize={true}
                            isInitialValid={true}
                            validationSchema={""}
                            onSubmit={(values, action) => {
                              confirmOtpHandler(values, action);
                            }}
                          >
                            {(formik) => (
                              <Form
                                className="form"
                                onSubmit={formik.handleSubmit}
                              >
                                <CodeInput6
                                  formik={formik}
                                  name="otp"
                                  phoneNumber={""}
                                  formRowXl={8}
                                  formRowLg={8}
                                  formRowMd={8}
                                  formRowXs={14}
                                  formRowSm={12}
                                  showMobileText={false}
                                  underLineMode={true}
                                  formRowMinHeight="0px"
                                />

                                <PrimaryButton
                                  color="primary"
                                  size="xs"
                                  width="45px"
                                  title="تایید"
                                  type="submit"
                                  isCurve={true}
                                  loading={confirmLoading}
                                />
                              </Form>
                            )}
                          </Formik>
                        </CreditAmountWrapper>
                      )}
                    </>
                  )}
                </MelatHaveCreditContainer>
              )}
            </MelatPaymentContainer>
          </PaymentWaysContainer>
          <Divider
            width="100%"
            height="1px"
            orientation="horizontal"
            bgColor={theme.gray400}
          />
          {!transactionId ? (
            <PaymentAmountContainer>
              <Row className="allAmountContainer">
                <SmallParagraph>مبلغ کل</SmallParagraph>
                <Row className="amount">
                  <SmallLabel color={theme.gray500}>
                    {addSeparator(amount)}
                  </SmallLabel>
                  <XSmallParagraph color={theme.gray500}>تومان</XSmallParagraph>
                </Row>
              </Row>

              <Row className="amountContainer">
                <SmallParagraph>مبلغ قابل پرداخت</SmallParagraph>
                <Row className="amount">
                  <LargeLabel color={theme.primary500}>
                    {addSeparator(amount)}
                  </LargeLabel>
                  <XSmallParagraph color={theme.gray500}>تومان</XSmallParagraph>
                </Row>
              </Row>
              <BtnsContainer>
                <PrimaryButton
                  color="primary"
                  size="sm"
                  width="calc(65% - 25px)"
                  title="پرداخت"
                  loading={confirmLoading}
                  onClick={() => {
                    setConfirmLoading(true);
                    paymentHandler();
                  }}
                  isCurve={true}
                  disabled={
                    pickedWay === "melat" ? !creditRegistered : confirmLoading
                  }
                />

                <OutlineButton
                  color="primary"
                  size="sm"
                  width="calc(40% - 25px)"
                  title="انصراف"
                  loading={false}
                  onClick={onClose}
                  isCurve={true}
                />
              </BtnsContainer>
            </PaymentAmountContainer>
          ) : (
            <OutlineButton
              color="primary"
              size="sm"
              width="calc(40% - 25px)"
              title="انصراف"
              loading={false}
              onClick={onClose}
              isCurve={true}
            />
          )}
        </MainContainer>
      </Modal>
    </ModalWrapper>
  );
};

export default CheckOrderModal;
