import React, { useState } from "react";
import { useSelector } from "react-redux";
import { ModalContainer, Container, Body, ActionsContainer } from "./styles";

import { selectTheme } from "@/Redux/App/Selectors";
import Modal from "@/Shared/Kit/Modal";
import Col from "@/Shared/Kit/Col";
import Row from "@/Shared/Kit/Row";
import { XSmallParagraph } from "@/Shared/Kit/Typography/Paragraph";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import { PrimaryButton } from "@/Shared/Kit/Button/PrimaryButton";
import WarningIcon from "@/Shared/Kit/Icons/WarningIcon";

interface Props {
  text?: string;
  type: "confirm" | "delete";
  onConfirm: any;
  onCancel: any;
  loadingOnConfirm?: boolean;
}

const ConfirmModal: React.FC<Props> = (props) => {
  const theme = useSelector(selectTheme);

  const { text, onConfirm, onCancel, loadingOnConfirm = false } = props;

  const [loading, setLoading] = useState(false);

  const onConfirmClick = () => {
    if (loadingOnConfirm) {
      setLoading(true);
      let callback = () => {
        setLoading(false);
      };
      onConfirm(callback);
    } else {
      onConfirm();
    }
  };

  return (
    <ModalContainer className="confirm-modal-container">
      <Modal
        width={"500px"}
        // height="30vh"
        visible={true}
        headerTitle={"تایید عملیات"}
        onClose={onCancel}
        closable={false}
      >
        <Container>
          <Body>
            <Col className="icon">
              <WarningIcon />
            </Col>
            <Row className="text">
              <XSmallParagraph color={theme.gray800}>
                {text || "آیا از انجام عملیات اطمینان دارید؟"}
              </XSmallParagraph>
            </Row>
          </Body>
          <ActionsContainer>
            <GhostButton
              width={"110px"}
              size={"xs"}
              color={"gray"}
              title={"انصراف"}
              type="button"
              onClick={onCancel}
            />
            <PrimaryButton
              width={"110px"}
              size={"xs"}
              color={"primary"}
              title={"تایید"}
              type="button"
              loading={loadingOnConfirm ? loading : false}
              onClick={onConfirmClick}
            />
          </ActionsContainer>
        </Container>
      </Modal>
    </ModalContainer>
  );
};

export default ConfirmModal;
