import styled from "styled-components";
import Row from "@/Shared/Kit/Row";

export const ModalContainer = styled(Row)``;

export const Container = styled(Row)`
  height: 100%;
  align-items: flex-start;
  padding: 20px;
`;

export const Body = styled(Row)`
  margin-bottom: 20px;
  .icon {
    width: 42px;
    height: 42px;
    margin-left: 10px;
    background-color: ${(props) => props.theme.warning50};
    border-radius: 8px;
    svg {
      width: 22px;
      height: 20px;
      fill: ${(props) => props.theme.warning600};
    }
  }
  .text {
    width: calc(100% - 52px);
    p {
      text-align: justify;
    }
  }
`;

export const ActionsContainer = styled(Row)`
  margin-top: auto;
  justify-content: flex-end;
  button:first-child {
    margin-left: 10px;
  }
  @media (max-width: ${(props) => props.theme.xs}) {
    button {
      width: 45%;
    }
    button:first-child {
      margin-left: auto;
    }
  }
`;
