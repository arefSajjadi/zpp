import { SUPPORT_PHONE } from "@/config/constants";

    export const PublicDic: any = {
        login: {
            fa:"ورود",
            en:""
        },
        register: {
            fa:"ثبت نام",
            en:""
        },
        phoneNumber: {
            fa:SUPPORT_PHONE,
            en:""
        },
        followUs: {
            fa:"مارا در شبکه های اجتماعی دنبال کنید",
            en:""
        }
    }
    