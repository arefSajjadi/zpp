
    export const MessagesDic: any = {
    }
    