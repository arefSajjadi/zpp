
import type { AppProps } from 'next/app';
import '@/styles/globals.css';
import { Provider } from "react-redux";
import { store } from "@/Redux/store";
import { ThemeProvider } from "styled-components"
import { theme } from '@/Utils/theme';
import { ToastContainer } from "@/Shared/Kit/Toast";

import GTM from '@/Components/GTM';

function MyApp({ Component, pageProps }: AppProps) {

  return (
    
    <Provider store={store}>
      <ThemeProvider theme={theme}>
        <Component {...pageProps} />
        <GTM />
        <ToastContainer />
      </ThemeProvider>
    </Provider>
    
  );
}

export default MyApp;
    