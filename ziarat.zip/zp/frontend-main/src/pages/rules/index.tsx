import Breadcrumb from "@/Components/Breadcrumb/Breadcrumb";
import Rules from "@/Components/Dashboard/Rules";
import { MainContainer } from "@/Components/Rules/styles";
import Row from "@/Shared/Kit/Row";
import Layout from "@/Shared/Layout";
import useIsMobile from "@/Utils/Responsive";

const Index = () => {
  const responsive = useIsMobile();
  const breadcrumb = [
    {
      src: `/rules`,
      name: `قوانین و مقررات`,
    },
  ];
  return (
    <Layout>
      <MainContainer>
        <Row className="breadcrumb">
          {responsive !== "mobile" && (
            <Breadcrumb BreadcrumbList={breadcrumb} />
          )}
        </Row>
        <Rules />
      </MainContainer>
    </Layout>
  );
};

export default Index;
