import React from 'react';
import axios from "axios";
import {baseURL} from "@/Requests/AxiosInstance";
import Head from "next/head";
import {ContentContainer} from "@/Components/MainPage/HeaderBox/styles";
import {XXLargeHeading} from "@/Shared/Kit/Typography/Heading";
import {MainContainer} from "@/Components/Tours/KarbalaTour/styles";
import Layout from "@/Shared/Layout";

const Index = () => {
    return (
        <>
            <Layout>
                <MainContainer xl={24}>
                    <ContentContainer>
                        <XXLargeHeading>{"بلیط هواپیما"}</XXLargeHeading>
                    </ContentContainer>
                </MainContainer>
            </Layout>
        </>
    );
};

export default Index;
