import Breadcrumb from "@/Components/Breadcrumb/Breadcrumb";
import HotelDetails from "@/Components/Hotel/HotelDetails";
import { fetchHomeDataCsr } from "@/Redux/Home/ApiFunction";
import { fetchHome } from "@/Redux/Home/HomeSlice";
import { SliderType } from "@/Redux/Home/Interfaces";
import { getHotelDetail } from "@/Redux/Hotel/HotelSlice";
import { HotelType } from "@/Redux/Hotel/Interface";
import { AppDispatch } from "@/Redux/store";
import { baseURL } from "@/Requests/AxiosInstance";
import Layout from "@/Shared/Layout";
import axios from "axios";
import Head from "next/head";
import { useEffect } from "react";
import { useDispatch } from "react-redux";

interface Props {
  data: HotelType;
  hotelname: string;
  persionHotelname: string;
  slider: SliderType[];
}
const Index: React.FC<Props> = (props) => {
  const { data, hotelname, persionHotelname, slider } = props;

  const dispatch = useDispatch<AppDispatch>();
  useEffect(() => {
    dispatch(
      getHotelDetail({
        data: data,
        loading: false,
      })
    );
    dispatch(
      fetchHome({
        slider,
        loading: false,
        sourceProvince: [],
        destinationProvince: [],
      })
    );
  }, []);

  return (
    <>
      <Head>
        <title>{`هتل ${persionHotelname} نجف | تصاویر + لیست تورها`}</title>
        <meta
          name="description"
          content={`رزرو هتل ${persionHotelname} نجف با رسم زیارت - بهترین قیمت`}
        />
        <meta name="google-site-verification" content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk" />
        <meta name="enamad" content="850460"/>
      </Head>
      <Layout>
        <HotelDetails
          hotelname={hotelname}
          persionHotelname={persionHotelname}
          hotelCity="najaf"
          hotelCityPersian="نجف"
        />
      </Layout>
    </>
  );
};

export default Index;

export async function getServerSideProps(context: any) {
  const hotelname = context.params?.hotelname;
  const { data } = await axios.get(`/api/landing/hotel/${hotelname}`, {
    baseURL: baseURL,
  });
  const homeData = await axios.get(`/api/landing/home`, {
    baseURL: baseURL,
  });
  return {
    props: {
      data: data,
      hotelname: hotelname,
      persionHotelname: data?.name,
      slider: homeData?.data?.slider,
    },
  };
}