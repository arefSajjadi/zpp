import Layout from "@/Shared/Layout";
import { AppDispatch } from "@/Redux/store";
import { SrcOrDesProvince } from "@/Utils/FindSrcOrDesProvince";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { fetchHome } from "@/Redux/Home/HomeSlice";
import { ProvinceType, SliderType } from "@/Redux/Home/Interfaces";
import axios from "axios";
import { baseURL } from "@/Requests/AxiosInstance";
import HotelComponent from "@/Components/Hotel";
import Head from "next/head";

interface Props {
  data: {
    slider: SliderType[];
    province: ProvinceType[];
  };
}
export default function Hotel({ data }: Props) {
  const dispatch = useDispatch<AppDispatch>();
  useEffect(() => {
    const srcOrDesProvince = SrcOrDesProvince(data?.province);

    dispatch(
      fetchHome({
        slider: data.slider,
        sourceProvince: srcOrDesProvince.srcProvince,
        destinationProvince: srcOrDesProvince.desProvince,
        loading: false,
      })
    );
  }, []);
  return (
    <>
      <Head>
        <title>رزرو هتل های عراق با بهترین قیمت | رسم زیارت </title>
        <meta
          name="description"
          content={
            "رزرو هتل های عراق با تضمین بهترین قیمت همراه با عکس و مشخصات هتل با پشتیبانی 24 ساعته "
          }
        />
        <meta name="enamad" content="850460" />
        <link rel="canonical" href="https://ziarat.co/hotel" />
      </Head>
      <Layout>
        <HotelComponent />
      </Layout>
    </>
  );
}

export async function getServerSideProps() {
  const { data } = await axios.get(`/api/landing/home`, {
    baseURL: baseURL,
  });
  return { props: { data: data } };
}
