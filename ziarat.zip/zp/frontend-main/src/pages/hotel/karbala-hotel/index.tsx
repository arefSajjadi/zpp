import HotelList from "@/Components/Hotel/HotelList";
import HeaderBox from "@/Components/MainPage/HeaderBox";
import Layout from "@/Shared/Layout";
import React, { useEffect } from "react";
import { HotelListMainContainer } from "@/Components/Hotel/styles";
import axios from "axios";
import { baseURL } from "@/Requests/AxiosInstance";
import { useDispatch } from "react-redux";
import { AppDispatch } from "@/Redux/store";
import { getHotels } from "@/Redux/Hotel/HotelSlice";
import Row from "@/Shared/Kit/Row";
import Breadcrumb from "@/Components/Breadcrumb/Breadcrumb";
import Head from "next/head";
import useIsMobile from "@/Utils/Responsive";
import KarbalaHotelDes from "@/Components/SourceCityDescription/KarbalaHotelDes";
import { SUPPORT_PHONE } from "@/config/constants";

interface Props {
  data: any;
}
const Index = ({ data }: Props) => {
  const dispatch = useDispatch<AppDispatch>();
  const responsive = useIsMobile();
  useEffect(() => {
    dispatch(
      getHotels({
        data: data?.data,
        count: data?.total,
        loading: false,
        skip: 1,
      })
    );
  }, []);

  const breadcrumb = [
    {
      src: `/hotel`,
      name: `هتل`,
    },
    {
      src: `/hotel/karbala-hotel`,
      name: `هتل های کربلا`,
    },
  ];
  return (
    <>
      <Head>
        <title>رزرو هتل کربلا - تضمین قیمت هتل های کربلا | رسم و زیارت</title>
        <meta
          name="description"
          content="رزرو هتل کربلا همراه با لیست قیمت هتل های کربلا با تضمین و تخفیف ویژه در رسم زیارت"
        />
        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
        <meta name="enamad" content="850460" />
        <link rel="canonical" href="https://ziarat.co/hotel/karbala-hotel" />
        {/* <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "BreadcrumbList",
              itemListElement: [
                {
                  "@type": "ListItem",
                  position: 1,
                  name: "رسم زیارت",
                  item: "https://ziarat.co",
                },
                {
                  "@type": "ListItem",
                  position: 2,
                  name: "هتل",
                  item: "https://ziarat.co/hotel",
                },
                {
                  "@type": "ListItem",
                  position: 3,
                  name: "هتل های شهر کربلا",
                  item: "https://ziarat.co/hotel/karbala-hotel",
                },
              ],
            }),
          }}
        /> */}
      </Head>
      <Layout>
        <HotelListMainContainer>
          <HeaderBox
            description=""
            title="رزرو هتل کربلا"
            showContent={true}
            showTab={true}
            mode="hotel"
            hotelDefaultCity={1}
          />
          <Row className="breadcrumb">
            {responsive !== "mobile" && (
              <Breadcrumb BreadcrumbList={breadcrumb} />
            )}
          </Row>
          <HotelList hotelCity="karbala" />

          <Row className="descriptionContainer">
            <KarbalaHotelDes />
          </Row>
        </HotelListMainContainer>
      </Layout>
    </>
  );
};

export default Index;

export async function getServerSideProps() {
  const params = {
    type: "hotel",
    src_province_slug: "karbala",
    per_page: 8,
  };
  const { data } = await axios.get(`/api/home/filter`, {
    baseURL: baseURL,
    params: params,
  });
  return { props: { data: data } };
}
