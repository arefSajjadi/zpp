import Payment from "@/Components/Payment";
import Layout from "@/Shared/Layout";

const Index = () => {
    return ( 
        <Layout>
            <Payment />
        </Layout>
     );
}
 
export default Index;