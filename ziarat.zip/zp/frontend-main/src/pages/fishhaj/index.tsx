import Breadcrumb from "@/Components/Breadcrumb/Breadcrumb";
import FishHajDescription from "@/Components/SourceCityDescription/FishHajDescription";
import Layout from "@/Shared/Layout";
import Head from "next/head";
import { ContentContainer } from "@/Components/MainPage/HeaderBox/styles";
import { XLargeHeading, XXLargeHeading } from "@/Shared/Kit/Typography/Heading";
import React from "react";
import FishhajDetail from "@/Components/Fishhaj/FishhajDetail";
import { FishHajContainer } from "@/Components/Fishhaj/styles";
import { XXLargeHeadingStyle } from "@/Shared/Kit/Typography/Heading/styles";
import useIsMobile from "@/Utils/Responsive";
import Row from "@/Shared/Kit/Row";

const Index = () => {
  const responsive = useIsMobile();
  const BreadcrumbList = [
    {
      src: `/fishhaj`,
      name: `فیش حج`,
    },
  ];
  return (
    <>
      <Head>
        <title>فیش حج | نقل‌وانتقال عمره وتمتع + خرید فیش</title>
        <meta
          name="description"
          content="خرید فیش تمتع و عمره + نقل وانتقال فیش با هزینه مصوب حج وزیارت"
        />
        <link rel="canonical" href="https://ziarat.co/fishhaj" />
      </Head>
      <Layout>
        <FishHajContainer>
          <ContentContainer
            backgroundImageUrl={"/Images/MainPage/fishhaj_banner.webp"}
            mode={"normal"}
          >
            {<XXLargeHeadingStyle>{"فیش حج عمره و تمتع"}</XXLargeHeadingStyle>}
          </ContentContainer>
          <Row className="breadcrumb">
            {responsive !== "mobile" && (
              <Breadcrumb BreadcrumbList={BreadcrumbList} />
            )}
          </Row>
          <FishhajDetail />
          <FishHajDescription />
        </FishHajContainer>
      </Layout>
    </>
  );
};

export default Index;
