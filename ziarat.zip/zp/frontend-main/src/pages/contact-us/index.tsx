import ContactUs from "@/Components/ContactUs";
import Layout from "@/Shared/Layout";
import Head from "next/head";
import React from "react";

const Index = () => {
  return (
    <>
      <Head>
        <title> تماس با ما | رسم زیارت </title>
        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
        <meta name="enamad" content="850460" />
        {/* <script 
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify( 
          {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList", 
            "itemListElement": [
              {
                "@type": "ListItem",
                "position": 1,
                "name": "رسم زیارت",
                "item": "https://ziarat.co"
            },
            {
              "@type": "ListItem",
              "position": 2,
              "name": "تماس با ما",
              "item": "https://ziarat.co/contact-us"
            }
            ]
          }
        )}}
        /> */}
      </Head>
      <Layout>
        <ContactUs />
      </Layout>
    </>
  );
};

export default Index;
