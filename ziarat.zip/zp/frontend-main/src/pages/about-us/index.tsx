import AboutUs from '@/Components/AboutUs';
import Layout from '@/Shared/Layout';
import Head from 'next/head';
import React from 'react';

const Index = () => {
    return (
        <>
        <Head>
        <meta name="google-site-verification" content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk" />
        <meta name="enamad" content="850460"/>
        </Head>
        <Layout>
            <AboutUs />
        </Layout>
        </> 
     );
}
 
export default Index;
