import React from "react";
import { TourType } from "@/Redux/Tour/Interface";
import { ProvinceType } from "@/Redux/Home/Interfaces";
import Head from "next/head";
import Layout from "@/Shared/Layout";
import axios from "axios";
import { baseURL } from "@/Requests/AxiosInstance";
import KarbalaTour from "@/Components/Tours/KarbalaTour";
import KarbalaInstallmentDes from "@/Components/SourceCityDescription/KarbalaInstallmentDes";

interface Props {
  province: ProvinceType[];
  title: string;
  description: string;
}

const Index: React.FC<Props> = (props) => {
  const { province, title, description } = props;
  return (
    <>
      <Head>
        <title>{title}</title>
        <meta key="description" name="description" content={description} />
        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
        <meta name="enamad" content="850460" />
        <link
          rel="canonical"
          href="https://ziarat.co/tours/karbala/installment"
        />
        <meta charSet="utf-8" />
        <meta httpEquiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta httpEquiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <link
          rel="apple-touch-icon"
          sizes="60x60"
          href="https://ziarat.co/favicon.ico"
        />
        <link
          rel="icon"
          type="image/png"
          sizes="32x32"
          href="https://ziarat.co/favicon.ico"
        />
        <link
          rel="icon"
          type="image/png"
          sizes="16x16"
          href="https://ziarat.co/favicon.ico"
        />
        <link rel="mask-icon" href="https://ziarat.co/favicon.ico" />
        <meta name="msapplication-TileColor" content="#da532c" />
        <meta name="theme-color" content="#ffffff" />
        <meta
          name="keywords"
          content="تور کربلا،تور عتبات عالیات ، رسم زیارت ، کربلا"
        />
        <meta name="author" content="rasm ziarat" />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta
          property="og:url"
          content="https://ziarat.co/tours/karbala/installment"
        />
        <meta
          property="og:image"
          content="https://ziarat.co/tours/karbala/installment"
        />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="تور اقساطی کربلا با رسم زیارت" />
        <meta
          name="vb_meta_bburl"
          content="https://ziarat.co/tours/karbala/installment"
        />
        <link rel="dns-prefetch" href="https://google.com" />
        {/* <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "BreadcrumbList",
              itemListElement: [
                {
                  "@type": "ListItem",
                  position: 1,
                  name: "رسم زیارت",
                  item: "https://ziarat.co",
                },
                {
                  "@type": "ListItem",
                  position: 2,
                  name: "تورها",
                  item: "https://ziarat.co/tours",
                },
                {
                  "@type": "ListItem",
                  position: 3,
                  name: "کربلا",
                  item: "https://ziarat.co/tours/karbala",
                },
              ],
            }),
          }}
        /> */}
      </Head>
      <Layout>
        <KarbalaTour
          breadcrumb={[
            {
              src: `/tours`,
              name: `تورها`,
            },
            {
              src: `/tours/karbala`,
              name: `تور کربلا`,
            },
            {
              src: "/tours/karbala/installment",
              name: "تور کربلا اقساطی",
            },
          ]}
          title={"تور اقساطی کربلا"}
          descriptionGone={true}
          province={province}
        >
          <KarbalaInstallmentDes />
        </KarbalaTour>
      </Layout>
    </>
  );
};

export default Index;

export const getStaticProps = async () => {
  const province = await axios.get("/api/province", {
    baseURL: baseURL,
  });

  const title = "تور اقساطی کربلا | بدون ضامن و اقساط بلند مدت - رسم زیارت";
  const description =
    "رزرو تور اقساطی کربلا بدون پیش پرداخت و دسته چک  با اقساط بلند ماهه همراه با تمامی امکانات در رسم زیارت";

  return {
    props: {
      title,
      description,
      province: province.data,
    },
  };
};
