import React from "react";
import Order from "@/Components/Order";
import Layout from "@/Shared/Layout";

const Index = () => {
  return;
  // (
  //     <Layout>
  //         <Order />
  //     </Layout>
  //  );
};

export default Index;
