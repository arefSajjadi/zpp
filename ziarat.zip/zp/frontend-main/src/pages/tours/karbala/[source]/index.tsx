import React, { useEffect, useState } from "react";
import {
  FormContainer,
  InfoContainer,
  MainContainer,
} from "@/Components/Tours/styles";
import Layout from "@/Shared/Layout";
import ToursList from "@/Components/Tours/ToursList";
import axios from "axios";
import { baseURL } from "@/Requests/AxiosInstance";
import { ProvinceType } from "@/Redux/Home/Interfaces";
import {
  findCityPersianName,
  titleMetaOfPages,
} from "@/Utils/FindeCityPersianName";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch } from "@/Redux/store";
import { useRouter } from "next/router";
import { fetchHomeDataCsr } from "@/Redux/Home/ApiFunction";
import Row from "@/Shared/Kit/Row";
import AirPlaneIcon from "@/Assets/Icons/AirPlaneIcon";
import CalendarIcon from "@/Assets/Icons/CalendarIcon";
import { SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";
import TwoUserIcon from "@/Assets/Icons/TwoUserIcon";
import { PrimaryButton } from "@/Shared/Kit/Button/PrimaryButton";
import SearchIcon from "@/Shared/Kit/Icons/SearchIcon";
import Divider from "@/Shared/Kit/Divider";
import { selectTheme } from "@/Redux/App/Selectors";
import SelectTourBox from "@/Components/MainPage/SelectTourBox";
import CrossIcon from "@/Shared/Kit/Icons/CrossIcon";
import { GhostButton } from "@/Shared/Kit/Button/GhostButton";
import Breadcrumb from "@/Components/Breadcrumb/Breadcrumb";
import FromTehran from "@/Components/SourceCityDescription/FromTehran";
import FromYazdDescription from "@/Components/SourceCityDescription/FromYazdDescription";
import FromEsfahanDescription from "@/Components/SourceCityDescription/FromEsfahanDescription";
import FromMashhadDescription from "@/Components/SourceCityDescription/FromMashhadDescription";
import FromQomDescription from "@/Components/SourceCityDescription/FromQomDescription";
import FromKarajDescription from "@/Components/SourceCityDescription/FromKarajDescription";
import FromTabrizDescription from "@/Components/SourceCityDescription/FromTabrizDescription";
import FromAhvazDescription from "@/Components/SourceCityDescription/FromAhvazDescription";
import FromShirazDescription from "@/Components/SourceCityDescription/FromShirazDescription";
import FromKashanDescription from "@/Components/SourceCityDescription/FromKashanDescription";
import FromAmolDescription from "@/Components/SourceCityDescription/FromAmolDescription";
import FromRashtDescription from "@/Components/SourceCityDescription/FromRashtDescription";
import FromBirjandDescription from "@/Components/SourceCityDescription/FromBirjandDescription";
import FromZanjanDescription from "@/Components/SourceCityDescription/FromZanjanDescription";
import FromSemnanDescription from "@/Components/SourceCityDescription/FromSemnanDescription";
import FromQazvinDescription from "@/Components/SourceCityDescription/FromQazvinDescription";
import FromGolestanDescription from "@/Components/SourceCityDescription/FromGolestanDescription";
import FromArdabilDescription from "@/Components/SourceCityDescription/FromArdabilDescription";
import FromUrmiaDescription from "@/Components/SourceCityDescription/FromUrmiaDescription";
import FromArakDescription from "@/Components/SourceCityDescription/FromArakDescription";
import FromYasojDescription from "@/Components/SourceCityDescription/FromYasojDescription";
import FromBojnurdDescription from "@/Components/SourceCityDescription/FromBojnurdDescription";
import FromHamedanDescription from "@/Components/SourceCityDescription/FromHamedanDescription";
import FromKermanshahDescription from "@/Components/SourceCityDescription/FromKermanshahDescription";
import FromZahedanDescription from "@/Components/SourceCityDescription/FromZahedanDescription";

import useIsMobile from "@/Utils/Responsive";
import Head from "next/head";
import moment from "moment-jalaali";

interface Props {
  source: string;
  sourceId: number;
  sourceCityPersionName: string;
  title: string;
  description: string;
  sourceCityEnName: string;
}
const Index: React.FC<Props> = ({
  source,
  sourceCityPersionName,
  sourceId,
  title,
  description,
  sourceCityEnName,
}) => {
  const dispatch = useDispatch<AppDispatch>();
  const theme = useSelector(selectTheme);
  const router = useRouter();
  const [showForm, setShowForm] = useState<boolean>(false);
  const responsive = useIsMobile();
  moment.loadPersian({ dialect: "persian-modern", usePersianDigits: false });

  useEffect(() => {
    fetchHomeDataCsr(dispatch);
  }, []);

  const onSearchInfoClick = () => {
    setShowForm(true);
  };

  const cancelHandler = () => {
    setShowForm(false);
  };

  const BreadcrumbList = [
    { src: `/tours`, name: `تورها` },
    { src: `/tours/karbala/from-tehran`, name: `تور کربلا` },
    {
      src: `/tours/karbala/${source}`,
      name: `تور کربلا از ${sourceCityPersionName}`,
    },
  ];

  const renderSwitch = (param: string) => {
    switch (param) {
      case "from-tehran":
        return <FromTehran />;
      case "from-yazd":
        return <FromYazdDescription />;
      case "from-isfahan":
        return <FromEsfahanDescription />;
      case "from-mashhad":
        return <FromMashhadDescription />;
      case "from-qom":
        return <FromQomDescription />;
      case "from-karaj":
        return <FromKarajDescription />;
      case "from-tabriz":
        return <FromTabrizDescription />;
      case "from-ahvaz":
        return <FromAhvazDescription />;
      case "from-hamedan":
        return <FromHamedanDescription />;
      case "from-shiraz":
        return <FromShirazDescription />;
      case "from-kashan":
        return <FromKashanDescription />;
      case "from-kermanshah":
        return <FromKermanshahDescription />;
      case "from-amol":
        return <FromAmolDescription />;
      case "from-rasht":
        return <FromRashtDescription />;
      case "from-birjand":
        return <FromBirjandDescription />;
      case "from-zanjan":
        return <FromZanjanDescription />;
      case "from-semnan":
        return <FromSemnanDescription />;
      case "from-qazvin":
        return <FromQazvinDescription />;
      case "from-golestan":
        return <FromGolestanDescription />;
      case "from-ardabil":
        return <FromArdabilDescription />;
      case "from-urmia":
        return <FromUrmiaDescription />;
      case "from-arak":
        return <FromArakDescription />;
      case "from-yasuj":
        return <FromYasojDescription />;
      case "from-bojnurd":
        return <FromBojnurdDescription />;
      case "from-zahedan":
        return <FromZahedanDescription />;
      default:
        return "";
    }
  };

  moment.loadPersian({ usePersianDigits: false });

  const renderDateLabel = () => {
    const { from, to, date } = router.query;

    // from / to → میلادی
    const parseGregorian = (value?: string | string[]) => {
      if (!value || typeof value !== "string") return null;

      // مثال: 2025-12-18
      const m = moment(value, "YYYY-MM-DD");
      return m.isValid() ? m : null;
    };

    // date → جلالی
    const parseJalali = (value?: string | string[]) => {
      if (!value || typeof value !== "string") return null;

      // مثال: 1404-09-27
      const m = moment(value, "jYYYY-jMM-jDD");
      return m.isValid() ? m : null;
    };

    // حالت بازه: from/to میلادی، خروجی جلالی
    const fromM = parseGregorian(from);
    const toM = parseGregorian(to);

    if (fromM && toM) {
      const fromLabel = `${fromM.jDate()} ${fromM.format("jMMMM")}`;
      const toLabel = `${toM.jDate()} ${toM.format("jMMMM")}`;
      return `از ${fromLabel} تا ${toLabel}`;
    }

    // حالت تک‌تاریخ: date جلالی
    const singleM = parseJalali(date);
    if (singleM) {
      return `${singleM.jDate()} ${singleM.format("jMMMM")}`;
    }

    return "همه روزها";
  };

  return (
    <>
      <Head>
        <title>{title}</title>
        <meta name="description" content={description} />
        <link
          rel="canonical"
          href={`https://ziarat.co/tours/karbala/from-${sourceCityEnName}`}
        />
        <link rel="preconnect" href="https://api.hotelaa.ir" />
        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
        <meta name="enamad" content="850460" />
      </Head>
      <Layout>
        <MainContainer xl={24}>
          {showForm ? (
            <FormContainer>
              <GhostButton
                size="sm"
                color="primary"
                width="44px"
                icon={CrossIcon}
                onClick={cancelHandler}
                className="cancelBtn"
              />

              <SelectTourBox setShowForm={setShowForm} />
            </FormContainer>
          ) : (
            <InfoContainer>
              <Row className="eachInfoContainer">
                <AirPlaneIcon />
                <h1 style={{ fontSize: "14px", fontWeight: "unset" }}>
                  {`تور کربلا از ${sourceCityPersionName}`}
                </h1>
              </Row>
              <Divider
                orientation="vertical"
                height="20px"
                width="1px"
                bgColor={theme.gray300}
              />
              <Row className="eachInfoContainer">
                <CalendarIcon />
                <SmallParagraph>{renderDateLabel()}</SmallParagraph>
              </Row>

              {/* <Divider
                orientation="vertical"
                height="20px"
                width="1px"
                bgColor={theme.gray300}
              /> */}
              {/* <Row className="eachInfoContainer">
                <TwoUserIcon />
                <SmallParagraph>
                  {`${router.query?.total ? router.query?.total : 1} مسافر`}
                </SmallParagraph>
              </Row> */}
              <PrimaryButton
                size="sm"
                color="primary"
                width="40px"
                icon={SearchIcon}
                onClick={onSearchInfoClick}
                isCurve={true}
                className="searchBtn"
              />
            </InfoContainer>
          )}

          <Row className="breadcrumb">
            {responsive !== "mobile" && (
              <Breadcrumb BreadcrumbList={BreadcrumbList} />
            )}
          </Row>
          <ToursList
            source={source}
            sourceId={sourceId}
            cancelHandler={cancelHandler}
          />

          <Row className="descriptionContainer">{renderSwitch(source)}</Row>
        </MainContainer>
      </Layout>
    </>
  );
};

export default Index;

export const getStaticPaths = async () => {
  const data = await axios.get("/api/province", { baseURL: baseURL });
  const provinces = data.data;
  const paths = provinces.map((province: ProvinceType) => ({
    params: { source: `from-${province.slug}`, sourceId: province.id },
  }));

  return { paths, fallback: false };
};

export const getStaticProps = async ({ params }: any) => {
  const cityNameWithOutFrom = params.source.split("-")[1];
  const PN = findCityPersianName(cityNameWithOutFrom);
  const [title, description] = titleMetaOfPages(cityNameWithOutFrom);

  const data = await axios.get("/api/province", { baseURL: baseURL });
  const provinces = data.data;
  const id = provinces.filter(
    (province: ProvinceType) => province.slug == cityNameWithOutFrom
  )[0].id;

  return {
    props: {
      source: params.source,
      sourceCityPersionName: PN,
      sourceId: id,
      title: title,
      description: description,
      sourceCityEnName: cityNameWithOutFrom,
    },
  };
};
