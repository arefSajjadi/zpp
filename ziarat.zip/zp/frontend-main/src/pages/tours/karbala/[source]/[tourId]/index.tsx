import Layout from "@/Shared/Layout";
import React, { useEffect, useState } from "react";
import {
  DescriptionContainer,
  LeftCol,
  MainContainer,
  RightCol,
  Arrow,
  ModalContainer,
  ListsStyle,
} from "@/Components/Tours/TourId/styles";
import TourDetails from "@/Components/Tours/TourId/TourDetails";
import TourHotels from "@/Components/Tours/TourId/TourHotels";
import { SmallLabel } from "@/Shared/Kit/Typography/Label";
import Divider from "@/Shared/Kit/Divider";
import { useDispatch, useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import { selectTourState } from "@/Redux/Tour/Selectors";
import {
  MediumParagraph,
  SmallParagraph,
  XSmallParagraph,
  XXSmallParagraph,
} from "@/Shared/Kit/Typography/Paragraph";
import Row from "@/Shared/Kit/Row";
import Sidebar from "@/Components/Tours/TourId/Sidebar";
import { useRouter } from "next/router";
import { GetTour } from "@/Redux/Tour/ApiFunction";
import { AppDispatch } from "@/Redux/store";
import Storage from "@/Storage";
import ArrowRightIcon from "@/Shared/Kit/Icons/ArrowRightIcon";
import useIsMobile from "@/Utils/Responsive";
import { CloseRequest, ReserveTour } from "@/Redux/Profile/ApiFunction";
import Modal from "@/Shared/Kit/Modal";
import { PrimaryButton } from "@/Shared/Kit/Button/PrimaryButton";
import { setNextUrl, setShowLoginModal } from "@/Redux/Auth/AuthSlice";
import { hasCookie } from "cookies-next";
import NameSpace from "@/Storage/NameSpace";
import { OutlineButton } from "@/Shared/Kit/Button/OutlineButton";
import SimpleStarIcon from "@/Assets/Icons/SimpleStarIcon";
import Loading from "@/Shared/Kit/Loading";

const Index = () => {
  const [btnLoading, setBtnLoading] = useState<boolean>(false);
  const [show, setShow] = useState(false);
  const [timer, setTimer] = useState(5);
  const [reserveId, setreserveId] = useState<null | number>(null);

  const theme = useSelector(selectTheme);
  const dispatch = useDispatch<AppDispatch>();
  const { tourDetails, tourDetailsLoading } = useSelector(selectTourState);
  const router = useRouter();
  const responsive = useIsMobile();

  useEffect(() => {
    if (tourDetails?.status === "deactive") router.push("/");
  }, [tourDetails, router]);

  useEffect(() => {
    if (router.query?.tourId && typeof router.query?.tourId === "string") {
      GetTour(dispatch, router.query.tourId);
    }
  }, [router.query, dispatch]);

  const userToken = hasCookie(NameSpace.token);

  useEffect(() => {
    const shouldReserve = Storage.get("shouldShowReserveModal");
    if (userToken && shouldReserve) {
      Storage.remove("shouldShowReserveModal");
      handleReserve();
    }
  }, [userToken]);

  useEffect(() => {
    if (!show) return;

    if (timer === 0) {
      router.push("/dashboard");
      setShow(false);
      return;
    }

    const interval = setInterval(() => {
      setTimer((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [show, timer, router]);

  const onNextHandler = () => {
    if (!hasCookie(NameSpace.token)) {
      dispatch(setNextUrl(router.asPath));
      Storage.set("shouldShowReserveModal", true);
      dispatch(setShowLoginModal(true));
    } else {
      handleReserve();
    }
  };

  const handleReserve = () => {
    Storage.remove("orderHistory");
    Storage.set("history", {
      ...router.query,
      adult: router?.query?.adult ? router?.query?.adult : 1,
      child: router?.query?.child ? router?.query?.child : undefined,
      baby: router?.query?.baby ? router?.query?.baby : undefined,
    });

    const failCallback = () => {
      setBtnLoading(false);
    };

    const successCallback = (data: any) => {
      setBtnLoading(false);
      setShow(true);
      setTimer(5);
      setreserveId(data.id);
    };

    if (router.query?.tourId) {
      setBtnLoading(true);
      ReserveTour(+router.query?.tourId, successCallback, failCallback);
    }
  };

  const closeDialog = () => {
    setShow(false);
  };

  useEffect(() => {
    if (typeof window === "undefined") return;

    if (!router.asPath.includes("#comments")) return;

    if (tourDetailsLoading) return;

    const timeout = setTimeout(() => {
      const el = document.getElementById("comments");
      if (!el) return;

      el.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }, 100);
    return () => clearTimeout(timeout);
  }, [router.asPath, tourDetailsLoading, tourDetails?.comments?.length]);

  return (
    <Layout>
      <Modal
        // height="40vh"
        headerTitle="درخواست ثبت نام"
        size="xxs"
        visible={show}
        onClose={closeDialog}
      >
        <ModalContainer>
          <MediumParagraph color="#1E8C3D">
            درخواست شما ثبت شد، در اسرع وقت با شما تماس میگیریم.
          </MediumParagraph>
          <PrimaryButton
            color="primary"
            size="sm"
            width="60%"
            title="ورود به حساب کاربری"
            onClick={() => {
              router.push("/dashboard");
              setShow(false);
            }}
            isCurve={true}
          />
          <OutlineButton
            width="110px"
            color="negative"
            size="sm"
            title="لغو درخواست"
            onClick={() => {
              reserveId && CloseRequest(reserveId, dispatch);
              closeDialog();
            }}
          />
          <XXSmallParagraph>
            تا
            <span style={{ fontWeight: "bold" }}> 0{timer} : 00 </span>
            آینده به صفحه پنل کاربری انتقال داده می‌شوید
          </XXSmallParagraph>
        </ModalContainer>
      </Modal>

      <MainContainer>
        {responsive === "mobile" && (
          <Arrow onClick={() => router.back()}>
            <ArrowRightIcon />
            <MediumParagraph>بازگشت</MediumParagraph>
          </Arrow>
        )}

        <RightCol xl={17} xs={24}>
          <TourDetails showBrokerage={false} />

          <TourHotels />

          <DescriptionContainer>
            <Row className="first-des">
              <SmallLabel> توضیحات </SmallLabel>
              <Divider
                orientation="vertical"
                width="1px"
                height="20px"
                bgColor={theme.gray200}
              />
              <Row className="textContainer">
                {tourDetails.descriptions?.map((des, index) => (
                  <SmallParagraph key={index + 1}>{des}</SmallParagraph>
                ))}
              </Row>
            </Row>

            <Row className="second-des">
              <SmallLabel>مدارک لازم</SmallLabel>
              <Divider
                orientation="vertical"
                width="1px"
                height="20px"
                bgColor={theme.gray200}
              />
              <Row className="textContainer">
                {tourDetails.travel_options &&
                  tourDetails.travel_options?.map((item, index) => (
                    <SmallParagraph key={index + 1}>
                      {item.value}
                    </SmallParagraph>
                  ))}
              </Row>
            </Row>

            {tourDetailsLoading ? (
              <Loading />
            ) : (
              <Row className="third-des" id="comments">
                <Row className="title">
                  <SmallLabel>نظرات مسافران</SmallLabel>
                  <SmallParagraph>
                    ( {tourDetails?.comments?.length} نظر )
                  </SmallParagraph>
                </Row>

                {tourDetails?.comments?.map((comment, i) => (
                  <Row key={i} className="commentBody">
                    <Row className="rowContent">
                      <Row className="star">
                        <SmallParagraph>امتیاز</SmallParagraph>
                        <Row>
                          {[1, 2, 3, 4, 5].map((star) => (
                            <SimpleStarIcon
                              key={star}
                              isSelected={star <= comment.rate}
                            />
                          ))}
                        </Row>
                      </Row>

                      <ListsStyle>
                        {comment?.negative_points?.map((item, index) => (
                          <Row
                            key={index}
                            className={`point ${
                              true ? "badPointSelected" : ""
                            }`}
                          >
                            <XSmallParagraph>{item}</XSmallParagraph>
                          </Row>
                        ))}
                        {comment?.positive_points?.map((item, index) => (
                          <Row
                            key={index}
                            className={`point ${
                              true ? "goodPointSelected" : ""
                            }`}
                          >
                            <XSmallParagraph>{item}</XSmallParagraph>
                          </Row>
                        ))}
                      </ListsStyle>
                    </Row>

                    <SmallParagraph>{comment.description}</SmallParagraph>
                  </Row>
                ))}
              </Row>
            )}
          </DescriptionContainer>
        </RightCol>

        <LeftCol xl={6} xs={24}>
          <Sidebar handler={onNextHandler} loading={btnLoading} />
        </LeftCol>
      </MainContainer>
    </Layout>
  );
};

export default Index;
