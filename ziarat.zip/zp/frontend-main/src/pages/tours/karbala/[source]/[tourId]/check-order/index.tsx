import CheckOrder from "@/Components/CheckOrder";
import Layout from "@/Shared/Layout";

const Index = () => {
  return;
  // (
  //     <Layout
  //     >
  //         <CheckOrder />
  //     </Layout>
  //  );
};

export default Index;
