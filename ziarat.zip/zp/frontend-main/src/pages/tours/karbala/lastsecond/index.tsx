import React from "react";
import { TourType } from "@/Redux/Tour/Interface";
import { ProvinceType } from "@/Redux/Home/Interfaces";
import Head from "next/head";
import Layout from "@/Shared/Layout";
import axios from "axios";
import { baseURL } from "@/Requests/AxiosInstance";
import KarbalaTour from "@/Components/Tours/KarbalaTour";
import KarbalaLastSecondDes from "@/Components/SourceCityDescription/KarbalalastSecondDes";

interface Props {
  tours: TourType[];
  province: ProvinceType[];
  title: string;
  description: string;
}

const Index: React.FC<Props> = (props) => {
  const { province, tours, title, description } = props;
  return (
    <>
      <Head>
        <title>{title}</title>
        <meta key="description" name="description" content={description} />
        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
        <meta name="enamad" content="850460" />
        <link
          rel="canonical"
          href="https://ziarat.co/tours/karbala/lastsecond"
        />
        <meta charSet="utf-8" />
        <meta httpEquiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta httpEquiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <link
          rel="apple-touch-icon"
          sizes="60x60"
          href="https://ziarat.co/favicon.ico"
        />
        <link
          rel="icon"
          type="image/png"
          sizes="32x32"
          href="https://ziarat.co/favicon.ico"
        />
        <link
          rel="icon"
          type="image/png"
          sizes="16x16"
          href="https://ziarat.co/favicon.ico"
        />
        <link rel="mask-icon" href="https://ziarat.co/favicon.ico" />
        <meta name="msapplication-TileColor" content="#da532c" />
        <meta name="theme-color" content="#ffffff" />
        <meta
          name="keywords"
          content="تور کربلا،تور عتبات عالیات ، رسم زیارت ، کربلا"
        />
        <meta name="author" content="rasm ziarat" />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta
          property="og:url"
          content="https://ziarat.co/tours/karbala/lastsecond"
        />
        <meta
          property="og:image"
          content="https://ziarat.co/tours/karbala/lastsecond"
        />
        <meta property="og:type" content="website" />
        <meta
          property="og:site_name"
          content="تور لحظه آخری کربلا با رسم زیارت"
        />
        <meta
          name="vb_meta_bburl"
          content="https://ziarat.co/tours/karbala/lastsecond"
        />
        <link rel="dns-prefetch" href="https://google.com" />
        {/* <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "BreadcrumbList",
              itemListElement: [
                {
                  "@type": "ListItem",
                  position: 1,
                  name: "رسم زیارت",
                  item: "https://ziarat.co",
                },
                {
                  "@type": "ListItem",
                  position: 2,
                  name: "تورها",
                  item: "https://ziarat.co/tours",
                },
                {
                  "@type": "ListItem",
                  position: 3,
                  name: "کربلا",
                  item: "https://ziarat.co/tours/karbala",
                },
              ],
            }),
          }}
        /> */}
      </Head>
      <Layout>
        <KarbalaTour
          breadcrumb={[
            {
              src: `/tours`,
              name: `تورها`,
            },
            {
              src: `/tours/karbala`,
              name: `تور کربلا`,
            },
            {
              src: "/tours/karbala/lastsecond",
              name: "تور کربلا لحظه آخری",
            },
          ]}
          title={"تور لحظه آخری کربلا"}
          descriptionGone={true}
          province={province}
          // tours={tours}
        >
          <KarbalaLastSecondDes />
        </KarbalaTour>
      </Layout>
    </>
  );
};

export default Index;

export const getServerSideProps = async () => {
  const province = await axios.get("/api/province", {
    baseURL: baseURL,
  });
  const body = {
    type: "package",
    dst_province_slug: "karbala",
    src_province_slug: "tehran",
    page: 1,
    per_page: 10,
    sort: "order:asc",
  };
  const title =
    "تور لحظه آخری کربلا 1404 - قیمت تور ارزان لحظه آخری کربلا | رسم و زیارت";
  const description =
    "رزرو تور لحظه آخری کربلا با ارزانترین قیمت تور کربلا لحظه آخری زیر نظر سازمان حج و زیارت و پشتیبانی 24 ساعته رسم زیارت";
  const tours = await axios.get("/api/home/filter", {
    baseURL: baseURL,
    params: body,
  });

  return {
    props: {
      tours: tours.data?.data,
      province: province.data,
      title,
      description,
    },
  };
};
