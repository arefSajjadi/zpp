import CitiesTours from "@/Components/MainPage/CitiesTours";
import KarbalaDescription from "@/Components/SourceCityDescription/KarbalaDescription";
import KarbalaTour from "@/Components/Tours/KarbalaTour";
import { fetchHome } from "@/Redux/Home/HomeSlice";
import { popularType, ProvinceType, SliderType } from "@/Redux/Home/Interfaces";
import { AppDispatch } from "@/Redux/store";
import { TourType } from "@/Redux/Tour/Interface";
import { baseURL } from "@/Requests/AxiosInstance";
import Row from "@/Shared/Kit/Row";
import Layout from "@/Shared/Layout";
import { SrcOrDesProvince } from "@/Utils/FindSrcOrDesProvince";
import axios from "axios";
import Head from "next/head";
import { useEffect } from "react";
import { useDispatch } from "react-redux";

interface Props {
  // tours: TourType[];
  province: ProvinceType[];
  title: string;
  description: string;
    data: {
      slider: SliderType[];
      province: ProvinceType[];
      popular_province:popularType[]
    };
}

const Index: React.FC<Props> = (props) => {
  const { province, title, description ,data } = props;

  const dispatch = useDispatch<AppDispatch>();
  useEffect(() => {
    const srcOrDesProvince = SrcOrDesProvince(data?.province);
    dispatch(
      fetchHome({
        slider: data.slider,
        sourceProvince: srcOrDesProvince.srcProvince,
        popularProvince:data?.popular_province,
        destinationProvince: srcOrDesProvince.desProvince,
        loading: false,
      })
    );
  }, []);
  return (
    <>
      <Head>
        <title>{title}</title>
        <meta key="description" name="description" content={description} />
        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
        <meta name="enamad" content="850460" />
        <link rel="canonical" href="https://ziarat.co/tours/karbala" />
        <meta charSet="utf-8" />
        <meta httpEquiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta httpEquiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta name="robots" content="index, follow" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <link
          rel="apple-touch-icon"
          sizes="60x60"
          href="https://ziarat.co/favicon.ico"
        />
        <link
          rel="icon"
          type="image/png"
          sizes="32x32"
          href="https://ziarat.co/favicon.ico"
        />
        <link
          rel="icon"
          type="image/png"
          sizes="16x16"
          href="https://ziarat.co/favicon.ico"
        />
        <link rel="mask-icon" href="https://ziarat.co/favicon.ico" />
        <meta name="msapplication-TileColor" content="#da532c" />
        <meta name="theme-color" content="#ffffff" />
        <meta
          name="keywords"
          content="تور کربلا،تور عتبات عالیات ، رسم زیارت ، کربلا"
        />
        <meta name="author" content="rasm ziarat" />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:url" content="https://ziarat.co/tours/karbala" />
        <meta property="og:image" content="https://ziarat.co/tours/karbala" />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="رسم زیارت" />
        <meta name="vb_meta_bburl" content="https://ziarat.co/tours/karbala" />
        <link rel="dns-prefetch" href="https://google.com" />
      </Head>
      <Layout>
        <KarbalaTour tourDefaultCity={true} province={province} descriptionGone={true} >
          <KarbalaDescription />
        </KarbalaTour>
        <Row xl={20} xs={24}>
        <CitiesTours />

        </Row>
      </Layout>
    </>
  );
};

export default Index;

export const getStaticProps = async () => {
  const province = await axios.get("/api/province", {
    baseURL: baseURL,
  });
  const { data } = await axios.get(`/api/landing/home`, {
    baseURL: baseURL,
  });

  const title = "تور کربلا | حج و زیارت + آنلاین از تمامی شهرها";
  const description ="رزرو کاروان کربلا با ضمانت ارزان ترین قیمت به همراه تنوع تور و پشتیبانی 24 ساعته";

  return {
    props: {
      title,
      description,
      province: province.data,
      data
    },
  };
};
