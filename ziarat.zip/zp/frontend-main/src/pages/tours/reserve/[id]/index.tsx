import Reserves from "@/Components/Request";
import Layout from "@/Shared/Layout";
import Head from "next/head";

const Requests = () => {
  return (
    <>
      <Head>
        <meta name="robots" content="noindex" />
      </Head>
      <Layout>
        <Reserves />
      </Layout>
    </>
  );
};

export default Requests;
