import React from "react";
import Head from "next/head";
import Layout from "@/Shared/Layout";
import MashhadTrain6boardsDes from "@/Components/SourceCityDescription/MashhadTrain6boardsDes";
import Breadcrumb from "@/Components/Breadcrumb/Breadcrumb";
import { MainContainer } from "@/Components/Rules/styles";
import {
  BodyContainer,
  MainContainer as Main,
} from "@/Components/Dashboard/Rules/styles";
import Row from "@/Shared/Kit/Row";

const Index = () => {
  const title =
    "تور مشهد با قطار 6 تخته ارزان - انواع قطارها + هتل نزدیک حرم | رسم زیارت";
  const description =
    "رزرو تور مشهد با قطار 6 تخته ارزان از تمامی شهرها همراه با اقامت در هتل نزدیک حرم امام رضا با صبحانه ناهار شام و پشتیبانی 24ساعته رسم زیارت";
  const breadcrumb = [
    {
      src: `/tours`,
      name: `تورها`,
    },
    {
      src: "/tours/mashhad-train-6boards",
      name: "تور مشهد",
    },
  ];
  return (
    <>
      <Head>
        <title>{title}</title>
        <meta key="description" name="description" content={description} />
        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
        <meta name="enamad" content="850460" />
        <link
          rel="canonical"
          href="https://ziarat.co/tours/mashhad-train-6boards"
        />
        <meta charSet="utf-8" />
        <meta httpEquiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta httpEquiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <link
          rel="apple-touch-icon"
          sizes="60x60"
          href="https://ziarat.co/favicon.ico"
        />
        <link
          rel="icon"
          type="image/png"
          sizes="32x32"
          href="https://ziarat.co/favicon.ico"
        />
        <link
          rel="icon"
          type="image/png"
          sizes="16x16"
          href="https://ziarat.co/favicon.ico"
        />
        <link rel="mask-icon" href="https://ziarat.co/favicon.ico" />
        <meta name="msapplication-TileColor" content="#da532c" />
        <meta name="theme-color" content="#ffffff" />
        <meta name="keywords" content="تور مشهد ، رسم زیارت" />
        <meta name="author" content="rasm ziarat" />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta
          property="og:url"
          content="https://ziarat.co/tours/mashhad-train-6boards"
        />
        <meta
          property="og:image"
          content="https://ziarat.co/tours/mashhad-train-6boards"
        />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="تور مشهد با رسم زیارت" />
        <meta
          name="vb_meta_bburl"
          content="https://ziarat.co/tours/mashhad-train-6boards"
        />
        <link rel="dns-prefetch" href="https://google.com" />
      </Head>
      <Layout>
        <MainContainer>
          <Row className="breadcrumb">
            <Breadcrumb BreadcrumbList={breadcrumb} />
          </Row>

          <Main>
            <BodyContainer>
              <MashhadTrain6boardsDes />
            </BodyContainer>
          </Main>
        </MainContainer>
      </Layout>
    </>
  );
};

export default Index;
