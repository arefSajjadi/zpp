import FromSyriaDescription from "@/Components/SourceCityDescription/FromSyriaDescription";
import { SyriaContainer } from "@/Components/Tours/Syria/styles";
import Layout from "@/Shared/Layout";
import Head from "next/head";

const Index = () => {
  return (
    <Layout>
      <Head>
        <title>تور سوریه هوایی - زیر نظر حج و زیارت | رسم زیارت </title>
        <meta
          name="description"
          content="بهترین قیمت تور سوریه هوایی به همراه رزرو آنلاین | بیشترین تنوع کاروان ها با بهترین هتل ها از همه شهرها"
        />
        <meta name="google-site-verification" content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk" />
        <meta name="enamad" content="850460"/>
        <link rel="canonical" href="https://ziarat.co/tours/syria" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "BreadcrumbList",
              itemListElement: [
                {
                  "@type": "ListItem",
                  position: 1,
                  name: "رسم زیارت",
                  item: "https://ziarat.co",
                },
                {
                  "@type": "ListItem",
                  position: 2,
                  name: "تورها",
                  item: "https://ziarat.co/tours",
                },
                {
                  "@type": "ListItem",
                  position: 3,
                  name: "سوریه",
                  item: "https://ziarat.co/tours/syria",
                },
              ],
            }),
          }}
        />
      </Head>
      <SyriaContainer>
        <FromSyriaDescription />
      </SyriaContainer>
    </Layout>
  );
};

export default Index;
