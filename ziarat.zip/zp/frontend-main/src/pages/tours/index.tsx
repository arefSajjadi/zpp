import React from "react";
import Layout from "@/Shared/Layout";
import { ContentContainer } from "@/Components/MainPage/HeaderBox/styles";
import { XXLargeHeading } from "@/Shared/Kit/Typography/Heading";
import { MainContainer } from "@/Components/Tours/KarbalaTour/styles";
import { theme } from "@/Utils/theme";
import Head from "next/head";
import Breadcrumb from "@/Components/Breadcrumb/Breadcrumb";
import useIsMobile from "@/Utils/Responsive";
import Row from "@/Shared/Kit/Row";
import ToursDescription from "@/Components/SourceCityDescription/ToursDescription";

const Index = () => {
  const responsive = useIsMobile();
  const breadcrumb = [
    {
      src: `/tours`,
      name: `تورها`,
    },
  ];
  return (
    <>
      <Head>
        <title>خرید تور های زیارتی - رسم زیارت</title>
        <meta
          key="description"
          name="description"
          content=" بهترین قیمت تور های زیارتی با پشتیبانی 24 ساعته - رسم زیارت"
        />
        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
        <meta name="enamad" content="850460" />
        <link rel="canonical" href="https://ziarat.co/tours" />
        <meta charSet="utf-8" />
        <meta httpEquiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta httpEquiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta name="robots" content="index, follow" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <link
          rel="apple-touch-icon"
          sizes="60x60"
          href="https://ziarat.co/favicon.ico"
        />
        <link
          rel="icon"
          type="image/png"
          sizes="32x32"
          href="https://ziarat.co/favicon.ico"
        />
        <link
          rel="icon"
          type="image/png"
          sizes="16x16"
          href="https://ziarat.co/favicon.ico"
        />
        <link rel="mask-icon" href="https://ziarat.co/favicon.ico" />
        <meta name="msapplication-TileColor" content="#da532c" />
        <meta name="theme-color" content="#ffffff" />
        <meta
          name="keywords"
          content="تور کربلا،تور عتبات عالیات ، رسم زیارت ، کربلا"
        />
        <meta name="author" content="rasm ziarat" />
        <meta
          property="og:title"
          content="تور کربلا 1404 | تحت نظر حج و زیارت + قیمت ارزان با رسم زیارت"
        />
        <meta
          property="og:description"
          content="بهترین قیمت تور کربلا در رسم زیارت به همراه رزرو آنلاین❗ بیشترین تنوع کاروان کربلا هوایی و زمینی با بهترین هتل ها و خدمات  از همه شهرها⚡"
        />
        <meta property="og:url" content="https://ziarat.co/tours" />
        <meta property="og:image" content="https://ziarat.co/tours" />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="تور کربلا با رسم زیارت" />
        <meta name="vb_meta_bburl" content="https://ziarat.co/tours" />
        <link rel="dns-prefetch" href="https://google.com" />
        {/* <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "BreadcrumbList",
              itemListElement: [
                {
                  "@type": "ListItem",
                  position: 1,
                  name: "رسم زیارت",
                  item: "https://ziarat.co",
                },
                {
                  "@type": "ListItem",
                  position: 2,
                  name: "تورها",
                  item: "https://ziarat.co/tours",
                },
                {
                  "@type": "ListItem",
                  position: 3,
                  name: "کربلا",
                  item: "https://ziarat.co/tours/karbala",
                },
              ],
            }),
          }}
        /> */}
      </Head>
      <Layout>
        <MainContainer xl={24}>
          <ContentContainer>
            <XXLargeHeading>{"تور های زیارتی"}</XXLargeHeading>
          </ContentContainer>
          <Row className="breadcrumb" xl={20} xs={24}>
            {responsive !== "mobile" && (
              <Breadcrumb BreadcrumbList={breadcrumb} />
            )}
          </Row>
          <div
            style={{
              cursor: "pointer",
              display: "flex",
              backgroundColor: theme.primary500,
              color: "white",
              width: "200px",
              borderRadius: "1rem",
              marginTop: "1rem",
              paddingInline: "2rem",
              alignItems: "center",
              justifyContent: "center",
            }}
            onClick={() => {
              window.location.href = "/tours/karbala";
            }}
          >
            <h2>تور کربلا</h2>
          </div>
          <ToursDescription />
        </MainContainer>
      </Layout>
    </>
  );
};

export default Index;
