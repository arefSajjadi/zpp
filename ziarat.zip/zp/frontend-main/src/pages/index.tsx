import HeaderBox from "@/Components/MainPage/HeaderBox";
import Layout from "@/Shared/Layout";
import { MainPageWrapper } from "@/Components/MainPage/styles";
import OurProperties from "@/Components/MainPage/OurProperties";
import CitiesTours from "@/Components/MainPage/CitiesTours";
import Section4 from "@/Components/MainPage/Section4";
import Section5 from "@/Components/MainPage/Section5";
import Section6 from "@/Components/MainPage/Section6";
import axios from "axios";
import { baseURL } from "@/Requests/AxiosInstance";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { fetchHome } from "@/Redux/Home/HomeSlice";
import { popularType, ProvinceType, SliderType } from "@/Redux/Home/Interfaces";
import { AppDispatch } from "@/Redux/store";
import MainPageSuggestedTours from "@/Components/MainPage/MainPageSuggestedTours";
import { SrcOrDesProvince } from "@/Utils/FindSrcOrDesProvince";
import Head from "next/head";

interface Props {
  data: {
    slider: SliderType[];
    province: ProvinceType[];
    popular_province: popularType[];
  };
}
export default function Home({ data }: Props) {
  const dispatch = useDispatch<AppDispatch>();
  useEffect(() => {
    const srcOrDesProvince = SrcOrDesProvince(data?.province);
    console.log(data, "asd");
    dispatch(
      fetchHome({
        slider: data.slider,
        sourceProvince: srcOrDesProvince.srcProvince,
        popularProvince: data?.popular_province,
        destinationProvince: srcOrDesProvince.desProvince,
        loading: false,
      })
    );
  }, []);
  return (
    <>
      <Head>
        <title>رسم زیارت | همراه امن سفرهای زیارتی شما </title>
        <meta
          name="description"
          content="با رسم زیارت بهترین تورهای زیارتی از تمامی شهرهای ایران همراه با بهترین هتل ها را با قیمت مناسب و پشتیبانی 24ساعته رزرو کنید."
        />

        <meta
          name="google-site-verification"
          content="_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk"
        />
        <meta name="enamad" content="850460" />
        <link rel="canonical" href="https://ziarat.co/" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta charSet="utf-8" />
        <meta httpEquiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta httpEquiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <link
          rel="apple-touch-icon"
          sizes="60x60"
          href="https://ziarat.co/favicon.ico"
        />
        <link
          rel="icon"
          type="image/png"
          sizes="32x32"
          href="https://ziarat.co/favicon.ico"
        />
        <link
          rel="icon"
          type="image/png"
          sizes="16x16"
          href="https://ziarat.co/favicon.ico"
        />
        <link rel="mask-icon" href="https://ziarat.co/favicon.ico" />
        <meta name="msapplication-TileColor" content="#da532c" />
        <meta name="theme-color" content="#ffffff" />
        <meta
          name="keywords"
          content="تور کربلا،تور عتبات عالیات ، رسم زیارت ، کربلا"
        />
        <meta name="author" content="rasm ziarat" />
        <meta
          property="og:title"
          content="رسم زیارت | همراه امن سفرهای زیارتی شما"
        />
        <meta
          property="og:description"
          content="با رسم زیارت بهترین تورهای زیارتی از تمامی شهرهای ایران همراه با بهترین هتل ها را با قیمت مناسب و پشتیبانی 24ساعته رزرو کنید."
        />
        <meta property="og:url" content="https://ziarat.co/tours/karbala" />
        <meta property="og:image" content="https://ziarat.co/tours/karbala" />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="تور کربلا با رسم زیارت" />
        <meta name="vb_meta_bburl" content="https://ziarat.co/tours/karbala" />
        <link rel="dns-prefetch" href="https://google.com" />
      </Head>
      <Layout>
        <MainPageWrapper>
          <HeaderBox
            description="مقایسه و خرید آنلاین سفرهای زیارتی"
            title="رسم زیارت"
            showContent={true}
            showTab={true}
            mode="tour"
          />
          <OurProperties />
          <CitiesTours />
          <MainPageSuggestedTours />
          <Section4 />
          <Section5 />
          <Section6 />
        </MainPageWrapper>
      </Layout>
    </>
  );
}

export async function getServerSideProps() {
  const { data } = await axios.get(`/api/landing/home`, {
    baseURL: baseURL,
  });
  return { props: { data: data } };
}
