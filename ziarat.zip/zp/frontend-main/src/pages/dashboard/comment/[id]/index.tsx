import { XSmallHeading } from "@/Shared/Kit/Typography/Heading";
import Col from "@/Shared/Kit/Col";
import CommentsIcon from "@/Assets/Icons/Comment";
import {
  LargeLabel,
  MediumLabel,
  SmallLabel,
} from "@/Shared/Kit/Typography/Label";
import {
  SmallParagraph,
  XSmallParagraph,
} from "@/Shared/Kit/Typography/Paragraph";
import { theme } from "@/Utils/theme";
import Row from "@/Shared/Kit/Row";
import {
  HeaderContainer,
  Wrapper,
  BodyHeader,
  BodyContent,
  ListsStyle,
} from "@/Components/Dashboard/Comments/styles";
import SimpleStarIcon from "@/Assets/Icons/SimpleStarIcon";
import { useEffect, useState } from "react";
import Textarea from "@/Shared/Kit/FromElements/Textarea";
import { PrimaryButton } from "@/Shared/Kit/Button/PrimaryButton";
import { PostComment } from "@/Redux/Profile/ApiFunction";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch } from "@/Redux/store";
import Layout from "@/Shared/Layout";
import { useRouter } from "next/router";
import { hasCookie } from "cookies-next";
import { setNextUrl, setShowLoginModal } from "@/Redux/Auth/AuthSlice";
import NameSpace from "@/Storage/NameSpace";
import { GetTour } from "@/Redux/Tour/ApiFunction";
import { selectTourState } from "@/Redux/Tour/Selectors";
import DateTimeController from "@/Utils/DateTimeController";
import Loading from "@/Shared/Kit/Loading";

const Index = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { tourDetails, tourDetailsLoading } = useSelector(selectTourState);

  const router = useRouter();
  const [rate, setRate] = useState<number>(0);
  const [selectedGoodPoints, setSelectedGoodPoints] = useState<string[]>([]);
  const [selectedBadPoints, setSelectedBadPoints] = useState<string[]>([]);
  const [description, setDescription] = useState<string>("");
  const [isShowresult, setIsShowresult] = useState<boolean>(false);
  const [loading, setloaing] = useState<boolean>(false);
  const [showValidation, setShowValidation] = useState(false);

  const goodPointsList = ["غذای با کیفیت", "نظافت", "نظم"];
  const badPointsList = ["غذای بی کیفیت", "بی نظمی", "عدم نظافت"];

  const package_id = router.query.id;

  useEffect(() => {
    if (!router.isReady) return;

    if (!hasCookie(NameSpace.token)) {
      dispatch(setNextUrl(router.asPath));
      dispatch(setShowLoginModal(true));
    }
  }, [router.isReady, router.asPath, dispatch]);

  useEffect(() => {
    if (package_id) {
      GetTour(dispatch, String(package_id));
    }
  }, [package_id]);

  if (!package_id) {
    return null;
  }

  let returnDate = DateTimeController.getDateNDaysLater(
    +tourDetails?.staying_night + tourDetails?.staying_night_margin,
    tourDetails?.date
  );

  const handleStarClick = (starNumber: number) => {
    if (rate === starNumber) {
      setRate(0);
    } else {
      setRate(starNumber);
    }
  };

  const handleGoodPointClick = (item: string) => {
    if (selectedGoodPoints.includes(item)) {
      setSelectedGoodPoints(
        selectedGoodPoints.filter((point) => point !== item)
      );
    } else {
      setSelectedGoodPoints([...selectedGoodPoints, item]);
    }
  };

  const handleBadPointClick = (item: string) => {
    if (selectedBadPoints.includes(item)) {
      setSelectedBadPoints(selectedBadPoints.filter((point) => point !== item));
    } else {
      setSelectedBadPoints([...selectedBadPoints, item]);
    }
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setDescription(e.target.value);
  };

  const isFormValid =
    rate > 0 &&
    selectedGoodPoints.length > 0 &&
    selectedBadPoints.length > 0 &&
    description.trim().length > 0;

  const handleSubmit = () => {
    if (!isFormValid) {
      setShowValidation(true);
      return;
    }

    const successCallback = () => {
      setIsShowresult(true);
      setloaing(false);
    };

    setloaing(true);

    PostComment(
      +package_id,
      rate,
      selectedGoodPoints,
      selectedBadPoints,
      description,
      successCallback
    );
  };
  if (tourDetailsLoading) {
    return (
      <Layout>
        <Wrapper>
          <Loading />
        </Wrapper>
      </Layout>
    );
  }
  return (
    <Layout>
      <Wrapper>
        {isShowresult ? (
          <LargeLabel color={theme.gray600} className="text">
            از اشتراک تجربه ی سفر خود با ما سپاس گزاریم.
            <br /> نظر شما پس از برسی منتشر خواهد شد.
          </LargeLabel>
        ) : (
          <>
            <HeaderContainer>
              <CommentsIcon />
              <XSmallHeading>ثبت نظر</XSmallHeading>
            </HeaderContainer>
            <Col className="cardsContainer">
              <BodyHeader>
                <Row className="title">
                  <SmallParagraph>امتیار به سفر</SmallParagraph>
                  <MediumLabel color={theme.primary400}>
                    {tourDetails.source_province.name} -عتبات عالیات
                  </MediumLabel>
                </Row>
                <Row className="title end">
                  <SmallParagraph color={theme.gray600}>
                    تاریخ سفر
                  </SmallParagraph>
                  <SmallLabel color={theme.gray600}>
                    {" "}
                    {DateTimeController.parseToJDate(
                      tourDetails?.date,
                      "jDD jMMMM",
                      true
                    )}
                  </SmallLabel>
                  <SmallParagraph color={theme.gray600}>تا</SmallParagraph>
                  <SmallLabel color={theme.gray600}>
                    {" "}
                    {DateTimeController.parseToJDate(
                      returnDate,
                      "jDD jMMMM",
                      true
                    )}
                  </SmallLabel>
                </Row>
              </BodyHeader>
              <BodyContent>
                <Row className="starWrapper">
                  <SmallParagraph>به سفر خود چه امتیازی میدهید؟</SmallParagraph>
                  <Row className="starBody">
                    {[5, 4, 3, 2, 1].map((starNumber) => (
                      <Col key={starNumber}>
                        <SimpleStarIcon
                          onClick={() => handleStarClick(starNumber)}
                          isSelected={rate === starNumber}
                          style={{ cursor: "pointer" }}
                        />
                        <XSmallParagraph color={theme.gray500}>
                          {starNumber}
                        </XSmallParagraph>
                      </Col>
                    ))}
                  </Row>
                </Row>
                <Row>
                  <SmallParagraph>نقاط قوت</SmallParagraph>
                  <ListsStyle>
                    {goodPointsList.map((item, index) => (
                      <button
                        key={index}
                        className={`point ${
                          selectedGoodPoints.includes(item)
                            ? "goodPointSelected"
                            : ""
                        }`}
                        onClick={() => handleGoodPointClick(item)}
                      >
                        {item}
                      </button>
                    ))}
                  </ListsStyle>
                </Row>
                <Row>
                  <SmallParagraph>نقاط ضعف</SmallParagraph>
                  <ListsStyle>
                    {badPointsList.map((item, index) => (
                      <button
                        key={index}
                        className={`point ${
                          selectedBadPoints.includes(item)
                            ? "badPointSelected"
                            : ""
                        }`}
                        onClick={() => handleBadPointClick(item)}
                      >
                        {item}
                      </button>
                    ))}
                  </ListsStyle>
                </Row>
                <Row className="textRow">
                  <SmallParagraph>توضیحات بیشتر</SmallParagraph>
                  <Textarea
                    label=""
                    size="lg"
                    name="description"
                    onBlur={() => {}}
                    value={description}
                    onChange={handleTextChange}
                  />
                  {showValidation && !isFormValid && (
                    <XSmallParagraph color={theme.negative500}>
                      برای ثبت نظر، لطفاً به سفر امتیاز بدهید، حداقل یک نقطه
                      قوت، حداقل یک نقطه ضعف و توضیحات خود را وارد کنید.
                    </XSmallParagraph>
                  )}
                  <Row className="btn">
                    <PrimaryButton
                      width="85px"
                      color="primary"
                      size="xs"
                      title="ثبت"
                      isCurve={true}
                      onClick={handleSubmit}
                      loading={loading}
                      disabled={loading}
                    />
                  </Row>
                </Row>
              </BodyContent>
            </Col>
          </>
        )}
      </Wrapper>
    </Layout>
  );
};

export default Index;
