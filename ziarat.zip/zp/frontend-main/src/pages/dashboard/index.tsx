import Dashboard from '@/Components/Dashboard';
import Layout from '@/Shared/Layout';
import React from 'react';


const Index = () => {
    return ( 
        <Layout>
            <Dashboard />
        </Layout>
     );
}
 
export default Index;