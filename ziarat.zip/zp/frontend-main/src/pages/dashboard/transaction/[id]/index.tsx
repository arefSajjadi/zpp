import Layout from "@/Shared/Layout";
import { MediumLabel } from "@/Shared/Kit/Typography/Label";
import {
  LargeParagraph,
  SmallParagraph,
} from "@/Shared/Kit/Typography/Paragraph";
import { theme } from "@/Utils/theme";
import { addSeparator } from "@/Utils/Separator";
import { PrimaryButton } from "@/Shared/Kit/Button/PrimaryButton";
import Row from "@/Shared/Kit/Row";
import CheckOrderModal from "@/Modals/CheckOrderModal";
import { useEffect, useState } from "react";
import { getCookie, hasCookie } from "cookies-next";
import Keys from "@/Storage/NameSpace";
import { useRouter } from "next/router";
import { useDispatch, useSelector } from "react-redux";
import { selectProfile } from "@/Redux/Profile/Selectors";
import { GetOrder } from "@/Redux/Profile/ApiFunction";
import Loading from "@/Shared/Kit/Loading";
import PayIcon from "@/Assets/Icons/PayIcon";
import { XSmallHeading } from "@/Shared/Kit/Typography/Heading";
import { setNextUrl, setShowLoginModal } from "@/Redux/Auth/AuthSlice";
import NameSpace from "@/Storage/NameSpace";
import {
  RowStyle,
  Title,
  TransactionContent,
  TransactionWrapper,
} from "@/Components/Dashboard/styles";

const Index = () => {
  const { orderData, orderLoading } = useSelector(selectProfile);
  const dispatch = useDispatch();

  const [showCheckOrderModal, setShowCheckOrderModal] = useState(false);
  const [totalPrice, setTotalPrice] = useState<number>(0);

  const router = useRouter();

  const transactionId = router.query.id;
  const userToken = hasCookie(NameSpace.token);

  useEffect(() => {
    if (!router.isReady) return;

    if (!hasCookie(NameSpace.token)) {
      dispatch(setNextUrl(router.asPath));
      dispatch(setShowLoginModal(true));
    }
  }, [router.isReady, router.asPath, dispatch]);

  useEffect(() => {
    if (transactionId && userToken) {
      GetOrder(+transactionId, dispatch);
    }
  }, [transactionId, userToken, dispatch]);

  useEffect(() => {
    if (orderData?.amount) {
      setTotalPrice(orderData.amount);
    }
  }, [orderData]);

  if (!router.isReady) {
    return (
      <Layout>
        <TransactionWrapper>
          <TransactionContent>
            <Loading />
          </TransactionContent>
        </TransactionWrapper>
      </Layout>
    );
  }

  if (!transactionId) {
    return null;
  }

  return (
    <Layout>
      <TransactionWrapper>
        <Title>
          <PayIcon />
          <XSmallHeading>پرداخت هزینه سفر</XSmallHeading>
        </Title>
        {orderLoading ? (
          <TransactionContent>
            <Loading />
          </TransactionContent>
        ) : orderData.amount ? (
          <TransactionContent>
            <Row className="row">
              <MediumLabel> مبلغ: </MediumLabel>
              <MediumLabel className="price">
                {addSeparator(totalPrice)} تومان
              </MediumLabel>
            </Row>
            <Row className="row">
              <MediumLabel color={theme.gray800}>توضیحات:</MediumLabel>
              <SmallParagraph color={theme.gray800}>
                {orderData?.description}
              </SmallParagraph>
            </Row>

            <RowStyle>
              <PrimaryButton
                color="primary"
                size="sm"
                title="پرداخت"
                width="150px"
                onClick={() => {
                  setShowCheckOrderModal(true);
                }}
                isCurve={true}
              />
            </RowStyle>
          </TransactionContent>
        ) : (
          <Row className="contentWrapper">
            <LargeParagraph>
              دسترسی به این صفحه منقضی گردیده است.
            </LargeParagraph>
          </Row>
        )}

        {showCheckOrderModal && totalPrice !== null && (
          <CheckOrderModal
            orderId={orderData.order_id}
            mobileNumber={getCookie(Keys.mobileNumber)}
            onClose={() => setShowCheckOrderModal(false)}
            amount={totalPrice}
            setAmount={setTotalPrice}
            onPaymentClick={() => {}}
            transactionId={+transactionId}
          />
        )}
      </TransactionWrapper>
    </Layout>
  );
};

export default Index;
