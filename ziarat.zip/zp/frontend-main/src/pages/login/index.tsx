import React from 'react';
import LoginComponent from '@/Components/Login';

const Index = () => {
    return ( 
        
            <LoginComponent />
        
     );
}
 
export default Index;
