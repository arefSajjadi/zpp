import * as Yup from "yup"
import { date, typeId ,string } from "./Rules"


export const SearchHotelSchema = Yup.object().shape({
    city: typeId("city" ,true),

})