import * as Yup from "yup"
import { mobileNumber ,string } from "./Rules"


export const LoginSchema = Yup.object().shape({
    mobileNumber: mobileNumber("mobileNumber" ,true),
})

export const VerifyOtpSchema = Yup.object().shape({
    otp: string("otp" ,true),
})