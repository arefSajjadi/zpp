import * as Yup from "yup";
import {
  nationalCode,
  firstName,
  lastName,
  mobile,
  birthDate,
  mobileNumber,
} from "./Rules";

export const PassengerFromSchema = Yup.object().shape({
  passengers: Yup.array().of(
    Yup.object().shape({
      firstName: firstName("firstName", true),
      lastName: lastName("lastName", true),
      nationalCode: nationalCode("nationalCode", true),
      mobile: mobile("mobile", true),
      birthDay: birthDate("birthDay", true),
      birthMonth: birthDate("birthMonth", true),
      birthYear: birthDate("birthYear", true),
      mobileNumber: mobileNumber("mobileNumber", false),
    })
  ),
});
