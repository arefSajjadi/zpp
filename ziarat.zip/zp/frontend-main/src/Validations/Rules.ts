import * as Yup from 'yup';
const requireMessage = 'این فیلد الزامی است.';
const requireLocationMessage = "مبداء را انتخاب کنید.";

const dateTypeMessage = 'تاریخ وارد شده صحیح نمی باشد.';
const typeIdTypeMessage = 'فیلد وارد شده نامعتبر است.';
// const mobileRegex = /^(\+98|0)9\d{9}$/;
const mobileRegex = /^09\d{9}$/;
const nationalCodeRegex = /^[0-9]{10}$/;
const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
const phoneRegex = /(^[0-9]+$)/;
const shebaRegex = /(^(?:IR)(?=.{24}$)[0-9]*$)/;
const captchaRegex = /\b\d{5}\b/
const otpRegex5 = /\b\d{5}\b/
const otpRegex6 = /\b\d{6}\b/
const sejamOtpRegex = /\b\d{5}\b/ //x
const cardNumberRegex = /^[0-9]{16}$/; //x
const colorRegex = /(^#(?:[0-9a-fA-F]{3}){1,2}$)/
const numberRegex = /^[0-9]*$/
// const percentRegex = /^[1-9][0-9]?$|^100$/
// const percentRegex = /(^100)$|(^\d{1,2})$/
const percentRegex = /(^100([.]0{1,2})?)$|(^\d{1,2}([.]\d{1,2})?)$/

export const string = (label: string, isRequire: boolean = false) => {
  if (isRequire) {
    return Yup.string()
      .label(label)
      .required(requireMessage);
  } else {
    return Yup.string()
      .label(label);
  }
};

export const stringWithMax = (label: string, isRequire: boolean = false, max: number) => {
  if (isRequire) {
    return Yup.string()
      .label(label)
      .required(requireMessage)
      .max(max, `حداکثر تعداد کاراکتر مجاز ${max} کاراکتر می باشد.`)
  } else {
    return Yup.string()
      .label(label)
      .max(max, `حداکثر تعداد کاراکتر مجاز ${max} کاراکتر می باشد.`)
  }
};

export const number = (label: string, isRequire: boolean = false) => {
  if (isRequire) {
    return Yup.string()
      .label(label)
      .matches(numberRegex, 'مقدار فقط باید شامل اعداد باشد.')
      .required(requireMessage);
  } else {
    return Yup.string()
      .label(label)
      .matches(numberRegex, 'مقدار فقط باید شامل اعداد باشد.')
  }
}

export const percent = (label: string, isRequire: boolean = false) => {
  if (isRequire) {
    return Yup.string()
      .label(label)
      .matches(percentRegex, typeIdTypeMessage)
      .required(requireMessage);
  } else {
    return Yup.string()
      .label(label)
      .matches(percentRegex, typeIdTypeMessage);
  }
};

export const typeId = (label: string, isRequire: boolean = false, isPositive: boolean = true) => {
  if (isRequire) {
    if (isPositive) {
      return Yup.number()
        .label(label)
        .nullable(requireMessage)
        .positive(typeIdTypeMessage)
        .typeError(typeIdTypeMessage)
        .required(requireMessage)
    } else {
      return Yup.number()
        .label(label)
        .nullable(requireMessage)
        .typeError(typeIdTypeMessage)
        .required(requireMessage)
    }
  }
  else {
    if (isPositive) {
      return Yup.number()
        .label(label)
        .nullable(requireMessage)
        .positive(typeIdTypeMessage)
        .typeError(typeIdTypeMessage)
    } else {
      return Yup.number()
        .label(label)
        .nullable(requireMessage)
        .typeError(typeIdTypeMessage)
    }
  }
};

export const locationTypeId = (label: string, isRequire: boolean = false, isPositive: boolean = true) => {
  if (isRequire) {
    if (isPositive) {
      return Yup.number()
        .label(label)
        .nullable()
        .positive(typeIdTypeMessage)
        .typeError(typeIdTypeMessage)
        .required(requireLocationMessage);
    } else {
      return Yup.number()
        .label(label)
        .nullable()
        .typeError(typeIdTypeMessage)
        .required(requireLocationMessage);
    }
  } else {
    if (isPositive) {
      return Yup.number()
        .label(label)
        .nullable()
        .positive(typeIdTypeMessage)
        .typeError(typeIdTypeMessage);
    } else {
      return Yup.number()
        .label(label)
        .nullable()
        .typeError(typeIdTypeMessage);
    }
  }
};


export const date = (label: string, isRequire: boolean = false) => {
  if (isRequire) {
    return Yup.date()
      .label(label)
      .typeError(dateTypeMessage)
      .required(requireMessage);
  } else {
    return Yup.date()
      .label(label)
      .typeError(dateTypeMessage);
  }
};

export const mobileNumber = (label: string, isRequire: boolean = false) => {
  if (isRequire) {
    return Yup.string()
      .label(label)
      .matches(mobileRegex, 'شماره موبایل وارد شده صحیح نمی باشد')
      .required(requireMessage);
  } else {
    return Yup.string()
      .label(label)
      .matches(mobileRegex, 'شماره موبایل وارد شده صحیح نمی باشد')
  }
}

export const email = (label: string, isRequire: boolean = false) => {
  if (isRequire) {
    return Yup.string()
      .label(label)
      .matches(emailRegex, 'ایمیل وارد شده صحیح نمی باشد')
      .required(requireMessage);
  } else {
    return Yup.string()
      .label(label)
      .matches(emailRegex, 'ایمیل وارد شده صحیح نمی باشد')
  }
}

export const nationalCode = (label: string, isRequire: boolean = false) => {
  if (isRequire) {
    return Yup.string()
      .label(label)
      .matches(nationalCodeRegex, 'فرمت کد ملی وارد شده صحیح نمی باشد')
      .required("کد ملی اجباری است.");
  } else {
    return Yup.string()
      .label(label)
      .matches(nationalCodeRegex, 'فرمت کد ملی وارد شده صحیح نمی باشد')
  }
}

export const firstName = (label: string, isRequire: boolean = false) => {
  if (isRequire) {
    return Yup.string().label(label).required("نام اجباری است.");
  }
  return Yup.string().label(label);
};

export const lastName = (label: string, isRequire: boolean = false) => {
  if (isRequire) {
    return Yup.string().label(label).required("نام خانوادگی اجباری است.");
  }
  return Yup.string().label(label);
};

export const gender = (label: string, isRequire: boolean = false) => {
  if (isRequire) {
    return Yup.string().label(label).required("جنسیت اجباری است.");
  }
  return Yup.string().label(label);
};
export const mobile = (label: string, isRequire: boolean = false) => {
  if (isRequire) {
    return Yup.string().label(label).required("شماره موبایل اجباری است.");
  }
  return Yup.string().label(label);
};
export const birthDate = (label: string, isRequire: boolean = false) => {
  if (isRequire) {
    return Yup.string().label(label).required("روز تولد اجباری است.");
  }
  return Yup.string().label(label);
};

export const phone = (label: string, isRequire: boolean = false) => {
  if (isRequire) {
    return Yup.string()
      .label(label)
      .matches(phoneRegex, 'شماره تلفن فقط باید شامل اعداد باشد.')
      .required(requireMessage);
  } else {
    return Yup.string()
      .label(label)
      .matches(phoneRegex, 'شماره تلفن فقط باید شامل اعداد باشد.')
  }
};

export const postalCode = (label: string, isRequire: boolean = false) => {
  if (isRequire) {
    return Yup.string()
      .label(label)
      .min(10)
      .max(10)
      .required(requireMessage);
  } else {
    return Yup.string()
      .label(label)
      .min(10)
      .max(10);
  }
};

export const shebaNumber = (label: string, isRequire: boolean = false) => {
  if (isRequire) {
    return Yup.string()
      .label(label)
      .matches(shebaRegex, 'شماره شبا وارد شده صحیح نمی باشد')
      .nullable(requireMessage)
      .required(requireMessage);
  } else {
    return Yup.string()
      .label(label)
      .nullable(requireMessage)
      .matches(shebaRegex, 'شماره شبا وارد شده صحیح نمی باشد')
  }
};

export const cardNumber = (label: string, isRequire: boolean = false) => { //x
  if (isRequire) {
    return Yup.string()
      .label(label)
      .matches(cardNumberRegex, 'شماره کارت وارد شده صحیح نمی باشد')
      .nullable(requireMessage)
      .required(requireMessage);
  } else {
    return Yup.string()
      .label(label)
      .nullable(requireMessage)
      .matches(cardNumberRegex, 'شماره کارت وارد شده صحیح نمی باشد')
  }
};

export const captcha = Yup.string()
  .label('captcha')
  .matches(captchaRegex, 'فرمت کد امنیتی صحیح نیست.')
  .required(requireMessage);

export const otp5 = Yup.string()
  .label('otp')
  .matches(otpRegex5, 'فرمت کد تایید صحیح نیست.')
  .required(requireMessage);

export const otp6 = Yup.string()
  .label('otp')
  .matches(otpRegex6, 'فرمت کد تایید صحیح نیست.')
  .required(requireMessage);

export const sejamOtp = Yup.string()
  .label('sejamOtp')
  .matches(sejamOtpRegex, 'فرمت کد تایید صحیح نیست.')
  .required(requireMessage);

export const password = (label: string) => {
  return Yup.string()
    .label(label)
    .min(8, 'رمز عبور حداقل 8 کاراکتر می باشد.')
    // .matches(/^(?=.*[A-Z])(?=.*[\W])(?=.*[0-9])(?=.*[a-z]).{8}$/g,"رمز عبور صحیح نمی باشد")
    .required(requireMessage);
}

export const hexColor = (label: string, isRequire: boolean = false) => {
  if (isRequire) {
    return Yup.string()
      .label(label)
      .matches(colorRegex, "فرمت رنگ صحیص نمی‌باشد")
      .required(requireMessage)
  }
  return Yup.string()
    .label(label)
    .matches(colorRegex, "فرمت رنگ صحیص نمی‌باشد")
}

export const arrayOfnumber = (label: string, isRequire: boolean = false) => {
  if (isRequire) {
    return Yup.array()
      .of(Yup.number())
      .label(label)
      .required(requireMessage)
  }
  return Yup.array()
    .of(Yup.number())
    .label(label)
}