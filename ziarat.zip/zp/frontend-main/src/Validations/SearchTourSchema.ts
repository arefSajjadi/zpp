import * as Yup from "yup"
import { date, locationTypeId ,string } from "./Rules"


export const SearchTourSchema = Yup.object().shape({
    sourceCity: locationTypeId("sourceCity" ,true),
    destinationCity: locationTypeId("destinationCity" ,false),
    date: string("date" ,false),

})