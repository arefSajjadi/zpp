export const swiperPagination = {
    clickable: true,
    renderBullet: function (className:any) {
      return '<span class="' + className + '">' + '</span>';
    },
  };