import jmoment from "moment-jalaali";
import moment from "moment";

class DateTimeController {
  parseToJDate(
    date: string,
    format: string,
    usePersianDigits: boolean = false,
    fa: boolean = true
  ) {
    if (usePersianDigits) {
      jmoment.loadPersian({
        dialect: "persian-modern",
        usePersianDigits: usePersianDigits,
      });
    }
    if (!date || date === "Invalid date") return "Invalid or missing date";

    return jmoment(date)
      .locale(fa ? "fa" : "en")
      .format(format);
  }
  formatJDate(date: string, format: string) {
    if (!date || date === "Invalid date") return "Invalid or missing date";

    return jmoment(date).format(format);
  }
  parseToMDate(date: string, format: string) {
    if (!date || date === "Invalid date") return "Invalid or missing date";

    return jmoment(date, "jYYYY/jMM/jDD").locale("en").format(format);
  }
  isFirstDateAfterSecondDate(firstDate: string, secondDate: string) {
    return jmoment(firstDate).isSameOrAfter(secondDate);
  }
  getDifferencesBetweenTwoDates(firstDate: string, secondDate: string) {
    const duration = jmoment.duration(
      jmoment(firstDate).diff(jmoment(secondDate))
    );
    return duration;
  }
  getToday() {
    const d = new Date();
    const today = moment(d).format("YYYY-MM-DD");
    return today;
  }
  getDateNDaysAgo(n: number) {
    //گرفتن تاریخ n روز قبل
    const d = new Date();
    const oneMounthAgo = moment(d?.setDate(d.getDate() - n)).format(
      "YYYY-MM-DD"
    );
    return oneMounthAgo;
  }
  getDateNDaysLater(n: number, startDate: string) {
    //گرفتن تاریخ n روز بعد
    const d = new Date(startDate);
    const oneMounthAgo = moment(d?.setDate(d.getDate() + n))
      .locale("en")
      .format("YYYY-MM-DD");
    return oneMounthAgo;
  }
  getDayOfWeek(date: string) {
    if (!date || date === "Invalid date") return "Invalid or missing date";

    const day = jmoment(date).day();
    switch (day) {
      case 6:
        return "شنبه";
      case 0:
        return "یکشنبه";
      case 1:
        return "دوشنبه";
      case 2:
        return "سه شنبه";
      case 3:
        return "چهارشنبه";
      case 4:
        return "پنج شنبه";
      case 5:
        return "جمعه";

      default:
        break;
    }
  }

  getDayOfWeekShort(date: string) {
    if (!date || date === "Invalid date") return "Invalid or missing date";

    const day = jmoment(date).day();
    switch (day) {
      case 6:
        return "ش"; // شنبه
      case 0:
        return "ی"; // یکشنبه
      case 1:
        return "د"; // دوشنبه
      case 2:
        return "س"; // سه شنبه
      case 3:
        return "چ"; // چهارشنبه
      case 4:
        return "پ"; // پنج شنبه
      case 5:
        return "ج"; // جمعه
      default:
        return "";
    }
  }
  
  getNNextDays(n: number) {
    const today = moment();
    const next10Days = [];
    for (let i = 1; i <= n; i++) {
      next10Days.push({
        date: today.clone().add(i, "days").locale("en").format("YYYY-MM-DD"),
        tour: false,
      });
    }

    return [...next10Days];
  }
}

export default new DateTimeController();
