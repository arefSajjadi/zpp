const persian_to_english_number = (value:any) => {
    const converted = value
    ?.replace(/[٠-٩]/g, (d: string) => "٠١٢٣٤٥٦٧٨٩".indexOf(d))
    ?.replace(/[۰-۹]/g, (d: string) => "۰۱۲۳۴۵۶۷۸۹".indexOf(d));
    return converted
  };
  
  export default persian_to_english_number;