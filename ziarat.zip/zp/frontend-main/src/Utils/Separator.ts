export default function separator(str: string | number) {
    let number = (str || str === 0)
        ? Number(Number(str).toFixed(0))
        : null
    if (number || number === 0) {
        return str.toLocaleString()
    } else {
        return "-"
    }
}

//جدا کننده ی ارقام با "," و حذف ","
//توی فرم ها استفاده می شود.
export const addSeparator = (str: string | number) => {
    if (str) {
        return str.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    } else {
        return str
    }
}
export const removeSeparator = (str: string | number) => {
    if (str) {
        return str.toString().replace(/[^0-9]/g, '')
    } else {
        return str
    }
}