import { useEffect, useState } from "react";

const useIsMobile = () => {
  const [width, setWidth] = useState(0);

  const handleWindowSizeChange = () => {
    setWidth(window.innerWidth);
  };

  useEffect(() => {
    handleWindowSizeChange();

    window.addEventListener("resize", handleWindowSizeChange);

    return () => {
      window.removeEventListener("resize", handleWindowSizeChange);
    };
  }, []);

  if (width === 0) return undefined
  if (width <= 480) return "mobile";
  else if (width > 480 && width <= 768) return "tablet";
  else if (width > 768 && width <= 1366) return "desktop";
  else if (width > 1366) return "desktop-lg";
};

export default useIsMobile;