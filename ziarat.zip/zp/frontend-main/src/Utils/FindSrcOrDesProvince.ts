import { ProvinceType } from "@/Redux/Home/Interfaces";

export const SrcOrDesProvince = (data: ProvinceType[]) => {
    const srcProvince = data.filter((item) => item.src === 0);
    const desProvince = data.filter((item) => item.src === 1);
    return {srcProvince ,desProvince}
}