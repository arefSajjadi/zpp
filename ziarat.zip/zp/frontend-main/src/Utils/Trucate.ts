export default function truncate(str: string, num: number) {
    if (str) {
        if (str.length > num) {
            return str.slice(0, num) + "...";
        } else {
            return str;
        }
    } else {
        return ""
    }
}