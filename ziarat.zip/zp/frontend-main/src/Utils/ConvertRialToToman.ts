export function convertCurrency(amount: number, fromUnit:"Rial" | "Toman", toUnit:"Rial" | "Toman") {
    const rialToTomanRate = 10;

    // Convert Rial to Toman
    if (fromUnit === 'Rial' && toUnit === 'Toman') {
        return amount / rialToTomanRate;
    }
    // Convert Toman to Rial
    else if (fromUnit === 'Toman' && toUnit === 'Rial') {
        return amount * rialToTomanRate;
    }
    else if (fromUnit === toUnit) {
        return amount;
    }
    else {
        throw new Error('Invalid units. Please use "Rial" or "Toman".');
    }
}