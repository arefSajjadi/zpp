import { saveAs } from 'file-saver';

export const DownloadFile = (data: any, title = "", ext = "xlsx") => {
    saveAs(data, `${title}.${ext}`);
}