const DownloadBase64 = (
    res: {
        fileName: string,
        value: string
    }
) => {
    var a = document.createElement("a"); //Create <a>
    a.href = res.value
    a.download = res.fileName; //File name Here
    a.click()
}

export default DownloadBase64;