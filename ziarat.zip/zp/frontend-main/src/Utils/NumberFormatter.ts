const NumberFormatter = (num: number) => {
    if (num < 1000) {
        return num;
    }
    else if (num >= 1000 && num < 1000000) {
        return (num / 1000).toLocaleString() + ' K';
    }
    else if (num >= 1000000 && num < 1000000000) {
        return (num / 1000000).toLocaleString() + ' M';
    }
    else if (num > 1000000000) {
        return (num / 1000000000).toLocaleString() + ' B';
    }
};

export default NumberFormatter;