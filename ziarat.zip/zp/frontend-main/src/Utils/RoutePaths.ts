// eslint-disable-next-line import/no-anonymous-default-export
export default {
  default: "/",
  login: "/login",

  //tours
  karbalaTour: "/tours/karbala",
  karbalaAirTour: "/tours/karbala/air",
  karbalaGroundTour: "/tours/karbala/ground",
  syriaTour: "/tours/syria",
  karbalaTehran: "/tours/karbala/from-tehran",
  lastSecond: "/tours/karbala/lastsecond",
  threeAndFourDays: "/tours/karbala/3-and-4-days",
  karbalaMashhad: "/tours/karbala/from-mashhad",
  karbalaShiraz: "/tours/karbala/from-shiraz",
  karbalaIsfahan: "/tours/karbala/from-isfahan",
  karbalaTabriz: "/tours/karbala/from-tabriz",
  installment: "/tours/karbala/installment",
  vip: "/tours/karbala/vip",

  //hotel
  hotel: "/hotel",
  karbalaHotel: "/hotel/karbala-hotel",
  najafHotel: "/hotel/najaf-hotel",
  kadhimiyaHotel: "/hotel/kadhimiya-hotel",

  //contact-us
  contactUs: "/contact-us",

  //about-us
  aboutUs: "/about-us",

  //dashboard
  dashboard: "/dashboard",

  //mag
  mag: "/mag",

  //rules
  rules: "/rules",

  //fishhaj
  fishhaj: "/fishhaj",
};
