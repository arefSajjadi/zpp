class RecordController {
  add(list: any, item: any) {
    let newList = [...list];
    newList.unshift(item);
    return newList;
  }
  update(list: any, item: any, idName = "id") {
    let newList = [...list];
    let record = newList.findIndex((each) => each[idName] === item[idName]);
    newList[record] = item;
    return newList;
  }
  updateWithIndex(list: any, item: any, index: number) {
    let newList = [...list];
    newList[index] = item;
    return newList;
  }
  updateSingleProperty(list: any, item: any, property: string) {
    let newList = [...list];
    newList = newList.map((each) => {
      return {
        ...each,
        [property]: each.id === item.id ? item[property] : !item[property],
      };
    });
    return newList;
  }
  deleteWithIndex(list: any, index: number) {
    let newList = [...list];
    newList.splice(index, 1);
    return newList;
  }
  delete(list: any, item: any, idName = "id") {
    let newList = [...list];
    let record = newList.findIndex((each) => each[idName] === item[idName]);
    newList.splice(record, 1);
    return newList;
  }
}

export default new RecordController();