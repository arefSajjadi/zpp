import { addSeparator, removeSeparator } from "./Separator";

class FormHandlers {
  onChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    formik: any,
    callBack?: any
  ) => {
    let value = e.target.value;
    let name = e.target.name;
    formik.setFieldValue(e.target.name, e.target.value);
    callBack && callBack(e, name, value);
  };

  onChangeWithIndex = (
    e: React.ChangeEvent<HTMLInputElement>,
    formik: any,
  ) => {
    let value = e.target.value;
    let name = e.target.name;
    formik.setFieldValue(e.target.name, e.target.value);
    // callBack && callBack(e, name, value);
  };

  onChange_number = ( //input type number 
    e: React.ChangeEvent<HTMLInputElement>,
    formik: any,
    callBack?: any
  ) => {
    let name = e.target.name;
    const value = removeSeparator(e.target.value)
    const formattedValue = addSeparator(value);
    formik.setFieldValue(e.target.name, formattedValue);
    callBack && callBack(e, name, formattedValue ,value);
  };

  onSelect = (
    selected: any,
    name: string,
    formik: any,
    callBack?: any,
    mutli?: boolean,
    displayId: string = "id"
  ) => {
    let value;
    if (!mutli) {
      // value = selected[displayId].toString();
      value = selected[displayId];
    } else {
      //تبدیل لیست به رشته
      //selected: newListOfString
      value = selected.map((each: any) => each).join();
    }
    formik.setFieldValue(name, value);
    callBack && callBack(selected, name);
  };

  onDeSelect = (
    option: any, //ایتم انتخاب شده
    name: string,
    formik: any,
    displayId: string = "id"
  ) => {
    //تبدیل رشته به آرایه ای از رشته ها
    let value = formik.values[name].split(',');
    //پیدا کردن ایندکس مورد انتخاب شده در لیست رشته ها
    let item = option[displayId].toString()
    let itemIndex = value.findIndex((each: any) => each === item);
    //حذف از لیست رشته ها
    value.splice(itemIndex, 1);
    //تبدیل لیست جدید به رشته
    value = value.join(',');
    //ست کردن رشته ی جدید
    formik.setFieldValue(name, value);
  };

  onClear = (
    name: string,
    formik: any,
    callBack?: any,
    multi?: boolean
  ) => {
    formik.setFieldTouched(name);
    if (multi) {
      formik.setFieldValue(name, '');
    } else {
      formik.setFieldValue(name, null);
    }
    callBack && callBack();
  };

  onBlur = (
    e: React.ChangeEvent<HTMLInputElement>,
    formik: any
  ) => {
    let name = e.target.name;
    formik.setFieldTouched(name);
  };

  onPress = (
    name: string,
    formik: any
  ) => {
    formik.setFieldTouched(name);
  };
}

export default new FormHandlers();