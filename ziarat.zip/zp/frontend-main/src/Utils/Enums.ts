export enum SortOrderEnum {
    ASCENDING = "ascending",
    DESCENDING = "descending"
}

//پروفایل --------------------------------------------------
//تنظیمات پنل مشتری
export enum SettingTypesTypesEnum {
    THEME = 1,
    SMS = 2,
    EMAIL = 3,
    NOTIFICATION = 4
}

//درخواست ها --------------------------------------------------
//نوع درخواست ها
export enum CardRequestTypes { //آیدی دیتابیسه - تغییر داده نشه
    UNKNOWN = 0,
    CHANGE_PROFILE_INFO = 8,
    MARKETING_CONTRACT = 3,
    MARKETING_CONTRACT_EXTENSION = 10,

    WITHDRAWAL = 1000, //xxx
    CHANGE_SUPERVISOR = 1001, //xxx
}

//وضعیت درخواست ها
export enum RequestStatusEnum {
    New = 1, //ایجاد شده
    Verified = 2, //احراز شده
    Requested = 6, //در انتظار تایید کارگزاری
    Confirm = 4, //تایید شده
    Return = 8, //ارجاع شده به مرحله قبل
    Execution = 5, //انجام شده
    Rejected = 3, //رد شده
    Canceled = 7, //لغو شده
}

//بازاریابی --------------------------------------------------
//دوره زمانی
export enum TimeFrame {
    Unknown = 0,
    /// روزانه
    Daily,
    /// هفتگی
    Weekly,
    /// ماهانه
    Monthly,
    /// سه ماهه
    Trimester,
    /// شش ماهه
    SixMonths,
    /// سالانه
    Yearly
}

// نوع گزارش
export enum FunctionalCheckType {
    // کارمزد بازاریاب
    MarketerFeeStatistic = 3,
    // تعداد مشتریان زیرمجموعه
    SubcategoryCustomersStatistic = 1,
}

//نوع شخص - برای نمایش لیست قرارداد های بازاریابی
export enum PersonTypeEnum {
    UNKNOWN,
    FIRM,
    INDIVIDUAL
}

//وضعیت انقضا
export enum ExpirationStatus {
    UNKNOWN = 0,
    EXPIRED = 1,
    EXPIRING = 2,
    ACTIVE = 3
}

//آپشن --------------------------------------------------
//نوع درخواست آپشن
export enum OptionRequestTypes {
    FREEZE = 1,
    UNFREEZE = 2
}

//نوع تضمین
export enum OptionGuaranteeTypes {
    CASH = 1,
    OPTION_CONTRACT_COUNT = 2,
    INSTRUMENT_COUNT = 3
}