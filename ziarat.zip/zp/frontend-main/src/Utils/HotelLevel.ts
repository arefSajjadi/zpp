export const HotelLevel = (star: number | string) => {
    return star == 5 ? "الف ویژه" : 
        star == 4 ? "الف" :
        star == 3 ? "ب" :
        star == 2 ? "ج" : "ج"

}