import React, { useEffect, useState } from "react";
import { HeaderContainer, Notice } from "./styles";

import { useSelector } from "react-redux";
import { selectLang } from "@/Redux/App/Selectors";
import routePath from "@/Utils/RoutePaths";
import { selectAuth } from "@/Redux/Auth/Selectors";
import { hasCookie } from "cookies-next";
import NameSpace from "@/Storage/NameSpace";
import Menu from "./Menu";
import Row from "../Kit/Row";
import { LogoContainer } from "./Menu/styles";
import Logo1Icon from "@/Assets/Icons/Logo1Icon";
import CrossIcon from "../Kit/Icons/CrossIcon";

export type menuProps = {
  id: number;
  title: string;
  url: string;
  children?: subMenuProps[];
};

export type subMenuProps = {
  id: number;
  icon?: string;
  title: string;
  url: string;
  sectionName: string;
  target?: string;
  onClick?: any;
};

interface Props {
  notification?: string | null | undefined;
  phoneNumber?: string | null | undefined;
  setNotification?: (value: any) => void;
}
const Header = ({ notification, setNotification, phoneNumber }: Props) => {
  const { mobileNumber } = useSelector(selectAuth);

  const [isAuth, setIsAuth] = useState(false);

  useEffect(() => {
    if (hasCookie(NameSpace.token)) {
      setIsAuth(true);
    } else {
      setIsAuth(false);
    }
  }, []);

  const headerItems: menuProps[] = [
    {
      id: 1,
      title: "تورهای زیارتی",
      url: "",
      children: [
        {
          id: 1,
          title: "تور کربلا",
          url: routePath.karbalaTour + "/from-tehran",
          sectionName: "",
        },
        {
          id: 2,
          title: "تور کربلا هوایی",
          url: routePath.karbalaAirTour,
          sectionName: "",
        },
        {
          id: 3,
          title: "تور کربلا زمینی",
          url: routePath.karbalaGroundTour,
          sectionName: "",
        },
        {
          id: 4,
          title: "تور لحظه آخری کربلا",
          url: routePath.lastSecond,
          sectionName: "",
        },
        {
          id: 5,
          title: "تور 3 و 4 روزه کربلا",
          url: routePath.threeAndFourDays,
          sectionName: "",
        },
        {
          id: 6,
          title: "تور اقساطی کربلا",
          url: routePath.installment,
          sectionName: "",
        },
        {
          id: 7,
          title: "تور VIP کربلا",
          url: routePath.vip,
          sectionName: "",
        },
      ],
    },
    {
      id: 2,
      title: "تور کربلا از شهر ها",
      url: "",
      children: [
        {
          id: 1,
          title: "تور کربلا از تهران",
          url: routePath.karbalaTour + "/from-tehran",
          sectionName: "",
        },
        {
          id: 2,
          title: "تور کربلا از مشهد",
          url: routePath.karbalaMashhad,
          sectionName: "",
        },
        {
          id: 3,
          title: "تور کربلا از شیراز",
          url: routePath.karbalaShiraz,
          sectionName: "",
        },
        {
          id: 4,
          title: "تور کربلا از اصفهان",
          url: routePath.karbalaIsfahan,
          sectionName: "",
        },

        {
          id: 5,
          title: "تور کربلا از تبریز",
          url: routePath.karbalaTabriz,
          sectionName: "",
        },
      ],
    },
    {
      id: 3,
      title: "هتل های عراق",
      url: "",
      children: [
        {
          id: 1,
          title: "هتل کربلا",
          url: routePath.karbalaHotel,
          sectionName: "",
        },
        {
          id: 2,
          title: "هتل نجف",
          url: routePath.najafHotel,
          sectionName: "",
        },
        {
          id: 3,
          title: "هتل کاظمین",
          url: routePath.kadhimiyaHotel,
          sectionName: "",
        },
      ],
    },
    {
      id: 4,
      title: "مجله رسم زیارت",
      url: routePath.mag,
    },
    {
      id: 5,
      title: "تماس با ما",
      url: routePath.contactUs,
    },
  ];

  return (
    <>
      <HeaderContainer>
        <Row className="content">
          <LogoContainer href={routePath.default}>
            <Logo1Icon />
          </LogoContainer>

          <Menu
            MenuConfig={headerItems}
            isAuth={isAuth}
            mobileNumber={mobileNumber || ""}
          />
        </Row>
      </HeaderContainer>
      {!!notification && (
        <Notice>
          <div>
            {notification}{" "}
            {phoneNumber && <a href={`tel:${phoneNumber}`}>{phoneNumber}</a>}
          </div>
          <div onClick={() => setNotification?.(null)}>
            <CrossIcon />
          </div>
        </Notice>
      )}
    </>
  );
};

export default Header;
