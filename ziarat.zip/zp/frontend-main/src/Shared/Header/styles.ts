import styled from "styled-components";

export const HeaderContainer = styled.header`
  display: flex;
  direction: rtl;
  flex-direction: row;
  align-items: center;
  box-sizing: border-box;
  line-height: 1.6;
  flex-wrap: wrap;
  width: 100%;
  -webkit-flex-wrap: wrap;
  padding: 0 150px;
  flex-wrap: nowrap;
  height: 100px;
  border-bottom: 1px solid ${(props) => props.theme.gray50};
  background-color: #fcfcfc;
  justify-content: center;
  position: sticky;
  top: 0;
  z-index: 100;
  .content {
    gap: 30px;
    flex-wrap: nowrap;
    max-width: 1920px;
    @media (min-width: ${(props) => props.theme.xl}) {
      padding: 0 150px !important;
    }
  }

  .burgerContainer {
    display: none;
  }

  @media (max-width: ${(props) => props.theme.lg}) {
    padding: 0 100px;
  }

  @media (min-width: ${(props) => props.theme.xl}) {
    padding: 0 150px !important;
  }

  @media (max-width: ${(props) => props.theme.xs}) {
    height: 70px;
    padding: 0 20px;
    width: 100%;
    justify-content: space-between;

    .content {
      justify-content: space-between;
    }
    .burgerContainer {
      justify-content: flex-end;
      display: flex;
    }
  }
`;

export const Notice = styled.p`
  padding: 0 20px;
  margin: 15px auto;
  display: flex;
  justify-content: center;
  align-items: center;
  width: calc(100% - 300px);
  max-width: 1920px;
  background-color: ${(props) => props.theme.primary300};
  color: ${(props) => props.theme.white};
  padding: 15px 0px;
  margin: 0 150px !important;
  box-sizing: border-box;
  a {
    color: ${(props) => props.theme.white};
  }
  svg {
    margin-right: 10px;
    fill: ${(props) => props.theme.white};
  }
  @media (max-width: ${(props) => props.theme.lg}) {
    margin: 0 100px !important;
    width: calc(100% - 200px);
  }
  @media (max-width: ${(props) => props.theme.xs}) {
    padding: 15px;
    margin: 0 !important;
    width: 100%;
  }
`;
