import React from "react";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import Link from "next/link";
import {
    SubMenuCol,
    SubMenuItem,
    SubMenuIcon,
} from "./styles";
import Row from "@/Shared/Kit/Row";
import { LargeParagraph, SmallParagraph } from "@/Shared/Kit/Typography/Paragraph";
import { menuProps } from ".";

interface Props {
    xl: number,
    menu: menuProps,
    sliceIndexFrom: number,
    sliceIndexTo: number,
    p_size: string
}

const SubMenuColView: React.FC<Props> = (props) => {
    const {
        xl,
        menu,
        sliceIndexFrom,
        sliceIndexTo,
        p_size
    } = props;

    const theme = useSelector(selectTheme);

    let ParagraphComponent =
        p_size === "sm"
            ? SmallParagraph
            : p_size === "lg"
                ? LargeParagraph
                : LargeParagraph //x

    return (
        <SubMenuCol xl={xl}>
            {menu.children?.slice(sliceIndexFrom, sliceIndexTo).map((subMenu, i) => {
                return (
                    <SubMenuItem
                        key={i}
                    >
                        {subMenu.url || subMenu.sectionName
                            ? <Link
                                href={
                                    subMenu.sectionName
                                        ? subMenu.url + "#" + subMenu.sectionName
                                        : subMenu.url
                                }
                                target={subMenu.target || "_self"}
                            >
                                {subMenu.icon && <SubMenuIcon source={subMenu.icon} />}
                                <ParagraphComponent color={theme.gray800}>
                                    {subMenu.title}
                                </ParagraphComponent>
                            </Link>
                            :
                            <Row
                                onClick={subMenu.onClick}
                            >
                                <ParagraphComponent color={theme.gray800}>
                                    {subMenu.title}
                                </ParagraphComponent>
                            </Row>
                        }
                    </SubMenuItem>
                );
            })}
        </SubMenuCol>
    );
};

export default SubMenuColView;
