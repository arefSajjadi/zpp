import React, { useRef } from "react";
import {
    MenuContainer
} from "./styles"
import PcMenu from "./PcMenu";
import MobileMenu from "./MobileMenu";


interface Props {
  MenuConfig: menuProps[],
  isAuth: boolean,
  mobileNumber: string
}

export type menuProps = {
  id: number;
  title: string;
  url: string;
  children?: subMenuProps[];
}

export type subMenuProps = {
  id: number;
  icon?: string;
  title: string;
  url: string;
  sectionName: string;
  target?: string;
  onClick?: any;
}

const Menu: React.FC<Props> = (props) => {
  const {
    MenuConfig,
    isAuth,
    mobileNumber
  } = props;

  const targetRef = useRef<any>();

  return (
    <MenuContainer>
      <PcMenu
        MenuConfig={MenuConfig}
        isAuth={isAuth}
        mobileNumber={mobileNumber}
      />
      <MobileMenu
        MenuConfig={MenuConfig}
        isAuth={isAuth}
        mobileNumber={mobileNumber}
      />
    </MenuContainer>
  );
};

export default Menu;
