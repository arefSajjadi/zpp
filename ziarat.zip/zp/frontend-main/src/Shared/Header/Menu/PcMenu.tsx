import React from "react";
import {
  BtnsContainer,
  ItemContainer,
  ItemWithSubMenuContainer,
  ItemsContainer,
  LinkItem,
  SubMenuContainer,
} from "./styles";
import Row from "../../Kit/Row";
import { SmallParagraph } from "../../Kit/Typography/Paragraph";
import { PrimaryLink } from "../../Kit/Link/PrimaryLink";
import { OutlineLink } from "../../Kit/Link/OutlineLink";
import TelephonIcon from "@/Assets/Icons/TelephonIcon";
import ProfileIcon from "@/Assets/Icons/ProfileIcon";
import { PublicDic } from "@/Dictionary/PublicDic";
import { useSelector } from "react-redux";
import { selectLang } from "@/Redux/App/Selectors";
import ArrowDownIcon from "../../Kit/Icons/ArrowDownIcon";
import LoginModal from "@/Modals/LoginModal";
import { menuProps } from "..";
import RoutePaths from "@/Utils/RoutePaths";
import { SUPPORT_PHONE } from "@/config/constants";

interface Props {
  MenuConfig: menuProps[];
  isAuth: boolean;
  mobileNumber: string;
}
const PcMenu: React.FC<Props> = (props) => {
  const { MenuConfig, isAuth, mobileNumber } = props;
  const lang = useSelector(selectLang);

  return (
    <>
      <ItemsContainer>
        {MenuConfig.map((item) => {
          return (
            <ItemContainer key={item.id}>
              {item.children ? (
                <ItemWithSubMenuContainer>
                  <Row className="itemWithChildrenContainer">
                    <SmallParagraph>{item.title}</SmallParagraph>
                    <ArrowDownIcon />
                  </Row>

                  <SubMenuContainer className="subMenuContainer">
                    {item.children?.map((item) => {
                      return (
                        <Row key={item.id} className="subItem">
                          <LinkItem
                            key={item.id}
                            href={item?.url ? item.url : "#"}
                          >
                            {item.title}
                          </LinkItem>
                          <ArrowDownIcon />
                        </Row>
                      );
                    })}
                  </SubMenuContainer>
                </ItemWithSubMenuContainer>
              ) : (
                <LinkItem href={item?.url ? item.url : "#"}>
                  {item.title}
                </LinkItem>
              )}
            </ItemContainer>
          );
        })}
      </ItemsContainer>

      <BtnsContainer>
        <OutlineLink
          color="primary"
          size="xs"
          to={`tel:${SUPPORT_PHONE}`}
          width="132px"
          icon={TelephonIcon}
          iconPosition="left"
          title={PublicDic.phoneNumber[lang]}
        />
        {isAuth ? (
          <PrimaryLink
            color="primary"
            size="xs"
            to={RoutePaths.dashboard}
            width="132px"
            icon={ProfileIcon}
            iconPosition="left"
            title="حساب کاربری"
          />
        ) : (
          <PrimaryLink
            color="primary"
            size="xs"
            to={RoutePaths.login}
            width="132px"
            icon={ProfileIcon}
            iconPosition="right"
            title={PublicDic.login[lang]}
          />
        )}
      </BtnsContainer>

      <LoginModal />
    </>
  );
};

export default PcMenu;
