import React, { useState } from "react";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import Link from "next/link";
import { MenuItem, MobileSubMenuContainer } from "../styles";

import { LargeParagraph } from "@/Shared/Kit/Typography/Paragraph";
import SubMenuColView from "../SubMenuColView";
import { menuProps } from "../..";
import useIsMobile from "@/Utils/Responsive";
import Col from "@/Shared/Kit/Col";
import Row from "@/Shared/Kit/Row";

interface Props {
  menu: menuProps;
}

const MobileMenuItem: React.FC<Props> = (props) => {
  const { menu } = props;

  const theme = useSelector(selectTheme);

  const isMobile = useIsMobile();

  const subMenuId = `mobile-submenu-container-${menu.id}`;
  const childrenCount = menu.children ? menu.children.length : 0;

  const [expand, setExpand] = useState(false);

  const onToggleMenu = () => {
    let subMenuContainerElement = document.getElementById(subMenuId);
    let style = subMenuContainerElement?.style;
    if (style) {
      if (!expand) {
        style.height =
          isMobile === "tablet"
            ? `${childrenCount * 67}px`
            : `${childrenCount * 53}px`;
      } else {
        style.height = "0px";
      }
    }
    setExpand(!expand);
  };

  return (
    <Col>
      <MenuItem key={menu.id}>
        {menu.children ? (
          <Row onClick={onToggleMenu}>
            <LargeParagraph color={theme.gray800}>{menu.title}</LargeParagraph>
          </Row>
        ) : (
          <Link href={menu.url}>
            <LargeParagraph color={theme.gray800}>{menu.title}</LargeParagraph>
          </Link>
        )}
      </MenuItem>
      {menu.children && (
        <MobileSubMenuContainer id={subMenuId} className="hide-scroll-bar">
          <SubMenuColView
            xl={24}
            menu={menu}
            sliceIndexFrom={0}
            sliceIndexTo={menu.children.length}
            p_size={"lg"}
          />
        </MobileSubMenuContainer>
      )}
    </Col>
  );
};

export default MobileMenuItem;
