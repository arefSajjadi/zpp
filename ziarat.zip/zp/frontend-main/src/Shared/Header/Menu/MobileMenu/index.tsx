import React from "react";
import { useSelector } from "react-redux";
import { selectLang, selectTheme } from "@/Redux/App/Selectors";
import Link from "next/link";
import {
  MobileMenuContainer,
  CloseIconContainer,
  MobileMenuItemsContainer,
  EachItemContainer,
  NavBar,
} from "../styles";
import Row from "@/Shared/Kit/Row";

import { MediumParagraph } from "@/Shared/Kit/Typography/Paragraph";
import SlidingMenu from "@/Shared/Kit/SlidingMenu";
import { closeMenu } from "@/Shared/Kit/SlidingMenu";

import { menuProps } from "../..";
import CrossIcon from "@/Shared/Kit/Icons/CrossIcon";

import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";

import routePath from "@/Utils/RoutePaths";

interface Props {
  MenuConfig: menuProps[];
  isAuth: boolean;
  mobileNumber: string;
}

const MobileMenu: React.FC<Props> = (props) => {
  const theme = useSelector(selectTheme);
  const lang = useSelector(selectLang);

  const items = [
    {
      id: 1,
      title: "تور کربلا",
      url: routePath.karbalaTour + "/from-tehran",
    },
    {
      id: 2,
      title: "تور کربلا هوایی",
      url: routePath.karbalaAirTour,
    },
    {
      id: 3,
      title: "تور کربلا زمینی",
      url: routePath.karbalaGroundTour,
    },
    {
      id: 4,
      title: "تور لحظه آخری کربلا",
      url: routePath.lastSecond,
    },
    {
      id: 5,
      title: "تور 3 و 4 روزه کربلا",
      url: routePath.threeAndFourDays,
    },
    {
      id: 6,
      title: "تور اقساطی کربلا",
      url: routePath.installment,
    },
    {
      id: 7,
      title: "تور VIP کربلا",
      url: routePath.vip,
    },

    {
      id: 9,
      title: "تور کربلا از تهران",
      url: routePath.karbalaTour + "/from-tehran",
    },
    {
      id: 10,
      title: "تور کربلا از مشهد",
      url: routePath.karbalaMashhad,
    },
    {
      id: 11,
      title: "تور کربلا از شیراز",
      url: routePath.karbalaShiraz,
    },
    {
      id: 12,
      title: "تور کربلا از اصفهان",
      url: routePath.karbalaIsfahan,
    },

    {
      id: 13,
      title: "تور کربلا از تبریز",
      url: routePath.karbalaTabriz,
    },

    {
      id: 14,
      title: "هتل کربلا",
      url: routePath.karbalaHotel,
    },
    {
      id: 15,
      title: "هتل نجف",
      url: routePath.najafHotel,
    },
    {
      id: 16,
      title: "هتل کاظمین",
      url: routePath.kadhimiyaHotel,
    },

    {
      id: 17,
      title: "مجله رسم زیارت",
      url: routePath.mag,
    },
    {
      id: 18,
      title: "تماس با ما",
      url: routePath.contactUs,
    },
  ];
  return (
    <>
      <SlidingMenu>
        <MobileMenuContainer>
          <Row className="first-row">
            <CloseIconContainer onClick={() => closeMenu()}>
              <CrossIcon />
            </CloseIconContainer>
          </Row>
        </MobileMenuContainer>
        <NavBar>
          <MobileMenuItemsContainer>
            {items.map((item) => {
              return (
                <Link href={item.url} key={item.id} target={"_blank"}>
                  <EachItemContainer>
                    <Row className="iconAndTitleContainer">
                      <MediumParagraph color={theme.gray800}>
                        {item.title}
                      </MediumParagraph>
                    </Row>
                    <Row className="arrowContainer">
                      <ArrowDownIcon />
                    </Row>
                  </EachItemContainer>
                </Link>
              );
            })}
          </MobileMenuItemsContainer>
        </NavBar>
      </SlidingMenu>
    </>
  );
};

export default MobileMenu;
