import styled from "styled-components";
import Link from "next/link";
import Row from "@/Shared/Kit/Row";
import Col from "@/Shared/Kit/Col";

export const MenuContainer = styled.div`
  display: flex;
  flex-direction: row;
  width: calc(100% - 140px);
  justify-content: space-between;
  * {
    transition: all 300ms;
  }
  .menu-item-and-submenu-container-pc {
    width: auto;
    &:hover {
      svg {
        rotate: 180deg;
        path {
          fill: ${(props) => props.theme.primary600} !important;
        }
      }
    }
  }
  @media screen and (max-width: ${(props) => props.theme.md}) {
    justify-content: flex-end;
    .menu-item-and-submenu-container-pc {
      display: none;
    }
  }
`;

export const LogoContainer = styled(Link)`
  display: flex;
  width: max-content;
`;

export const ItemsContainer = styled(Row)`
  flex-wrap: nowrap;
  max-width: 680px;
  gap: 20px;
  margin: auto;
  justify-content: center;
  @media (max-width: ${(props) => props.theme.md}) {
    display: none;
  }
`;

export const ItemContainer = styled.nav`
  display: flex;
  direction: rtl;
  flex-direction: row;
  align-items: center;
  box-sizing: border-box;
  line-height: 1.6;
  flex-wrap: wrap;
  -webkit-flex-wrap: wrap;
  width: max-content;
  position: relative;
  justify-content: center;
  gap: 10px;
  cursor: pointer;

  .itemWithChildrenContainer {
    flex-wrap: nowrap;
    gap: 10px;
  }
`;

export const LinkItem = styled(Link)``;

export const BtnsContainer = styled(Row)`
  justify-content: flex-end;
  width: max-content;
  flex-wrap: nowrap;
  gap: 10px;
  @media (max-width: ${(props) => props.theme.md}) {
    display: none;
  }
`;

interface ItemWithSubMenuContainer {}
export const ItemWithSubMenuContainer = styled(Col)<ItemWithSubMenuContainer>`
  &:hover {
    .subMenuContainer {
      opacity: 1;
      height: max-content;
      display: flex;
    }
  }
`;

interface SubMenuContainerProps {}
export const SubMenuContainer = styled(Col)<SubMenuContainerProps>`
  gap: 8px;
  height: 0px;
  width: 170px;
  opacity: 0;
  display: none;
  position: absolute;
  top: 30px;
  padding: 10px;
  background-color: ${(props) => props.theme.white};
  box-shadow: 0px 0px 50px 5px rgba(0, 0, 0, 0.1);
  border-radius: 5px;
  transition: all 0.2s ease;
  z-index: 2;
  .subItem {
    gap: 10px;
    svg {
      rotate: 90deg;
    }
  }
`;

export const SubMenuCol = styled(Col)`
  height: 100%;
  align-items: flex-start;
  justify-content: space-between;
  &:first-child > div {
    border-right: 0;
  }
  @media screen and (max-width: 1080px) {
    justify-content: flex-start;
  }
`;

export const SubMenuItem = styled(Row)`
  width: auto;
  padding-right: 22px;
  border-right: 1px solid ${(props) => props.theme.gray50};
  cursor: pointer;
  a {
    display: flex;
    flex-direction: row;
    align-items: center;
  }
  &:hover {
    transform: translateY(-3px);
    p {
      color: ${(props) => props.theme.primary600};
    }
  }
  @media screen and (min-width: 1367px) {
    p {
      scale: 0.95;
    }
  }
  @media screen and (max-width: 1080px) {
    width: 100%;
    padding: 15px 0;
    border-bottom: 1px solid ${(props) => props.theme.gray100};
    &:hover {
      transform: translateY(0);
    }
  }
  @media screen and (max-width: ${(props) => props.theme.xs}) {
    padding: 12px 0;
    p {
      font-size: 14px;
      line-height: 28px;
    }
  }
`;

interface SubMenuIconProps {
  source: string;
}
export const SubMenuIcon = styled(Col)<SubMenuIconProps>`
  width: 25px !important;
  height: 25px;
  background-image: url(${(props) => props.source});
  background-size: contain;
  background-position: center;
  background-repeat: no-repeat;
  margin-left: 10px;
`;

interface SubMenuContainerProps {
  spaceWidth?: string;
}
export const MobileSubMenuContainer = styled(Row)<SubMenuContainerProps>`
  position: absolute;
  top: 46px;
  left: 0;
  width: ${(props) => `calc(100% - ${props.spaceWidth})`};
  height: 150px;
  align-items: flex-start;
  padding: 25px 0 25px 22px;
  border-radius: 4px;
  border: 1px solid ${(props) => props.theme.gray100};
  background: ${(props) => props.theme.white};
  box-shadow: 0px 6px 6px 0px rgba(25, 24, 22, 0.08);
  z-index: 1;
  //motion
  display: none;
  opacity: 0;
  transition: all 300ms;
  @media screen and (min-width: 1367px) {
    height: 180px;
  }
  @media screen and (max-width: 1080px) {
    display: flex;
    flex-direction: column;
    position: relative;
    top: 0;
    width: 100%;
    padding: 0 45px 0 0;
    box-shadow: none;
    border: 0;
    opacity: 1;
    //motion
    height: 0;
    overflow-y: auto;
    transition: all 600ms;
  }
  @media screen and (max-width: ${(props) => props.theme.xs}) {
    padding: 0 25px 0 0;
  }
`;

export const MenuItem = styled(Row)`
  width: auto;
  height: 46px;
  margin: 0 15px;
  cursor: pointer;
  svg {
    width: 9.333px;
    height: 5.444px;
    fill: ${(props) => props.theme.gray900};
    margin-right: 10px;
  }
  &:hover {
    p {
      color: ${(props) => props.theme.primary600};
    }
  }
  @media screen and (min-width: 1367px) {
    p {
      scale: 0.95;
    }
    svg {
      scale: 1.2;
    }
  }
  @media screen and (max-width: 1080px) {
    width: 100%;
    height: auto;
    margin: 0;
    padding: 15px 0;
    border-bottom: 1px solid ${(props) => props.theme.gray100};
  }
  @media screen and (max-width: ${(props) => props.theme.xs}) {
    padding: 12px 0;
    p {
      font-size: 14px;
      line-height: 28px;
    }
  }
`;

//tablet and mobile
export const MobileMenuIconContainer = styled(Col)`
  width: auto;
  cursor: pointer;
  svg {
    width: 24px;
    height: 16px;
    fill: ${(props) => props.theme.gray700};
  }
  @media screen and (min-width: 1081px) {
    display: none;
  }
`;
export const MobileMenuContainer = styled(Col)`
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  z-index: 2;
  height: 40px;
  border-bottom: 1px solid ${(props) => props.theme.gray50};
  .first-row {
    align-self: flex-end;
    width: max-content;
    justify-content: flex-end;
  }
`;

interface LogoProps {
  source: string;
}
export const Logo = styled(Col)<LogoProps>`
  width: 253px;
  height: 39px;
  background-image: url(${(props) => props.source});
  background-size: contain;
  background-position: right;
  background-repeat: no-repeat;
  @media screen and (max-width: ${(props) => props.theme.xs}) {
    width: 195px;
    height: 30px;
  }
`;

export const CloseIconContainer = styled(Col)`
  width: auto;
  padding: 15px;
  cursor: pointer;
  svg {
    width: 14px;
    height: 14px;
    fill: ${(props) => props.theme.gray400};
  }
  @media screen and (max-width: ${(props) => props.theme.xs}) {
    svg {
      width: 10px;
      height: 10px;
    }
  }
`;

export const MobileMenuItemsContainer = styled(Col)`
  display: flex;
  flex-direction: column;
  gap: 8px;
  width: 100%;
  padding: 0 15px 15px;

  > a {
    width: 100%;
  }
`;

export const NavBar = styled(Row)`
  position: absolute;
  top: 56px;
  right: 0;
  left: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  align-items: stretch;
  overflow-y: auto;
  overflow-x: hidden;
`;

export const EachItemContainer = styled(Row)`
  width: 100%;
  height: 44px;
  border: 1px solid ${(props) => props.theme.primary200};
  border-radius: 10px;
  padding: 0 12px;
  justify-content: space-between !important;

  /* path {
    stroke: ${(props) => props.theme.primary300};
  } */

  .iconAndTitleContainer,
  .arrowContainer {
    width: max-content;
  }

  .iconAndTitleContainer {
    gap: 13px;
    svg {
      width: 24px;
      height: 24px;
    }
  }

  .arrowContainer {
    rotate: 90deg;
    path {
      stroke: ${(props) => props.theme.primary300};
    }
  }
`;
