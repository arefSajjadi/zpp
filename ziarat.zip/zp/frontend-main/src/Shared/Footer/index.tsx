import React from "react";
import {
  FirstRow,
  FooterContainer,
  LinksContainer,
  SecondRow,
  ThirdRow,
} from "./styles";
import SocialMedia from "./SocialMedia";
import Col from "../Kit/Col";
import { XSmallParagraph, XXSmallParagraph } from "../Kit/Typography/Paragraph";
import Link from "next/link";
import LocationIcon from "@/Assets/Icons/LocationIcon";
import PhoneIcon from "@/Assets/Icons/PhoneIcon";
import Row from "../Kit/Row";
import RegisterForm from "./RegisterForm";
import Image from "next/image";
import SazmanHaj from "@/Assets/Images/sazmanHaj.png";
import { theme } from "@/Utils/theme";
import { SmallLabel } from "../Kit/Typography/Label";
import RoutePaths from "@/Utils/RoutePaths";
import useIsMobile from "@/Utils/Responsive";
import ToggleTab from "../Kit/ToggleTab";
import ArrowDownIcon from "../Kit/Icons/ArrowDownIcon";
import { MediumHeadingStyle } from "@/Shared/Kit/Typography/Heading/styles";
import FooterMenu from "./FooterMenu";
import { SUPPORT_PHONE } from "@/config/constants";

const Footer = () => {
  const responsive = useIsMobile();
  const ziarat = [
    {
      id: 1,
      title: "مجله گردشگری",
      url: RoutePaths.mag,
    },
    {
      id: 2,
      title: "تماس با ما",
      url: RoutePaths.contactUs,
    },
    {
      id: 3,
      title: "قوانین و مقررات",
      url: RoutePaths.rules,
    },
    {
      id: 4,
      title: "دعوت از دوستان",
      url: "https://invite.ziarat.co/",
    },

    {
      id: 5,
      title: "خدمات فیش حج",
      url: RoutePaths.fishhaj,
    },
  ];

  const useFullLinks = [
    {
      id: 1,
      title: "تور هوایی کربلا",
      url: RoutePaths.karbalaAirTour,
    },
    {
      id: 2,
      title: " قیمت کاروان کربلا زمینی",
      url: RoutePaths.karbalaGroundTour,
    },
    {
      id: 3,
      title: "تور کربلا از تهران",
      url: RoutePaths.karbalaTehran,
    },
    {
      id: 4,
      title: "تور کربلا لحظه آخری",
      url: RoutePaths.lastSecond,
    },
    {
      id: 5,
      title: "قیمت تور کربلا هوایی 4 روزه",
      url: RoutePaths.threeAndFourDays,
    },
    {
      id: 6,
      title: "تور کربلا هوایی از مشهد",
      url: RoutePaths.karbalaMashhad,
    },
  ];
  const hotels = [
    { id: 1, title: "هتل های کربلا", url: RoutePaths.karbalaHotel },
    { id: 1, title: "هتل های نجف", url: RoutePaths.najafHotel },
    { id: 1, title: "هتل های کاظمین", url: RoutePaths.kadhimiyaHotel },
  ];
  const contactUs = [
    {
      id: 1,
      title:
        "تهران ،خیابان سپهبد قرنی ،نبش خیابان کلانتری ،ساختمان شماره 17 ،طبقه چهارم",
      url: "",
      icon: LocationIcon,
    },
    {
      id: 2,
      title: SUPPORT_PHONE,
      url: `tel:${SUPPORT_PHONE}`,
      icon: PhoneIcon,
    },
  ];
  return (
    <FooterContainer>
      <FirstRow>
        <SocialMedia />
        {/* <Col className="registerFormWrapper">
          <RegisterForm />
        </Col> */}
      </FirstRow>
      <SecondRow>
        {responsive === "mobile" ? (
          <LinksContainer>
            <ToggleTab
              item={{ id: 1 }}
              name="ziarat"
              ExpandIcon={ArrowDownIcon}
              titleElements={<MediumHeadingStyle>رسم زیارت</MediumHeadingStyle>}
            >
              <Col className="ziaratContainer">
                {ziarat.map((item) => {
                  return (
                    <XSmallParagraph key={item.id}>
                      <Link href={item.url}>{item.title}</Link>
                    </XSmallParagraph>
                  );
                })}
              </Col>
            </ToggleTab>

            <ToggleTab
              item={{ id: 1 }}
              name="useFullLinks"
              ExpandIcon={ArrowDownIcon}
              titleElements={
                <MediumHeadingStyle>لینک های مفید</MediumHeadingStyle>
              }
            >
              <Col className="useFullLinksContainer">
                {useFullLinks.map((item) => {
                  return (
                    <XSmallParagraph key={item.id}>
                      <Link href={item.url}>{item.title}</Link>
                    </XSmallParagraph>
                  );
                })}
              </Col>
            </ToggleTab>

            <ToggleTab
              item={{ id: 1 }}
              name="contactUs"
              ExpandIcon={ArrowDownIcon}
              titleElements={
                <MediumHeadingStyle>تماس با ما</MediumHeadingStyle>
              }
            >
              <Col className="phoneAndLocationContainer">
                {contactUs.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Row key={item.id} className="iconAndTextContainer">
                      <Icon />
                      <Link href={item.url}>
                        <XSmallParagraph key={item.id}>
                          {item.title}
                        </XSmallParagraph>
                      </Link>
                    </Row>
                  );
                })}
              </Col>
            </ToggleTab>
          </LinksContainer>
        ) : (
          <LinksContainer>
            <Col xl={5}>
              <MediumHeadingStyle>رسم زیارت</MediumHeadingStyle>
              <Col>
                {ziarat.map((item) => {
                  return (
                    <XSmallParagraph key={item.id}>
                      <Link href={item.url}>{item.title}</Link>
                    </XSmallParagraph>
                  );
                })}
              </Col>
            </Col>

            <Col xl={5}>
              <MediumHeadingStyle>تورهای رسم زیارت</MediumHeadingStyle>

              <Col>
                {useFullLinks.map((item) => {
                  return (
                    <XSmallParagraph key={item.id}>
                      <Link href={item.url}>{item.title}</Link>
                    </XSmallParagraph>
                  );
                })}
              </Col>
            </Col>
            <Col xl={5}>
              <MediumHeadingStyle>هتل های عراق</MediumHeadingStyle>

              <Col>
                {hotels.map((item) => {
                  return (
                    <XSmallParagraph key={item.id}>
                      <Link href={item.url}>{item.title}</Link>
                    </XSmallParagraph>
                  );
                })}
              </Col>
            </Col>
            <Col xl={10}>
              <MediumHeadingStyle>تماس با ما</MediumHeadingStyle>
              <Col className="phoneAndLocationContainer">
                {contactUs.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Row key={item.id} className="iconAndTextContainer">
                      <Icon />
                      <XSmallParagraph key={item.id}>
                        {item.title}
                      </XSmallParagraph>
                    </Row>
                  );
                })}
              </Col>
            </Col>
          </LinksContainer>
        )}

        <Row className="imagesMainContainer">
          {/* <Col className="registerFormWrapper">
            <RegisterForm />
          </Col> */}
          <Row className="imagesWrapper">
            <Col className="imagesContainer">
              <Link href="https://www.haj.ir" target="_blank">
                <Image alt="" src={SazmanHaj} fill />
              </Link>
            </Col>

            <Col className="imagesContainer">
              <a
                referrerPolicy="origin"
                href="https://trustseal.enamad.ir/?id=309481&Code=efyahmBkt5ayQWUyDNry"
              >
                <Image
                  referrerPolicy="origin"
                  src="https://trustseal.enamad.ir/logo.aspx?id=309481&Code=efyahmBkt5ayQWUyDNry"
                  alt=""
                  style={{ cursor: "pointer" }}
                  width={147}
                  height={180}
                  unoptimized
                />
              </a>
            </Col>
          </Row>
        </Row>
      </SecondRow>
      <ThirdRow>
        <XXSmallParagraph color={theme.gray200}>
          © کلیه حقوق این سایت متعلق به آوای رسم سفر می‌باشد.
        </XXSmallParagraph>
      </ThirdRow>
      <FooterMenu />
    </FooterContainer>
  );
};

export default Footer;
