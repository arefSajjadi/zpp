import Col from "@/Shared/Kit/Col";
import Row from "@/Shared/Kit/Row";
import styled from "styled-components";

export const RegisterFormContainer = styled(Col)`
  gap: 24px;
  background-color: ${(props) => props.theme.primary600};
  width: 380px;
  border-radius: 10px;
  padding: 15px;
  height: 150px !important;

  .bellContainer {
    gap: 13px;
  }

  .btnAndInputContianer {
    border-radius: 10px;
    background-color: ${(props) => props.theme.white};
    flex-wrap: nowrap;
    padding: 5px;
    .sendNumberInput {
      background-color: ${(props) => props.theme.white};
      border-radius: 0 8px 8px 0;
      input {
        outline: none;
        border: none;
      }
    }
    .sendBtn {
        .label {
            color: ${(props) => props.theme.black} !important; 
        }
        svg {
            fill: transparent !important;
        }
    }
  }

  @media (max-width: ${props => props.theme.xs}) {
        width: 100%;
    }
`;


export const OtpFormContainer = styled(Row)`
    gap: 10px;
    flex-wrap:nowrap;
    .timerContainer {
        height: 44px;
        justify-content: center;
        border-radius: 10px;
        background-color: ${(props) => props.theme.white};
    }
`