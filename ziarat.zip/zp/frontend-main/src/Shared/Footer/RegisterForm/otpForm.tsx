import SendIcon from "@/Assets/Icons/SendIcon";
import { PrimaryButton } from "@/Shared/Kit/Button/PrimaryButton";
import Input from "@/Shared/Kit/FromElements/Input";
import Row from "@/Shared/Kit/Row";
import { Dispatch, useState } from "react";
import { OtpFormContainer } from "./styles";
import { XXSmallParagraph } from "@/Shared/Kit/Typography/Paragraph";

interface Props {
    setStatus: Dispatch<React.SetStateAction<"numberForm" | "otpForm" | "text">>;
}
const OptForm:React.FC<Props> = (props) => {
    const {
        setStatus
    } = props;
    const [value ,setValue] = useState("")

    const onSendClick = () => {
        setStatus("text")
    }
    return ( 
        <OtpFormContainer>
            <Row xl={4} className="timerContainer">
                <XXSmallParagraph>
                    00:59
                </XXSmallParagraph>
            </Row>
            <Row className="btnAndInputContianer">
            <Input
                label=""
                name="confirmCode"
                size="xs"
                onBlur={() => {}}
                onChange={(e:any) => setValue(e.target.value)}
                value={value}
                className="sendNumberInput"
            />
            <PrimaryButton
                color="secondary"
                size="xs"
                width="68px"
                title="ثبت"
                icon={SendIcon}
                iconPosition="left"
                onClick={onSendClick}
                className="sendBtn"
            />
        </Row>
    </OtpFormContainer>
     );
}
 
export default OptForm;