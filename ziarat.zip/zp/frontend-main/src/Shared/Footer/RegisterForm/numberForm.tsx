import SendIcon from "@/Assets/Icons/SendIcon";
import { PrimaryButton } from "@/Shared/Kit/Button/PrimaryButton";
import Input from "@/Shared/Kit/FromElements/Input";
import Row from "@/Shared/Kit/Row";
import { Dispatch, useState } from "react";

interface Props {
    setStatus: Dispatch<React.SetStateAction<"numberForm" | "otpForm" | "text">>
}

const NumberForm:React.FC<Props> = (props) => {
    const {
        setStatus
    } = props;
    const [value ,setValue] = useState("")

    const onSendClick = () => {
        setStatus("otpForm")
    }
    return ( 
        <Row className="btnAndInputContianer">
        <Input
            label=""
            name="mobileNumber"
            size="xs"
            onBlur={() => {}}
            onChange={(e:any) => setValue(e.target.value)}
            value={value}
            className="sendNumberInput"
        />
        <PrimaryButton
            color="secondary"
            size="xs"
            width="68px"
            title="ارسال"
            icon={SendIcon}
            iconPosition="left"
            onClick={onSendClick}
            className="sendBtn"
        />
    </Row>

     );
}
 
export default NumberForm;