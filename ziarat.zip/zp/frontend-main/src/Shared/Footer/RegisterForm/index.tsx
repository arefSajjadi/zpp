import Row from "@/Shared/Kit/Row";
import { RegisterFormContainer } from "./styles";
import { SmallParagraph, XSmallParagraph } from "@/Shared/Kit/Typography/Paragraph";
import BellIcon from "@/Assets/Icons/BellIcon";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import Input from "@/Shared/Kit/FromElements/Input";
import { useState } from "react";
import { PrimaryButton } from "@/Shared/Kit/Button/PrimaryButton";
import SendIcon from "@/Assets/Icons/SendIcon";
import NumberForm from "./numberForm";
import OptForm from "./otpForm";

const RegisterForm = () => {

    const theme = useSelector(selectTheme)



    const [status ,setStatus] = useState<"numberForm"|"otpForm"|"text">("numberForm")
    
    return ( 
        <RegisterFormContainer>
                <Row className="bellContainer">
                    <BellIcon />
                    <SmallParagraph color={theme.white}>
                        اطلاع از تخفیف تور ها
                    </SmallParagraph>
                </Row>
                <Row>
                    <XSmallParagraph color={theme.white} >
                    با ثبت شماره ی خود از تور های با تخفیف ویژه ما با خبر شوید.
                    </XSmallParagraph>
                </Row>

                {/* {
                    status === "numberForm" ?
                    <NumberForm setStatus={setStatus} />
                    :
                    status === "otpForm" ?
                    <OptForm setStatus={setStatus} />
                    :
                    <></>
                } */}
        </RegisterFormContainer>
     );
}
 
export default RegisterForm;