import HomeIcon from "@/Assets/Icons/HomeIcon";
import { EachItemContainer, MainContainer } from "./styles";
import TwoUserIcon from "@/Assets/Icons/TwoUserIcon";
import SearchIcon from "@/Shared/Kit/Icons/SearchIcon";
import TelephonIcon from "@/Assets/Icons/TelephonIcon";
import {
  MediumParagraph,
  XSmallParagraph,
} from "@/Shared/Kit/Typography/Paragraph";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import Home2Icon from "@/Assets/Icons/Home2Icon";
import ProfileIcon from "@/Assets/Icons/ProfileIcon";
import Telephone2Icon from "@/Assets/Icons/Telephone2Icon";
import Search2Icon from "@/Assets/Icons/Search2Icon";
import Link from "next/link";
import { openMenu, closeMenu } from "@/Shared/Kit/SlidingMenu";
import { SUPPORT_PHONE } from "@/config/constants";

const FooterMenu = () => {
  const theme = useSelector(selectTheme);
  const items = [
    {
      id: 1,
      title: "خانه",
      icon: Home2Icon,
      link: "/",
      onClick: () => {},
    },
    {
      id: 2,
      title: "خدمات",
      icon: Search2Icon,
      onClick: () => openMenu(),
    },
    {
      id: 3,
      title: "حساب کاربری",
      icon: ProfileIcon,
      link: "/dashboard",
      onClick: () => {},
    },
    {
      id: 4,
      title: "",
      icon: Telephone2Icon,
      link: `tel:${SUPPORT_PHONE}`,
    },
  ];
  return (
    <MainContainer>
      {items.map((item, index) => {
        const Icon = item.icon;
        if (item.link) {
          return (
            <Link href={item.link} key={item.id}>
              <EachItemContainer
                className={
                  item.id === 3 ? "profile" : item.id === 4 ? "telephone" : ""
                }
              >
                <Icon />
                {item.id !== 4 && (
                  <MediumParagraph color={theme.gray900}>
                    {item.title}
                  </MediumParagraph>
                )}
              </EachItemContainer>
            </Link>
          );
        } else {
          return (
            <EachItemContainer key={item.id} onClick={item.onClick}>
              <Icon />
              <MediumParagraph color={theme.gray900}>
                {item.title}
              </MediumParagraph>
            </EachItemContainer>
          );
        }
      })}
    </MainContainer>
  );
};

export default FooterMenu;
