import Col from "@/Shared/Kit/Col";
import Row from "@/Shared/Kit/Row";
import styled from "styled-components";

export const MainContainer = styled(Row)`
  display: none;
  @media (max-width: ${(props) => props.theme.md}) {
    display: flex;
  }
  position: fixed;
  bottom: 0;
  width: 100vw;
  background-color: ${(props) => props.theme.white};
  justify-content: space-between;
  padding: 10px 14px;
  z-index: 3;
  border-top: 0.5px solid ${(props) => props.theme.gray400};
`;

export const EachItemContainer = styled(Col)`
  display: flex;
  flex-direction: row;
  max-width: 110px;
  white-space: nowrap;
  gap: 5px;
  &.profile {
    svg {
      path {
        stroke: ${(props) => props.theme.gray900};
      }
    }
  }
  &.telephone {
    background-color: ${(props) => props.theme.primary500};
    border-radius: 50%;
    width: 32px;
    height: 32px;
    svg {
      stroke: ${(props) => props.theme.white};
      path {
        stroke: ${(props) => props.theme.white};
      }
    }
  }
`;
