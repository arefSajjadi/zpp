import styled from "styled-components";
import Row from "../Kit/Row";
import Col from "../Kit/Col";

export const FooterContainer = styled.footer`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  flex-wrap: nowrap;
  width: 100%;
  margin-top: auto;
`;

export const FirstRow = styled(Row)`
  margin-bottom: 20px;
  padding: 0 150px;
  max-width: 1920px;
  .registerFormWrapper {
    display: none;
  }

  @media (max-width: ${(props) => props.theme.lg}) {
    padding: 0 100px;
  }

  @media (min-width: ${(props) => props.theme.xl}) {
    padding: 0 150px !important;
  }

  @media (max-width: ${(props) => props.theme.xs}) {
    padding: 0 20px;
    flex-direction: column;
    .registerFormWrapper {
      margin-top: 20px;
      display: flex;
    }
  }
`;

export const SecondRow = styled(Row)`
  padding: 0 150px;
  max-width: 1920px;

  display: flex;
  flex-wrap: nowrap;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 20px;
  gap: 20px;
  > .imagesMainContainer {
    flex: 0 0 auto;
    width: auto;
  }

  > .imagesMainContainer {
    display: flex;
    flex: 0 0 auto;
    width: auto;
    justify-content: center;
    flex-wrap: nowrap;
    gap: 10px;
  }

  @media (max-width: ${(props) => props.theme.lg}) {
    padding: 0 100px;
  }

  @media (min-width: ${(props) => props.theme.xl}) {
    padding: 0 150px !important;
  }

  @media (max-width: ${(props) => props.theme.xs}) {
    padding: 0 20px;
    flex-direction: column;

    > .imagesMainContainer {
      width: 100%;
    }

    .imagesMainContainer {
      flex-direction: column;

      .imagesWrapper {
        justify-content: center;
        gap: 20px;
      }

      .registerFormWrapper {
        display: none;
      }
    }
  }
  .iconAndTextContainer {
    gap: 15px;
    flex-wrap: nowrap;

    svg {
      width: 20px;
      height: 20px;
    }
  }

  .phoneAndLocationContainer {
    gap: 50px;
  }

  .imagesWrapper {
    display: flex;
    justify-content: end;
    flex-wrap: nowrap;
    gap: 10px;
  }
  .imagesContainer {
    position: relative;
    width: 147px;
    height: 194px;
  }
`;

export const ThirdRow = styled(Row)`
  background-color: ${(props) => props.theme.primary600};
  height: 44px;
  justify-content: center;
`;

export const LinksContainer = styled(Row)`
  flex-wrap: nowrap;
  gap: 5px;

  align-items: start;
  > div {
    gap: 30px;
    align-items: flex-start;

    > div {
      align-items: flex-start;
    }
  }

  @media (max-width: ${(props) => props.theme.xs}) {
    flex-direction: column;
    gap: 10px;
    margin-bottom: 1rem;
    > div {
      gap: 0px;
      align-items: flex-start;
      // border: none;
    }

    .ziaratContainer,
    .useFullLinksContainer {
      align-items: flex-start;
      gap: 8px;
    }
  }
`;
