import Row from "@/Shared/Kit/Row";
import { ItemsContainer, SocialMediaContainer } from "./styles";
import { PublicDic } from "@/Dictionary/PublicDic";
import { useSelector } from "react-redux";
import { selectLang, selectTheme } from "@/Redux/App/Selectors";
import InstagramIcon from "@/Assets/Icons/InstagramIcon";
import EttaIcon from "@/Assets/Icons/EttaIcon";
import BaleIcon from "@/Assets/Icons/BaleIcon";
import Link from "next/link";
import { LargeLabel } from "@/Shared/Kit/Typography/Label";
import TelegramWhiteIcon from "@/Assets/Icons/TelegramWhiteIcon";

const SocialMedia = () => {
  const lang = useSelector(selectLang);
  const theme = useSelector(selectTheme);
  const socialMedias = [
    {
      id: 1,
      icon: InstagramIcon,
      link: "https://www.instagram.com/ziarat.co?igsh=MXU4dXJxZHJvNTM2cA==",
    },
    {
      id: 2,
      icon: EttaIcon,
      link: "https://eitaa.com/ziaratco",
    },
    {
      id: 3,
      icon: BaleIcon,
      link: "https://ble.ir/ziaratco",
    },
    // {
    //     id:4,
    //     icon:TelegramWhiteIcon,
    //     link: "https://telegram.me/ziaratco"
    // }
  ];
  return (
    <SocialMediaContainer>
      <LargeLabel color={theme.white}>{PublicDic.followUs[lang]}</LargeLabel>
      <ItemsContainer>
        {socialMedias.map((item) => {
          const Icon = item.icon;
          return (
            <Row key={item.id}>
              <Link target="_blnak" href={item.link}>
                <Icon />
              </Link>
            </Row>
          );
        })}
      </ItemsContainer>
    </SocialMediaContainer>
  );
};

export default SocialMedia;
