import Row from "@/Shared/Kit/Row";
import styled from "styled-components";

export const SocialMediaContainer = styled(Row)`
  flex-wrap: nowrap;
  background-color: ${(props) => props.theme.primary600};
  justify-content: space-between;
  padding: 20px;
  border-radius: 20px;

  @media (max-width: ${props => props.theme.xs}) {
    border-radius: 10px;
  }
`;

export const ItemsContainer = styled(Row)`
  flex-wrap: nowrap;
  gap: 16px;
  width: max-content;
  > div {
   a {
    display: flex;
    align-items: center;
    }
    width: max-content;
  }
`;
