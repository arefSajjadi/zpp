import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import { Wrapper, Title, Description } from "./styles";
import Row from "../Row";
import Col from "../Col";
import { SmallParagraph, XSmallParagraph } from "../Typography/Paragraph";

interface Props {
  name: string;
  item: {
    id: number;
    title?: string;
    description?: string;
  };
  children?: React.ReactNode;
  titleElements?: React.ReactNode;
  maxHeight?: string;
  ExpandIcon?: any;
  padding?: string;
}

const ToggleTab: React.FC<Props> = (props) => {
  const {
    name,
    item,
    children,
    titleElements,
    maxHeight,
    ExpandIcon,
    padding,
  } = props;

  const { id, title, description } = item;

  const _id = `toggle-tab-description-${name}-${id}`;

  const theme = useSelector(selectTheme);

  const [expand, setExpand] = useState<boolean | null>(null);

  useEffect(() => {
    let descriptionElement = document.getElementById(_id);
    if (descriptionElement && descriptionElement.style) {
      descriptionElement.style.maxHeight = "0";
    }
  }, []);
  const toggle = () => {
    let descriptionElement = document.getElementById(_id);
    if (descriptionElement && descriptionElement.style) {
      if (!expand) {
        descriptionElement.style.maxHeight = maxHeight || "300px";
      } else {
        descriptionElement.style.maxHeight = "0";
      }
    }
    setExpand(!expand);
  };

  return (
    <Wrapper expand={expand}>
      <Title
        onClick={toggle}
        expand={expand}
        expandIcon={ExpandIcon}
        padding={padding ? padding : undefined}
      >
        <Row className="title">
          {title ? (
            <SmallParagraph
              color={!expand ? theme.primary600 : theme.primary600}
            >
              {title}
            </SmallParagraph>
          ) : (
            titleElements
          )}
        </Row>
        <Col className="icon">
          {/* <ArrowDownIcon 
            // color={theme.primary500}
          /> */}
          {ExpandIcon ? <ExpandIcon /> : <XSmallParagraph> + </XSmallParagraph>}
        </Col>
      </Title>
      <Description id={_id} className={`hide-scroll-bar`} expand={expand}>
        <Row>
          {children ? (
            children
          ) : (
            <XSmallParagraph color={theme.gray700}>
              {description?.split("\n").map((each, index) => {
                return (
                  <React.Fragment key={index}>
                    {each}
                    {index !== description?.split("\n")?.length - 1 && <br />}
                  </React.Fragment>
                );
              })}
            </XSmallParagraph>
          )}
        </Row>
      </Description>
    </Wrapper>
  );
};

export default ToggleTab;
