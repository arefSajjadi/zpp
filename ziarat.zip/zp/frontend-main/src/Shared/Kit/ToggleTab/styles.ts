import styled from "styled-components";
import Row from "../Row";
import Col from "../Col";

interface WrapperProps {
    expand: boolean | null;
}

export const Wrapper = styled(Col) <WrapperProps>`
    background-color: transparent;
    border: 1px solid ${(props) => !props.expand ? props.theme.primary600 : props.theme.secondary600};
    border-radius: 10px;
    /* padding: 10px 25px; */
    /* margin-bottom: 12px; */
    * {
        transition: all 300ms;
    }
`

interface TitleProps {
    expand: boolean | null;
    expandIcon?: boolean;
    padding?: string
}
export const Title = styled(Row) <TitleProps>`
    align-items: center;
    border-radius: 10px;
    padding: ${props => props.padding ? props.padding : "20px 16px"};
    /* border: 1px solid ${props => props.theme.primary600}; */
    flex-wrap: nowrap;
    background-color: transparent;
    cursor: pointer;

    .title {
        width: 100%;
    height: 100%;
        label {
            cursor: pointer;
            text-align: justify;
        }

        p {
            font-weight: ${props => props.expand ? "700" : "400"};
        }
    }
    .icon {
        width: 20px;
        height: 20px;
        p {
            font-size: 18px;
            color: ${props => props.expand ? props.theme.warning600 : props.theme.gray400};
            rotate: ${(props) => props.expandIcon ?  props.expand && "180deg" : props.expand && "45deg"};
        }
        padding: 5px;
        border: ${props => props.expandIcon ? "none" : ` 1.5px solid ${!props.expand ? props.theme.primary600 : props.theme.secondary600}`};
        border-radius: 6px;
        margin-right: 15px;
        svg {
            width: 14px;
            height: 14px;
            fill: ${(props) => !props.expand ? props.theme.gray900 : props.theme.primary600};
        }
    }
    &:hover {
        /* background-color: ${props => props.theme.primary50}; */
    }
`

export const Description = styled(Row) <TitleProps>`
    align-items: flex-start;
    padding: 0 32px;
    .description {
        font-size: 14px !important;
    }
    > div {
        padding: 15px 0 25px 0;
        p {
        text-align: justify;
        }
    }
    transition: all 700ms;
    //motion
    max-height: 0;
    overflow-y: auto;

    @media screen and (max-width: ${props => props.theme.sm}) {
        padding: 0 12px;
}
`