import React from 'react';
import { useSelector } from 'react-redux';
import { selectTheme } from '../../../Redux/App/Selectors';
import {
    Wrapper,
    Container,
    TabItem,
} from "./styles";
import Col from '../Col';
import { XXSmallLabel } from '../Typography/Label';

interface Props {
    tabItemConfig: tabItemProps[],
    onChangeTab: any,
    selectedTab: number,
}

interface tabItemProps {
    id: number,
    title: string,
    icon: any,
    size: number,
    disable?:boolean
}

//tab دایره ای با آیکون
const ModalTab: React.FC<Props> = (props) => {
    const {
        tabItemConfig,
        onChangeTab,
        selectedTab,
    } = props;

    const theme = useSelector(selectTheme)

    return (
        <Wrapper className="tab-wrapper">
            <Container>
                {tabItemConfig && tabItemConfig.length !== 0 &&
                    tabItemConfig.map((each) => {
                        let Icon = each.icon;
                        let isActive = selectedTab === each.id
                        return (
                            !each.disable &&
                            <TabItem
                                onClick={() => onChangeTab(each.id)}
                                className={isActive ? "active" : ""}
                                iconSize={each.size}
                            >
                                <Col className="icon">
                                    <Icon />
                                </Col>
                                <Col className="title">
                                    <XXSmallLabel
                                        color={
                                            isActive
                                                ? theme.primary600
                                                : theme.gray400
                                        }
                                    >
                                        {each.title}
                                    </XXSmallLabel>
                                </Col>
                            </TabItem>
                        )
                    })
                }
            </Container>
        </Wrapper>
    )
}

export default ModalTab;