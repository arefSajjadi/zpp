import styled from 'styled-components';
import Row from '../Row';
import Col from '../Col';
import { HexToRgba } from '../../../Utils/HexToRgba';

export const Wrapper = styled(Row)`
`
export const Container = styled(Row)`
    width: 100%;
    justify-content: space-between;
`
interface TabItemProps{
    iconSize: number
}
export const TabItem = styled(Col)<TabItemProps>`
    width: 85px;
    cursor: pointer;
    * {
        transition: all 300ms;
    }
    .icon {
        width: 40px;
        height: 40px;
        background-color: ${(props) => HexToRgba(props.theme.gray200, 0.5)}; 
        border-radius: 50%;
        border: 1px solid transparent;
        svg {
            width: ${(props) => props.iconSize + "px"};
            height:  ${(props) => props.iconSize + "px"};
            fill: ${(props) => props.theme.gray500};
        }
    }
    .title {
        text-align: center;
        margin-top: 8px;
        label {
            font-size: 12px !important;
        }
    }
    &:last-child {
        margin-left: 0;
    }
    &.active {
        .icon {
            background-color: ${(props) => props.theme.primary100};
        }
        svg {
            fill: ${(props) => props.theme.primary600};
        }
    } 
`