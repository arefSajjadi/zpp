import styled from "styled-components";
import Row from "../Row";

const backgroundColor = (theme: any, color: string) => theme[color + "300"];
const disabledBackgroundColor = (theme: any, color: string) => theme.gray100;

const getBackgroundColor = (theme: any, color: string) => {
  return backgroundColor(theme, color);
};

interface Props {
  labelContainer: "right" | "left";
}
export const MainContainer = styled(Row)<Props>`
  flex-direction: ${(props) =>
    props.labelContainer === "left" ? "row-reverse" : "row"};
  width: max-content;
  gap: 8px;
`;
interface OuterContainerProps {
  isActive: boolean;
  width: string;
  height: string;
  color: string;
}
export const OuterContainer = styled(Row)<OuterContainerProps>`
  position: relative;
  justify-content: flex-end;
  align-items: center;
  width: ${(props) => props.width};
  height: ${(props) => props.height};
  background-color: ${(props) => props.isActive ?  getBackgroundColor(props.theme, props.color) :props.theme.gray300};
  border-radius: 1.2rem;
  padding: 0 4px;
  cursor: pointer;
  @media screen and (max-width: ${(props) => props.theme.lg}) {
    scale: 0.9;
  }
  @media screen and (max-width: ${(props) => props.theme.sm}) {
    scale: 1.2;
  }
  @media screen and (max-width: ${(props) => props.theme.xs}) {
    scale: 0.9;
  }
`;
interface InnerContainerProps {
  isActive: boolean;
  height: string;
}
export const InnerContainer = styled(Row)<InnerContainerProps>`
  width: ${(props) => `calc(${props.height} - 6px)`};
  height: calc(100% - 6px);
  border-radius: 50%;
  background-color: ${(props) => props.theme.white};
  transition: all 0.3s ease;
  transform: ${(props) =>
    !props.isActive ? "translate(0 ,0)" : "translate(12px ,0)"}; //change
  /* position: absolute; */
  /* left: ${(props) => !props.isActive && "5px"};
    right: ${(props) => props.isActive && "5px"}; */
`;
