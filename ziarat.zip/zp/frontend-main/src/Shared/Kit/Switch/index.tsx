import React from 'react';
import {
    MainContainer,
    OuterContainer,
    InnerContainer,
} from './styles';
import { XXSmallParagraph } from '../Typography/Paragraph';

interface SwitchProps {
    isActive: boolean,
    width?: string,
    height?: string,
    onClick?: () => any,
    label?: string;
    labelPosition?: "left" | "right",
    color: "primary" | "positive" | "negative"
}
const Switch: React.FC<SwitchProps> = ({
    isActive,
    width = "30px",
    height = "16px",
    onClick,
    label = "",
    labelPosition = "right",
    color
}) => {
    // useEffect(() => {
    //     setToggleIsActive(isActive)
    // } ,[])

    const clickHandler = () => {
        // setToggleIsActive(perv => !perv)
        onClick && onClick()
    }

    return (
        <MainContainer labelContainer={labelPosition}>
            {label &&
                <XXSmallParagraph>
                    {label}
                </XXSmallParagraph>
            }
            <OuterContainer
                color={color}
                width={width}
                height={height}
                isActive={isActive}
                onClick={clickHandler}
                
            >
                <InnerContainer
                    isActive={isActive}
                    height={height}
                />
            </OuterContainer>
        </MainContainer>
    );
}

export default Switch;