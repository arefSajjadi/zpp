import React from "react";
import { useSelector } from "react-redux";
import {
    TabWrapper,
    TabContainer,
    TabItem
} from "./styles";
import { selectTheme } from "../../../Redux/App/Selectors";
import { XXSmallParagraph } from "../Typography/Paragraph";

interface Props {
    TabItemConfig: tabItemProps[]
    selectedTab: number
    onChangeTab: any
    colorType?: "primary" | "secondary" | "negative" | "warning" | "positive" | "gray" | "info",
}

export type tabItemProps = {
    id: number,
    title: string,
}

const Tab2: React.FC<Props> = (props) => {
    const theme = useSelector(selectTheme);

    const {
        TabItemConfig,
        onChangeTab,
        selectedTab, //آیدی
        colorType = "secondary",
    } = props;

    return (
        <TabWrapper
            className="tab2-wrapper hide-scroll-bar"
        >
            <TabContainer className="tab2-container">
                {TabItemConfig.map((each) => {
                    let active = each.id === selectedTab
                    return (
                        <TabItem
                            key={each.id}
                            className={active ? "active" : ""}
                            onClick={() => onChangeTab(each.id)}
                            colorType={colorType}
                        >
                            <XXSmallParagraph
                                color={active ? theme.white : theme.gray600}
                            >
                                {each.title}
                            </XXSmallParagraph>
                        </TabItem>
                    )
                })}
            </TabContainer>
        </TabWrapper>
    );
};

export default Tab2;