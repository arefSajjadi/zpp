import styled from "styled-components";
import Row from "../Row";
import Col from "../Col";

const activeBorderColor = (theme: any, color: string) => theme[color + "600"];
const activeBgColor = (theme: any, color: string) => theme[color + "600"];

export const TabWrapper = styled(Row)`
    overflow-x: auto;
`
export const TabContainer = styled(Row)`
    width: max-content;
    min-width: max-content;
    gap: 0 6px;
`
interface TabItemProps {
    colorType: "primary" | "secondary" | "negative" | "warning" | "positive" | "gray" | "info",
}
export const TabItem = styled(Col) <TabItemProps>`
    width: auto;
    padding: 0px 10px;
    border-radius: 14px;
    border: 1px solid ${(props) => props.theme.gray200};
    cursor: pointer;
    transition: all 300ms;
    label {
        transition: all 300ms;
        cursor: pointer;
    }
    &.active {
        border: 1px solid ${(props) => activeBorderColor(props.theme, props.colorType)};
        background: ${(props) => activeBgColor(props.theme, props.colorType)};
        &:hover {
            background: ${(props) => activeBgColor(props.theme, props.colorType)};
        }
    }
    &:hover {
        background: ${(props) => props.theme.gray100};
    }
`