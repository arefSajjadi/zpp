import React from 'react';
import { useSelector } from 'react-redux';
import { selectLang } from '../../../Redux/App/Selectors';
import {
    Wrapper,
    Container,
    MenuItem,
    LinkItem,
} from "./styles";
import Col from '../Col';
import { XXSmallLabel } from '../Typography/Label';
import { XXSmallMonoParagraph } from '../Typography/MonoParagraph';
import separator from '../../../Utils/Separator';

export type tabItemProps = {
    id: number,
    title: {
        fa: string,
        en: string
    },
    disabled: boolean,
    count?: number,
    src?: string
}

interface Props {
    TabItemConfig: tabItemProps[],
    onChangeTab: any,
    selectedTab: string, //عنوان لاتین
    tabItemWidth?: string,
    colorType?: "primary" | "secondary" | "negative" | "warning" | "positive" | "gray" | "info",
    showCount?: boolean,
    withLink?: boolean,
}

const Tab: React.FC<Props> = (props) => {
    const {
        TabItemConfig,
        onChangeTab,
        selectedTab,
        tabItemWidth = "150px",
        colorType = "gray",
        showCount = false,
        withLink = false
    } = props;

    const lang = useSelector(selectLang)
    return (
        <Wrapper
            className="tab-wrapper hide-scroll-bar"
        >
            <Container>
                {
                !withLink ?
                TabItemConfig.map((each, index) => {
                    let active = selectedTab === each.title["en"]
                    return (
                        !each.disabled &&
                        <MenuItem
                            key={each.id}
                            onClick={() => onChangeTab(each)}
                            className={active ? "active" : ""}
                            width={tabItemWidth}
                            colorType={colorType}
                        >
                            <XXSmallLabel>
                                {each.title[lang]}
                            </XXSmallLabel>
                            {showCount &&
                                <Col className="count">
                                    <XXSmallMonoParagraph>
                                        {separator(each.count || 0)}
                                    </XXSmallMonoParagraph>
                                </Col>
                            }
                        </MenuItem>
                    )
                })
                :
                TabItemConfig.map((each, index) => {
                    let active = selectedTab === each.title["en"]
                    return (
                        !each.disabled &&
                        <LinkItem
                            href={each.src || ""}
                            key={each.id}
                            onClick={() => onChangeTab(each)}
                            className={active ? "active" : ""}
                            width={tabItemWidth}
                            colorType={colorType}
                            prefetch={true}
                        >
                            <XXSmallLabel>
                                {each.title[lang]}
                            </XXSmallLabel>
                            {showCount &&
                                <Col className="count">
                                    <XXSmallMonoParagraph>
                                        {separator(each.count || 0)}
                                    </XXSmallMonoParagraph>
                                </Col>
                            }
                        </LinkItem>
                    )
                })
            }
            </Container>
        </Wrapper>
    )
}

export default Tab;