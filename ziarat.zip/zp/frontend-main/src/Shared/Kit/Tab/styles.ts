import styled from "styled-components";
import Row from "../Row";
import Link from "next/link";

const titleColor = (theme: any, color: string) => theme.gray400;
const countBgColor = (theme: any, color: string) => theme.gray100;
const countColor = (theme: any, color: string) => theme.gray400;

const hoverTitleColor = (theme: any, color: string) => theme[color + "500"];
const hoverCountBgColor = (theme: any, color: string) => theme[color + "500"];
const hoverCountColor = (theme: any, color: string) => theme.white;

const activeTitleColor = (theme: any, color: string) => theme[color + "600"];
const activeCountBgColor = (theme: any, color: string) => theme[color + "600"];
const activeCountColor = (theme: any, color: string) => theme.white;
const activeBorderColor = (theme: any, color: string) => theme[color + "600"];

export const Wrapper = styled(Row)`
  overflow-x: auto;
`;

export const Container = styled(Row)`
  width: max-content;
  min-width: max-content;
  gap: 25px;
  /* margin: auto; */
  @media screen and (max-width: 768px) {
    gap: 15px;
  }
`;

interface MenuItemProps {
  width: string;
  colorType: string;
}
export const MenuItem = styled(Row)<MenuItemProps>`
  width: ${(props) => props.width};
  height: 40px;
  border-bottom: 2px solid transparent;
  padding: 0 3px;
  cursor: pointer;
  label {
    color: ${(props) => titleColor(props.theme, props.colorType)};
    cursor: pointer;
  }
  .count {
    width: auto;
    min-width: 25px;
    padding: 0 7px;
    height: 24px;
    margin-right: 6px;
    background-color: ${(props) => countBgColor(props.theme, props.colorType)};
    border-radius: 4px;
    p {
      color: ${(props) => countColor(props.theme, props.colorType)};
    }
  }
  &:hover {
    label {
      color: ${(props) => hoverTitleColor(props.theme, props.colorType)};
    }
    .count {
      background-color: ${(props) =>
        hoverCountBgColor(props.theme, props.colorType)};
      p {
        color: ${(props) => hoverCountColor(props.theme, props.colorType)};
      }
    }
  }
  &.active {
    border-bottom: 2px solid
      ${(props) => activeTitleColor(props.theme, props.colorType)};
    label {
      color: ${(props) => activeBorderColor(props.theme, props.colorType)};
    }
    .count {
      background-color: ${(props) =>
        activeCountBgColor(props.theme, props.colorType)};
      p {
        color: ${(props) => activeCountColor(props.theme, props.colorType)};
      }
    }
    &:hover {
      label {
        color: ${(props) => activeBorderColor(props.theme, props.colorType)};
      }
      .count {
        background-color: ${(props) =>
          activeCountBgColor(props.theme, props.colorType)};
        p {
          color: ${(props) => activeCountColor(props.theme, props.colorType)};
        }
      }
    }
  }
  transition: all 300ms;
  * {
    transition: all 300ms;
  }
`;

export const LinkItem = styled(Link)<MenuItemProps>`
  display: flex;
  direction: rtl;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  box-sizing: border-box;
  line-height: 1.6;
  flex-wrap: wrap;
  -webkit-flex-wrap: wrap;
  flex-wrap: wrap;
  width: ${(props) => props.width};
  height: 40px;
  border-bottom: 2px solid transparent;
  padding: 0 3px;
  cursor: pointer;
  label {
    color: ${(props) => titleColor(props.theme, props.colorType)};
    cursor: pointer;
  }
  .count {
    width: auto;
    min-width: 25px;
    padding: 0 7px;
    height: 24px;
    margin-right: 6px;
    background-color: ${(props) => countBgColor(props.theme, props.colorType)};
    border-radius: 4px;
    p {
      color: ${(props) => countColor(props.theme, props.colorType)};
    }
  }
  &:hover {
    label {
      color: ${(props) => hoverTitleColor(props.theme, props.colorType)};
    }
    .count {
      background-color: ${(props) =>
        hoverCountBgColor(props.theme, props.colorType)};
      p {
        color: ${(props) => hoverCountColor(props.theme, props.colorType)};
      }
    }
  }
  &.active {
    border-bottom: 2px solid
      ${(props) => activeTitleColor(props.theme, props.colorType)};
    label {
      color: ${(props) => activeBorderColor(props.theme, props.colorType)};
    }
    .count {
      background-color: ${(props) =>
        activeCountBgColor(props.theme, props.colorType)};
      p {
        color: ${(props) => activeCountColor(props.theme, props.colorType)};
      }
    }
    &:hover {
      label {
        color: ${(props) => activeBorderColor(props.theme, props.colorType)};
      }
      .count {
        background-color: ${(props) =>
          activeCountBgColor(props.theme, props.colorType)};
        p {
          color: ${(props) => activeCountColor(props.theme, props.colorType)};
        }
      }
    }
  }
  transition: all 300ms;
  * {
    transition: all 300ms;
  }
`;
