import { PrimaryLinkStyle } from "./styles";
import { LinkContent } from "../LinkContent";
import { LinkProps } from "../LinkContent";

//ورودی ها:
// className?: string,
// size:  "xl" |"lg" | "md" | "sm" | "xs",
// width: string,
// color: string,
// isCurve?: boolean,
// icon?: any,
// iconPosition?: "right" | "left",
// title?: string,
// to: string,
// target?: string

export const PrimaryLink: React.FC<LinkProps> = (props) => {
  const {
    className = "",
    size,
    width,
    color,
    isCurve = false,
    iconPosition,
    title = "",
    to,
    target = "_self",
  } = props;

  return (
    <PrimaryLinkStyle
      className={className}
      width={width}
      size={size}
      color={color}
      isCurve={isCurve}
      iconPosition={iconPosition}
      hasTilte={title ? true : false}
      href={to}
      target={target}
    >
      {LinkContent(props)}
    </PrimaryLinkStyle>
  );
};
