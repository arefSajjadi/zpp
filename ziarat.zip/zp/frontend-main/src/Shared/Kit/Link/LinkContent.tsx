import { LinkLabel } from "./CommonStyles";

export type LinkProps = {
  className?: string;
  width: string;
  size: "xl" | "lg" | "md" | "sm" | "xs";
  color: string;
  isCurve?: boolean;
  icon?: any;
  iconPosition?: "right" | "left";
  title?: string;
  to: string;
  target?: any;
};

export const LinkContent: React.FC<LinkProps> = (props) => {
  const { size, icon, iconPosition = "left", title } = props;

  const Icon = icon || null;

  return (
    <>
      {icon && title ? (
        iconPosition === "left" ? (
          <>
            <LinkLabel className="label" size={size}>
              {title}
            </LinkLabel>
            <Icon />
          </>
        ) : (
          <>
            <Icon />
            <LinkLabel className="label" size={size}>
              {title}
            </LinkLabel>
          </>
        )
      ) : icon ? (
        <Icon />
      ) : (
        <LinkLabel className="label" size={size}>
          {title}
        </LinkLabel>
      )}
    </>
  );
};
