import {
    GhostLinkStyle,
} from "./styles";
import { LinkContent } from "../LinkContent";
import { LinkProps } from "../LinkContent";

//ورودی ها: 
// className?: string,
// size: "lg" | "md" | "sm" | "xs", 
// width: string,
// color: string,
// isCurve?: boolean,
// icon?: any,
// iconPosition?: "right" | "left",
// title?: string,
// to: string,
// target?: string 

export const GhostLink: React.FC<LinkProps> = (props) => {
    const {
        className = "",
        size,
        width,
        color,
        isCurve = false,
        iconPosition,
        title = "",
        to,
        target = "_self"
    } = props;

    return (
        <GhostLinkStyle
            className={className}
            width={width}
            size={size}
            color={color}
            isCurve={isCurve}
            iconPosition={iconPosition}
            hasTilte={title ? true : false}
            href={to}
            target={target}
        >
            {LinkContent(props)}
        </GhostLinkStyle>
    )
}