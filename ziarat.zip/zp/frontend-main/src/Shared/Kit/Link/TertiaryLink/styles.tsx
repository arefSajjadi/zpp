import styled from "styled-components";
import Link from "next/link";
import { LinkCommonStyles } from "../CommonStyles";

const backgroundColor = (theme: any, color: string) => theme[color + "900"];
const hoverBackgroundColor = (theme: any, color: string) =>
  theme[color + "800"];
const focusBackgroundColor = (theme: any, color: string) =>
  theme[color + "700"];

const _color = (theme: any, color: string) => theme.white;
const hoverColor = (theme: any, color: string) => theme.white;
const focusColor = (theme: any, color: string) => theme.white;

// const border = () => "none";
// const hoverBorder = () => "none";
// const focusBorder = () => "none";

const getBackgroundColor = (theme: any, color: string) => {
  return backgroundColor(theme, color);
};

const getHoverBackgroundColor = (theme: any, color: string) => {
  return hoverBackgroundColor(theme, color);
};

const getFocusBackgroundColor = (theme: any, color: string) => {
  return focusBackgroundColor(theme, color);
};

const getColor = (theme: any, color: string) => {
  return _color(theme, color);
};

const getHoverColor = (theme: any, color: string) => {
  return hoverColor(theme, color);
};

const getFocusColor = (theme: any, color: string) => {
  return focusColor(theme, color);
};

interface LinkStyleProps {
  width: string;
  size: "xl" | "lg" | "md" | "sm" | "xs";
  color: string;
  isCurve: boolean;
  iconPosition?: "right" | "left";
  hasTilte: boolean;
}

export const TertiaryLinkStyle = styled(Link)<LinkStyleProps>`
  ${(props) =>
    LinkCommonStyles(
      props.width,
      props.size,
      props.isCurve,
      props.hasTilte,
      props.iconPosition
    )};
  background-color: ${(props) => getBackgroundColor(props.theme, props.color)};
  border: none;
  .label {
    color: ${(props) => getColor(props.theme, props.color)};
  }
  svg {
    fill: ${(props) => getColor(props.theme, props.color)};
  }
  &:hover {
    background-color: ${(props) =>
      getHoverBackgroundColor(props.theme, props.color)};
    .label {
      color: ${(props) => getHoverColor(props.theme, props.color)};
    }
    svg {
      fill: ${(props) => getHoverColor(props.theme, props.color)};
    }
  }
  &:active {
    background-color: ${(props) =>
      getFocusBackgroundColor(props.theme, props.color)};
    .label {
      color: ${(props) => getFocusColor(props.theme, props.color)};
    }
    svg {
      fill: ${(props) => getFocusColor(props.theme, props.color)};
    }
  }
`;
