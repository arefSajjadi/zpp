import React, { useEffect, useState } from 'react';
import {
    Notification,
    CloseIconContainer,
    IconContainer,
    ContentContainer,
} from "./styles";
import Row from "../Row";
import Col from "../Col";
import Exclamation from "../Icons/Exclamation";
import Loading from "../Icons/LoadingIcon";
import Check from "../Icons/CheckIcon2";
import Cross from "../Icons/CrossIcon";
import { SmallLabel } from '../Typography/Label';
import { XSmallParagraph } from '../Typography/Paragraph';

interface Props {
    toast: {
        type: string,
        msg: string,
    },
}

const ToastItem: React.FC<Props> = (props) => {
    const {
        toast,
    } = props;

    const {
        type,
        msg,
    } = toast

    const Icon = () => {
        switch (type) {
            case "success":
                return <Check />;
            case "error":
                return <Exclamation />;
            case "warning":
                return <Exclamation />;
            case "pending":
                return <Loading />;
            default:
                break;
        }
    };

    const Title = () => {
        switch (type) {
            case "success":
                return "موفق";
            case "error":
                return "خطا";
            case "warning":
                return "هشدار";
            case "pending":
                return "";
            default:
                break;
        }
    };

    const ToastDuration = 4500; //مدت زمان نمایش پیام
    const [animation, setAnimation] = useState("show-toast") //انیمیشن toast
    const animationDuration = 700;
    const [height, setHeight] = useState("auto")

    const onClose = () => {
        setAnimation("hide-toast")
        setTimeout(() => {
            setHeight("0")
        }, animationDuration)
    }

    useEffect(() => {
        setTimeout(() => {
            onClose()
        }, ToastDuration)
    }, [])

    return (
        <Notification
            type={type}
            animation={animation}
            animationDuration={animationDuration}
            height={height}
        >
            <Row className='progress' />
            <Row className='background1'>
                <Row className='background2'>
                    <IconContainer type={type}>
                        <Col>
                            {Icon()}
                        </Col>
                    </IconContainer>
                    <ContentContainer type={type}>
                        <Row className="notification-title">
                            <SmallLabel>
                                {Title()}
                            </SmallLabel>
                        </Row>
                        <Row className="notification-message">
                            <XSmallParagraph>
                                {msg}
                            </XSmallParagraph>
                        </Row>
                    </ContentContainer>
                    <CloseIconContainer onClick={onClose}>
                        <Cross />
                    </CloseIconContainer>
                </Row>
            </Row>
        </Notification>
    )
};

export default ToastItem;