import React, { useState, useEffect } from 'react';
import ReactDOM from "react-dom/client";
import {
    ToastWrapper,
} from "./styles";
import ToastItem from "./ToastItem";

interface ToastContainerProps {
    children?: React.ReactNode;
}

export const ToastContainer: React.FC<ToastContainerProps> = (props) => {
    return (
        <ToastWrapper id='toast_wrapper'>
            {props.children}
        </ToastWrapper>
    );
};



interface ToastListProps {
    toast: {
        type: string,
        msg: string,
        id: number
    },
}

interface ListProps {
    id: number
    type: string,
    msg: string,
}

export const ToastList: React.FC<ToastListProps> = (props) => {
    const currentToast  = props.toast;

    let [list, setList] = useState<ListProps[]>([])
    let temp = [...list]

    useEffect(() => {
        temp.push({
            id: currentToast.id,
            type: currentToast.type,
            msg: currentToast.msg,
        })
        setList(temp)
    }, [currentToast.id])

    return (
        <>
            {list.map((each, index) => {
                return (
                    <ToastItem
                        key={index}
                        toast={{
                            type: each.type,
                            msg: each.msg,
                        }}
                    />
                )
            })}
        </>
    );
};

class Toast {
    success(msg: string) {
        ReactDOM.createRoot(document.getElementById("toast_wrapper")!).render(
            <ToastList
                toast={{
                    type: "success",
                    msg: msg,
                    id: Date.now()
                }}
            />
        );
    }
    error(msg: string) {
        ReactDOM.createRoot(document.getElementById("toast_wrapper")!).render(
            <ToastList
                toast={{
                    type: "error",
                    msg: msg,
                    id: Date.now()
                }}
            />,
           
        );
    }
    warning(msg: string) {
        ReactDOM.createRoot(document.getElementById("toast_wrapper")!).render(
            <ToastList
                toast={{
                    type: "warning",
                    msg: msg,
                    id: Date.now()
                }}
            />
        );
    }
    pending(msg: string) {
        ReactDOM.createRoot(document.getElementById("toast_wrapper")!).render(
            <ToastList
                toast={{
                    type: "pending",
                    msg: msg,
                    id: Date.now()
                }}
            />
        );
    }
}

export default new Toast();