import styled from "styled-components";
import Row from "../Row";
import Col from "../Col";
import { theme } from "../../../Utils/theme";

const color = (type: string) => {
    switch (type) {
        case "success":
            return `${theme.positive600}`;
        case "error":
            return `${theme.negative600}`;
        case "warning":
            return `${theme.warning600}`;
        case "pending":
            return `${theme.info600}`;
        default:
            break;
    }
};

const backgroundColor = (type: string) => {
    switch (type) {
        case "success":
            return `${theme.positive50}`;
        case "error":
            return `${theme.negative50}`;
        case "warning":
            return `${theme.warning50}`;
        case "pending":
            return `${theme.info50}`;
        default:
            break;
    }
};

const borderColor = (type: string) => {
    switch (type) {
        case "success":
            return `${theme.positive100}`;
        case "error":
            return `${theme.negative100}`;
        case "warning":
            return `${theme.warning100}`;
        case "pending":
            return `${theme.info100}`;
        default:
            break;
    }
};

export const ToastWrapper = styled(Col)`
    position: fixed;
    width: auto;
    height: auto;
    top: 20px;
    right: 0;
    align-items: flex-start;
    justify-content: flex-start;
    z-index: 100;
    p {
        overflow-wrap: anywhere;
    }
`
interface NotifProps {
    type: string,
    animation: string,
    animationDuration: number,
    height: string
}
export const Notification = styled(Row) <NotifProps>`
    width: 350px;
    height: ${(props) => props.height};
    @keyframes show-toast {
        0% {
            transform: translateX(355px);
        }
        100% {
            transform: translateX(0);
        }
    }
    @keyframes hide-toast {
        0% {
            transform: translateX(0);
        }
        100% {
            transform: translateX(355px);
        }
    }
    @keyframes toast-progress {
        0% {
            width: 0;
        }
        100% {
            width: 100%;
        }
    }
    animation: ${(props) => props.animation} ${(props) => props.animationDuration + "ms"} ease both;
    .progress {
        animation: toast-progress ${(props) => props.animationDuration + 2000 + "ms"} ease both;
        animation-delay: 800ms;
        height: 4px;
        background-color: ${(props) => color(props.type)};
        margin-bottom: -2px;
        z-index: 2;
    }
    .background1 {
        width: 100%;
        height: auto;
        background-color: white;
        margin-bottom: 20px;
    }
    .background2 {
        width: 100%;
        height: auto;
        min-height: 70px;
        background-color: ${(props) => backgroundColor(props.type)};
        border: 1px solid ${(props) => borderColor(props.type)};
        padding: 16px;
        align-items: flex-start;
    }
`
interface IconProps {
    type: string,
}
export const IconContainer = styled(Col) <IconProps>`
    width: 55px;
    > div {
        width: 36px;
        height: 36px;
        margin-left: auto;
        background-color: ${(props) => color(props.type)};
        border-radius: 50%;
        svg {
            fill: white;
        }
    }
`;
interface ContentContainerProps {
    type: string,
}
export const ContentContainer = styled(Col) <ContentContainerProps>` //متن خطا
    width: calc(100% - 65px);
    height: auto;
    text-align: justify;
    color: ${(props) => color(props.type)};
    .notification-title {
        label {
            font-family: ${(props) => props.theme.fontFaNumBold} !important;
        }
    }
    .notification-message {
        padding: 0 8px;
        margin-bottom: 5px;
        margin-top: ${(props) => props.type === "pending" ? "8px" : "5px"};
        p {
            font-family: ${theme.fontFaNumRegular} !important;
        }
    }
`;
export const CloseIconContainer = styled(Col)`
    width: auto;
    height: auto;
    margin-bottom: auto;
    cursor: pointer;
    svg {
        width: 9.1px;
        height: 9.1px;
        fill: ${theme.gray600};
    }
`;