import React from "react";
import {
    StepBarContainer,
    BaseLine,
    ProgressLine,
    StepsWrapper,
    TitleWrapper
} from "./styles";
import Col from "../Col";
import { XXSmallLabel } from "../Typography/Label";
import { useSelector } from "react-redux";
import { selectTheme } from "../../../Redux/App/Selectors";
import CheckIcon from "../Icons/CheckIcon";

interface Props {
    steps: any[],
    activeStep: number,
    color?: "primary" | "secondary" | "negative" | "positive" | "gray" | "info",
    checkIconOnCompletedStep?: boolean,
    displayTitle?: string,
    displayId?: string
}

interface StepItemProps {
    id: number,
    title: string,
}

const HorizontalStepProgressBar: React.FC<Props> = (props) => {
    const {
        steps,
        activeStep,
        color = "primary",
        checkIconOnCompletedStep = false,
        displayId = "id",
        displayTitle = "title"
    } = props;

    const count = steps.length

    const theme = useSelector(selectTheme)

    // const percent = activeStep === count || activeStep === count + 1
    //     ? 100
    //     : (100 / (count - 1)) * activeStep

    const space = Number(100 / (count - 1))
    const breakPoint1 = Number((space * (activeStep - 1)))
    const breakPoint2 = Number(breakPoint1 + (space / 2))

    return (
        <StepBarContainer>
            <BaseLine
                xl={((count - 1) / count * 24)}
            >
                <ProgressLine
                    breakPoint1={breakPoint1}
                    breakPoint2={breakPoint2}
                    isLastStep={activeStep === count || activeStep === count + 1}
                    color={color}
                />
                <StepsWrapper
                    color={color}
                    checkIconOnCompletedStep={checkIconOnCompletedStep}
                >
                    {steps.map((each, index) => {
                        let active = activeStep === each[displayId];
                        let completed = activeStep > each[displayId];
                        return (
                            <Col
                                key={index}
                                className={`
                                    step 
                                    ${active ? "active" : ""}
                                    ${completed ? "completed" : ""}
                                `}
                            >
                                <Col />
                                {completed && checkIconOnCompletedStep &&
                                    <CheckIcon />
                                }
                            </Col>
                        )
                    })}
                </StepsWrapper>
            </BaseLine>
            <TitleWrapper>
                {steps.map((each, index) => {
                    let active = activeStep === each[displayId];
                    let completed = activeStep > each[displayId];
                    return (
                        <Col
                            key={index}
                            className={`
                                title 
                                ${active ? "active" : ""}
                                ${completed ? "completed" : ""}
                            `}
                            xl={24 / count}
                        >
                            <XXSmallLabel
                                color={
                                    active || completed
                                        ? theme[`${color}600`]
                                        : theme.gray400
                                }
                            >
                                {each[displayTitle]}
                            </XXSmallLabel>
                        </Col>
                    )
                })}
            </TitleWrapper>
        </StepBarContainer>
    )
}

export default HorizontalStepProgressBar;