import styled from "styled-components";
import Row from "../Row";
import Col from "../Col";

export const StepBarContainer = styled(Col)`
    * {
        transition: all 300ms;
    }
`
export const BaseLine = styled(Row)`
    position: relative;
    height: 4px;
    background-color: ${(props) => props.theme.gray100};
`

interface ProgressLineProps {
    breakPoint1: any,
    breakPoint2: any,
    isLastStep: boolean,
    color: string
}
export const ProgressLine = styled(Row) <ProgressLineProps>`
    position: absolute;
    right: 0;
    height: 4px;
    background: ${(props) =>
        props.isLastStep
            ? props.theme[`${props.color}600`]
            // : `linear-gradient(270deg, ${props.theme[`${props.color}600`]} 0%, rgba(191,192,192,0) 75%)`
            : `linear-gradient(270deg, ${props.theme[`${props.color}600`]} ${props.breakPoint1}%, rgba(191,192,192,0) ${props.breakPoint2}%)`
    };
`
interface StepsWrapperProps {
    color: string,
    checkIconOnCompletedStep: boolean
}
export const StepsWrapper = styled(Row) <StepsWrapperProps>`
    position: absolute;
    right: 0;
    justify-content: space-between !important;
    .step {
        position: relative;
        width: 14px;
        height: 14px;
        background-color: white;
        border-radius: 50%;
        > div {
            width: 6px;
            height: 6px;
            background-color: ${(props) => props.theme.gray100};
            border-radius: 50%;
        }
        &.completed {
            width: ${(props) => props.checkIconOnCompletedStep ? "16px" : "14px"};
            height: ${(props) => props.checkIconOnCompletedStep ? "16px" : "14px"};
            background-color: ${(props) => props.checkIconOnCompletedStep && props.theme[`${props.color}600`]};
            > div {
                background-color: ${(props) => props.theme[`${props.color}600`]};
            }
            svg {
                position: absolute;
                top: auto;
                bottom: auto;
                left: auto;
                right: auto;
                fill: #fff;
                width: 10px;
                height: 10px;
            }
        }
        &.active {
            width: 18px;
            height: 18px;
            > div {
                width: 10px;
                height: 10px;
                background-color: ${(props) => props.theme[`${props.color}600`]};
            }
            border:  ${(props) => props.checkIconOnCompletedStep ? `1px solid ${props.theme[`${props.color}600`]}` : "0"};
        }
    }
`

export const TitleWrapper = styled(Row)`
    align-items: flex-start;
    margin-top: 12px;
    .title {
        text-align: center;
    }
    .active {
        font-weight: bold;
    }
    .active,
    .completed {
    }
`