import React from "react";
import {
    ActionContainer,
} from "./styles";
import { GhostButton } from "../Button/GhostButton";
import { PrimaryButton } from "../Button/PrimaryButton";
import { OutlineButton } from "../Button/OutlineButton";
import ArrowLeftIcon from "../Icons/ArrowLeftIcon";
import CrossIcon from "../Icons/CrossIcon";
import Row from "../Row";
import useIsMobile from "../../../Utils/Responsive";

interface Props {
    primaryButtonShow?: boolean,
    primaryButtonWidth?: string,
    primaryButtonButtonType?: "button" | "submit" | "reset",
    primaryButtonType?: "next" | "continue" | "finish", //next (مرحله بعد) - continue (ادامه) - finish (پایان)
    primaryButtonText?: string,
    onPrimaryButtonClick?: any,
    primaryButtonLoading?: boolean,
    primaryButtonDisabled?: boolean,
    showPrimaryBtnIcon?: boolean,

    secondaryButtonShow?: boolean,
    secondaryButtonType?: "previous" | "return", //previous (مرحله قبل) - return (بازگشت)
    secondaryButtonText?: string,
    onSecondaryButtonClick?: any,
    secondaryButtonWidth?: string,

    thirdButtonShow?: boolean,
    thirdButtonText?: string,
    onThirdButtonClick?: any,
    thirdButtonWidth?: string
}

const FormActions: React.FC<Props> = (props) => {
    const responsive = useIsMobile()

    const {
        primaryButtonShow = true,
        primaryButtonWidth = "140px",
        primaryButtonButtonType = "submit",
        primaryButtonType = "next",
        primaryButtonText,
        onPrimaryButtonClick,
        primaryButtonLoading = false,
        primaryButtonDisabled = false,
        showPrimaryBtnIcon = true,

        secondaryButtonShow = false,
        secondaryButtonType = "previous",
        secondaryButtonText,
        onSecondaryButtonClick,
        secondaryButtonWidth = "100px",

        thirdButtonShow = false,
        thirdButtonText = responsive !== "mobile" ? "انصراف از درخواست" : "انصراف",
        onThirdButtonClick,
        thirdButtonWidth = "200px"
    } = props;

    return (
        <ActionContainer
            hasThirdBtn={thirdButtonShow}
            className="form-actions-container"
        >
            {thirdButtonShow &&
                <OutlineButton
                    className={"third-button"}
                    width={thirdButtonWidth}
                    size={"sm"}
                    color={"negative"}
                    isCurve={false}
                    icon={CrossIcon}
                    iconPosition="right"
                    title={thirdButtonText}
                    loading={false}
                    disabled={false}
                    type="button"
                    onClick={onThirdButtonClick}
                />
            }
            <Row className="actionBtnsContainer">
                {secondaryButtonShow &&
                    <GhostButton
                        className={"secondary-button"}
                        width={secondaryButtonWidth}
                        size={"sm"}
                        color={"gray"}
                        isCurve={false}
                        title={
                            !secondaryButtonText
                                ? secondaryButtonType === "previous"
                                    ? "مرحله قبل"
                                    : secondaryButtonType === "return"
                                        ? "بازگشت"
                                        : ""
                                : secondaryButtonText
                        }
                        loading={false}
                        disabled={false}
                        type="button"
                        onClick={onSecondaryButtonClick}
                    />
                }
                {primaryButtonShow &&
                    (primaryButtonButtonType === "button"
                        ? <PrimaryButton
                            className={"primary-button"}
                            width={primaryButtonWidth}
                            size="sm"
                            color={"primary"}
                            isCurve={false}
                            icon={(showPrimaryBtnIcon && primaryButtonType !== "finish") && ArrowLeftIcon}
                            iconPosition={"left"}
                            title={
                                !primaryButtonText
                                    ? primaryButtonType === "next"
                                        ? "مرحله بعد"
                                        : primaryButtonType === "continue"
                                            ? "ادامه"
                                            : primaryButtonType === "finish"
                                                ? "پایان"
                                                : ""
                                    : primaryButtonText
                            }
                            loading={primaryButtonLoading}
                            disabled={primaryButtonDisabled}
                            type={primaryButtonButtonType}
                            onClick={onPrimaryButtonClick}
                        />
                        : <PrimaryButton
                            className={"primary-button"}
                            width={primaryButtonWidth}
                            size={"sm"}
                            color={"primary"}
                            isCurve={false}
                            icon={showPrimaryBtnIcon && ArrowLeftIcon}
                            iconPosition={"left"}
                            title={
                                !primaryButtonText
                                    ? primaryButtonType === "next"
                                        ? "مرحله بعد"
                                        : primaryButtonType === "continue"
                                            ? "ادامه"
                                            : primaryButtonType === "finish"
                                                ? "پایان"
                                                : ""
                                    : primaryButtonText
                            }
                            loading={primaryButtonLoading}
                            disabled={primaryButtonDisabled}
                            type={primaryButtonButtonType}
                        />
                    )
                }
            </Row>
        </ActionContainer>
    )
}

export default FormActions;