import styled from "styled-components";
import Row from "../Row";

interface ActionContainerProps {
    hasThirdBtn?: boolean
}

export const ActionContainer = styled(Row) <ActionContainerProps> `
    margin-right: ${props => props.hasThirdBtn ? "none" : "auto"};
    width: ${props => props.hasThirdBtn ? "100%" : "auto"};
    justify-content: space-between;
    flex-wrap: nowrap;
    .actionBtnsContainer {
        flex-wrap: nowrap;
        margin-right: auto !important;
        justify-content: flex-end;
    }
    .secondary-button {
        margin-left: 8px;
    }
    .third-button {
        svg {
            width: 10px;
            height: 10px;
        }
    }
`