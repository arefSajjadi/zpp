import React from "react";

interface DeleteIconProps {
  onClick?: func;
  className?: string;
}

type func = (...args: any) => any;

const DeleteIcon: React.FC<DeleteIconProps> = ({ className, onClick }) => {
  return (
    <svg
      width="20"
      height="21"
      viewBox="0 0 20 21"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      onClick={onClick}
      className={className}
    >
      <path
        d="M15.7395 8.46094C15.7395 15.1435 16.7014 18.1641 10.2316 18.1641C3.76092 18.1641 4.74266 15.1435 4.74266 8.46094"
        stroke="#FF0033"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M16.9704 5.90073H3.51172"
        stroke="#FF0033"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M13.0955 5.89981C13.0955 5.89981 13.536 2.76172 10.2408 2.76172C6.94632 2.76172 7.3868 5.89981 7.3868 5.89981"
        stroke="#FF0033"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default DeleteIcon;
