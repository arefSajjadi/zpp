import React from "react";

const SortIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
    <path d="M12 10H2L6.495 5.22229C6.62895 5.07996 6.8106 5 7 5C7.1894 5 7.37105 5.07996 7.505 5.22229L12 10Z" />
  </svg>
);

export default SortIcon;
