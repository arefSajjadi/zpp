const Exclamation = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={2.026}
    height={14.18}
  >
    <path
      d="M9.726 13.291H7.7V3.163h2.026zm0 2.026H7.7v2.026h2.026z"
      transform="translate(-7.7 -3.163)"
    />
  </svg>
)

export default Exclamation;