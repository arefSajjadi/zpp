const AddIcon = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="14" viewBox="0 0 15 14" fill="none">
      <path d="M6.66667 6.16667V2H8.33333V6.16667H12.5V7.83333H8.33333V12H6.66667V7.83333H2.5V6.16667H6.66667Z"/>
    </svg> 
  );
};

export default AddIcon;
