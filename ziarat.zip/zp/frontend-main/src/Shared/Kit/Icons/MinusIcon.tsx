import { useSelector } from 'react-redux';
import { selectTheme } from '../../../Redux/App/Selectors';

const MinusIcon = () => { 
  const theme = useSelector(selectTheme);

  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M8 0C3.58867 0 0 3.58867 0 8C0 12.4113 3.58867 16 8 16C12.4113 16 16 12.4113 16 8C16 3.58867 12.4113 0 8 0ZM11.3333 8.66667H4.66667V7.33333H11.3333V8.66667Z" fill={theme.negative600} />
    </svg>
  );
};

export default MinusIcon;
