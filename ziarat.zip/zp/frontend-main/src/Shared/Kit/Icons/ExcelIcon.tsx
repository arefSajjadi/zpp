const ExcelIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={13}
      height={15.6}
      viewBox="0 0 13 15.6"
    >
      <path
        d="M10.066 0H3.95A1.956 1.956 0 0 0 2 1.95V15.6h13V4.933zm.383 2.216 2.334 2.334H10.45zM13.7 14.3H3.3V1.95a.652.652 0 0 1 .65-.65h5.2v4.55h4.55zM8.5 8.833 9.54 7.15h1.527l-1.8 2.925 1.8 2.925H9.54L8.5 11.316 7.46 13H5.932l1.8-2.925-1.8-2.925H7.46z"
        transform="translate(-2)"
      />
    </svg>
  );
};

export default ExcelIcon;
