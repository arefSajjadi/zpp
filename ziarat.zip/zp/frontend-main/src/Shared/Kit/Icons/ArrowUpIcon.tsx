const ArrowUpIcon = () => {
  return (
    <svg
      width="12"
      height="6"
      viewBox="0 0 12 6"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      style={{ transform: "rotate(180deg)" }}
    >
      <path
        d="M10.6673 0.664062C10.6673 0.664062 7.90465 5.33073 6.00065 5.33073C4.09732 5.33073 1.33398 0.664062 1.33398 0.664062"
        stroke="#292D32"
        stroke-linecap="round"
        stroke-linejoin="round"
        fill="transparent"
      />
    </svg>
  );
};
export default ArrowUpIcon;
