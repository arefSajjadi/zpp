const CrossIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="13.114"
    height="13.114"
    viewBox="0 0 13.114 13.114"
  >
    <g data-name="Group 4586">
      <g data-name="sort-amount-down-alt (1)">
        <path
          data-name="Path 979"
          d="M24.594 1H11.751C10.783 1 10 1.493 10 2.1s.783 1.1 1.751 1.1h12.843c.968 0 1.751-.493 1.751-1.1S25.562 1 24.594 1z"
          transform="rotate(-45 17.745 18.35)"
        />
        <path
          data-name="Path 980"
          d="M23.894 7H12.452C11.1 7 10 7.493 10 8.1s1.1 1.1 2.452 1.1h11.442c1.355 0 2.452-.493 2.452-1.1S25.249 7 23.894 7z"
          transform="rotate(45 14.228 -6.694)"
        />
      </g>
    </g>
  </svg>
);

export default CrossIcon;
