import * as React from "react";

const NextPageIcon = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M4.90431 8.41557L9.28756 12.7988L10.3184 11.7658L6.45452 7.89908L10.3184 4.03231L9.28464 2.99932L4.90138 7.38258C4.76481 7.51997 4.6884 7.70597 4.68895 7.89968C4.6895 8.0934 4.76696 8.27896 4.90431 8.41557Z"
      fill="#434240"
    />
  </svg>
);

export default NextPageIcon;
