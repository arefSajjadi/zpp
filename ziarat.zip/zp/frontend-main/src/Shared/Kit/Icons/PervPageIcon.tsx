import * as React from "react";

const PervPageIcon = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M10.1036 8.41551L5.72026 12.7988L4.68945 11.7658L8.55335 7.899L4.68945 4.03218L5.72319 2.99918L10.1065 7.3825C10.2431 7.51989 10.3195 7.70589 10.3189 7.89961C10.3184 8.09333 10.2409 8.27889 10.1036 8.41551Z"
      fill="#434240"
    />
  </svg>
);

export default PervPageIcon;
