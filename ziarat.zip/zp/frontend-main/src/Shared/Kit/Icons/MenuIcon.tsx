const MenuIcon = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="10" viewBox="0 0 14 10" fill="none">
      <path d="M14.0002 4.0835H0V5.25018H14.0002V4.0835Z" />
      <path d="M14.0002 0H0V1.16668H14.0002V0Z" />
      <path d="M14.0002 8.1665H0V9.33319H14.0002V8.1665Z" />
    </svg>
  );
};

export default MenuIcon;