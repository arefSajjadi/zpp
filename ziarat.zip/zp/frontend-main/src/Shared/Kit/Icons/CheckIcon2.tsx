const CheckIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={14.633}
    height={10}
    viewBox="0 0 15 10"
  >
    <g data-name="01 align center">
      <path
        data-name="Path 231"
        d="M4.823 14.246a1.836 1.836 0 0 1-1.3-.539L.086 10.274.954 9.4l3.435 3.435a.614.614 0 0 0 .868 0l8.593-8.593.868.868-8.592 8.598a1.836 1.836 0 0 1-1.3.539z"
        transform="translate(-.086 -4.246)"
      />
    </g>
  </svg>
)

export default CheckIcon;