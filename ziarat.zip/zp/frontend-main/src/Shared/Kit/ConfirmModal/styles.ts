import styled from "styled-components";
import Row from "../Row";

export const ModalContainer = styled(Row)`
    @media(max-width: ${props => props.theme.sm}){
        .bict__modal__wrapper {
            bottom: auto !important;
        }
        .bict__modal__container {
            width: 500px !important;
            height: 200px !important;
        }
        .bict__modal__container {
            border-radius: 4px !important;
        }
    }
    @media(max-width: ${props => props.theme.xs}){
        .bict__modal__wrapper {
            bottom: 0 !important;
        }
        .bict__modal__container {
            width: 100vw !important;
            height: 230px !important;
        }
        .bict__modal__container {
            border-radius: 0 !important;
        }
    }
`

export const Container = styled(Row)`
    height: 100%;
    align-items: flex-start;
`

export const Body = styled(Row)`
    .icon {
        width: 42px;
        height: 42px;
        margin-left: 10px;
        background-color: ${(props) => props.theme.warning50};
        border-radius: 8px;
        svg {
            width: 22px;
            height: 20px;
            fill: ${(props) => props.theme.warning600};
        }
    }
    .text {
        width: calc(100% - 52px);
        p {
            text-align: justify;
        }
    }
`

export const ActionsContainer = styled(Row)`
    margin-top: auto;
    justify-content: flex-end;
    button:first-child {
        margin-left: 10px;
    }
    @media(max-width: ${props => props.theme.xs}){
        button {
            width: 45%;
        }
        button:first-child {
            margin-left: auto;
        }
    }
`