import React, { useState } from "react";
import { useSelector } from "react-redux";
import { selectTheme } from "../../../Redux/App/Selectors";
import { Wrapper, Title, Description } from "./styles";
import Row from "../Row";
import Col from "../Col";
import ArrowDownIcon from "../Icons/ArrowDownIcon";
import InfoIcon from "../Icons/InfoIcon";
import { XSmallParagraph } from "../Typography/Paragraph";

interface Props {
  name: string
  item: {
    id: number
    title: string
    descriptionList: string[]
  },
  maxHeight?: string
  color: "primary" | "secondary" | "negative" | "positive" | "gray" | "info",
}

const InfoToggleTab: React.FC<Props> = (props) => {
  const {
    name,
    item,
    maxHeight,
    color
  } = props;

  const {
    id,
    title,
    descriptionList
  } = item;

  const theme = useSelector(selectTheme);

  const _id = `toggle-tab-description-${name}-${id}`;

  const [expand, setExpand] = useState<boolean | null>(false);

  const toggle = () => {
    let descriptionElement = document.getElementById(_id);
    if (descriptionElement && descriptionElement.style) {
      if (!expand) {
        descriptionElement.style.maxHeight = maxHeight || "300px";
      } else {
        descriptionElement.style.maxHeight = "0";
      }
    }
    setExpand(!expand);
  };

  return (
    <Wrapper
      className="toggle-tab-wrapper"
    >
      <Title
        onClick={toggle}
        expand={expand}
        color={color}
      >
        <Row className="title">
          <InfoIcon />
          <XSmallParagraph color={theme[`${color}600`]}>
            {title}
          </XSmallParagraph>
        </Row>
        <Col className="icon">
          <ArrowDownIcon />
        </Col>
      </Title>
      <Description
        id={_id}
        className={`hide-scroll-bar`}
        expand={expand}
        color={color}
      >
        <Row>
          {descriptionList.map((each, index) => {
            return (
              <XSmallParagraph
                key={index}
                color={theme[`${color}600`]}
              >
                {each}
              </XSmallParagraph>
            )
          })}
        </Row>
      </Description>
    </Wrapper>
  );
};

export default InfoToggleTab;