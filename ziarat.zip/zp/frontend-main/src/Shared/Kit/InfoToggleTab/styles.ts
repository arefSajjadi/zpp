import styled from "styled-components";
import Row from "../Row";
import Col from "../Col";

export const Wrapper = styled(Col)`
    margin-bottom: 40px;
`

interface TitleProps {
    expand: boolean | null
    color: string
}
export const Title = styled(Row) <TitleProps>`
    align-items: flex-start;
    background-color: ${(props) => props.theme[props.color + 50]};
    padding: 8px 12px;
    border-radius: 4px;
    cursor: pointer;
    * {
        transition: all 300ms;
    }
    .title {
        width: calc(100% - 35px);
        svg {
            width: 14px;
            height: 14px;
            fill: ${(props) => props.theme[props.color + 600]};
            margin-left: 10px;
        }
    }
    .icon {
        width: 20px;
        rotate: ${(props) => props.expand && "180deg"};
        padding: 5px;
        margin-right: 15px;
        svg {
            width: 10px;
            height: 10px;
            fill: ${(props) => props.theme[props.color + 600]};
        }
    }
`

export const Description = styled(Row) <TitleProps>`
    align-items: flex-start;
    > div {
        padding: 20px 15px;
    }
    transition: all 700ms;
    //motion
    max-height: 0;
    overflow-y: auto;
`