import styled from "styled-components";
import Col from "../Col";
import { HexToRgba } from "../../../Utils/HexToRgba";

interface BackgroundProps {
  hiddenBreakPoint: string;
}

export const Background = styled(Col)<BackgroundProps>`
  position: fixed;
  top: 0;
  right: 0;
  width: 100vw;
  height: 100vh;
  align-items: flex-start;
  justify-content: flex-end;
  z-index: 500;
  background-color: ${(props) => HexToRgba(props.theme.gray800, 0.5)};
  display: none;

  @media screen and (min-width: ${(props) => props.hiddenBreakPoint}) {
    display: none !important;
  }
`;

export const Container = styled(Col)`
  position: relative;
  width: 80%;
  max-width: 625px;
  height: 100vh;
  background-color: ${(props) => props.theme.white};
  overflow: hidden;
  transform: translateX(100%);
  transition: transform 500ms !important;

  @media screen and (max-width: ${(props) => props.theme.sm}) {
    width: 90%;
    max-width: 330px;
  }
`;
