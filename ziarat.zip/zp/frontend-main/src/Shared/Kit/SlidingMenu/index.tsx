import React from "react";
import { Background, Container } from "./styles";

type func = () => void;

export const openMenu = (name?: string, callback?: func) => {
  let backgroundElement = document.getElementById(
    `sliding-menu-background-${name || ""}`
  );
  let slidingMenuElement = document.getElementById(
    `sliding-menu-${name || ""}`
  );
  let style1 = backgroundElement?.style;
  let style2 = slidingMenuElement?.style;
  if (style1 && style2) {
    style1.display = "flex";
    setTimeout(() => {
      if (style2) {
        style2.transform = "translateX(0)";
      }
    }, 100);
  }
  callback && callback();
};

export const closeMenu = (name?: string, callback?: func) => {
  let backgroundElement = document.getElementById(
    `sliding-menu-background-${name || ""}`
  );
  let slidingMenuElement = document.getElementById(
    `sliding-menu-${name || ""}`
  );
  let style1 = backgroundElement?.style;
  let style2 = slidingMenuElement?.style;
  if (style1 && style2) {
    style2.transform = "translateX(100%)";
    setTimeout(() => {
      if (style1) {
        style1.display = "none";
      }
    }, 500);
  }
  callback && callback();
};

interface Props {
  name?: string;
  children: React.ReactNode;
  hiddenBreakPoint?: string;
}

const SlidingMenu: React.FC<Props> = (props) => {
  const {
    name,
    children,
    hiddenBreakPoint = "1081px", //از جه سایزی نمایش داده نشود.
  } = props;

  return (
    <Background
      id={`sliding-menu-background-${name || ""}`}
      hiddenBreakPoint={hiddenBreakPoint}
      onClick={() => closeMenu(name)}
    >
      <Container
        id={`sliding-menu-${name || ""}`}
        onClick={(e: any) => e.stopPropagation()}
      >
        {children}
      </Container>
    </Background>
  );
};

export default SlidingMenu;
