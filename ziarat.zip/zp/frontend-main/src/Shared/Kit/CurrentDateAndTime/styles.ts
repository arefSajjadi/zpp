import styled from "styled-components";
import Row from "../Row";

export const Conatiner = styled(Row)`
    width: auto;
    margin-right: auto;
    gap: 2px;
    p {
        font-size: 12px !important;
    }
`

export const ClockIconContainer = styled(Row)`
    width: auto;
    background-color: ${props => props.theme.primary50};
    border-radius: 6px;
    padding: 4px;
    margin-right: 5px;
    svg {
        fill: ${props => props.theme.primary600};
    }
`