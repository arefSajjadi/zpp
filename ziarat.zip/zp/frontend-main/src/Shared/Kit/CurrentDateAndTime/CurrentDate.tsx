import { XXSmallMonoParagraph } from "../Typography/MonoParagraph";
import DateTimeController from "../../../Utils/DateTimeController";

const CurrentDate = () => {
    return (
        <XXSmallMonoParagraph>
            {DateTimeController.parseToJDate(new Date().toISOString(), "jYYYY/jMM/jDD")}
        </XXSmallMonoParagraph>
    );
};

export default CurrentDate;
