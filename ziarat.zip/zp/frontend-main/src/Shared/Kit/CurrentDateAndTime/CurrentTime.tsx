import { useEffect, useState } from "react";
import moment from "moment";
import { XXSmallMonoParagraph } from "../Typography/MonoParagraph";

const CurrentTime = () => {
    const [now, setNow] = useState(Date.now());

    useEffect(() => {
        let timerInterval: any = () => {
            setInterval(() => {
                setNow(Date.now());
            }, 1000);
        };
        timerInterval();
        return timerInterval && clearInterval(timerInterval);
    }, []);

    return (
        <XXSmallMonoParagraph>
            {moment(now).format('HH:mm:ss')}
        </XXSmallMonoParagraph>
    );
};

export default CurrentTime;
