import {
  Conatiner,
  ClockIconContainer
} from "./styles";
import { XSmallMonoParagraph } from "../Typography/MonoParagraph";
import ClockIcon from "../Icons/ClockIcon";
import CurrentDate from "./CurrentDate";
import CurrentTime from "./CurrentTime";

const CurrentDateAndTime = () => {
  return (
    <Conatiner>
      <CurrentTime />
      <XSmallMonoParagraph>
        -
      </XSmallMonoParagraph>
      <CurrentDate />
      <ClockIconContainer>
        <ClockIcon />
      </ClockIconContainer>
    </Conatiner>
  );
};

export default CurrentDateAndTime;
