import React from 'react';
import { MainContainer } from './styles';

interface Props {
    orientation: "horizontal" | "vertical"
    width?: string,
    height?: string,
    bgColor?: string
}
const Divider:React.FC<Props> = (props) => {
    const {
        orientation,
        width,
        height,
        bgColor
    } = props;
    return ( 
        <MainContainer
            height={height}
            width={width}
            orientation={orientation}
            bgColor={bgColor}
        />

     );
}
 
export default Divider;
