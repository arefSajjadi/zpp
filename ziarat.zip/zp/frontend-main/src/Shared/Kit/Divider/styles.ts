import styled from "styled-components";
import Row from "../Row";


interface MianContainerProps {
    orientation: "horizontal" | "vertical",
    width?: string,
    height?: string,
    bgColor?: string
}
export const MainContainer = styled(Row)<MianContainerProps>`
    flex-direction: ${props => props.orientation === "horizontal" ? "row" : "column"};
    width: ${props => props.width ? props.width : "100%"};
    height: ${props => props.height ? props.height : "100%"};
    background-color: ${props => props.bgColor ? props.bgColor : props.theme.black};
`