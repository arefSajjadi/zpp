import styled from "styled-components";
import Col from "../Col";

interface NoItemContainerProps {
    center: boolean
}
export const NoItemContainer = styled(Col) <NoItemContainerProps>`
    width: auto;
    margin: ${(props) => props.center ? "auto" : 0};
`