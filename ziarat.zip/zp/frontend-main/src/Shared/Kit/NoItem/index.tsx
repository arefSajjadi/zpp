import { useSelector } from "react-redux";
import { selectTheme } from "../../../Redux/App/Selectors";
import {
    NoItemContainer
} from "./styles";
import { XSmallLabel } from "../Typography/Label";

interface Props {
    text?: string
    center?: boolean
}

const NoItem: React.FC<Props> = (props) => {
    const theme = useSelector(selectTheme);

    const {
        text,
        center = false
    } = props

    return (
        <NoItemContainer center={center}>
            <XSmallLabel color={theme.gray400}>
                {text || "موردی وجود ندارد"}
            </XSmallLabel>
        </NoItemContainer>
    )
}

export default NoItem;