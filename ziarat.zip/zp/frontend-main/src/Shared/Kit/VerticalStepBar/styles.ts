import styled from "styled-components";
import Row from "../Row";
import Col from "../Col";

interface StepBarContainerProps {
  height: number
}
export const StepBarContainer = styled(Row)<StepBarContainerProps>`
  width: auto;
  height: ${(props) => props.height}px;
  min-height: ${(props) => props.height}px;
  * {
    transition: all 0.5s;
  }
`;

export const BaseLine = styled(Col)`
  width: 2px;
  height: 100%;
  position: relative;
  justify-content: flex-start;
  background-color: ${(props) => props.theme.gray100};
`;

interface ProgressLineProps {
  height: any;
  activeStep: number,
  stepLength: number
}
export const ProgressLine = styled(Col)<ProgressLineProps>`
  position: absolute;
  top: 0;
  left: 0;
  width: 2px;
  height: ${(props) => props.height}%;
  background: ${(props) => 
    props.activeStep >= props.stepLength
    ? props.theme.primary600
    : `linear-gradient(180deg, ${props.theme.primary600} 0%, rgba(48, 149, 96, 0.00) 100%)`
  };
`;

export const StepsWrapper = styled(Col)`
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  justify-content: space-between !important;
  .step {
    width: 30px;
    height: 30px;
    border: 1px solid transparent;
    background-color: ${(props) => props.theme.gray50};
    border-radius: 50%;
  }
  .active {
      border: solid 1px ${(props) => props.theme.primary600} !important;
      background-color: ${(props) => props.theme.primary50} !important;
  }
  .completed {
    border: solid 1px ${(props) => props.theme.primary600} !important;
    background-color: ${(props) => props.theme.primary600} !important;
    svg {
      width: 18px;
      height: 18px;
      fill: ${(props) => props.theme.white};
    }
  }
`;

export const TitleContainer = styled(Col)`
  width: auto;
  height: 100%;
  justify-content: space-between;
  margin-right: 30px;
  padding: 5px 0;
  .title {
    align-items: flex-start;
  }
`;