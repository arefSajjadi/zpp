import React from "react";
import { useSelector } from "react-redux";
import {
  StepBarContainer,
  BaseLine,
  ProgressLine,
  StepsWrapper,
  TitleContainer,
} from "./styles";
import Col from "../Col";
import { XSmallLabel } from "../Typography/Label";
import { selectTheme } from "../../../Redux/App/Selectors";

interface Props {
  steps: any[];
  activeStep: number;
  displayId?: string;
  displayTitle?: string
}

const VerticalStepBar: React.FC<Props> = (props) => {
  const {
    steps,
    activeStep,
    displayId = "id",
    displayTitle = "title"
  } = props;
  
  const theme = useSelector(selectTheme);

  return (
    <StepBarContainer
      height={
        steps.length === 1
          ? 30
          : steps.length * 50
      }
    >
      <BaseLine xl={24}>
        <ProgressLine
          activeStep={activeStep}
          stepLength={steps.length}
          height={100}
        />
        <StepsWrapper>
          {steps.map((each, index) => {
            return (
              <Col
                key={index}
                className="step active"
              >
                <XSmallLabel
                  color={theme.primary600}
                >
                  {each[displayId]}
                </XSmallLabel>
              </Col>
            );
          })}
        </StepsWrapper>
      </BaseLine>
      <TitleContainer>
        {steps.map((each, index) => {
          return (
            <Col
              key={index}
              className={"title active"}
            >
              <XSmallLabel
                color={theme.primary600}
              >
                {each[displayTitle]}
              </XSmallLabel>
            </Col>
          );
        })}
      </TitleContainer>
    </StepBarContainer>
  );
};

export default VerticalStepBar;
