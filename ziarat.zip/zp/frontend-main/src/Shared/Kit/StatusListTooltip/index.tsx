import React from "react";
import { useSelector } from "react-redux";
import { selectTheme } from "../../../Redux/App/Selectors";
import {
    StatusContainer,
} from "./styles";
import { XXSmallParagraph } from "../Typography/Paragraph";
import { PrimaryButton } from "../Button/PrimaryButton";
import Col from "../Col";

export type listItemType = {
    label: string
    completionStatus: boolean
}

interface Props {
    name: string,
    id: number,
    list: listItemType[],
    showButton?: boolean,
    buttonTitle?: string,
    onClickButton?: any,
}

export const onMouseEnter = (name: string, id: number) => {
    const _id = `${name}-status-list-tooltip-${id}`
    let element = document.getElementById(_id);
    let style = element?.style;
    if (style) {
        style.display = "flex";
        setTimeout(() => {
            if (style) {
                style.opacity = "1";
            }
        }, 50)
    }
};

export const onMouseLeave = (name: string, id: number) => {
    const _id = `${name}-status-list-tooltip-${id}`
    let element = document.getElementById(_id);
    let style = element?.style
    if (style) {
        style.opacity = "0";
        setTimeout(() => {
            if (style) {
                style.display = "none";
            }
        }, 50)
    }
};

const StatusListTooltip: React.FC<Props> = (props) => {
    const theme = useSelector(selectTheme)

    const {
        name,
        id,
        list,
        showButton = false,
        buttonTitle = "",
        onClickButton,
    } = props;

    const _id = `${name}-status-list-tooltip-${id}`

    return (
        <StatusContainer
            id={_id}
            className="status-list-tooltip status-container"
        >
            {list.map((item: listItemType ,index) => {
                return (
                    <XXSmallParagraph
                        key={index}
                        color={
                            item.completionStatus
                                ? theme.positive600
                                : theme.negative600
                        }
                    >
                        {item.label}
                    </XXSmallParagraph>
                );
            })}
            {showButton &&
                <Col
                    className="status-list-tooltip-button-container"
                >
                    <PrimaryButton
                        size="xs"
                        width="100%"
                        color="info"
                        title={buttonTitle}
                        type="button"
                        onClick={onClickButton}
                    />
                </Col>
            }
        </StatusContainer>
    )
}

export default StatusListTooltip;