import styled from "styled-components";
import Col from "../Col";

export const StatusContainer = styled(Col)`
    position: absolute;
    top: auto;
    bottom: auto;
    left: 100%;
    align-items: flex-start;
    justify-content: flex-start;
    width: 150px;
    padding: 10px;
    background-color: ${(props) => props.theme.white};
    border: 1px solid ${(props) => props.theme.gray100};
    border-radius: 5px;
    gap: 5px;
    z-index: 2;
    //motion
    display: none;
    opacity: 0;
    transition: all 300ms;
    .status-list-tooltip-button-container {
        margin-top: 5px;
        padding-top: 10px;
        border-top: 1px solid ${(props) => props.theme.gray100};
        button {
            height: 25px;
            * {
                font-size: 10px;
            }
        }
    }
`;