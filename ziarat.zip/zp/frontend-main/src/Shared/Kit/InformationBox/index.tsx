import React from 'react';
import { HeaderContainer, MainContainer ,ContentContainer } from './styles';

interface Props {
    width?: string,
    heigth?: string,
    HeaderComponent: React.FC
    ContentComponent: React.FC
}

const InformationBox:React.FC<Props> = ({
    heigth = "344px",
    width = "300px",
    HeaderComponent,
    ContentComponent
}) => {
    return ( 
        <MainContainer
            heigth={heigth}
            width={width}
        >
            <HeaderContainer>
                <HeaderComponent />
            </HeaderContainer>
            <ContentContainer>
                <ContentComponent />
            </ContentContainer>
        </MainContainer>
     );
}
 
export default InformationBox;