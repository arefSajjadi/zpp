import styled from "styled-components";
import Row from "../Row";
import Col from "../Col";


interface MainContainerProps {
    width: string;
    heigth: string
}

export const MainContainer = styled(Col) <MainContainerProps>`
    width: ${props => props.width};
    height: ${props => props.heigth};   
    justify-content: space-between ;
    padding: 1rem 0 0 0;
`

export const HeaderContainer = styled(Row)`
    width: 100%;
    padding: 0 1rem;
`

export const ContentContainer = styled(Col)`
    width: 100%;
`
