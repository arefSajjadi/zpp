import styled from "styled-components";
import Col from "../Col";

interface ContainerProps {
    color: string,
    display?: "block" | "flex" | "none"
}
export const Container = styled(Col) <ContainerProps>` 
    display: ${props => props.display};
    margin: auto;
    @keyframes ldio-0u379xqha3k {
        0% { transform: translate(-50%,-50%) rotate(0deg); }
        100% { transform: translate(-50%,-50%) rotate(360deg); }
    }
    .ldio-0u379xqha3k div {
        position: absolute;
        top: 167%;
        left: 167%;
        width: 200%;
        height: 200%;
        border: 10px solid ${(props) => props.color};
        border-top-color: transparent;
        border-radius: 50%;
        animation: ldio-0u379xqha3k 1s linear infinite;
    }
    .loadingio-spinner-rolling-1amlj6klx32 {
        width: 30px;
        height: 30px;
        display: inline-block;
        overflow: hidden;
        background: none;
    }
    .ldio-0u379xqha3k {
        width: 100%;
        height: 100%;
        position: relative;
        transform: translateZ(0) scale(0.3);
        backface-visibility: hidden;
        transform-origin: 0 0; /* see note above */
    }
    .ldio-0u379xqha3k div { box-sizing: content-box; }
`