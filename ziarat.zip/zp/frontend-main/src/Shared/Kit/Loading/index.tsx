import React from "react";
import { useSelector } from "react-redux";
import { selectTheme } from "../../../Redux/App/Selectors";
import {
    Container
} from "./styles";

interface Props {
    color?: string,
    display?: 'flex' | 'none' | 'block'
}

const Loading: React.FC<Props> = (props) => {
    const theme = useSelector(selectTheme)

    const {
        color = theme.gray500,
        display = "flex"
    } = props;

    return (
        <Container display={display} color={color}>
            <div className="loadingio-spinner-rolling-1amlj6klx32">
                <div className="ldio-0u379xqha3k">
                    <div></div>
                </div>
            </div>
        </Container>
    )
}

export default Loading;