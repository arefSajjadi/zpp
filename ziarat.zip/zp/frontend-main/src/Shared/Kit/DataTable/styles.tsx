import styled from "styled-components";
import Row from "../Row";
import Col from "../Col";

export const MainContainer = styled(Col)`
    border: 1px solid ${props => props.theme.gray50};
    border-radius: 4px;
`

export const HeaderContainer = styled(Row)`
    background-color: ${props => props.theme.gray50};
    padding: 9px 20px;
`

export const ContentContainer = styled(Row)`
    align-items: flex-start;
    @media (max-width:${props => props.theme.sm}) {
        flex-direction: column;
    }
`

export const FirstColumnContainer = styled(Col)`
    padding: 0 20px;
    border-left: 1px solid ${props => props.theme.gray100};
    @media (max-width:${props => props.theme.sm}) {
        border-left: 0;
    }
`

export const SecondColumnContainer = styled(Col)`
    padding: 0 20px;
`

export const EachRowContainer = styled(Row)`
    border-bottom: 1px solid ${props => props.theme.gray50};
    justify-content: space-between;
    align-items: flex-start;
    padding: 9px 0;
    &:last-child {
        border-bottom: 0
    }
    .value {
        justify-content: flex-end;
    }
    p,
    label {
        line-height: 28px !important;
    }
`