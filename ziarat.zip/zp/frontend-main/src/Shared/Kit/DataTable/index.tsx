import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { selectTheme } from "../../../Redux/App/Selectors";
import {
    MainContainer,
    HeaderContainer,
    ContentContainer,
    FirstColumnContainer,
    SecondColumnContainer,
    EachRowContainer,
} from "./styles";
import Row from "../Row";
import { XSmallParagraph } from "../Typography/Paragraph";
import { XSmallLabel } from "../Typography/Label";
import { XSmallMonoLabel } from "../Typography/MonoLabel";

export interface DataTableColType {
    title: any,
    value: string | number
}

interface Props {
    data: DataTableColType[],
    title1: string,
    title2?: string,
}
const DataTable: React.FC<Props> = (props) => {
    const theme = useSelector(selectTheme);

    const {
        data,
        title1,
        title2,
    } = props;

    const [firstColData, setFirstColData] = useState<DataTableColType[]>([])
    const [secondColData, setSecondColData] = useState<DataTableColType[]>([])

    useEffect(() => {
        if (data && data.length !== 0) {
            const count = data.length
            const firstData = data?.filter((item, index) => index < Math.ceil(count / 2))
            const secondData = data?.filter((item, index) => index >= Math.ceil(count / 2))
            setFirstColData(firstData)
            setSecondColData(secondData)
        }
    }, [data])

    return (
        <MainContainer>
            <HeaderContainer>
                <XSmallParagraph color={theme.gray800}>
                    {title1}
                </XSmallParagraph>
                {title2 &&
                    <XSmallLabel color={theme.gray800}>
                        :
                        &nbsp;
                        {title2}
                    </XSmallLabel>
                }
            </HeaderContainer>
            <ContentContainer>
                <FirstColumnContainer xl={12} sm={24}>
                    {firstColData?.map((item, index) => {
                        return (
                            <EachRowContainer key={index}>
                                <Row xl={14} className="label">
                                    <XSmallParagraph color={theme.gray700}>
                                        {item.title}:
                                    </XSmallParagraph>
                                </Row>
                                <Row xl={10} className="value">
                                    <XSmallMonoLabel color={theme.gray700}>
                                        {item.value}
                                    </XSmallMonoLabel>
                                </Row>
                            </EachRowContainer>
                        )
                    })}
                </FirstColumnContainer>
                <SecondColumnContainer xl={12} sm={24}>
                    {secondColData?.map((item, index) => {
                        return (
                            <EachRowContainer key={index}>
                                <Row xl={14} className="label">
                                    <XSmallParagraph color={theme.gray700}>
                                        {item.title}:
                                    </XSmallParagraph>
                                </Row>
                                <Row xl={10} className="value">
                                    <XSmallMonoLabel color={theme.gray700}>
                                        {item.value}
                                    </XSmallMonoLabel>
                                </Row>
                            </EachRowContainer>
                        )
                    })}
                </SecondColumnContainer>
            </ContentContainer>
        </MainContainer>

    );
}

export default DataTable;