import styled from "styled-components";
import Row from "../Row";

interface StatusProps {
    bgColor: string,
    color: string
}
export const Status = styled(Row) <StatusProps>`
    width: auto;
    padding: 4px 8px;
    background-color: ${(props) => props.bgColor};
    border-radius: 19px;
    .circle {
        width: 5px;
        height: 5px;
        margin-left: 4px;
        margin-bottom: -2px;
        background-color: ${(props) => props.color};
        border-radius: 50%;
    }
    label {
        font-family: ${(props) => props.theme.fontFaNumBold} !important;
        line-height: 1;
        scale: 0.9;
        /* transform-origin: right; */
    }
` 