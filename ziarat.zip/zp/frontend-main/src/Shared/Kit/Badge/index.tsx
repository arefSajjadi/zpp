import React from 'react';
import { Status } from './styles';
import { XXSmallLabel } from '../Typography/Label';
import Col from '../Col';

interface BadgeProps {
    bgColor: string,
    color: string,
    statusTitle: string,
    hasIcon?: boolean,
    IconComponent?: any
}

const Badge: React.FC<BadgeProps> = ({
    bgColor,
    color,
    statusTitle,
    hasIcon = false,
    IconComponent
}) => {

    return (
        <Status
            className='badge'
            bgColor={bgColor}
            color={color}
        >
            <Col className="circle" />
            <XXSmallLabel
                color={color}
            >
                {statusTitle}
            </XXSmallLabel>
            {hasIcon &&
                IconComponent
            }
        </Status>
    );
}

export default Badge;