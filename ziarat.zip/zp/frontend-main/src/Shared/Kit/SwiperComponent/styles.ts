import styled from "styled-components";
import Row from "../Row";

interface props {
  fullWidth?: boolean;
  isMobile?: boolean;
}
export const SwiperWrapper = styled(Row)<props>`
  max-width: 1150px;
  .swiper {
    width: 100% !important;

    /* border: .5px solid ${(props) => props.theme.gray600}; */
  }
  .swiper-wrapper {
    width: 100% !important;
    transition-timing-function: linear !important;
  }

  .swiper-slide {
    ${(props) =>
      props.fullWidth &&
      `
      width: auto !important;
    `}
  }

  @media (max-width: ${(props) => props.theme.xs}) {
    .swiper-wrapper {
      ${(props) =>
        props.fullWidth &&
        `
        gap:0;
    `}
    }
  }

  .swiperWithArrowWrapper {
    flex-wrap: nowrap;
    position: relative;
    background-color: ${(props) => props.theme.gray50};
    border-radius: ${(props) => (props.isMobile ? 0 : 20)}px;
    border: 1px solid ${(props) => props.theme.gray600};
    .pervBtn {
      height: 30px;
      background-color: ${(props) => props.theme.gray50};
      border-radius: 0px 14px 14px 0px;
      height: auto;
      :hover {
        path {
          stroke: ${(props) => props.theme.primary400};
        }
      }
    }
    .nextBtn {
      height: 30px;
      background-color: ${(props) => props.theme.gray50};
      border-radius: 14px 0 0 14px;
      /* border: 1px solid ${(props) => props.theme.gray600}; */
      height: auto;
      svg {
        rotate: 180deg;
      }
      :hover {
        path {
          stroke: ${(props) => props.theme.primary400};
        }
      }
    }
  }
`;
export const ButtonContainer = styled(Row)<props>`
  //h: 45px
  justify-content: flex-end;
  margin-top: 15px;
  .swiper-count {
    width: max-content;
    margin-left: 1rem;
    gap: 3px;
  }
  .pervBtn {
    height: 30px;
    background-color: ${(props) => props.theme.gray100};
    border-radius: 0px 14px 14px 0px;
  }
  .nextBtn {
    height: 30px;
    background-color: ${(props) => props.theme.gray100};
    border-radius: 14px 0 0 14px;

    svg {
      rotate: 180deg;
    }
  }
  @media screen and (max-width: 768px) {
    margin-left: 10px;
  }
`;
export const ButtonContainer2 = styled(Row)<props>`
  //h: 45px
  justify-content: space-between;
  margin-top: 20px;
  .swiper-count {
    width: max-content;
    gap: 3px;
  }
  .w-100 {
    width: 100px;
  }
`;
