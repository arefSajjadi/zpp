import { useEffect, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination, Navigation } from "swiper/modules";
import { useSelector } from "react-redux";
import { selectTheme } from "../../../Redux/App/Selectors";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/scrollbar";
import { SwiperWrapper, ButtonContainer, ButtonContainer2 } from "./styles";
import Row from "../Row";
import Col from "../Col";
import { XSmallMonoParagraph } from "../Typography/MonoParagraph";
import { XSmallParagraph } from "../Typography/Paragraph";
import { PrimaryButton } from "../Button/PrimaryButton";
import { OutlineButton } from "../Button/OutlineButton";
import PervArrowIcon from "../Icons/PervPageIcon";
import NextArrowIcon from "../Icons/NextPageIcon";
import ArrowIcon from "@/Assets/Icons/ArrowIcon";
import useIsMobile from "@/Utils/Responsive";

interface Props {
  list: any[];
  CardComponent: any;
  otherPropsForCardComponent?: any;
  speed?: number;
  showNavigationBtn?: boolean;
  navigationBtnType?: "icon" | "button";
  //اگر از نوع button بود
  hasPrevButton?: boolean;
  hasNextButton?: boolean;
  prevButtonTitle?: string;
  nextButtonTitle?: string;
  prevButtonIcon?: string;
  nextButtonIcon?: string;
  nextButtonDisable?: boolean;
  nextButtonLoading?: boolean;
  onPrevButtonClick?: any;
  onNextButtonClick?: any;
  //
  setSelectedIndex?: any;
  fullWidth?: boolean;
  loop?: boolean;
  autoplay?: boolean;
  showPagination?: boolean;
  isForDates?: boolean;
  haveBreakpoint?: boolean;
  initialSlice?: number;
  cancelHandler?: () => void;
  set$SwiperRef?: (value: any) => void;
  $SelectedItem?: string;
}

const SwiperComponent: React.FC<Props> = (props) => {
  const theme = useSelector(selectTheme);

  const {
    list,
    CardComponent,
    otherPropsForCardComponent,
    speed = 3000,
    showNavigationBtn = false,
    navigationBtnType = "icon",
    //اگر از نوع button بود
    hasPrevButton = true,
    hasNextButton = true,
    prevButtonTitle = "قبلی",
    nextButtonTitle = "بعدی",
    nextButtonIcon = ArrowIcon,
    prevButtonIcon = ArrowIcon,
    nextButtonDisable,
    nextButtonLoading = false,
    onPrevButtonClick,
    onNextButtonClick,
    //
    setSelectedIndex,
    fullWidth = false,
    loop = true,
    autoplay = true,
    showPagination = true,
    isForDates = false,
    haveBreakpoint = true,
    initialSlice,
    cancelHandler,
    set$SwiperRef,
    $SelectedItem,
  } = props;
  const responsive = useIsMobile();

  const [swiperRef, setSwiperRef] = useState<any>(null);
  const [selectedItem, setSelectedItem] = useState<any>(1);

  useEffect(() => {
    if ($SelectedItem) {
      set$SwiperRef?.(swiperRef);
      setSelectedItem($SelectedItem);
    }
  }, [$SelectedItem, set$SwiperRef, swiperRef]);

  const prevHandler = () => {
    if (selectedItem !== 1) {
      swiperRef.slidePrev();
      onPrevButtonClick && onPrevButtonClick();
    }
  };

  const nextHandler = () => {
    const swiper = document.getElementById("swiper-container");
    const swiper_width = swiper?.clientWidth || 0;

    // Use the actual card width from your styles
    const card_width = window.innerWidth <= parseInt(theme.xs) ? 80 : 155;

    if (swiper_width && card_width) {
      const visibleSlides = Math.floor(swiper_width / card_width);
      const maxIndex = list.length - visibleSlides;

      if (nextButtonDisable === undefined) {
        if (selectedItem <= maxIndex) {
          swiperRef.slideNext();
          onNextButtonClick && onNextButtonClick();
        }
      } else if (nextButtonDisable === false) {
        swiperRef.slideNext();
        onNextButtonClick && onNextButtonClick();
      }
    }
  };

  return (
    <SwiperWrapper
      fullWidth={!!$SelectedItem}
      isMobile={responsive === "mobile"}
    >
      {list && list.length !== 0 && (
        <Row className={isForDates ? "swiperWithArrowWrapper" : ""}>
          {showNavigationBtn &&
            navigationBtnType === "icon" &&
            hasPrevButton && (
              <PrimaryButton
                className="pervBtn"
                size="xs"
                width="33px"
                color="gray"
                icon={ArrowIcon}
                type="button"
                onClick={prevHandler}
                disabled={selectedItem === 1}
              />
            )}
          <Swiper
            id="swiper-container"
            spaceBetween={0}
            slidesPerView={!!$SelectedItem ? "auto" : 5}
            loop={loop}
            autoplay={{
              delay: speed,
              disableOnInteraction: true,
            }}
            // centeredSlides={true}
            preventInteractionOnTransition
            initialSlide={initialSlice}
            watchOverflow={true}
            watchSlidesProgress={true}
            speed={200}
            modules={
              autoplay
                ? [Autoplay, Pagination, Navigation]
                : [Pagination, Navigation]
            }
            onSlideChange={(e) => {
              setSelectedItem(e?.activeIndex + 1);
              setSelectedIndex && setSelectedIndex(e?.activeIndex + 1);
            }}
            onSwiper={(swiper) => {
              cancelHandler?.();
              setSwiperRef(swiper);
            }}
            breakpoints={
              haveBreakpoint
                ? {
                    992: {
                      slidesPerView: 7,
                      spaceBetween: 0,
                    },
                  }
                : {}
            }
          >
            {list.map((each, index) => {
              return (
                <SwiperSlide key={index}>
                  <CardComponent
                    key={index}
                    index={index}
                    item={each}
                    otherPropsForCardComponent={otherPropsForCardComponent}
                    // type={each.type}
                    // cardBtnClick={each?.onClick}
                  />
                </SwiperSlide>
              );
            })}
          </Swiper>
          {showNavigationBtn &&
            navigationBtnType === "icon" &&
            hasPrevButton && (
              <PrimaryButton
                className="nextBtn"
                size="xs"
                width="33px"
                color="gray"
                icon={ArrowIcon}
                type="button"
                onClick={nextHandler}
                disabled={selectedItem === list.length}
              />
            )}
        </Row>
      )}
      {showNavigationBtn &&
        list &&
        list.length !== 0 &&
        navigationBtnType === "button" && (
          <ButtonContainer2>
            {hasPrevButton ? (
              <OutlineButton
                className="pervBtn"
                size="xs"
                width="100px"
                color="primary"
                title={prevButtonTitle}
                type="button"
                onClick={prevHandler}
                disabled={selectedItem === 1}
              />
            ) : (
              <Col className="w-100" />
            )}
            {showPagination && (
              <Row className="swiper-count">
                <XSmallMonoParagraph color={theme.gray700}>
                  {selectedItem}
                </XSmallMonoParagraph>
                <XSmallParagraph color={theme.gray700}>از</XSmallParagraph>
                <XSmallMonoParagraph color={theme.gray700}>
                  {list.length}
                </XSmallMonoParagraph>
              </Row>
            )}
            {hasNextButton ? (
              <PrimaryButton
                className="nextBtn"
                size="xs"
                width="100px"
                color="primary"
                title={nextButtonTitle}
                type="button"
                onClick={nextHandler}
                disabled={
                  nextButtonDisable === undefined
                    ? selectedItem === list.length
                    : nextButtonDisable
                }
                loading={nextButtonLoading}
              />
            ) : (
              <Col className="w-100" />
            )}
          </ButtonContainer2>
        )}
    </SwiperWrapper>
  );
};

export default SwiperComponent;
