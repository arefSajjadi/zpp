import styled from "styled-components";
import Row from "../Row";
import Col from "../Col";
import { HexToRgba } from "../../../Utils/HexToRgba";

interface StyledModalLayoutProps {
  alignItems: string;
  width: string;
}
export const StyledModalLayout = styled.div<StyledModalLayoutProps>`
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  justify-content: center;
  align-items: ${(props) => props.alignItems};
  width: 100vw;
  height: 100vh;
  background-color: ${(props) => HexToRgba(props.theme.gray900, 0.7)};
  opacity: 0;
  z-index: 100;
  pointer-events: none;
  &.open {
    opacity: 1;
    pointer-events: all;
  }
  @media (max-width: ${(props) => props.width}) {
    .bict__modal__container {
      width: 100vw;
    }
  }
  @media (max-width: ${(props) => props.theme.sm}) {
    .bict__modal__wrapper {
      bottom: 0;
    }
    .bict__modal__container {
      width: 100vw;
      height: 100%;
    }
    .bict__modal__container {
      border-radius: 0;
    }
  }
  @media (max-width: ${(props) => props.theme.xs}) {
    .bict__modal__container {
      height: 100%;
      border-radius: 15px 15px 0 0;
    }
  }
`;

interface ModalWrapperProps {
  heightSize?: string;
}
export const StyledModalWrapper = styled.div<ModalWrapperProps>`
  position: fixed;
  width: 100vw;
  height: ${(props) => (props.heightSize ? props.heightSize : "unset")};
  display: flex;
  justify-content: center;
`;

interface ModalContainerProps {
  width: string;
  height: string;
}
export const StyledModalContainer = styled.div<ModalContainerProps>`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  background-color: ${(props) => props.theme.white};
  width: ${(props) => props.width};
  height: ${(props) => props.height};
  border-radius: 25px;
  box-shadow: 0px 3px 7px 0 rgba(0, 0, 0, 0.03);
  @keyframes fade-in-top {
    0% {
      -webkit-transform: translateY(100px);
      transform: translateY(100px);
      opacity: 0;
    }
    100% {
      -webkit-transform: translateY(0);
      transform: translateY(0);
      opacity: 1;
    }
  }

  /* .flip-horizontal-bottom { */
  -webkit-animation: fade-in-top 0.5s cubic-bezier(0.39, 0.575, 0.565, 1) both;
  animation: fade-in-top 0.2s cubic-bezier(0.39, 0.575, 0.565, 1) both;
  /* } */
`;

export const StyledHeader = styled(Row)`
  height: 50px;
  border-radius: 5px 5px 0 0;
  flex-wrap: nowrap;
  border-bottom: 1px solid #d6d6d6;
  padding: 10px 16px 10px 0;
`;

export const StyledHeaderTitle = styled(Row)`
  position: relative;
  width: calc(100% - 50px) !important;
  height: 100%;
  justify-content: space-between;
  label {
    color: ${(props) => props.theme.primary600};
  }
`;

export const HeaderLine = styled(Row)`
  position: absolute;
  left: 0;
  width: 100%;
  height: 1px;
  z-index: -1;
  background-color: ${(props) => props.theme.gray100};
  margin-bottom: -3px;
`;

export const StyledHeaderAction = styled(Col)`
  width: 50px !important;
  height: 100%;
  cursor: pointer;
  svg {
    width: 16px;
    height: 16px;
    fill: ${(props) => props.theme.gray600};
  }
`;

interface StyledModalBodyProps {
  padding: string;
}
export const StyledModalBody = styled(Col)<StyledModalBodyProps>`
  height: 100%;
  justify-content: flex-start;
  padding: ${(props) => props.padding};
  overflow-y: auto;
  overflow-x: hidden;
  &::-webkit-scrollbar {
    width: 3px;
  }
  &::-webkit-scrollbar-track {
    box-shadow: inset 0 0 3px #c0c0bf;
  }
  &::-webkit-scrollbar-thumb {
    background-color: #c0c0bf;
  }
`;
