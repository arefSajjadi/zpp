import React, { useEffect, useRef, useState } from "react";
import { useSelector } from "react-redux";
import { selectTheme } from "../../../Redux/App/Selectors";
import {
  StyledModalLayout,
  StyledModalWrapper,
  StyledModalContainer,
  StyledHeader,
  StyledHeaderTitle,
  StyledHeaderAction,
  StyledModalBody,
} from "./styles";
import CrossIcon from "../Icons/CrossIcon";
import { MediumLabel } from "../Typography/Label";

interface Props {
  size?: "xxs" | "xs" | "sm" | "md" | "lg";
  width?: string;
  height?: string;
  visible: boolean;
  headerTitle?: string;
  onCancel?: () => void;
  onClose?: () => void;
  closable?: boolean;
  children: React.ReactNode;
  padding?: string;
  alignItem?: string;
}

const Modal: React.FC<Props> = (props) => {
  const theme = useSelector(selectTheme);

  const {
    size,
    width,
    height,
    visible,
    headerTitle,
    onCancel,
    onClose,
    closable = true,
    children,
    padding = "0",
    alignItem = "center",
  } = props;

  const [show, setShow] = useState(false);
  const ModalRef = useRef<any>();

  const callBack = () => {
    setShow(false);

    if (onClose) {
      onClose();
    } else if (onCancel) {
      onCancel();
    }
  };

  const OutSideClick = (e: any, ref: any, callback: any) => {
    if (ref && ref.current && callback) {
      if (!ref.current.contains(e.target)) {
        callback();
      }
    }
  };

  const ClickFunc = (e: any) => {
    OutSideClick(e, ModalRef, callBack);
  };

  useEffect(() => {
    setShow(visible);
    if (visible === true) {
      document.body.style.overflowY = "hidden";
      window.addEventListener("mousedown", ClickFunc, false);
    }

    return () => {
      if (visible === true) {
        document.body.style.overflowY = "auto";
        window.removeEventListener("mousedown", ClickFunc, false);
      }
    };
  }, [visible]);

  const closeHandler = () => {
    if (closable !== false) {
      setShow(false);
      if (onClose) {
        onClose();
      } else if (onCancel) {
        onCancel();
      }
    }
  };

  const getWidth = () => {
    switch (size) {
      case "xxs":
        return "500px";
      case "xs":
        return "500px";
      case "sm":
        return "500px";
      case "md":
        return "625px";
      case "lg":
        return "1000px";
      default:
        return width || "";
    }
  };

  const getHeight = () => {
    switch (size) {
      case "xxs":
        return "250px";
      case "xs":
        return "450px";
      case "sm":
        return "600px";
      case "md":
        return "450px";
      case "lg":
        return "600px";
      default:
        return height || "auto";
    }
  };

  return show ? (
    <StyledModalLayout
      className={`bict__modal__layout ${show ? "open" : "close"}`}
      alignItems={alignItem}
      width={getWidth()}
    >
      <StyledModalWrapper heightSize={height} className="bict__modal__wrapper">
        <StyledModalContainer
          className="bict__modal__container"
          width={getWidth()}
          height={getHeight()}
          ref={ModalRef}
        >
          <StyledHeader className="bict__modal__header">
            <StyledHeaderTitle className="bict__modal__headerTitle">
              <MediumLabel color={theme.gray700}>{headerTitle}</MediumLabel>
            </StyledHeaderTitle>
            <StyledHeaderAction
              className="bict__modal__headerAction"
              onClick={closeHandler}
            >
              {closable !== false && <CrossIcon />}
            </StyledHeaderAction>
          </StyledHeader>
          <StyledModalBody className="bict__modal__body" padding={padding}>
            {children}
          </StyledModalBody>
        </StyledModalContainer>
      </StyledModalWrapper>
    </StyledModalLayout>
  ) : (
    <></>
  );
};

export default Modal;
