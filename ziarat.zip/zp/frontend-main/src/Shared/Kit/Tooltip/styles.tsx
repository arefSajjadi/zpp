import styled from "styled-components";
import Col from "../Col";
import Row from "../Row";

const getTooltipPosition = (position: "top" | "bottom" | "left" | "right") => {
    switch (position) {
        case "top":
        return "transform: translate(0, -25px);"
        case "bottom":
            return "transform: translate(0, 25px);"
        case "left":
            return "right: 100%; transform: translate(-5px, 0);"
        case "right":
            return "left: 100%; transform: translate(5px, 0);"
        default:
            return ""
    }
}

const bachgroundColor = (theme: any, color: string) => theme[color + "50"];
const borderColor = (theme: any, color: string) => theme[color + "100"];
const color = (theme: any, color: string) => theme[color + "700"];

interface DescriptionContainerProps {
    position: "top" | "bottom" | "left" | "right",
    colorType: "primary" | "secondary" | "negative" | "warning" | "positive" | "gray" | "info",
}
export const DescriptionContainer = styled(Col) <DescriptionContainerProps>`
    position: absolute;
    ${(props) => getTooltipPosition(props.position)}
    width: auto;
    padding: 2px 6px;
    background-color: ${(props) => bachgroundColor(props.theme, props.colorType)};
    border: 1px solid ${(props) => borderColor(props.theme, props.colorType)};
    border-radius: 4px;
    z-index: 2;
    p {
        white-space: nowrap;
        font-weight: normal;
        color: ${(props) => color(props.theme, props.colorType)};
    }
    //motion
    display: none;
    opacity: 0;
    transition: all 300ms;
`

interface TooltipWithIconContainerProps {
    iconColor?: string
    iconWidth?: string
    iconHeight?: string
}
export const TooltipWithIconContainer = styled(Row) <TooltipWithIconContainerProps>`
    position: relative;
    width: auto;
    * {
        cursor: pointer;
    }
    svg {
        width: ${(props) => props.iconWidth};
        height: ${(props) => props.iconHeight};
        fill: ${(props) => props.iconColor};
    }
`;