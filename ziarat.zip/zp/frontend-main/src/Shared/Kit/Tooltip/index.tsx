import React from "react";
import {
    DescriptionContainer
} from "./styles";
import { XXSmallParagraph } from "../Typography/Paragraph";

interface Props {
    name: string
    description: string
    position?: "top" | "bottom" | "left" | "right"
    colorType?: "primary" | "secondary" | "negative" | "warning" | "positive" | "gray" | "info",
}

export const onMouseEnter = (name?: string) => {
    const _id = `${name}-tooltip`
    let element = document.getElementById(_id);
    let style = element?.style;
    if (style) {
        style.display = "flex";
        setTimeout(() => {
            if (style) {
                style.opacity = "1";
            }
        }, 50)
    }
};

export const onMouseLeave = (name?: string) => {
    const _id = `${name}-tooltip`
    let element = document.getElementById(_id);
    let style = element?.style
    if (style) {
        style.opacity = "0";
        setTimeout(() => {
            if (style) {
                style.display = "none";
            }
        }, 50)
    }
};

const Tooltip: React.FC<Props> = (props) => {
    const {
        name,
        description,
        position = "left",
        colorType = "gray"
    } = props;

    const _id = `${name}-tooltip`

    return (
        <DescriptionContainer
            className="tooltip"
            id={_id}
            position={position}
            colorType={colorType}
        >
            <XXSmallParagraph>
                {description}
            </XXSmallParagraph>
        </DescriptionContainer>
    )
}

export default Tooltip;