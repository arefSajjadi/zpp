import React from "react";
import {
    TooltipWithIconContainer,
} from "./styles";
import InfoIcon from "../Icons/InfoIcon";
import Tooltip, { onMouseEnter, onMouseLeave } from ".";

interface Props {
    name: string
    description: string
    position?: "top" | "bottom" | "left" | "right"
    colorType?: "primary" | "secondary" | "negative" | "warning" | "positive" | "gray" | "info"
    Icon?: any
    iconWidth?: string
    iconHeight?: string
    iconColor?: string
}

const TooltipWithIcon: React.FC<Props> = (props) => {
    const {
        name,
        description,
        position = "left",
        colorType = "gray",
        Icon = InfoIcon,
        iconWidth,
        iconHeight,
        iconColor = "",
    } = props;

    return (
        <TooltipWithIconContainer
            className="tooltip-with-icon"
            iconColor={iconColor}
            iconWidth={iconWidth}
            iconHeight={iconHeight}
            onMouseEnter={() => onMouseEnter(name)}
            onMouseLeave={() => onMouseLeave(name)}
        >
            {Icon()}
            <Tooltip
                name={name}
                description={description}
                position={position}
                colorType={colorType}
            />
        </TooltipWithIconContainer>
    )
}

export default TooltipWithIcon;