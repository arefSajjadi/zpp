import { useSelector } from "react-redux";
import { selectTheme } from "../../../Redux/App/Selectors";
import {
    AccessDeniedContainer
} from "./styles";
import Col from '../Col';
import WarningIcon from "../Icons/WarningIcon";
import { SmallParagraph } from "../Typography/Paragraph";

const AccessDenidMessage = () => {
    const theme = useSelector(selectTheme);

    return (
        <AccessDeniedContainer>
            <Col>
                <WarningIcon />
            </Col>
            <SmallParagraph
                color={theme.negative600}
            >
                دسترسی به این صفحه برای شما امکان پذیر نمی باشد.
            </SmallParagraph>
        </AccessDeniedContainer>
    )
}

export default AccessDenidMessage;