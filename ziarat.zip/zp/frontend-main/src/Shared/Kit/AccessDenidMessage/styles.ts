import styled from "styled-components";
import Row from "../Row";

export const AccessDeniedContainer = styled(Row)`
    margin-top: 80px;
    justify-content: center;
    > div {
        width: 48px;
        height: 48px;
        background-color: ${(props) => props.theme.negative50};
        margin-left: 20px;
        border-radius: 8px;
        svg {
            width: 25px;
            height: 25px;
            fill: ${(props) => props.theme.negative600};
        }
    }
`