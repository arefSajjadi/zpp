import {
    BaseLine,
    ProgressLine,
} from "./styles";

interface Props {
    percentage: number,
    mode: "light" | "dark"
}

const ProgressBar: React.FC<Props> = (props) => {
    const {
        percentage,
        mode
    } = props;

    return (
        <BaseLine mode={mode}>
            <ProgressLine
                mode={mode}
                width={percentage}
            />
        </BaseLine>
    )
}

export default ProgressBar;