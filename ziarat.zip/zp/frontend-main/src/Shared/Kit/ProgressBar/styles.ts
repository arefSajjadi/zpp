import styled from "styled-components";
import Row from "../Row";

interface BaseLineProps {
    mode: "light" | "dark"
}

export const BaseLine = styled(Row) <BaseLineProps>`
    position: relative;
    width: 100%;
    height: 4px;
    background-color: ${(props) => props.mode === "dark" ? props.theme.secondary500 : props.theme.gray100};
    border-radius: 2px;
    margin-bottom: 8px;
`

interface ProgressLineProps {
    width: number,
    mode: "light" | "dark"
}
export const ProgressLine = styled(Row) <ProgressLineProps>`
    position: absolute;
    top: 0;
    right: 0;
    width: ${(props) => props.width}%;
    height: 4px;
    background-color: ${(props) =>
        props.mode === "dark"
            ? props.width === 100
                ? props.theme.positive400
                : props.theme.secondary200
            : props.theme.gray800
    };
    border-radius: 2px;
` 