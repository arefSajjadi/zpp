import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { selectTheme } from "../../../../Redux/App/Selectors";
import {
  RadioWrapper,
  RadioContainer,
  RadioTextContainer,
} from "../FormStyles";
import { SmallParagraph } from "../../Typography/Paragraph";
import useIsMobile from "../../../../Utils/Responsive";
import {
  ResizingForResponsive1920,
  ResizingForResponsive768,
} from "../../ResizingForResponsive";

interface Props {
  size: "xl" | "lg" | "md" | "sm" | "xs";
  selected: boolean;
  text: string;
  onSelect: any;
}

const Radio: React.FC<Props> = (props) => {
  const {
    // size,
    selected,
    text,
    onSelect,
  } = props;

  const theme = useSelector(selectTheme);

  const [size, setSize] = useState(props.size);

  const screenSize = useIsMobile();

  useEffect(() => {
    if (screenSize === "desktop-lg") {
      setSize(ResizingForResponsive1920(props.size));
    } else if (screenSize === "tablet") {
      setSize(ResizingForResponsive768(props.size));
    } else {
      setSize(props.size);
    }
  }, [screenSize]);

  return (
    <RadioWrapper className="bict__RadioWrapper" onClick={onSelect}>
      <RadioContainer
        size={size}
        className={`
                    bict__Radio
                    ${selected ? "selected" : ""}
                `}
      />
      <RadioTextContainer
        size={size}
        className={`
                    bict__RadioText 
                    ${selected ? "active" : ""}
                `}
      >
        <SmallParagraph color={theme.gray800}>{text}</SmallParagraph>
      </RadioTextContainer>
    </RadioWrapper>
  );
};

export default Radio;
