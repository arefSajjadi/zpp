import React, { useEffect, useState } from "react";
import {
  MainContainer,
  CaptchaContainer,
  CaptchaImg,
  ReloadBtn,
} from "./styles";
import Input from "../Input";
import ReloadIcon from "../../Icons/ReloadIcon";
import useIsMobile from "../../../../Utils/Responsive";
import {
  ResizingForResponsive1920,
  ResizingForResponsive768,
} from "../../ResizingForResponsive";

type func = (...args: any[]) => any;

interface Props {
  size: "xl" | "lg" | "md" | "sm" | "xs";
  name?: string;
  value: string;
  error?: any;
  onChange: func;
  onBlur?: func;
  captchaImg: any;
  getCaptcha: func;
  captchaBgColor?: string;
}

const Captcha: React.FC<Props> = (props) => {
  const {
    // size,
    name = "captcha",
    value,
    error,
    onChange,
    onBlur,
    captchaImg,
    getCaptcha,
    captchaBgColor,
  } = props;

  useEffect(() => {
    getCaptcha();
  }, []);

  const [size, setSize] = useState(props.size);

  const screenSize = useIsMobile();

  useEffect(() => {
    if (screenSize === "desktop-lg") {
      setSize(ResizingForResponsive1920(props.size));
    } else if (screenSize === "tablet") {
      setSize(ResizingForResponsive768(props.size));
    } else {
      setSize(props.size);
    }
  }, [screenSize]);

  return (
    <MainContainer>
      <Input
        size={props.size}
        label={"کدامنیتی"}
        name={name}
        value={value}
        error={error}
        onChange={onChange}
        onBlur={onBlur}
        mask={"99999"}
      />
      <CaptchaContainer captchaBgColor={captchaBgColor} size={size}>
        {captchaImg && <CaptchaImg className="captchaImg" src={captchaImg} />}
        <ReloadBtn type="button" onClick={getCaptcha}>
          <ReloadIcon />
        </ReloadBtn>
      </CaptchaContainer>
    </MainContainer>
  );
};

export default Captcha;
