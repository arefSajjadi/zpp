import styled from "styled-components";
import Row from "../../Row";
import Col from "../../Col";
import { getInputHeight } from "../FormStyles";

export const MainContainer = styled(Col)`
    position: relative;
`

interface CaptchaContainerProps {
    captchaBgColor?: string,
    size: "xl" | "lg" | "md" | "sm" | "xs"
}
export const CaptchaContainer = styled(Row) <CaptchaContainerProps>`
    width: 131px;
    height: ${(props) => `calc(${getInputHeight(props.size)} - 2px)`};
    position: absolute;
    left: 1px;
    top: 1px;
    background-color: ${(props) => props.captchaBgColor ? props.captchaBgColor : props.theme.white};
`

export const CaptchaImg = styled.img`
    width: 100px;
    height: 100%;
`

export const ReloadBtn = styled.button`
    display: flex;
    justify-content: center;
    align-items: center;
    width: 30px;
    height: 100%;
    background-color: inherit;
    border: none;
    cursor: pointer;
    z-index: 1;
    margin-right: auto;
    border-radius: 4px 0 0 4px;
`