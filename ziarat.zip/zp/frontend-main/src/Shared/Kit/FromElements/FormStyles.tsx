import styled from "styled-components";
import Row from "../Row";
import Col from "../Col";
import { HexToRgba } from "../../../Utils/HexToRgba";

export const getInputHeight = (size: "xl" | "lg" | "md" | "sm" | "xs") => {
  //input
  if (size === "xl") {
    return "55px";
  } else if (size === "lg") {
    return "50px";
  } else if (size === "md") {
    return "44px";
  } else if (size === "sm") {
    return "40px";
  } else if (size === "xs") {
    return "36px";
  }
};

const getInputFontSize = (size: "xl" | "lg" | "md" | "sm" | "xs") => {
  //input and textarea
  if (size === "xl") {
    return "18px";
  } else if (size === "lg") {
    return "16px";
  } else if (size === "md") {
    return "16px";
  } else if (size === "sm") {
    return "16px";
  } else if (size === "xs") {
    return "14px";
  }
};

export const getInputInfoIconSize = (
  size: "xl" | "lg" | "md" | "sm" | "xs"
) => {
  //input and textarea
  if (size === "xl") {
    return "18px";
  } else if (size === "lg") {
    return "16px";
  } else if (size === "md") {
    return "14px";
  } else if (size === "sm") {
    return "14px";
  } else if (size === "xs") {
    return "12px";
  }
};

export const getSelectIconTop = (size: "xl" | "lg" | "md" | "sm" | "xs") => {
  //select
  if (size === "xl") {
    return "18px";
  } else if (size === "lg") {
    return "15px";
  } else if (size === "md") {
    return "13px";
  } else if (size === "sm") {
    return "10px";
  } else if (size === "xs") {
    return "7px";
  }
};

const getOptionWrapperTop = (size: "xl" | "lg" | "md" | "sm" | "xs") => {
  //select
  if (size === "xl") {
    return "55px";
  } else if (size === "lg") {
    return "50px";
  } else if (size === "md") {
    return "44px";
  } else if (size === "sm") {
    return "40px";
  } else if (size === "xs") {
    return "39px";
  }
};

const getCheckboxSize = (size: "xl" | "lg" | "md" | "sm" | "xs") => {
  //checkbox, radio
  if (size === "xl") {
    return "24px";
  } else if (size === "lg") {
    return "18px";
  } else if (size === "md") {
    return "16px";
  } else if (size === "sm") {
    return "14px";
  } else if (size === "xs") {
    return "12px";
  }
};

const getCalendarInputFontSize = (size: "xl" | "lg" | "md" | "sm" | "xs") => {
  //calnedar
  if (size === "xl") {
    return "20px";
  } else if (size === "lg") {
    return "17px";
  } else if (size === "md") {
    return "15px";
  } else if (size === "sm") {
    return "15px";
  } else if (size === "xs") {
    return "13px";
  }
};

export const Form = styled.form`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: auto;
  flex-wrap: wrap;
`;

interface FormRowProps {
  minHeight?: string;
}
export const FormRow = styled(Row)<FormRowProps>`
  min-height: ${(props) => props.minHeight || "100px"};
  align-items: flex-start;
`;

interface FormGroupProps {
  size: "xl" | "lg" | "md" | "sm" | "xs";
  textareaHeight?: string;
}
export const FormGroup = styled(Col)<FormGroupProps>`
  > div:first-child {
    position: relative;
  }
  * {
    transition: all 200ms;
  }
  .bict__formLabel {
    font-size: 16px;
    display: flex;
    align-items: center;
    /* text-wrap: nowrap; */
    white-space: nowrap;
    .tooltip-with-icon svg {
      width: ${(props) => getInputInfoIconSize(props.size)};
      height: ${(props) => getInputInfoIconSize(props.size)};
      fill: transparent;
      opacity: 0.8;
    }
  }
  .bict__formInput {
    height: ${(props) => getInputHeight(props.size)};
    padding: 0 10px;
  }
  input[type="file"] {
    padding: 7px 10px;
  }
  .bict__formTextarea {
    resize: none;
    height: ${(props) => props.textareaHeight};
    padding: 10px;
    text-align: justify !important;
    &::-webkit-scrollbar {
      display: none;
    }
    scrollbar-width: none;
    -ms-overflow-style: none;
  }
  .bict__formInput,
  .bict__formTextarea {
    width: 100%;
    background-color: transparent;
    border: 1px solid ${(props) => props.theme.formElementBorderColor};
    border-radius: 10px;
    outline: none;
    box-sizing: border-box;
    font-size: 16px;
    font-weight: 700;
    color: ${(props) => props.theme.gray900};
    z-index: 1;
    &:hover {
      border: 1px solid ${(props) => props.theme.primary600};
    }
    &.has-error {
      border: 1px solid ${(props) => props.theme.negative600};
      &:hover {
        border: 1px solid ${(props) => props.theme.negative600};
      }
    }
    &:focus,
    &.bict__calendar__input_focus {
      border: 1px solid ${(props) => props.theme.primary600};
      &:hover {
        border: 1px solid ${(props) => props.theme.primary600};
      }
      &.has-error {
        border: 1px solid ${(props) => props.theme.negative600};
        &:hover {
          border: 1px solid ${(props) => props.theme.negative600};
        }
      }
    }
    &:disabled {
      border: 1px solid ${(props) => props.theme.disabledFormElementBorderColor};
      background-color: ${(props) => HexToRgba(props.theme.gray100, 0.4)};
      &:hover {
        border: 1px solid
          ${(props) => props.theme.disabledFormElementBorderColor};
      }
    }
  }
  .bict__formInput + .bict__formLabel {
    position: absolute;
    top: auto;
    right: 10px;
    z-index: 0;
  }
  .bict__formTextarea + .bict__formLabel {
    position: absolute;
    top: 8px;
    right: 10px;
    z-index: 0;
  }
  .bict__formInput:focus + .bict__formLabel,
  .bict__formTextarea:focus + .bict__formLabel,
  .has-value + .bict__formLabel {
    background-color: ${(props) => props.theme.white};
    padding: 0 6px;
    transform: translate(0, -90%) scale(0.85);
    transform-origin: right bottom;
    z-index: 1;
  }
  .bict__formInput:focus + .bict__formLabel,
  .bict__formTextarea:focus + .bict__formLabel {
    color: ${(props) => props.theme.primary600};
    font-weight: 700;
    .tooltip-with-icon svg {
      fill: ${(props) => props.theme.primary600};
    }
    + .bict__searchCountResult {
      opacity: 1;
      color: ${(props) => props.theme.primary600};
      font-weight: 700;
    }
  }
  .has-value + .bict__formLabel {
    color: ${(props) => props.theme.gray600};
    .tooltip-with-icon svg {
      fill: ${(props) => props.theme.gray600};
    }
  }
  .has-error + .bict__formLabel,
  .has-error:focus + .bict__formLabel {
    color: ${(props) => props.theme.negative600} !important;
    font-weight: 700;
    .tooltip-with-icon svg {
      fill: ${(props) => props.theme.negative600};
    }
  }
  //-------------------------------------------------------------calendar input styles
  .bict__calendar__input_focus + .bict__formLabel,
  .bict__calendar__input_has_value + .bict__formLabel {
    background-color: ${(props) => props.theme.white};
    padding: 0 6px;
    transform: translate(0, -90%) scale(0.85);
    transform-origin: right bottom;
    z-index: 1;
  }
  .bict__calendar__input_has_error,
  .bict__calendar__input_has_error.bict__calendar__input_focus {
    color: ${(props) => props.theme.negative600} !important;
    font-weight: 700;
    .tooltip-with-icon svg {
      fill: ${(props) => props.theme.negative600};
    }
  }
  .bict__calendar__input_has_value + .bict__formLabel {
    color: ${(props) => props.theme.gray600};
    .tooltip-with-icon svg {
      fill: ${(props) => props.theme.gray600};
    }
  }
  .bict__calendar__input_focus + .bict__formLabel {
    color: ${(props) => props.theme.primary600};
    font-weight: 700;
    .tooltip-with-icon svg {
      fill: ${(props) => props.theme.primary600};
    }
  }
  //-------------------------------------------------------------
  .bict__searchCountResult {
    position: absolute;
    left: 5px;
    background-color: ${(props) => props.theme.white};
    padding: 0 6px;
    transform: translate(0, -90%) scale(0.85);
    transform-origin: left bottom;
    z-index: 1;
    opacity: 0;
    transition: all 300ms;
  }
`;

export const FormError = styled(Row)`
  width: auto;
  margin-left: auto;
  padding: 0 4px;
  svg {
    width: 12px;
    height: 12px;
    fill: ${(props) => props.theme.negative600};
    margin-left: 8px;
  }
  p {
    scale: 0.9;
    transform-origin: right;
  }
`;

//styles for select
interface SelectWrapperProps {
  searchable: boolean;
  expand: boolean;
}
export const SelectWrapper = styled(Col)<SelectWrapperProps>`
  position: relative;
  > div {
    display: flex;
    flex-direction: column;
    width: 100%;
    position: relative;
  }
  input {
    caret-color: ${(props) => !props.searchable && "transparent"};

    border-radius: ${(props) => props.expand && "10px 10px 0 0"} !important;
  }
`;

interface SelectIconsContainerProps {
  size: "xl" | "lg" | "md" | "sm" | "xs";
}
export const SelectIconsContainer = styled(Row)<SelectIconsContainerProps>`
  position: absolute;
  top: ${(props) => getSelectIconTop(props.size)};
  left: 10px;
  width: auto;
`;

interface ToggleIconContainerProps {
  expand: boolean;
}
export const ToggleIconContainer = styled(Col)<ToggleIconContainerProps>`
  z-index: 3;
  width: auto;
  padding: 5px;
  cursor: pointer;
  transition: all 300ms;
  z-index: 1;
  svg {
    fill: ${(props) => props.theme.gray600};
  }
  &.arrow-down-icon {
    transform: ${(props) => (props.expand ? "rotate(180deg)" : "")};
    svg {
      width: 12px;
      height: 12px;
    }
  }
  &.search-icon {
    margin-top: -2px;
    svg {
      width: 13.5px;
      height: 13.5px;
    }
  }
  @media screen and (max-width: 1366px) {
    &.search-icon {
      margin-top: 0;
    }
  }
`;

interface ClearIconContainerProps {
  size: "xl" | "lg" | "md" | "sm" | "xs";
}
export const ClearIconContainer = styled(Col)<ClearIconContainerProps>`
  width: auto;
  padding: 5px;
  margin-left: 3px;
  cursor: pointer;
  z-index: 1;
  svg {
    width: 10.5px;
    height: 10.5px;
    fill: ${(props) => props.theme.gray600};
  }
`;

interface OptionWrapperProps {
  size: "xl" | "lg" | "md" | "sm" | "xs";
}
export const OptionWrapper = styled(Col)<OptionWrapperProps>`
  position: absolute;
  top: calc(${(props) => getOptionWrapperTop(props.size)} - 0);
  background-color: ${(props) => props.theme.white};
  border: 1px solid ${(props) => props.theme.formElementBorderColor};
  border-top: none;
  border-radius: 4px;
  z-index: 2;
  box-shadow: 0px 4px 4px 0px rgba(0, 0, 0, 0.05);
  @media (max-width: ${(props) => props.theme.xs}) {
    border: none;
    padding: 10px 10px;
    box-shadow: none;
    height: 100%;
  }
`;

export const HeaderContainer = styled(Row)`
  .bict__select__optionCell {
    border-bottom: 1px solid
      ${(props) => HexToRgba(props.theme.formElementBorderColor, 0.3)};
    cursor: default;
    label {
      cursor: default;
    }
  }
`;

interface OptionCellProps {
  flex: number;
}
export const OptionCell = styled(Row)<OptionCellProps>`
  flex: ${(props) => props.flex};
  min-height: 45px;
  padding: 10px;
  border-bottom: 0.5px solid ${(props) => props.theme.gray100};

  cursor: pointer;
  label {
    cursor: pointer;
  }
  .bict__select__optionCell__paragraph {
    gap: 10px;

    svg {
      display: block;
      path {
        stroke: ${(props) => props.theme.primary300};
      }
    }
  }
  @media (max-width: ${(props) => props.theme.xs}) {
  }
`;

export const MobileOptionWrapper = styled.div`
  height: 100%;
  width: 100%;
  position: relative;
  margin-bottom: 3rem;
`;

export const OptionContainer = styled(Col)`
  max-height: 200px;
  justify-content: flex-start;
  overflow-y: auto;
  padding: 0;
  &::-webkit-scrollbar {
    width: 5px;
  }
  &::-webkit-scrollbar-track {
    box-shadow: inset 0 0 3px white;
  }
  &::-webkit-scrollbar-thumb {
    background-color: #c0c0bf;
    border-radius: 4px;
  }
  .bict__select__option:last-child .bict__select__optionCell {
    border-bottom: none !important;
  }
  @media (max-width: ${(props) => props.theme.xs}) {
    max-height: max-content;
    overflow-y: auto;
    position: absolute;
    height: 100%;
    top: 0;

    .bict__select__option {
    }
    .bict__select__option:last-child .bict__select__optionCell {
      border-bottom: none !important;
    }
  }
`;

interface OptionProps {
  havePadding?: boolean;
}

export const Option = styled(Row)<OptionProps>`
  transition: all 300ms;

  padding: ${(props) => (props.havePadding ? "0 20px" : "0")};
  &:last-child {
    border-bottom: none;
  }
  &:hover {
    background-color: ${(props) => HexToRgba(props.theme.gray50, 0.5)};
  }
`;

//Checkbox
interface CheckBoxWrapperProps {
  disable?: boolean;
}
export const CheckBoxWrapper = styled(Row)<CheckBoxWrapperProps>`
  width: auto;
  cursor: ${(props) => !props.disable && "pointer"};
`;

interface CheckboxContainerProps {
  size: "xl" | "lg" | "md" | "sm" | "xs";
  disable?: boolean;
}
export const CheckboxContainer = styled(Col)<CheckboxContainerProps>`
  width: ${(props) => getCheckboxSize(props.size)};
  height: ${(props) => getCheckboxSize(props.size)};
  margin-left: 12px;
  border-radius: 5px;
  border: 2px solid ${(props) => props.theme.gray300};
  background-color: transparent;
  transition: all 300ms;
  svg {
    width: ${(props) => getCheckboxSize(props.size)};
    height: ${(props) => getCheckboxSize(props.size)};
    scale: 0.7;
    fill: ${(props) => props.theme.white};
  }
  &.checked {
    border: 1px solid
      ${(props) =>
        props.disable ? props.theme.primary400 : props.theme.primary600};
    background-color: ${(props) =>
      props.disable ? props.theme.primary400 : props.theme.primary600};
  }
  @media screen and (max-width: 1366px) {
    svg {
      scale: 0.65;
    }
  }
`;

interface CheckboxTextContainerProps {
  size: "xl" | "lg" | "md" | "sm" | "xs";
}
export const CheckboxTextContainer = styled(Row)<CheckboxTextContainerProps>`
  width: auto;
  /* max-width: ${(props) =>
    `calc(100% - 12px - ${getCheckboxSize(props.size)})`}; */
  p {
    cursor: pointer;
    // scale: 0.95;
    transform-origin: right;
  }
`;

//Radio
export const RadioWrapper = styled(Row)`
  width: auto;
  cursor: pointer;
`;

interface RadioContainerProps {
  size: "xl" | "lg" | "md" | "sm" | "xs";
}
export const RadioContainer = styled(Col)<RadioContainerProps>`
  width: ${(props) => getCheckboxSize(props.size)};
  height: ${(props) => getCheckboxSize(props.size)};
  margin-left: 12px;
  border-radius: 50%;
  border: 1px solid ${(props) => props.theme.gray400};
  transition: all 100ms;
  &.selected {
    border: 5px solid ${(props) => props.theme.primary600};
  }
`;

interface RadioTextContainerProps {
  size: "xl" | "lg" | "md" | "sm" | "xs";
}
export const RadioTextContainer = styled(Row)<RadioTextContainerProps>`
  width: auto;
  /* max-width: ${(props) =>
    `calc(100% - 12px - ${getCheckboxSize(props.size)})`}; */
  p {
    cursor: pointer;
  }
`;

//calendar
export const CalendarWrapper = styled(Col)`
  position: relative;
  * {
    transition: all 300ms;
  }
  > div {
    display: flex;
    flex-direction: column;
    width: 100%;
    position: relative;
  }
`;

interface InputsAndIconConatinerProps {
  size: "xl" | "lg" | "md" | "sm" | "xs";
  dayError: any;
  monthError: any;
  yearError: any;
}
export const InputsAndIconConatiner = styled(Row)<InputsAndIconConatinerProps>`
  position: absolute;
  top: 0;
  right: 0;
  > div:first-child {
    //inputs
    flex-direction: row-reverse;
    /* width: ${(props) => `calc(100% - ${getInputHeight(props.size)})`}; */
    width: calc(100% - 58px);
    span {
      width: 20px;
      display: flex;
      justify-content: center;
      align-items: center;
      font-size: 14px;

      color: ${(props) => props.theme.gray600};
    }
    input {
      box-sizing: border-box;
      width: calc((100% - 40px) / 3);
      height: ${(props) => getInputHeight(props.size)};
      margin: 0;
      padding: 0;
      text-align: center;
      font-size: ${(props) => getCalendarInputFontSize(props.size)};
      font-weight: 700;
      outline: none;
      border: none;
      background-color: transparent;
      z-index: 1;
      &:first-child {
        //year
        color: ${(props) =>
          props.yearError ? props.theme.negative600 : props.theme.gray900};
      }
      &:nth-child(3) {
        //month
        color: ${(props) =>
          props.monthError ? props.theme.negative600 : props.theme.gray900};
      }
      &:last-child {
        //day
        color: ${(props) =>
          props.dayError ? props.theme.negative600 : props.theme.gray900};
      }
    }
  }
  .calendar__view__button,
  .calendar__close__button {
    /* width: ${(props) => getInputHeight(props.size)}; */
    width: auto;
    padding: 0 6px;
    cursor: pointer;
    z-index: 1;
  }
  .calendar__view__button {
    margin-left: 4px;
    margin-right: auto;
    svg {
      width: 19px;
      height: 19px;
      fill: ${(props) => props.theme.gray600};
    }
  }
  .calendar__close__button {
    svg {
      width: 11px;
      height: 11px;
      fill: ${(props) => props.theme.gray600};
    }
  }
`;
interface CalenderViewWrapperProps {
  size: "xl" | "lg" | "md" | "sm" | "xs";
}
export const CalenderViewWrapper = styled(Row)<CalenderViewWrapperProps>`
  position: absolute;
  top: ${(props) => getOptionWrapperTop(props.size)};
  left: 0;
  /* min-width: 300px; */
  padding: 15px 20px;
  background-color: ${(props) => props.theme.white};
  border: 1px solid ${(props) => props.theme.formElementBorderColor};
  border-radius: 4px;
  z-index: 2;
  animation: shutter-in-left 1s ease both;
  @keyframes shutter-in-left {
    0% {
      transform: rotateY(100deg);
      transform-origin: left;
      opacity: 0;
    }
    100% {
      transform: rotateY(0);
      transform-origin: left;
      opacity: 1;
    }
  }
`;

export const SelectMonthAndYear = styled(Row)`
  justify-content: space-between;
  padding: 8px 0;
  border-bottom: 1px solid ${(props) => props.theme.gray50};
  margin-bottom: 10px;
`;

export const Title = styled(Row)`
  background-color: ${(props) => props.theme.primary50};
  padding: 6px 16px;
  border-radius: 4px;
  justify-content: space-between;
  margin-bottom: 10px;
  .title {
    width: auto;
  }
  .prv-icon,
  .next-icon {
    width: 18px;
    height: 18px;
    background-color: ${(props) => props.theme.primary100};
    border-radius: 4px;
    cursor: pointer;
    svg {
      width: 10px;
      height: 10px;
      fill: ${(props) => props.theme.primary600};
    }
  }
  .prv-icon {
    svg {
      rotate: -90deg;
    }
  }
  .next-icon {
    svg {
      rotate: 90deg;
    }
  }
`;

export const DaysTitle = styled(Row)`
  justify-content: space-between;
  p {
    width: 14.28%;
    display: flex;
    justify-content: center;
    align-items: center;
  }
`;

export const DaysContainer = styled(Row)`
  justify-content: space-between;
  margin: 15px auto;
`;

interface DayProps {
  disabled: boolean;
  selected: boolean;
}
export const Day = styled(Col)<DayProps>`
  width: 14.28%;
  margin: 3px 0;
  padding: 3px 0;
  border-radius: 5px;
  background-color: ${(props) =>
    props.selected ? props.theme.primary600 : "transparent"};
  opacity: ${(props) => (props.disabled ? 0.5 : 1)};
  cursor: ${(props) => (props.disabled ? "default" : "pointer")};
  &:hover {
    background-color: ${(props) =>
      props.disabled
        ? "transparent"
        : props.selected
        ? props.theme.primary600
        : props.theme.primary100};
  }
  label {
    cursor: ${(props) => (props.disabled ? "default" : "pointer")};
  }
`;

export const Today = styled(Row)`
  margin-top: -5px;
`;
