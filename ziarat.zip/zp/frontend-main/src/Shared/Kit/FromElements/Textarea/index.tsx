import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { selectTheme } from "../../../../Redux/App/Selectors";
import { FormGroup, FormError } from "../FormStyles";
import Col from "../../Col";
import { XSmallParagraph, XXSmallParagraph } from "../../Typography/Paragraph";
import WarningIcon from "../../Icons/WarningIcon";
import useIsMobile from "../../../../Utils/Responsive";
import {
  ResizingForResponsive1920,
  ResizingForResponsive768,
} from "../../ResizingForResponsive";

interface Props {
  className?: string;
  size: "xl" | "lg" | "md" | "sm" | "xs";
  label: string;
  name: string;
  value: string;
  error?: any; //string | null,
  onChange: any;
  onBlur: any;
  autoComplete?: string;
  disabled?: boolean;
  height?: string;
}

const Textarea: React.FC<Props> = (props) => {
  const {
    className = "",
    // size,
    label,
    name,
    value,
    error = null,
    onChange,
    onBlur,
    autoComplete = "off",
    disabled = false,
    height = "120px",
  } = props;

  const theme = useSelector(selectTheme);

  const [size, setSize] = useState(props.size);

  const screenSize = useIsMobile();

  useEffect(() => {
    if (screenSize === "desktop-lg") {
      setSize(ResizingForResponsive1920(props.size));
    } else if (screenSize === "tablet") {
      setSize(ResizingForResponsive768(props.size));
    } else {
      setSize(props.size);
    }
  }, [screenSize]);

  return (
    <FormGroup
      className={`bict__formGroup ${className}`}
      size={size}
      textareaHeight={height}
    >
      <Col>
        <textarea
          className={`
                    bict__formTextarea
                    ${value ? "has-value" : ""}
                    ${error ? "has-error" : ""}
                `}
          name={name}
          value={value}
          onChange={onChange}
          onBlur={onBlur}
          autoComplete={autoComplete}
          disabled={disabled}
        />
        <XSmallParagraph className="bict__formLabel" color={theme.gray700}>
          {label}
        </XSmallParagraph>
      </Col>
      {error && (
        <FormError className="bict__formError">
          <WarningIcon />
          <XXSmallParagraph color={theme.negative600}>{error}</XXSmallParagraph>
        </FormError>
      )}
    </FormGroup>
  );
};

export default Textarea;
