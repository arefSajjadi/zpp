import styled from "styled-components";
import Col from "../../Col";
import Row from "../../Row";

export const MainContainer = styled(Col)`
  .text {
    margin-bottom: 20px;
    p {
      text-align: center;
    }
  }
  .title {
    color: ${(props) => props.theme.primary600};
    font-size: 20px;
  }
  .info {
    margin-top: -40px;
    margin-bottom: 60px;
  }
  svg {
    fill: ${(props) => props.theme.positive600};
    margin-left: 8px;
    margin-bottom: -4px;
  }
`;

interface InputsContainerProps {
  hasError: boolean;
  underlineMode: boolean;
}
export const InputsContainer = styled(Row)<InputsContainerProps>`
  justify-content: center;
  flex-direction: row-reverse;
  gap: 0.6rem;
  // justify-content: space-between;
  flex-wrap: nowrap;
  input {
    text-align: center;
    width: ${(props) => (props.underlineMode ? "15px" : "40px")};
    height: ${(props) => (props.underlineMode ? "15px" : "40px")};
    background-color: ${(props) => props.theme.white};
    border-width: ${(props) => (props.underlineMode ? 0 : "1px")};
    border-style: solid;
    border-color: ${(props) =>
      props.hasError
        ? props.theme.negative600
        : props.theme.formElementBorderColor};
    border-bottom: 1px solid ${(props) => props.theme.gray300};
    border-radius: 2px;
    outline: none;
    color: ${(props) => props.theme.gray900};
    font-size: 16px;
    box-sizing: border-box;
    transition: all 300ms;
    &:focus {
      border: 1px solid
        ${(props) =>
          props.hasError ? props.theme.negative600 : props.theme.primary600};
      border-width: ${(props) => (props.underlineMode ? 0 : "1px")};
      border-bottom: 1px solid ${(props) => props.theme.gray300};
    }
    &:disabled {
      border: 1px solid ${(props) => props.theme.disabledFormElementBorderColor};
      background-color: ${(props) => props.theme.gray50};
    }
    &::placeholder {
      padding: 0;
    }
  }
  /* hide arrows
    Chrome, Safari, Edge, Opera */
  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    -webkit-appearance: none !important;
    margin: 0 !important;
  }

  /* Firefox */
  input[type="number"] {
    -moz-appearance: textfield !important;
  }
`;
