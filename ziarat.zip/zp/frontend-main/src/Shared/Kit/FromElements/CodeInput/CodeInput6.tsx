import React, { useEffect, useRef, useState } from "react";
import { useSelector } from "react-redux";
import { selectLang, selectTheme } from "../../../../Redux/App/Selectors";
import { InputsContainer, MainContainer } from "./styles";
import Col from "../../Col";
import { FormRow } from "../FormStyles";
import { XSmallParagraph } from "../../Typography/Paragraph";
import InfoIcon from "../../Icons/InfoIcon";
import { XSmallLabel } from "../../Typography/Label";

type func = (...args: any[]) => any;

interface Props {
  formik: any;
  name: string;
  phoneNumber: string;
  error?: string | null;
  formRowXl?: number;
  formRowLg?: number;
  formRowMd?: number;
  formRowSm?: number;
  formRowXs?: number;
  formRowMinHeight?: string;
  disabled?: boolean;
  className?: string;
  text?: string;
  info?: string;
  handler?: func;
  reset?: boolean;
  setReset?: any;
  showMobileText?: boolean;
  underLineMode?: boolean;
}

const CodeInput6: React.FC<Props> = (props) => {
  const {
    formik,
    name,
    phoneNumber,
    error,
    formRowXl = 24,
    formRowLg = 24,
    formRowMd = 24,
    formRowSm = 24,
    formRowXs = 24,
    formRowMinHeight = "90px",
    disabled = false,
    className,
    text,
    info,
    handler,
    reset = false,
    setReset,
    showMobileText = true,
    underLineMode = false,
  } = props;

  const theme = useSelector(selectTheme);

  const digitOne: { current: any | null } = useRef();
  const digitTwo: { current: any | null } = useRef();
  const digitThree: { current: any | null } = useRef();
  const digitFour: { current: any | null } = useRef();
  const digitFive: { current: any | null } = useRef();
  const digitSix: { current: any | null } = useRef();

  const [code, setCode] = useState({
    one: "",
    two: "",
    three: "",
    four: "",
    five: "",
    six: "",
  });

  useEffect(() => {
    if (reset) {
      setCode({
        one: "",
        two: "",
        three: "",
        four: "",
        five: "",
        six: "",
      });
      setReset(false);
    }
  }, [reset]);

  const handleKeyUp = (key: string, e: any) => {
    switch (key) {
      case "one":
        if (e.key === "Backspace" || e.keyCode === 8) {
          setCode({
            ...code,
            [key]: "",
          });
        } else {
          if (e.target.value !== "") {
            digitTwo.current.select();
            digitTwo.current.focus();
          }
        }
        break;
      case "two":
        if (e.key === "Backspace" || e.keyCode === 8) {
          setCode({
            ...code,
            [key]: "",
          });
          digitOne.current.select();
          digitOne.current.focus();
        } else {
          if (e.target.value !== "") {
            digitThree.current.select();
            digitThree.current.focus();
          }
        }
        break;
      case "three":
        if (e.key === "Backspace" || e.keyCode === 8) {
          setCode({
            ...code,
            [key]: "",
          });
          digitTwo.current.select();
          digitTwo.current.focus();
        } else {
          if (e.target.value !== "") {
            digitFour.current.select();
            digitFour.current.focus();
          }
        }
        break;
      case "four":
        if (e.key === "Backspace" || e.keyCode === 8) {
          setCode({
            ...code,
            [key]: "",
          });
          digitThree.current.select();
          digitThree.current.focus();
        } else {
          if (e.target.value !== "") {
            digitFive.current.select();
            digitFive.current.focus();
          }
        }
        break;
      case "five":
        if (e.key === "Backspace" || e.keyCode === 8) {
          setCode({
            ...code,
            [key]: "",
          });
          digitFour.current.select();
          digitFour.current.focus();
        } else {
          if (e.target.value !== "") {
            digitSix.current.select();
            digitSix.current.focus();
          }
        }
        break;
      case "six":
        if (e.key === "Backspace" || e.keyCode === 8) {
          setCode({
            ...code,
            [key]: "",
          });
          digitFive.current.select();
          digitFive.current.focus();
        } else {
          if (e.target.value !== "") {
            digitSix.current.select();
            digitSix.current.focus();
          }
        }
        break;
      default:
        break;
    }
  };

  const handleInputs = (key: string, e: any) => {
    const val: string = e.target.value;

    if (val?.length === 7 && !Number.isNaN(val)) {
      formik.setFieldValue(name, val);
      handler && handler(val);
      setCode({
        one: val?.slice(0, 1),
        two: val?.slice(1, 2),
        three: val?.slice(2, 3),
        four: val?.slice(3, 4),
        five: val?.slice(4, 5),
        six: val?.slice(5, 6),
      });
    } else {
      const re = /^[0-9]{1,1}$/;
      // const re = /^[0-9]{1}$/;

      if (e.target.value == "" || re.test(e.target.value)) {
        setCode({
          ...code,
          [key]: e.target.value,
        });
      }

      const fullcode = `${key === "one" ? e.target.value : code.one}${key === "two" ? e.target.value : code.two}${key === "three" ? e.target.value : code.three}${key === "four" ? e.target.value : code.four}${key === 'five' ? e.target.value : code.five}${key === 'six' ? e.target.value : code.six}`
      formik.setFieldValue(name, fullcode);
      handler && handler(fullcode);
    }
  };

  return (
    <MainContainer>
      {showMobileText && (
        <Col className="text">
          <XSmallParagraph color={theme.gray800}>
            {text || (
              <>
                لطفا کد ارسال شده به شماره
                <XSmallLabel>
                  &nbsp; &nbsp;
                  {phoneNumber?.slice(9, 11)}
                  {"****"}
                  {phoneNumber?.slice(0, 5)}
                  &nbsp; &nbsp;
                </XSmallLabel>
                را وارد نمایید.
              </>
            )}
          </XSmallParagraph>
        </Col>
      )}
      {info ? (
        <Col className="info">
          <XSmallParagraph color={theme.positive600}>
            <InfoIcon />
            {info}
          </XSmallParagraph>
        </Col>
      ) : null}
      <FormRow
        minHeight={formRowMinHeight}
        xl={formRowXl}
        lg={formRowLg}
        md={formRowMd}
        sm={formRowSm}
        xs={formRowXs}
      >
        <InputsContainer
          hasError={error ? true : false}
          underlineMode={underLineMode}
        >
          <input
            maxLength={1}
            disabled={disabled}
            className={className}
            value={code.one}
            onKeyUp={(e) => handleKeyUp("one", e)}
            onChange={(e) => handleInputs("one", e)}
            ref={digitOne}
            type="number"
          />
          <input
            maxLength={1}
            disabled={disabled}
            className={className}
            value={code.two}
            onKeyUp={(e) => handleKeyUp("two", e)}
            onChange={(e) => handleInputs("two", e)}
            ref={digitTwo}
            type="number"
          />
          <input
            maxLength={1}
            disabled={disabled}
            className={className}
            value={code.three}
            onKeyUp={(e) => handleKeyUp("three", e)}
            onChange={(e) => handleInputs("three", e)}
            ref={digitThree}
            type="number"
          />
          <input
            maxLength={1}
            disabled={disabled}
            className={className}
            value={code.four}
            onKeyUp={(e) => handleKeyUp("four", e)}
            onChange={(e) => handleInputs("four", e)}
            ref={digitFour}
            type="number"
          />
          <input
            maxLength={1}
            disabled={disabled}
            className={className}
            value={code.five}
            onKeyUp={(e) => handleKeyUp("five", e)}
            onChange={(e) => handleInputs("five", e)}
            ref={digitFive}
            type="number"
          />
          <input
            maxLength={1}
            disabled={disabled}
            className={className}
            value={code.six}
            onKeyUp={(e) => handleKeyUp("six", e)}
            onChange={(e) => handleInputs("six", e)}
            ref={digitSix}
            type="number"
          />
        </InputsContainer>
      </FormRow>
    </MainContainer>
  );
};

export default CodeInput6;
