export const monthsJalaali = [
    'فروردین',
    'اردیبهشت',
    'خرداد',
    'تیر',
    'مرداد',
    'شهریور',
    'مهر',
    'آبان',
    'آذر',
    'دی',
    'بهمن',
    'اسفند'
];

export const monthsJalaaliOptions = [
    {
        id: 1,
        title: "فروردین"
    },
    {
        id: 2,
        title: "اردیبهشت"
    },
    {
        id: 3,
        title: "خرداد"
    },
    {
        id: 4,
        title: "تیر"
    },
    {
        id: 5,
        title: "مرداد"
    },
    {
        id: 6,
        title: "شهریور"
    },
    {
        id: 7,
        title: "مهر"
    },
    {
        id: 8,
        title: "آبان"
    },
    {
        id: 9,
        title: "آذر"
    },
    {
        id: 10,
        title: "دی"
    },
    {
        id: 11,
        title: "بهمن"
    },
    {
        id: 12,
        title: "اسفند"
    },
];

export const daysJalaali = [
    'ش',
    'ی',
    'د',
    'س',
    'چ',
    'پ',
    'ج',
];

export const JalaiWeekDayConvertor = (isoDay: number) => { //نبدیل index روز میلادی به شمسی
    switch (isoDay) {
        case 0: //یک شنبه
            return 1
        case 1: //دو شنبه
            return 2
        case 2: //سه شنبه
            return 3
        case 3: //چهار شنبه
            return 4
        case 4: //پنج شنبه
            return 5
        case 5: //جمعه
            return 6
        case 6: //شنبه
            return 0
        default:
            return 0
    }
}