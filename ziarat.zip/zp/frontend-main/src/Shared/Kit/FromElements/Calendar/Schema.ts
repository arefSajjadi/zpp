import { string, number, object } from 'yup';

export const CalendarSchema = object().shape({
  year: string()
    .max(4, 'max error'),
  month: number()
    .min(1, 'min error')
    .max(12, 'max error'),
  day: number()
    .min(1, 'min error')
    .max(31, 'max error')
});