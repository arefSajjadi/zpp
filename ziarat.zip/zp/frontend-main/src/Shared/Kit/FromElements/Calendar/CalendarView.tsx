import React, { useEffect, useMemo, useState } from "react";
import { useSelector } from "react-redux";
import moment from "moment-jalaali";
import jmoment from "moment-jalaali";
import { selectTheme } from "../../../../Redux/App/Selectors";
import {
  CalenderViewWrapper,
  SelectMonthAndYear,
  Title,
  DaysTitle,
  DaysContainer,
  Day,
  Today,
} from "../FormStyles";
import Row from "../../Row";
import Col from "../../Col";
import {
  JalaiWeekDayConvertor,
  daysJalaali,
  monthsJalaali,
  monthsJalaaliOptions,
} from "./jalaiiCalendarUtility";
import { SmallLabel } from "../../Typography/Label";
import { SmallParagraph } from "../../Typography/Paragraph";
import ArrowDownIcon from "../../Icons/ArrowDownIcon";
import { GhostButton } from "../../Button/GhostButton";
import Select from "../Select";

interface Props {
  size: "xl" | "lg" | "md" | "sm" | "xs";
  selectedDateDetails: SelectedDateDetailsType;
  value: string;
  onSelect: any;
  setExpand: any;
  changeYearHandler: any;
  changeMonthHandler: any;
}

interface SelectedDateDetailsType {
  year: string;
  month: string;
  day: string;
}

const CalendarView: React.FC<Props> = (props) => {
  const {
    size,
    selectedDateDetails,
    value,
    onSelect,
    setExpand,
    changeYearHandler,
    changeMonthHandler,
  } = props;

  const theme = useSelector(selectTheme);

  const [currentDetails, setCurrentDetails] = useState({
    //ماه و سال نمایشی در تقویم
    year: "",
    month: "",
    day: "",
  });

  const now = Date.now();

  useEffect(() => {
    setCurrentDetails({
      year: selectedDateDetails.year || jmoment(now).format("jYYYY"),
      month: selectedDateDetails.month || jmoment(now).format("jMM"),
      // day: selectedDateDetails.day || jmoment(now).format("jDD"),
      day: "", //not used
    });
  }, [selectedDateDetails]);

  let currentYear = Number(currentDetails.year);
  let currentMonth = Number(currentDetails.month);

  let previousMonth = currentMonth === 1 ? 12 : currentMonth - 1; //ماه قبل
  let nextMonth = currentMonth === 12 ? 1 : currentMonth + 1; //ماه بعد

  let previousMonthYear = currentMonth === 1 ? currentYear - 1 : currentYear; //سال ماه قبل
  let nextMonthYear = currentMonth === 12 ? currentYear + 1 : currentYear; //سال ماه بعد

  let currentMonthLenght = jmoment.jDaysInMonth(currentYear, currentMonth - 1);
  let previousMonthLenght = jmoment.jDaysInMonth(
    previousMonthYear,
    previousMonth - 1
  );

  let startDay = jmoment(
    `${currentYear}-${currentMonth}-01`,
    "jYYYY-jMM-jDD"
  ).format("YYYY-MM-DD"); //اولین روز ماه
  let endDay = jmoment(
    `${currentYear}-${currentMonth}-${currentMonthLenght}`,
    "jYYYY-jMM-jDD"
  ).format("YYYY-MM-DD"); //اخرین روز ماه

  let firstDayInMonth = JalaiWeekDayConvertor(
    Number(moment(new Date(startDay)).day())
  );
  let lastDayInMonth = JalaiWeekDayConvertor(
    Number(moment(new Date(endDay)).day())
  );

  let daysNumber = currentMonthLenght + firstDayInMonth + (6 - lastDayInMonth); //تعداد روزهای نمایشی
  const [arrayOfDays, setArrayOfDays] = useState<any[]>([]);

  useMemo(() => {
    let newList = [];
    for (let i = 1; i <= daysNumber; i++) {
      if (firstDayInMonth >= i) {
        let p_day = previousMonthLenght - firstDayInMonth + i;
        let p_month = previousMonth;
        let p_year = previousMonthYear;
        let previousMonthDays = {
          day: p_day,
          month: p_month,
          year: p_year,
          date: jmoment(
            `${p_year}-${p_month}-${p_day}`,
            "jYYYY-jMM-jDD"
          ).format("YYYY-MM-DD"),
          disable: true,
        };
        newList.push(previousMonthDays);
      } else if (
        firstDayInMonth < i &&
        i <= currentMonthLenght + firstDayInMonth
      ) {
        let c_day = i - firstDayInMonth;
        let c_month = currentMonth;
        let c_year = currentYear;
        let currentMonthDays = {
          day: c_day,
          month: c_month,
          year: c_year,
          date: jmoment(
            `${c_year}-${c_month}-${c_day}`,
            "jYYYY-jMM-jDD"
          ).format("YYYY-MM-DD"),
          disable: false,
        };
        newList.push(currentMonthDays);
      } else {
        let n_day = i - currentMonthLenght - firstDayInMonth;
        let n_month = nextMonth;
        let n_year = nextMonthYear;
        let nextMonthDays = {
          day: n_day,
          month: n_month,
          year: n_year,
          date: jmoment(
            `${n_year}-${n_month}-${n_day}`,
            "jYYYY-jMM-jDD"
          ).format("YYYY-MM-DD"),
          disable: true,
        };
        newList.push(nextMonthDays);
      }
      setArrayOfDays(newList);
    }
  }, [currentDetails]);

  const onSelectDate = (each: any) => {
    if (!each.disable) {
      onSelect(each.date);
      setExpand(false);
    }
  };

  const GoToPreviousMonth = () => {
    setCurrentDetails({
      year: previousMonthYear.toString(),
      month: previousMonth.toString(),
      day: "",
    });
  };

  const GoToNextMonth = () => {
    setCurrentDetails({
      year: nextMonthYear.toString(),
      month: nextMonth.toString(),
      day: "",
    });
  };

  const GoToToday = () => {
    setCurrentDetails({
      year: jmoment(now).format("jYYYY"),
      month: jmoment(now).format("jMM"),
      day: "",
    });
    onSelect(moment(now).format("YYYY-MM-DD"));
    setExpand(false);
  };

  const [yearList, setYearList] = useState<any>([]);

  useEffect(() => {
    if (currentYear) {
      let newList = [];
      for (let i = 1370; i <= currentYear + 50; i++) {
        newList.push({
          id: i,
          title: i,
        });
      }
      setYearList([...newList].reverse());
    }
  }, [currentYear]);

  return (
    <CalenderViewWrapper className="bict__CalenderWrapper" size={size}>
      <SelectMonthAndYear>
        <Col xl={11.5}>
          <Select
            size={"xs"}
            label={"سال"}
            name="year"
            value={selectedDateDetails.year}
            options={yearList}
            onSelect={(selected: any, name: any) =>
              changeYearHandler(selected.id)
            }
            onClear={(name: any) => changeYearHandler("")}
          />
        </Col>
        <Col xl={11.5}>
          <Select
            size={"xs"}
            label={"ماه"}
            name="month"
            value={selectedDateDetails.month}
            options={monthsJalaaliOptions}
            onSelect={(selected: any, name: any) =>
              changeMonthHandler(selected.id)
            }
            onClear={(name: any) => changeMonthHandler("")}
          />
        </Col>
      </SelectMonthAndYear>
      <Title>
        <Col className="prv-icon" onClick={GoToPreviousMonth}>
          <ArrowDownIcon />
        </Col>
        <Row className="title">
          <SmallLabel color={theme.primary600}>
            {monthsJalaali[currentMonth - 1]}
          </SmallLabel>
          &nbsp;
          <SmallLabel color={theme.primary600}>{currentYear}</SmallLabel>
        </Row>
        <Col className="next-icon" onClick={GoToNextMonth}>
          <ArrowDownIcon />
        </Col>
      </Title>
      <DaysTitle>
        <Row>
          {daysJalaali.map((each: string, index: number) => {
            return (
              <SmallParagraph key={index} color={theme.gray400}>
                {each}
              </SmallParagraph>
            );
          })}
        </Row>
      </DaysTitle>
      <DaysContainer>
        {arrayOfDays.map((each, index) => {
          let selected = each.date === value?.slice(0, 10); //
          return (
            <Day
              key={index}
              disabled={each.disable}
              selected={selected}
              onClick={() => onSelectDate(each)}
            >
              <SmallLabel color={selected ? theme.white : theme.gray800}>
                {each.day}
              </SmallLabel>
            </Day>
          );
        })}
      </DaysContainer>
      <Today>
        <GhostButton
          size={"xs"}
          width={"60px"}
          color={"primary"}
          title={"امروز"}
          type={"button"}
          onClick={GoToToday}
        />
      </Today>
    </CalenderViewWrapper>
  );
};

export default CalendarView;
