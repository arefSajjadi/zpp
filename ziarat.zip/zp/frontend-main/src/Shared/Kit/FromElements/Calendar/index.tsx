import React, { useEffect, useRef, useState } from "react";
import { Formik } from "formik";
import MaskInput from "react-input-mask";
import moment from "moment-jalaali";
import jmoment from "moment-jalaali";
import { CalendarWrapper, Form, InputsAndIconConatiner } from "../FormStyles";
import Row from "../../Row";
import Col from "../../Col";
import Input from "../Input";
import CalendarIcon from "../../Icons/CalendarIcon";
import CrossIcon from "../../Icons/CrossIcon";
import { CalendarSchema } from "./Schema";
import FormHandlers from "../../../../Utils/FormHandlers";
import CalendarView from "./CalendarView";
import useIsMobile from "../../../../Utils/Responsive";
import {
  ResizingForResponsive1920,
  ResizingForResponsive768,
} from "../../ResizingForResponsive";

interface Props {
  className?: string;
  size: "xl" | "lg" | "md" | "sm" | "xs";
  label: string;
  name: string;
  value: string;
  error?: any; //string | null,
  disabled?: boolean;
  onSelect: any;
  reset?: boolean;
  setReset?: any;
  inputType?: string;
}

const Calendar: React.FC<Props> = (props) => {
  const {
    className = "",
    // size,
    label,
    name,
    value, //تاریخ میلادی
    error = null,
    disabled = false,
    onSelect,
    reset = false,
    setReset = () => {},
    inputType = "text",
  } = props;

  const [size, setSize] = useState(props.size);

  const screenSize = useIsMobile();

  useEffect(() => {
    if (screenSize === "desktop-lg") {
      setSize(ResizingForResponsive1920(props.size));
    } else if (screenSize === "tablet") {
      setSize(ResizingForResponsive768(props.size));
    } else {
      setSize(props.size);
    }
  }, [screenSize]);

  // const [selectedDateDetails, setSelectedDateDetails] = useState({ //تاریخ نمایشی در input
  //     year: "",
  //     month: "",
  //     day: "",
  // })

  const [selectedDateDetails, setSelectedDateDetails] = useState({
    //تاریخ نمایشی در input
    year: value ? jmoment(value).format("jYYYY") : "",
    month: value ? jmoment(value).format("jM") : "",
    day: value ? jmoment(value).format("jD") : "",
  });

  useEffect(() => {
    if (value) {
      setSelectedDateDetails({
        year: jmoment(value).format("jYYYY"),
        month: jmoment(value).format("jM"),
        day: jmoment(value).format("jD"),
      });
      setBaseInputClassName("bict__calendar__input_has_value");
    } else {
      setSelectedDateDetails({
        year: selectedDateDetails.year,
        month: selectedDateDetails.month,
        day: selectedDateDetails.day,
      });
    }
  }, [value]);

  useEffect(() => {
    if (reset) {
      setSelectedDateDetails({
        year: "",
        month: "",
        day: "",
      });
      setTimeout(() => {
        setReset && setReset(false);
      }, 3000);
    }
  }, [reset]);

  //clear
  useEffect(() => {
    if (
      selectedDateDetails.year === "" &&
      selectedDateDetails.month === "" &&
      selectedDateDetails.day === ""
    ) {
      onSelect("");
    }
  }, [selectedDateDetails]);

  const [expand, setExpand] = useState(false);
  const onToggleExpandHanlder = () => {
    if (!disabled) {
      setExpand(!expand);
    }
  };

  //clear
  const onClear = () => {
    if (!disabled) {
      onSelect("");
      setSelectedDateDetails({
        year: "",
        month: "",
        day: "",
      });
    }
  };

  const [baseInputClassName, setBaseInputClassName] = useState("");
  const onFocus = () => {
    let hasValue =
      selectedDateDetails.year ||
      selectedDateDetails.month ||
      selectedDateDetails.day
        ? true
        : false;
    setExpand(true);
    setBaseInputClassName(`
            bict__calendar__input_focus
                ${error ? "bict__calendar__input_has_error" : ""}
                ${hasValue ? "bict__calendar__input_has_value" : ""}
        `);
  };
  const onFocusOut = () => {
    let hasValue =
      selectedDateDetails.year ||
      selectedDateDetails.month ||
      selectedDateDetails.day
        ? true
        : false;
    setBaseInputClassName(`
            ${error ? "bict__calendar__input_has_error" : ""}
            ${hasValue ? "bict__calendar__input_has_value" : ""}
        `);
  };

  const changeYearHandler = (value: string) => {
    setSelectedDateDetails({
      ...selectedDateDetails,
      year: value,
    });
    if (value.length === 4) {
      //?
      if (
        checkValid(value, selectedDateDetails.month, selectedDateDetails.day)
      ) {
        setDate(value, selectedDateDetails.month, selectedDateDetails.day);
      } else {
        onSelect("");
      }
    }
  };

  const changeMonthHandler = (value: string) => {
    setSelectedDateDetails({
      ...selectedDateDetails,
      month: value,
    });
    if (checkValid(selectedDateDetails.year, value, selectedDateDetails.day)) {
      setDate(selectedDateDetails.year, value, selectedDateDetails.day);
    } else {
      onSelect("");
    }
  };

  const changeDayHandler = (value: string) => {
    setSelectedDateDetails({
      ...selectedDateDetails,
      day: value,
    });
    if (
      checkValid(selectedDateDetails.year, selectedDateDetails.month, value)
    ) {
      setDate(selectedDateDetails.year, selectedDateDetails.month, value);
    } else {
      onSelect("");
    }
  };

  const checkValid = (year: string, month: string, day: string) => {
    let date = moment(`${year}-${month}-${day}`, "jYYYY-jMM-jDD").format(
      "YYYY-MM-DD"
    );
    let isValid = moment(date).isValid();
    return isValid;
  };

  const setDate = (year: string, month: string, day: string) => {
    let date = moment(`${year}-${month}-${day}`, "jYYYY-jMM-jDD").format(
      "YYYY-MM-DD"
    ); //تاریخ میلادی
    onSelect(date);
  };

  const calendarRef = useRef<HTMLInputElement | null>(null);
  useEffect(() => {
    function handleClickOutside(event: any) {
      if (calendarRef.current && !calendarRef.current.contains(event.target)) {
        setExpand(false);
      }
    }
    document.addEventListener("mouseup", handleClickOutside);
    return () => {
      document.removeEventListener("mouseup", handleClickOutside);
    };
  }, []);

  return (
    <CalendarWrapper className={`bict__calendar__wrapper ${className}`}>
      <div ref={calendarRef}>
        <Formik
          initialValues={{
            year: selectedDateDetails?.year,
            month: selectedDateDetails?.month,
            day: selectedDateDetails?.day,
          }}
          validationSchema={CalendarSchema}
          isInitialValid={true}
          enableReinitialize={true}
          onSubmit={() => {}}
        >
          {(formik) => (
            <Form onSubmit={formik.handleSubmit}>
              <Input
                inputClassName={baseInputClassName}
                size={props.size}
                label={label}
                name={name}
                value={""}
                error={error}
                onChange={() => {}}
                onBlur={() => {}}
                disabled={disabled}
              />
              <InputsAndIconConatiner
                size={size}
                yearError={formik.errors.year}
                monthError={formik.errors.month}
                dayError={formik.errors.day}
              >
                <Row>
                  <MaskInput
                    name={"year"}
                    value={formik.values.year}
                    onChange={(e: any) =>
                      FormHandlers.onChange(
                        e,
                        formik,
                        (e: any, name: any, value: any) => {
                          changeYearHandler(value);
                        }
                      )
                    }
                    mask={"9999"}
                    maskChar={""}
                    autoComplete={"off"}
                    disabled={disabled}
                    onFocus={onFocus}
                    onBlur={onFocusOut}
                    type={inputType}
                  />
                  <span>
                    {selectedDateDetails?.year &&
                      selectedDateDetails?.month &&
                      "-"}
                  </span>
                  <MaskInput
                    name={"month"}
                    value={formik.values.month}
                    onChange={(e: any) =>
                      FormHandlers.onChange(
                        e,
                        formik,
                        (e: any, name: any, value: any) => {
                          changeMonthHandler(value);
                        }
                      )
                    }
                    mask={"99"}
                    maskChar={""}
                    autoComplete={"off"}
                    disabled={disabled}
                    onFocus={onFocus}
                    onBlur={onFocusOut}
                    type={inputType}
                  />
                  <span>
                    {selectedDateDetails?.month &&
                      selectedDateDetails?.day &&
                      "-"}
                  </span>
                  <MaskInput
                    name={"day"}
                    value={formik.values.day}
                    onChange={(e: any) =>
                      FormHandlers.onChange(
                        e,
                        formik,
                        (e: any, name: any, value: string) => {
                          changeDayHandler(value);
                        }
                      )
                    }
                    mask={"99"}
                    maskChar={""}
                    autoComplete={"off"}
                    disabled={disabled}
                    onFocus={onFocus}
                    onBlur={onFocusOut}
                    type={inputType}
                  />
                </Row>
                {(selectedDateDetails.year ||
                  selectedDateDetails.month ||
                  selectedDateDetails.day) && (
                  <Col className="calendar__close__button" onClick={onClear}>
                    <CrossIcon />
                  </Col>
                )}
                <Col
                  className="calendar__view__button"
                  onClick={onToggleExpandHanlder}
                >
                  <CalendarIcon />
                </Col>
              </InputsAndIconConatiner>
            </Form>
          )}
        </Formik>
        {expand && (
          <CalendarView
            size={size}
            selectedDateDetails={selectedDateDetails}
            value={value}
            onSelect={onSelect}
            setExpand={setExpand}
            changeYearHandler={changeYearHandler}
            changeMonthHandler={changeMonthHandler}
          />
        )}
      </div>
    </CalendarWrapper>
  );
};

export default Calendar;
