import React, { forwardRef, ReactNode, useEffect, useState } from "react";
import MaskInput from "react-input-mask";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import { FormError, FormGroup } from "../FormStyles";
import Col from "../../Col";
import { XSmallParagraph, XXSmallParagraph } from "../../Typography/Paragraph";
import { XSmallMonoParagraph } from "../../Typography/MonoParagraph";
import WarningIcon from "../../Icons/WarningIcon";
import useIsMobile from "../../../../Utils/Responsive";
import {
  ResizingForResponsive1920,
  ResizingForResponsive768,
} from "../../ResizingForResponsive";
import TooltipWithIcon from "../../Tooltip/TooltipWithIcon";

interface Props {
  className?: string;
  inputClassName?: string;
  size: "xl" | "lg" | "md" | "sm" | "xs";
  label: string | ReactNode;
  placeholder?: string;
  name: string;
  value: string | number;
  error?: any; //string | null,
  onChange: any;
  onBlur: any;
  mask?: string;
  maskChar?: string;
  autoComplete?: string;
  disabled?: boolean;
  type?: string;
  id?: string;
  acceptFile?: string; //برای type = file - محدودیت نوع فایل برای آپلود
  //برای حالت server side select
  isServerSideSelect?: boolean;
  totalCountResult?: number;
  countResult?: number;
  showInfo?: boolean;
  infoDescription?: string;
  tooltipPosition?: "top" | "bottom" | "left" | "right";
  //
  onClick?: any;
  ref?: any;
  readOnly?: boolean;
  InputIcon?: React.FC<{ color?: string }>;
  iconProps?: { color?: string };
}

const Input: React.FC<Props> = forwardRef((props, ref: any) => {
  const {
    className = "",
    inputClassName = "",
    // size,
    label,
    placeholder,
    name,
    value,
    error = null,
    onChange,
    onBlur,
    mask = "",
    maskChar = "",
    autoComplete = "off",
    disabled = false,
    type = "text",
    id,
    acceptFile = "",
    isServerSideSelect = false,
    totalCountResult = 0,
    countResult = 0,
    showInfo = false,
    infoDescription = "",
    tooltipPosition = "left",
    onClick,
    readOnly = false,
    InputIcon,
    iconProps,
  } = props;

  const theme = useSelector(selectTheme);

  const [size, setSize] = useState(props.size);

  const screenSize = useIsMobile();

  useEffect(() => {
    if (screenSize === "desktop-lg") {
      setSize(ResizingForResponsive1920(props.size));
    } else if (screenSize === "tablet") {
      setSize(ResizingForResponsive768(props.size));
    } else {
      setSize(props.size);
    }
  }, [screenSize]);

  return (
    <FormGroup className={`bict__formGroup ${className}`} size={size}>
      <Col>
        <MaskInput
          readOnly={readOnly}
          ref={ref}
          id={id}
          className={`bict__formInput ${inputClassName} ${
            value || value === 0 ? "has-value" : ""
          } ${error ? "has-error" : ""}`}
          type={type}
          name={name}
          value={value}
          onChange={onChange}
          onBlur={onBlur}
          mask={mask}
          maskChar={maskChar}
          autoComplete={autoComplete}
          disabled={disabled}
          placeholder={placeholder}
          accept={type === "file" && acceptFile ? acceptFile : ""}
          onClick={onClick ? onClick : () => {}}
        />
        <XSmallParagraph className="bict__formLabel" color={theme.gray700}>
          {InputIcon ? <InputIcon {...iconProps} /> : <></>}
          <span style={{ marginRight: "0.25rem" }}>{label}</span>
          {showInfo && infoDescription && (
            <>
              &nbsp; &nbsp;
              <TooltipWithIcon
                name={name + Math.random()}
                description={infoDescription}
                position={tooltipPosition}
              />
            </>
          )}
        </XSmallParagraph>
        {isServerSideSelect && (
          <XSmallMonoParagraph
            className="bict__searchCountResult"
            color={theme.gray700}
          >
            {countResult + " / " + totalCountResult}
          </XSmallMonoParagraph>
        )}
      </Col>
      {error && (
        <FormError className="bict__formError">
          <WarningIcon />
          <XXSmallParagraph color={theme.negative600}>{error}</XXSmallParagraph>
        </FormError>
      )}
    </FormGroup>
  );
});

Input.displayName = "Input";
export default Input;
