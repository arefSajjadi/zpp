import React, {
  useEffect,
  useState,
  useRef,
  ElementType,
  ReactNode,
} from "react";
import { useSelector } from "react-redux";
import { selectTheme } from "../../../../Redux/App/Selectors";
import {
  SelectWrapper,
  SelectIconsContainer,
  ToggleIconContainer,
  ClearIconContainer,
  OptionWrapper,
  HeaderContainer,
  OptionCell,
  OptionContainer,
  MobileOptionWrapper,
} from "../FormStyles";
import Input from "../Input";
import NoItem from "../../NoItem";
import { XXSmallLabel } from "../../Typography/Label";
import ArrowDownIcon from "../../Icons/ArrowDownIcon";
import CrossIcon from "../../Icons/CrossIcon";
import SearchIcon from "../../Icons/SearchIcon";
import Loading from "../../Loading";
import SelectOption from "./SelectOption";
import useIsMobile from "../../../../Utils/Responsive";
import {
  ResizingForResponsive1920,
  ResizingForResponsive768,
} from "../../ResizingForResponsive";
import Modal from "../../Modal";

interface Props {
  className?: string;
  havePadding?: boolean;
  size: "xl" | "lg" | "md" | "sm" | "xs";
  label: string;
  name: string;
  value: null | number | string;
  error?: any; //string | null,
  autoComplete?: string;
  disabled?: boolean;
  options: any[];
  displayTitle?: string;
  displayTitle2?: string;
  displayId?: string;
  columns?: columnsProps[];
  onSelect: any;
  onDeSelect?: any; //فقط برای حالت multi
  onClear?: any;
  searchType?: string; //clientSide - serverSide
  searchApi?: any;
  searchLoading?: boolean;
  multi?: boolean; //امکان انتخاب چند مورد
  inputType?: string;
  searchable?: boolean;
  //برای حالت server side
  totalCountResult?: number;
  countResult?: number;
  showInfo?: boolean;
  infoDescription?: string;
  tooltipPosition?: "left" | "bottom" | "top" | "right";
  // برای lazy loading
  haveLazyLoading?: boolean;
  GetMoreOption?: any;
  OptionsIcon?: any;
  readOnly?: boolean;
  InputIcon?: React.FC<{ color?: string }>;
  iconProps?: { color?: string };
}

export type columnsProps = {
  size: number;
  headerTitle: string;
  displayTitle: string;
};

const Select: React.FC<Props> = (props) => {
  const {
    className = "",
    havePadding = false,
    // size,
    label,
    name,
    value,
    error = null,
    autoComplete = "off",
    disabled = false,
    options,
    displayTitle = "title", //فیلد نمایشی در input
    displayTitle2,
    displayId = "id", //فیلد id در لیست
    columns = [
      {
        size: 1,
        headerTitle: "",
        displayTitle: "title", //فیلد نمایشی در لیست
      },
    ],
    onSelect,
    onDeSelect,
    onClear,
    searchType = "clientSide",
    searchApi,
    searchLoading = false,
    multi = false,
    inputType = "text",
    searchable = true,
    totalCountResult,
    countResult,
    showInfo = false,
    infoDescription = "",
    tooltipPosition = "left",
    haveLazyLoading = false,
    GetMoreOption,
    OptionsIcon,
    readOnly = false,
    InputIcon,
    iconProps,
  } = props;

  const [size, setSize] = useState(props.size);

  const screenSize = useIsMobile();

  useEffect(() => {
    if (screenSize === "desktop-lg") {
      setSize(ResizingForResponsive1920(props.size));
    } else if (screenSize === "tablet") {
      setSize(ResizingForResponsive768(props.size));
    } else {
      setSize(props.size);
    }
  }, [screenSize]);

  const theme = useSelector(selectTheme);
  const isClientSide = searchType === "clientSide" ? true : false;
  const isServerSide = searchType === "serverSide" ? true : false;

  const [optionsList, setOptionsList] = useState<any[]>([]);
  const [expand, setExpand] = useState(false);
  const [inputValue, setInputValue] = useState("");
  const [_value, setValue] = useState<any>(null); //null | string | string[]

  useEffect(() => {
    if (options) {
      setOptionsList(options);
    } else {
      setOptionsList([]);
    }
  }, [options]);

  useEffect(() => {
    if (value === null || value === "") {
      // if (!value) {
      setValue(null);
      if (isClientSide) {
        setInputValue("");
      }
    } else {
      if (!multi) {
        setValue(value?.toString()); //"1"
      } else {
        //multi
        if (typeof value === "number") {
          //عدد تکی
          setValue([value?.toString()]); //["1"]
        } else if (typeof value === "string" && value !== "") {
          //رشته اعداد
          setValue(value?.split(",")); //["1"] - ["1", "2", "3"]
        } else {
          setValue("");
        }
      }
    }
  }, [value]);

  useEffect(() => {
    //مقدار دهی input
    if (optionsList && _value) {
      if (!multi) {
        let selectedItem = optionsList.filter(
          (each) => each[displayId].toString() === _value
        )[0];
        if (selectedItem) {
          setInputValue(
            displayTitle && selectedItem[displayTitle]
              ? displayTitle2 && selectedItem[displayTitle2]
                ? selectedItem[displayTitle] +
                  " - " +
                  selectedItem[displayTitle2]
                : selectedItem[displayTitle]
              : displayTitle2 && selectedItem[displayTitle2]
              ? selectedItem[displayTitle2]
              : ""
          );
        } else {
          setInputValue(inputValue); //
        }
      } else {
        //multi
        let selectedItemsCount = _value.length;
        if (selectedItemsCount === 0) {
          setInputValue("");
        } else {
          setInputValue(`${selectedItemsCount} مورد انتخاب شده`);
        }
      }
    }
  }, [optionsList, _value]);

  const onChangeInputHandler = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!disabled && searchable) {
      setExpand(true);
      onClear(name); //
      // setValue(null)
      setInputValue(e.target.value);
      setOptionsList(options);
      if (isClientSide) {
        const checkInclude = (each: any) => {
          let dataSearchValue = false;
          for (let i = 0; i < columns.length; i++) {
            let str = `${each[columns[i].displayTitle]}`;
            dataSearchValue = str.includes(e.target.value);
            if (dataSearchValue) {
              break;
            }
          }
          return dataSearchValue;
        };
        let filterData = [];
        for (let i = 0; i < options.length; i++) {
          if (checkInclude(options[i])) {
            filterData.push(options[i]);
          }
        }
        setOptionsList(filterData);
      } else {
        //serverSide
        searchApi(e.target.value);
      }
    }
  };

  const onToggleExpandHanlder = () => {
    if (!disabled) {
      setExpand(!expand);
    }
  };

  const onSelectHanlder = (option: any) => {
    //option مورد انتخاب شده
    if (!disabled) {
      if (!multi) {
        setExpand(false);
        onSelect(option, name);
      } else {
        //multi
        let newList = [];
        if (_value) {
          newList = _value;
          newList.push(option[displayId].toString());
        } else {
          newList.push(option[displayId].toString());
        }
        onSelect(newList, name);
      }
    }
  };

  const onClearHandler = () => {
    if (!disabled) {
      setInputValue("");
      setValue(null);
      onClear(name);
      setOptionsList(options);
      if (isServerSide) {
        searchApi("");
      }
    }
  };

  const onDeSelectHanlder = (option: any) => {
    //فقط برای حالت multi
    if (!disabled) {
      onDeSelect(option, name);
      if (_value.length === 1) {
        //آخرین مورد انتخابی DeSelect شد
        setInputValue("");
      }
    }
  };

  const selectRef = useRef<HTMLInputElement | null>(null);
  useEffect(() => {
    function handleClickOutside(event: any) {
      if (selectRef.current && !selectRef.current.contains(event.target)) {
        setExpand(false);
      }
    }
    document.addEventListener("mouseup", handleClickOutside);
    return () => {
      document.removeEventListener("mouseup", handleClickOutside);
    };
  }, []);

  // برای lazy loading
  const onScrollDiv = (item: any) => {
    const element = item.target;
    if (haveLazyLoading) {
      let lastScrollTop = 0;
      if (element) {
        element.onscroll = () => {
          if (element.scrollTop < lastScrollTop) {
            // upscroll
            return;
          }
          lastScrollTop = element.scrollTop <= 0 ? 0 : element.scrollTop;
          if (
            element.scrollTop + element.offsetHeight >=
            element.scrollHeight
          ) {
            GetMoreOption();
          }
        };
      }
    }
  };

  return (
    <SelectWrapper
      className={`bict__select__wrapper ${className}`}
      searchable={searchable}
      expand={expand}
    >
      <div ref={selectRef}>
        <Input
          size={props.size}
          label={label}
          name={name}
          value={inputValue}
          error={error}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
            onChangeInputHandler(e)
          }
          // onBlur={() => setExpand(false)}
          onBlur={() => {}}
          autoComplete={autoComplete}
          disabled={disabled}
          type={inputType}
          isServerSideSelect={isServerSide ? true : false}
          totalCountResult={totalCountResult}
          countResult={countResult}
          onClick={onToggleExpandHanlder}
          showInfo={showInfo}
          infoDescription={infoDescription}
          tooltipPosition={tooltipPosition}
          readOnly={readOnly}
          InputIcon={InputIcon}
          iconProps={iconProps}
        />
        <SelectIconsContainer size={size}>
          {_value && onClear && (
            <ClearIconContainer size={size} onClick={onClearHandler}>
              <CrossIcon />
            </ClearIconContainer>
          )}
          <ToggleIconContainer
            expand={expand}
            onClick={onToggleExpandHanlder}
            className={isClientSide ? "arrow-down-icon" : "search-icon"}
          >
            {isClientSide ? <ArrowDownIcon /> : <SearchIcon />}
          </ToggleIconContainer>
        </SelectIconsContainer>
        {expand && screenSize !== "mobile" ? (
          <OptionWrapper className="bict__select__optionWrapper" size={size}>
            {columns && columns.length !== 0 && (
              <HeaderContainer className="bict__select__headerContainer">
                {columns.map((cell, i) => {
                  return (
                    cell.headerTitle && (
                      <OptionCell
                        className="bict__select__optionCell"
                        key={i}
                        flex={columns ? columns[i].size : 1}
                      >
                        <XXSmallLabel color={theme.gray600}>
                          {cell.headerTitle}
                        </XXSmallLabel>
                      </OptionCell>
                    )
                  );
                })}
              </HeaderContainer>
            )}

            <OptionContainer
              className="bict__select__optionContainer"
              onScroll={onScrollDiv}
            >
              {searchLoading ? (
                <OptionCell className="bict__select__optionCell" flex={1}>
                  <Loading color={theme.gray600} />
                </OptionCell>
              ) : optionsList && optionsList.length !== 0 ? (
                optionsList.map((option, index) => {
                  return (
                    <SelectOption
                      key={option[displayId]}
                      size={props.size}
                      _value={_value}
                      option={option}
                      displayId={displayId}
                      onSelectHanlder={onSelectHanlder}
                      onDeSelectHanlder={onDeSelectHanlder}
                      columns={columns}
                      multi={multi}
                      OptionsIcon={OptionsIcon}
                      havePadding={havePadding}
                    />
                  );
                })
              ) : (
                <OptionCell className="bict__select__optionCell" flex={1}>
                  <NoItem center />
                </OptionCell>
              )}
            </OptionContainer>
          </OptionWrapper>
        ) : (
          <Modal
            visible={expand}
            onClose={() => setExpand(false)}
            size="xs"
            closable={true}
            headerTitle={label}
            height="70%"
          >
            <OptionWrapper className="bict__select__optionWrapper" size={size}>
              {columns && columns.length !== 0 && (
                <HeaderContainer className="bict__select__headerContainer">
                  {columns.map((cell, i) => {
                    return (
                      cell.headerTitle && (
                        <OptionCell
                          className="bict__select__optionCell"
                          key={i}
                          flex={columns ? columns[i].size : 1}
                        >
                          <XXSmallLabel color={theme.gray600}>
                            {cell.headerTitle}
                          </XXSmallLabel>
                        </OptionCell>
                      )
                    );
                  })}
                </HeaderContainer>
              )}
              <MobileOptionWrapper>
                <OptionContainer
                  className="bict__select__optionContainer"
                  onScroll={onScrollDiv}
                >
                  {searchLoading ? (
                    <OptionCell className="bict__select__optionCell" flex={1}>
                      <Loading color={theme.gray600} />
                    </OptionCell>
                  ) : optionsList && optionsList.length !== 0 ? (
                    optionsList.map((option, index) => {
                      return (
                        <SelectOption
                          key={option[displayId]}
                          size={props.size}
                          _value={_value}
                          option={option}
                          displayId={displayId}
                          onSelectHanlder={onSelectHanlder}
                          onDeSelectHanlder={onDeSelectHanlder}
                          columns={columns}
                          multi={multi}
                          OptionsIcon={OptionsIcon}
                        />
                      );
                    })
                  ) : (
                    <OptionCell className="bict__select__optionCell" flex={1}>
                      <NoItem center />
                    </OptionCell>
                  )}
                </OptionContainer>
              </MobileOptionWrapper>
            </OptionWrapper>
          </Modal>
        )}
      </div>
    </SelectWrapper>
  );
};

export default Select;
