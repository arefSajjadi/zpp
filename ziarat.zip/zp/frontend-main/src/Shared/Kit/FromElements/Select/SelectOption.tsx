import React from "react";
import { useSelector } from "react-redux";
import { selectTheme } from "../../../../Redux/App/Selectors";
import { OptionCell, Option } from "../FormStyles";
import {
  SmallParagraph,
  XSmallParagraph,
  XXSmallParagraph,
} from "../../Typography/Paragraph";
import Checkbox from "../Checkbox";
import { columnsProps } from ".";
import Row from "../../Row";
import LocationIcon from "@/Assets/Icons/LocationIcon";

interface Props {
  size: "xl" | "lg" | "md" | "sm" | "xs";
  option: any;
  displayId: string;
  onSelectHanlder: any;
  onDeSelectHanlder: any;
  columns: columnsProps[];
  multi: boolean;
  _value: null | string | string[];
  OptionsIcon?: any;
  havePadding?: boolean;
}

const SelectOption: React.FC<Props> = (props) => {
  const {
    size,
    _value,
    option,
    displayId,
    onSelectHanlder,
    onDeSelectHanlder,
    columns,
    multi,
    OptionsIcon,
    havePadding = false,
  } = props;

  const theme = useSelector(selectTheme);

  const checkSelected = () => {
    if (_value) {
      if (_value.includes(option[displayId].toString())) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  };

  const onOptionClick = () => {
    if (multi) {
      if (!checkSelected()) {
        onSelectHanlder(option);
      } else {
        onDeSelectHanlder(option);
      }
    } else {
      onSelectHanlder(option);
    }
  };

  return (
    <Option
      havePadding={havePadding}
      className="bict__select__option"
      onClick={onOptionClick}
    >
      {columns &&
        columns.length !== 0 &&
        columns.map((cell, i) => {
          return (
            <OptionCell
              className="bict__select__optionCell"
              key={option[displayId] + "-" + i}
              flex={cell.size || 1}
            >
              {multi ? (
                <Checkbox
                  size={size}
                  checked={checkSelected()}
                  text={option[cell.displayTitle]}
                  onClick={() => {}}
                />
              ) : (
                <Row className="bict__select__optionCell__paragraph">
                  {OptionsIcon && <OptionsIcon />}
                  <SmallParagraph color={theme.gray800}>
                    {option[cell.displayTitle]}
                  </SmallParagraph>
                </Row>
              )}
            </OptionCell>
          );
        })}
    </Option>
  );
};

export default SelectOption;
