import React, { useState, useEffect, useRef } from "react";
import { MainContainer } from "./styles";
import Col from "../../Col";
import Input from "../Input";
import Calendar from "../Calendar";
import DateTimeController from "../../../../Utils/DateTimeController";
import CalendarIcon from "../../Icons/CalendarIcon";
import CrossIcon from "../../Icons/CrossIcon";
import useIsMobile from "../../../../Utils/Responsive";
import {
  ResizingForResponsive1920,
  ResizingForResponsive768,
} from "../../ResizingForResponsive";
import { OptionWrapper } from "../FormStyles";

interface DropDownInputProps {
  mode?: "date" | "normal";

  mainLabel?: string;
  size: "xl" | "lg" | "md" | "sm" | "xs";
  mainInputDisabled?: boolean;

  fromClassName?: string;
  fromInputClassName?: string;
  fromLabel?: string;
  fromPlaceholder?: string;
  fromName: string;
  fromValue: string | number;
  fromError?: any; //string | null,
  fromOnChange?: any;
  fromOnBlur?: any;
  fromMask?: string;
  fromMaskChar?: string;
  fromAutoComplete?: string;
  fromDisabled?: boolean;
  fromType?: string;
  fromOnSelect?: any; //برای تقویم

  toClassName?: string;
  toInputClassName?: string;
  toLabel?: string;
  toPlaceholder?: string;
  toName: string;
  toValue: string | number;
  toError?: any; //string | null,
  toOnChange?: any;
  toOnBlur?: any;
  toMask?: string;
  toMaskChar?: string;
  toAutoComplete?: string;
  toDisabled?: boolean;
  toType?: string;
  toOnSelect?: any; //برای تقویم

  resetCalendar?: boolean;
  setResetCalendar?: any;
  formik: any;
}

const DropDownInput: React.FC<DropDownInputProps> = (props) => {
  const {
    mode = "normal",

    mainLabel = "بازه",
    // size = "xs",
    mainInputDisabled = false,

    fromClassName,
    fromInputClassName,
    fromLabel = "از",
    fromPlaceholder,
    fromName,
    fromValue,
    fromError,
    fromOnChange = () => {},
    fromOnBlur = () => {},
    fromMask,
    fromMaskChar,
    fromAutoComplete,
    fromDisabled,
    fromType,
    fromOnSelect = () => {},

    toClassName,
    toInputClassName,
    toLabel = "تا",
    toPlaceholder,
    toName,
    toValue,
    toError,
    toOnChange = () => {},
    toOnBlur = () => {},
    toMask,
    toMaskChar,
    toAutoComplete,
    toDisabled,
    toType,
    toOnSelect = () => {},

    resetCalendar,
    setResetCalendar,
    formik,
  } = props;

  const [size, setSize] = useState(props.size);

  const screenSize = useIsMobile();
  useEffect(() => {
    if (screenSize === "desktop-lg") {
      setSize(ResizingForResponsive1920(props.size));
    } else if (screenSize === "tablet") {
      setSize(ResizingForResponsive768(props.size));
    } else {
      setSize(props.size);
    }
  }, [screenSize]);

  const [visible, setVisible] = useState(false);
  const clickHandler = () => {
    setVisible(true);
  };

  const selectRef = useRef<HTMLInputElement | null>(null);
  useEffect(() => {
    function handleClickOutside(event: any) {
      if (selectRef.current && !selectRef.current.contains(event.target)) {
        setVisible(false);
      }
    }
    document.addEventListener("mouseup", handleClickOutside);
    return () => {
      document.removeEventListener("mouseup", handleClickOutside);
    };
  }, []);

  const onClear = () => {
    if (!mainInputDisabled) {
      if (mode == "date") {
        fromOnSelect("");
        toOnSelect("");
        setResetCalendar(true);
      } else {
        formik.setFieldValue(fromName, "");
        formik.setFieldValue(toName, "");
      }
    }
  };

  return (
    <MainContainer visible={visible} mode={mode}>
      <div className="mainInput" ref={selectRef} onClick={clickHandler}>
        <Input
          className="DropDown"
          inputClassName="DropDownInput"
          size={props.size}
          label={mainLabel}
          name={""}
          value={
            mode == "date"
              ? fromValue && toValue
                ? `${DateTimeController.parseToJDate(
                    fromValue?.toString(),
                    "jYYYY/jM/jD"
                  )} - ${DateTimeController.parseToJDate(
                    toValue?.toString(),
                    "jYYYY/jM/jD"
                  )}`
                : ""
              : fromValue && toValue
              ? `${fromValue} - ${toValue}`
              : ""
          }
          onChange={() => {}}
          onBlur={() => {}}
          disabled={mainInputDisabled}
        />
        {fromValue && toValue && (
          <Col className="cancel-icon" onClick={onClear}>
            <CrossIcon />
          </Col>
        )}
        {mode === "date" && (
          <Col className="calendar-icon">
            <CalendarIcon />
          </Col>
        )}
        {mode === "normal" ? (
          <OptionWrapper size={size} className="fromToContainer">
            <Input
              className={fromClassName}
              inputClassName={fromInputClassName}
              size={props.size}
              label={fromLabel}
              placeholder={fromPlaceholder}
              name={fromName}
              value={fromValue}
              error={fromError}
              onChange={fromOnChange}
              onBlur={fromOnBlur}
              mask={fromMask}
              maskChar={fromMaskChar}
              autoComplete={fromAutoComplete}
              disabled={fromDisabled}
              type={fromType}
            />
            <Input
              className={toClassName}
              inputClassName={toInputClassName}
              size={props.size}
              label={toLabel}
              placeholder={toPlaceholder}
              name={toName}
              value={toValue}
              error={toError}
              onChange={toOnChange}
              onBlur={toOnBlur}
              mask={toMask}
              maskChar={toMaskChar}
              autoComplete={toAutoComplete}
              disabled={toDisabled}
              type={toType}
            />
          </OptionWrapper>
        ) : (
          <OptionWrapper size={size} className="fromToContainer">
            <Calendar
              className={fromClassName}
              size={props.size}
              label={fromLabel}
              name={fromName}
              value={fromValue?.toString()}
              error={fromError}
              disabled={fromDisabled}
              onSelect={fromOnSelect}
              reset={resetCalendar}
              setReset={setResetCalendar}
            />
            <Calendar
              className={toClassName}
              size={props.size}
              label={toLabel}
              name={toName}
              value={toValue?.toString()}
              error={toError}
              disabled={toDisabled}
              onSelect={toOnSelect}
              reset={resetCalendar}
              setReset={setResetCalendar}
            />
          </OptionWrapper>
        )}
      </div>
    </MainContainer>
  );
};

export default DropDownInput;
