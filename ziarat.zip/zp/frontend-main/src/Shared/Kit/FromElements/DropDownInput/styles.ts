import React from "react";
import styled from "styled-components";
import Row from "../../Row";

interface MainContainerProps {
  visible: boolean;
  mode: string
}
export const MainContainer = styled(Row) <MainContainerProps> `
  position: relative;
  > div {
    width: 100%;
  }
  .DropDownInput {
    direction: ltr !important;
    text-align: center;
    padding-left: ${(props) => props.mode === "date" ? "40px" : "10px"};
    margin-right: auto;
    cursor: pointer;
  }
  .calendar-icon,
  .cancel-icon { 
    position: absolute;
    width: auto;
    height: 100%;
    top: 0;
    padding: 0 6px;
    margin-right: auto;
    cursor: pointer;
    z-index: 1;
  }
  .calendar-icon { //31
    left: 4px;
    svg {
      width: 19px;
      height: 19px;
      fill: ${(props) => props.theme.gray600};
    }
  }
  .cancel-icon { //23
    left: ${(props) => props.mode === "date" ? "37px" : "10px"};
    svg {
        width: 11px;
        height: 11px;
        fill: ${(props) => props.theme.gray600};
    }
  }
  .fromToContainer {
    padding: 20px 15px;
    gap: 30px;
    box-shadow: 0px 4px 4px 0px rgba(0, 0, 0, 0.05);
    opacity: ${(props) => (props.visible ? 1 : 0)};
    visibility: ${(props) => (props.visible ? "visible" : "hidden")};
    transition: ease 0.3s all;
  }
`