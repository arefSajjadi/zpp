import styled from "styled-components";
import Row from "../Row";

export const Wrapper = styled(Row)`
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 30px 0;
  gap: 8px;

  span {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background-color: ${(props) => props.theme.primary300};
    animation: bounce 1s infinite ease-in-out both;
    opacity: 0.5;

    &:nth-child(1) {
      animation-delay: -0.32s;
    }

    &:nth-child(2) {
      animation-delay: -0.16s;
    }

    &:nth-child(3) {
      animation-delay: 0s;
    }
  }

  @keyframes bounce {
    0%,
    80%,
    100% {
      transform: scale(0);
      opacity: 0.2;
    }
    40% {
      transform: scale(1);
      opacity: 0.5;
    }
  }
`;
