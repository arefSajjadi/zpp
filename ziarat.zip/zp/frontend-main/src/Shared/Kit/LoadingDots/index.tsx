import { Wrapper } from "./styles";

const LoadingDots = () => {
  return (
    <Wrapper>
      <span></span>
      <span></span>
      <span></span>
    </Wrapper>
  );
};

export default LoadingDots;
