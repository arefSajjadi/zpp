import styled from "styled-components";
import Col from "../Col";
import {
  ResizingForResponsive1920,
  ResizingForResponsive768,
} from "../ResizingForResponsive";

export const getButtonHeight = (size: "xl" | "lg" | "md" | "sm" | "xs") => {
  if (size === "xl") {
    return "54px";
  } else if (size === "lg") {
    return "50px";
  } else if (size === "md") {
    return "44px";
  } else if (size === "sm") {
    return "40px";
  } else if (size === "xs") {
    return "34px";
  }
};

const getFontSize = (size: "xl" | "lg" | "md" | "sm" | "xs") => {
  if (size === "xl") {
    return "18px";
  } else if (size === "lg") {
    return "16px";
  } else if (size === "md") {
    return "16px";
  } else if (size === "sm") {
    return "14px";
  } else if (size === "xs") {
    return "12px";
  }
};

const getIconSize = (size: "xl" | "lg" | "md" | "sm" | "xs") => {
  // if (size === "lg") {
  //     return "32px"
  // } else if (size === "md") {
  //     return "24px"
  // } else if (size === "sm") {
  //     return "20px"
  // } else if (size === "xs") {
  //     return "16px"
  // }
  if (size === "xl") {
    return "24px";
  } else if (size === "lg") {
    return "22px";
  } else if (size === "md") {
    return "20px";
  } else if (size === "sm") {
    return "18px";
  } else if (size === "xs") {
    return "16px";
  }
};

export const buttonCommonStyles = (
  width: string,
  size: "xl" | "lg" | "md" | "sm" | "xs",
  isCurve: boolean,
  disabled: boolean,
  loading: boolean,
  hasTilte: boolean,
  iconPosition?: "right" | "left"
) => {
  return `
        display: flex;
        justify-content: center;
        align-items: center;
        width: ${width};
        height: ${getButtonHeight(size)};
        border-radius: ${!isCurve ? "5px" : "10px"};
        ${cursor(disabled, loading)};
        outline: none; 
        svg {
            width: ${getIconSize(size)};
            height: ${getIconSize(size)};
            margin-right: ${hasTilte && iconPosition === "left" ? "8px" : 0}; 
            margin-left: ${hasTilte && iconPosition === "right" ? "8px" : 0}; 
        }
        .loadingio-spinner-rolling-1amlj6klx32 {
            width: ${getIconSize(size)};
            height: ${getIconSize(size)};
        } 
        transition: all 300ms;
        * {
            transition: all 300ms;
        }
        @media screen and (min-width: 1367px) {
            height: ${getButtonHeight(ResizingForResponsive1920(size) || "")};
            svg,
            .loadingio-spinner-rolling-1amlj6klx32 {
                width: ${getIconSize(ResizingForResponsive1920(size) || "")};
                height:  ${getIconSize(ResizingForResponsive1920(size) || "")};
            }
        }
        @media screen and (min-width: 481px) and (max-width: 768px) {
            height: ${getButtonHeight(ResizingForResponsive768(size) || "")};
            svg,
            .loadingio-spinner-rolling-1amlj6klx32 {
                width: ${getIconSize(ResizingForResponsive768(size) || "")};
                height:  ${getIconSize(ResizingForResponsive768(size) || "")};
            }
        }
    `;
};

const cursor = (disabled: boolean, loading: boolean) => {
  if (disabled || loading) {
    return `cursor: default`;
  } else {
    return `cursor: pointer`;
  }
};

interface ButtonLabelProps {
  size: "xl" | "lg" | "md" | "sm" | "xs";
}
export const ButtonLabel = styled(Col)<ButtonLabelProps>`
  width: auto;
  font-family: ${(props) => props.theme.fontFaNumRegular} !important;
  font-size: ${(props) => getFontSize(props.size)};
  line-height: 20px;
  @media screen and (min-width: 1367px) {
    font-size: ${(props) => getFontSize(ResizingForResponsive1920(props.size))};
  }
  @media screen and (min-width: 481px) and (max-width: 768px) {
    font-size: ${(props) => getFontSize(ResizingForResponsive768(props.size))};
  }
`;
