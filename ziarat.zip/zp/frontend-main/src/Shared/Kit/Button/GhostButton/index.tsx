import { GhostButtonStyle } from "./styles";
import { ButtonContent } from "../ButtonContent";
import { ButtonProps } from "../ButtonContent";

//ورودی ها:
// className?: string,
// size: "xl" | "lg" | "md" | "sm" | "xs",
// width: string,
// color: string,
// isCurve?: boolean,
// icon?: any,
// iconPosition?: "right" | "left",
// title?: string,
// loading?: boolean,
// disabled?: boolean,
// type?: string,
// onClick?: any

export const GhostButton: React.FC<ButtonProps> = (props) => {
  const {
    className = "",
    size,
    width,
    color,
    isCurve = false,
    iconPosition,
    title = "",
    loading = false,
    disabled = false,
    type = "submit",
    onClick,
  } = props;

  const onClickHandler = () => {
    if (!loading && onClick) {
      onClick();
    }
  };

  return (
    <GhostButtonStyle
      className={className}
      size={size}
      width={width}
      color={color}
      isCurve={isCurve}
      iconPosition={iconPosition}
      hasTilte={title ? true : false}
      loading={loading}
      disabled={disabled}
      type={type}
      onClick={onClickHandler}
    >
      {ButtonContent(props)}
    </GhostButtonStyle>
  );
};
