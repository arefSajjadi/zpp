import styled from "styled-components";

export const FloatingButtonStyle = styled.button`
  position: fixed;
  bottom: 20px;
  right: 20px;
  background-color: ${(props) => props.theme.primary400}; 
  color: white;
  border: none;
  border-radius: 50%;
  width: 60px;
  height: 60px;
  font-size: 30px;
  display: flex;
  justify-content: center;
  align-items: center;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  transition: background-color 0.3s;
  z-index: 99;

  &:hover {
    background-color: ${(props) => props.theme.primary600};
  }

  &:active {
    transform: scale(0.95);
  }
`;