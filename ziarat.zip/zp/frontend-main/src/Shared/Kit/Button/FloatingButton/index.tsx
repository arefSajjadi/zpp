import React from "react";
import { FloatingButtonStyle } from "@/Shared/Kit/Button/FloatingButton/styles";
import PhoneIcon from "@/Assets/Icons/PhoneIcon";
import { SUPPORT_PHONE } from "@/config/constants";

const FloatingButton = () => {
  const phoneNumber = SUPPORT_PHONE;

  const handleClick = () => {
    window.location.href = `tel:${phoneNumber}`;
  };
  return (
    <FloatingButtonStyle onClick={handleClick}>
      <PhoneIcon color={"white"} />
    </FloatingButtonStyle>
  );
};

export default FloatingButton;
