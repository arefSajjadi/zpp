import { useSelector } from "react-redux";
import { selectTheme } from "../../../Redux/App/Selectors";
import Loading from "../Loading";
import { ButtonLabel } from "./CommonStyles";

export type ButtonProps = {
  className?: string;
  width: string;
  size: "xl" | "lg" | "md" | "sm" | "xs";
  color: "primary" | "secondary" | "negative" | "positive" | "gray" | "info";
  isCurve?: boolean;
  icon?: any;
  iconPosition?: "right" | "left";
  title?: string;
  loading?: boolean;
  disabled?: boolean;
  type?: string;
  onClick?: any;
};

type LoadingProps = {
  loadingColorMode?: "light" | "dark";
};

export const ButtonContent: React.FC<ButtonProps & LoadingProps> = (props) => {
  const {
    size,
    icon,
    iconPosition = "left",
    title,
    loading,
    loadingColorMode = "light",
    color,
  } = props;

  const Icon = icon || null;

  const theme = useSelector(selectTheme);

  return loading ? (
    <Loading
      color={
        loadingColorMode === "light" ? theme.gray100 : theme[`${color}700`]
      }
    />
  ) : (
    <>
      {icon && title ? (
        iconPosition === "left" ? (
          <>
            <ButtonLabel className="label" size={size}>
              {title}
            </ButtonLabel>
            <Icon />
          </>
        ) : (
          <>
            <Icon />
            <ButtonLabel className="label" size={size}>
              {title}
            </ButtonLabel>
          </>
        )
      ) : icon ? (
        <Icon />
      ) : (
        <ButtonLabel className="label" size={size}>
          {title}
        </ButtonLabel>
      )}
    </>
  );
};
