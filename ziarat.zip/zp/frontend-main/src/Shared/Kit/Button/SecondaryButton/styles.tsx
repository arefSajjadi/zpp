import styled from "styled-components";
import { buttonCommonStyles } from "../CommonStyles";

const backgroundColor = (theme: any, color: string) => theme[color + "50"];
const hoverBackgroundColor = (theme: any, color: string) =>
  theme[color + "100"];
const focusBackgroundColor = (theme: any, color: string) =>
  theme[color + "200"];
const disabledBackgroundColor = (theme: any, color: string) => theme.gray100;
const loadingBackgroundColor = (theme: any, color: string) =>
  theme[color + "200"];

const _color = (theme: any, color: string) => theme[color + "600"];
const hoverColor = (theme: any, color: string) => theme[color + "600"];
const focusColor = (theme: any, color: string) => theme[color + "700"];
const disabledColor = (theme: any, color: string) => theme.gray300;
// const loadingColor = ""

// const border = () => "none";
// const hoverBorder = () => "none";
// const focusBorder = () => "none";
// const disabledBorder = () => "none";
// const loadingBorder = () => "none";

const getBackgroundColor = (
  theme: any,
  color: string,
  disabled: boolean,
  loading: boolean
) => {
  if (disabled) {
    return disabledBackgroundColor(theme, color);
  } else if (loading) {
    return loadingBackgroundColor(theme, color);
  } else {
    return backgroundColor(theme, color);
  }
};

const getHoverBackgroundColor = (
  theme: any,
  color: string,
  disabled: boolean,
  loading: boolean
) => {
  if (disabled) {
    return disabledBackgroundColor(theme, color);
  } else if (loading) {
    return loadingBackgroundColor(theme, color);
  } else {
    return hoverBackgroundColor(theme, color);
  }
};

const getFocusBackgroundColor = (
  theme: any,
  color: string,
  disabled: boolean,
  loading: boolean
) => {
  if (disabled) {
    return disabledBackgroundColor(theme, color);
  } else if (loading) {
    return loadingBackgroundColor(theme, color);
  } else {
    return focusBackgroundColor(theme, color);
  }
};

const getColor = (theme: any, color: string, disabled: boolean) => {
  if (disabled) {
    return disabledColor(theme, color);
  } else {
    return _color(theme, color);
  }
};

const getHoverColor = (theme: any, color: string, disabled: boolean) => {
  if (disabled) {
    return disabledColor(theme, color);
  } else {
    return hoverColor(theme, color);
  }
};

const getFocusColor = (theme: any, color: string, disabled: boolean) => {
  if (disabled) {
    return disabledColor(theme, color);
  } else {
    return focusColor(theme, color);
  }
};

interface ButtonStyleProps {
  width: string;
  size: "xl" | "lg" | "md" | "sm" | "xs";
  color: string;
  isCurve: boolean;
  iconPosition?: "right" | "left";
  hasTilte: boolean;
  loading: boolean;
  disabled: boolean;
  type: string;
}

export const SecondaryButtonStyle = styled.button<ButtonStyleProps>`
  ${(props) =>
    buttonCommonStyles(
      props.width,
      props.size,
      props.isCurve,
      props.disabled,
      props.loading,
      props.hasTilte,
      props.iconPosition
    )};
  background-color: ${(props) =>
    getBackgroundColor(
      props.theme,
      props.color,
      props.disabled,
      props.loading
    )};
  border: none;
  .label {
    color: ${(props) => getColor(props.theme, props.color, props.disabled)};
  }
  svg {
    fill: ${(props) =>
      getColor(props.theme, props.color, props.disabled)} !important;
  }
  &:hover {
    background-color: ${(props) =>
      getHoverBackgroundColor(
        props.theme,
        props.color,
        props.disabled,
        props.loading
      )};
    .label {
      color: ${(props) =>
        getHoverColor(props.theme, props.color, props.disabled)};
    }
    svg {
      fill: ${(props) =>
        getHoverColor(props.theme, props.color, props.disabled)} !important;
    }
  }
  &:active {
    background-color: ${(props) =>
      getFocusBackgroundColor(
        props.theme,
        props.color,
        props.disabled,
        props.loading
      )};
    .label {
      color: ${(props) =>
        getFocusColor(props.theme, props.color, props.disabled)};
    }
    svg {
      fill: ${(props) =>
        getFocusColor(props.theme, props.color, props.disabled)} !important;
    }
  }
`;
