import {
    XXLargeMonoHeadingStyle,
    XLargeMonoHeadingStyle,
    LargeMonoHeadingStyle,
    MediumMonoHeadingStyle,
    SmallMonoHeadingStyle,
    XSmallMonoHeadingStyle
} from "./styles";

interface Props {
    children: React.ReactNode | string,
    className?: string,
    color?: string
}

export const XXLargeMonoHeading: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <XXLargeMonoHeadingStyle
            className={`mono-heading-xxlg ${className}`}
            color={color}
        >
            {children}
        </XXLargeMonoHeadingStyle>
    )
}

export const XLargeMonoHeading: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <XLargeMonoHeadingStyle
            className={`mono-heading-xlg ${className}`}
            color={color}
        >
            {children}
        </XLargeMonoHeadingStyle>
    )
}

export const LargeMonoHeading: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <LargeMonoHeadingStyle
            className={`mono-heading-lg ${className}`}
            color={color}
        >
            {children}
        </LargeMonoHeadingStyle>
    )
}

export const MediumMonoHeading: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <MediumMonoHeadingStyle
            className={`mono-heading-md ${className}`}
            color={color}
        >
            {children}
        </MediumMonoHeadingStyle>
    )
}

export const SmallMonoHeading: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <SmallMonoHeadingStyle
            className={`mono-heading-sm ${className}`}
            color={color}
        >
            {children}
        </SmallMonoHeadingStyle>
    )
}

export const XSmallMonoHeading: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <XSmallMonoHeadingStyle
            className={`mono-heading-xs ${className}`}
            color={color}
        >
            {children}
        </XSmallMonoHeadingStyle>
    )
}