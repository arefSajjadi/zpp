import styled from "styled-components";

const commonStyles = (theme: any, color?: string) => {
    return (`
        font-family: ${theme.fontStandardBold} !important;
        margin: 0;
        color: ${color || theme.black};
        direction: ltr !important;
    `)
}

export const XXLargeMonoHeadingStyle = styled.h1`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 26px;
    line-height: 39px;
`
export const XLargeMonoHeadingStyle = styled.h2`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 24px;
    line-height: 36px;
    @media screen and (min-width: 1367px) {
        font-size: 26px;
        line-height: 39px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 26px;
        line-height: 39px;
    }
`
export const LargeMonoHeadingStyle = styled.h3`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 22px;
    line-height: 33px;
    @media screen and (min-width: 1367px) {
        font-size: 24px;
        line-height: 36px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 26px;
        line-height: 39px;
    }
`
export const MediumMonoHeadingStyle = styled.h4`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 20px;
    line-height: 30px;
    @media screen and (min-width: 1367px) {
        font-size: 22px;
        line-height: 33px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 24px;
        line-height: 36px;
    }
`
export const SmallMonoHeadingStyle = styled.h5`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 18px;
    line-height: 27px;
    @media screen and (min-width: 1367px) {
        font-size: 20px;
        line-height: 30px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 22px;
        line-height: 33px;
    }
`
export const XSmallMonoHeadingStyle = styled.h6`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 16px;
    line-height: 24px;
    @media screen and (min-width: 1367px) {
        font-size: 18px;
        line-height: 27px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 20px;
        line-height: 30px;
    }
`
// export const XXSmallMonoHeadingStyle = styled.h6`
//     ${(props) => commonStyles(props.theme, props.color)};
//     font-size: 14px;
//     line-height: 21px;
//     @media screen and (min-width: 1367px) {
//         font-size: 16px;
//         line-height: 24px;
//     }
//     @media screen and (min-width: 481px) and (max-width: 768px) {
//         font-size: 18px;
//         line-height: 27px;
//     }
// `