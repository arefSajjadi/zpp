import styled from "styled-components";

const commonStyles = (theme: any, color?: string) => {
    return (`
        font-family: ${theme.fontFaNumBold} !important;
        color: ${color || theme.black};
    `)
}

export const LargeLabelStyle = styled.label`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 18px;
    line-height: 36px;
`
export const MediumLabelStyle = styled.label`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 16px;
    line-height: 24px;
    @media screen and (min-width: 1367px) {
        font-size: 18px;
        line-height: 36px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 18px;
        line-height: 36px;
    }
`
export const SmallLabelStyle = styled.label`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 14px;
    line-height: 20px;
    @media screen and (min-width: 1367px) {
        font-size: 16px;
        line-height: 24px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 18px;
        line-height: 36px;
    }
`
export const XSmallLabelStyle = styled.label`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 12px;
    line-height: 18px;
    @media screen and (min-width: 1367px) {
        font-size: 14px;
        line-height: 20px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 16px;
        line-height: 24px;
    }
`
export const XXSmallLabelStyle = styled.label`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 10px;
    line-height: 16px;
    @media screen and (min-width: 1367px) {
        font-size: 12px;
        line-height: 18px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 14px;
        line-height: 20px;  
    }
`