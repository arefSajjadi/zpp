import {
    LargeLabelStyle,
    MediumLabelStyle,
    SmallLabelStyle,
    XSmallLabelStyle,
    XXSmallLabelStyle,
} from "./styles";

interface Props {
    children: React.ReactNode | string,
    className?: string,
    color?: string
}

export const LargeLabel: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <LargeLabelStyle
            className={`label-lg ${className}`}
            color={color}
        >
            {children}
        </LargeLabelStyle>
    )
}

export const MediumLabel: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <MediumLabelStyle
            className={`label-md ${className}`}
            color={color}
        >
            {children}
        </MediumLabelStyle>
    )
}

export const SmallLabel: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <SmallLabelStyle
            className={`label-sm ${className}`}
            color={color}
        >
            {children}
        </SmallLabelStyle>
    )
}

export const XSmallLabel: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <XSmallLabelStyle
            className={`label-xs ${className}`}
            color={color}
        >
            {children}
        </XSmallLabelStyle>
    )
}

export const XXSmallLabel: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <XXSmallLabelStyle
            className={`label-xxs ${className}`}
            color={color}
        >
            {children}
        </XXSmallLabelStyle>
    )
}