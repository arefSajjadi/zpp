import {
    LargeParagraphStyle,
    MediumParagraphStyle,
    SmallParagraphStyle,
    XSmallParagraphStyle,
    XXSmallParagraphStyle,
} from "./styles";

interface Props {
    children: React.ReactNode | string,
    className?: string,
    color?: string,
}

export const LargeParagraph: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color,
    } = props;

    return (
        <LargeParagraphStyle
            className={`p-lg ${className}`}
            color={color}
        >
            {children}
        </LargeParagraphStyle>
    )
}

export const MediumParagraph: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color,
    } = props;

    return (
        <MediumParagraphStyle
            className={`p-md ${className}`}
            color={color}
        >
            {children}
        </MediumParagraphStyle>
    )
}

export const SmallParagraph: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color,
    } = props;

    return (
        <SmallParagraphStyle
            className={`p-sm ${className}`}
            color={color}
        >
            {children}
        </SmallParagraphStyle>
    )
}

export const XSmallParagraph: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color,
    } = props;

    return (
        <XSmallParagraphStyle
            className={`p-xs ${className}`}
            color={color}
        >
            {children}
        </XSmallParagraphStyle>
    )
}

export const XXSmallParagraph: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color,
    } = props;

    return (
        <XXSmallParagraphStyle
            className={`p-xxs ${className}`}
            color={color}
        >
            {children}
        </XXSmallParagraphStyle>
    )
}