import styled from "styled-components";

const commonStyles = (theme: any, color?: string) => {
    return (`
        font-family: ${theme.fontFaNumRegular} !important;
        margin: 0;
        color: ${color || theme.black};
    `)
}

export const LargeParagraphStyle = styled.p`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 18px;
    line-height: 36px;
`
export const MediumParagraphStyle = styled.p`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 16px;
    line-height: 32px;
    @media screen and (min-width: 1367px) {
        font-size: 18px;
        line-height: 36px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 18px;
        line-height: 36px;
    }
`
export const SmallParagraphStyle = styled.p`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 14px;
    line-height: 28px;
    @media screen and (min-width: 1367px) {
        font-size: 16px;
        line-height: 32px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 18px;
        line-height: 36px;
    }
`
export const XSmallParagraphStyle = styled.p`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 12px;
    line-height: 24px;
    @media screen and (min-width: 1367px) {
        font-size: 14px;
        line-height: 28px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 16px;
        line-height: 32px;
    }
`
export const XXSmallParagraphStyle = styled.p`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 10px;
    line-height: 20px;
    @media screen and (min-width: 1367px) {
        font-size: 12px;
        line-height: 24px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 14px;
        line-height: 28px;
    }
`

