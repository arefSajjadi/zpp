import styled from "styled-components";

const commonStyles = (theme: any, color?: string) => {
    return (`
        font-family: ${theme.fontStandardRegular} !important;
        margin: 0;
        color: ${color || theme.black};
        direction: ltr !important;
    `)
}

export const LargeMonoParagraphStyle = styled.p`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 18px;
    line-height: 36px;
`
export const MediumMonoParagraphStyle = styled.p`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 16px;
    line-height: 32px;
    @media screen and (min-width: 1367px) {
        font-size: 18px;
        line-height: 36px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 18px;
        line-height: 36px;
    }
`
export const SmallMonoParagraphStyle = styled.p`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 14px;
    line-height: 28px;
    @media screen and (min-width: 1367px) {
        font-size: 16px;
        line-height: 32px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 18px;
        line-height: 36px;
    }
`
export const XSmallMonoParagraphStyle = styled.p`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 12px;
    line-height: 24px;
    @media screen and (min-width: 1367px) {
        font-size: 14px;
        line-height: 28px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 16px;
        line-height: 32px;
    }
`
export const XXSmallMonoParagraphStyle = styled.p`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 10px;
    line-height: 20px;
    @media screen and (min-width: 1367px) {
        font-size: 12px;
        line-height: 24px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 14px;
        line-height: 28px;
    }
`