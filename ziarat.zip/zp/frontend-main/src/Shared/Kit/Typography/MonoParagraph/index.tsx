import {
    LargeMonoParagraphStyle,
    MediumMonoParagraphStyle,
    SmallMonoParagraphStyle,
    XSmallMonoParagraphStyle,
    XXSmallMonoParagraphStyle
} from "./styles";

interface Props {
    children: React.ReactNode | string,
    className?: string,
    color?: string
}

export const LargeMonoParagraph: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <LargeMonoParagraphStyle
            className={`mono-p-lg ${className}`}
            color={color}
        >
            {children}
        </LargeMonoParagraphStyle>
    )
}

export const MediumMonoParagraph: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <MediumMonoParagraphStyle
            className={`mono-p-md ${className}`}
            color={color}
        >
            {children}
        </MediumMonoParagraphStyle>
    )
}

export const SmallMonoParagraph: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <SmallMonoParagraphStyle
            className={`mono-p-sm ${className}`}
            color={color}
        >
            {children}
        </SmallMonoParagraphStyle>
    )
}

export const XSmallMonoParagraph: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <XSmallMonoParagraphStyle
            className={`mono-p-xs ${className}`}
            color={color}
        >
            {children}
        </XSmallMonoParagraphStyle>
    )
}

export const XXSmallMonoParagraph: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <XXSmallMonoParagraphStyle
            className={`mono-p-xxs ${className}`}
            color={color}
        >
            {children}
        </XXSmallMonoParagraphStyle>
    )
}