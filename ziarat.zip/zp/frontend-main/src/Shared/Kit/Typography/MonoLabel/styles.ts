import styled from "styled-components";

const commonStyles = (theme: any, color?: string) => {
    return (`
        font-family: ${theme.fontStandardBold} !important;
        color: ${color || theme.black};
        direction: ltr !important;
    `)
} 

export const LargeMonoLabelStyle = styled.label`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 18px;
    line-height: 36px;
`
export const MediumMonoLabelStyle = styled.label`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 16px;
    line-height: 24px;
    @media screen and (min-width: 1367px) {
        font-size: 18px;
        line-height: 36px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 18px;
        line-height: 36px;
    }
`
export const SmallMonoLabelStyle = styled.label`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 14px;
    line-height: 20px;
    @media screen and (min-width: 1367px) {
        font-size: 16px;
        line-height: 24px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 18px;
        line-height: 36px;
    }
`
export const XSmallMonoLabelStyle = styled.label`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 12px;
    line-height: 18px;
    @media screen and (min-width: 1367px) {
        font-size: 14px;
        line-height: 20px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 16px;
        line-height: 24px;
    }
`
export const XXSmallMonoLabelStyle = styled.label`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 10px;
    line-height: 16px;
    @media screen and (min-width: 1367px) {
        font-size: 12px;
        line-height: 18px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 14px;
        line-height: 20px;
    }
`