import {
    LargeMonoLabelStyle,
    MediumMonoLabelStyle,
    SmallMonoLabelStyle,
    XSmallMonoLabelStyle,
    XXSmallMonoLabelStyle
} from "./styles";

interface Props {
    children: React.ReactNode | string,
    className?: string,
    color?: string
}

export const LargeMonoLabel: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <LargeMonoLabelStyle
            className={`mono-label-lg ${className}`}
            color={color}
        >
            {children}
        </LargeMonoLabelStyle>
    )
}

export const MediumMonoLabel: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <MediumMonoLabelStyle
            className={`mono-label-md ${className}`}
            color={color}
        >
            {children}
        </MediumMonoLabelStyle>
    )
}

export const SmallMonoLabel: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <SmallMonoLabelStyle
            className={`mono-label-sm ${className}`}
            color={color}
        >
            {children}
        </SmallMonoLabelStyle>
    )
}

export const XSmallMonoLabel: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <XSmallMonoLabelStyle
            className={`mono-label-xs ${className}`}
            color={color}
        >
            {children}
        </XSmallMonoLabelStyle>
    )
}

export const XXSmallMonoLabel: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <XXSmallMonoLabelStyle
            className={`mono-label-xxs ${className}`}
            color={color}
        >
            {children}
        </XXSmallMonoLabelStyle>
    )
}