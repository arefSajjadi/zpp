import {
    XXLargeMonoDisplayStyle,
    XLargeMonoDisplayStyle,
    LargeMonoDisplayStyle,
    MediumMonoDisplayStyle,
    SmallMonoDisplayStyle,
    XSmallMonoDisplayStyle
} from "./styles";

interface Props {
    children: React.ReactNode | string,
    className?: string,
    color?: string
}

export const XXLargeMonoDisplay: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <XXLargeMonoDisplayStyle
            className={`mono-display-xxlg ${className}`}
            color={color}
        >
            {children}
        </XXLargeMonoDisplayStyle>
    )
}

export const XLargeMonoDisplay: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <XLargeMonoDisplayStyle
            className={`mono-display-xlg ${className}`}
            color={color}
        >
            {children}
        </XLargeMonoDisplayStyle>
    )
}

export const LargeMonoDisplay: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <LargeMonoDisplayStyle
            className={`mono-display-md ${className}`}
            color={color}
        >
            {children}
        </LargeMonoDisplayStyle>
    )
}

export const MediumMonoDisplay: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <MediumMonoDisplayStyle
            className={`mono-display-md ${className}`}
            color={color}
        >
            {children}
        </MediumMonoDisplayStyle>
    )
}

export const SmallMonoDisplay: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <SmallMonoDisplayStyle
            className={`mono-display-sm ${className}`}
            color={color}
        >
            {children}
        </SmallMonoDisplayStyle>
    )
}

export const XSmallMonoDisplay: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <XSmallMonoDisplayStyle
            className={`mono-display-xs ${className}`}
            color={color}
        >
            {children}
        </XSmallMonoDisplayStyle>
    )
}