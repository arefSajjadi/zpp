import {
    XXLargeHeadingStyle,
    XLargeHeadingStyle,
    LargeHeadingStyle,
    MediumHeadingStyle,
    SmallHeadingStyle,
    XSmallHeadingStyle,
    XXSmallHeadingStyle
} from "./styles";

interface Props {
    children: React.ReactNode | string,
    className?: string,
    color?: string
}

export const XXLargeHeading: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <XXLargeHeadingStyle
            className={`heading-xxlg ${className}`}
            color={color}
        >
            {children}
        </XXLargeHeadingStyle>
    )
}

export const XLargeHeading: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <XLargeHeadingStyle
            className={`heading-xlg ${className}`}
            color={color}
        >
            {children}
        </XLargeHeadingStyle>
    )
}

export const LargeHeading: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <LargeHeadingStyle
            className={`heading-lg ${className}`}
            color={color}
        >
            {children}
        </LargeHeadingStyle>
    )
}

export const MediumHeading: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <MediumHeadingStyle
            className={`heading-md ${className}`}
            color={color}
        >
            {children}
        </MediumHeadingStyle>
    )
}

export const SmallHeading: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <SmallHeadingStyle
            className={`heading-sm ${className}`}
            color={color}
        >
            {children}
        </SmallHeadingStyle>
    ) 
}

export const XSmallHeading: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <XSmallHeadingStyle
            className={`heading-xs ${className}`}
            color={color}
        >
            {children}
        </XSmallHeadingStyle>
    )
}

export const XXSmallHeading: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <XXSmallHeadingStyle
            className={`heading-xs ${className}`}
            color={color}
        >
            {children}
        </XXSmallHeadingStyle>
    )
}