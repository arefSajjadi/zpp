import styled from "styled-components";

const commonStyles = (theme: any, color?: string) => {
    return (`
        display: flex;
        font-family: ${theme.fontFaNumBlack} !important;
        color: ${color || theme.black};
    `)
}

export const XXLargeDisplayStyle = styled.div`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 76px;
    line-height: 84px;
`
export const XLargeDisplayStyle = styled.div`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 68px;
    line-height: 76px;
    @media screen and (min-width: 1367px) {
        font-size: 76px;
        line-height: 84px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 76px;
        line-height: 84px;
    }
`
export const LargeDisplayStyle = styled.div`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 60px;
    line-height: 68px;
    @media screen and (min-width: 1367px) {
        font-size: 68px;
        line-height: 76px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 76px;
        line-height: 84px;
    }
`
export const MediumDisplayStyle = styled.div`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 52px;
    line-height: 60px;
    @media screen and (min-width: 1367px) {
        font-size: 60px;
        line-height: 68px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 68px;
        line-height: 76px;
    }
`
export const SmallDisplayStyle = styled.div`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 44px;
    line-height: 52px;
    @media screen and (min-width: 1367px) {
        font-size: 52px;
        line-height: 60px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 60px;
        line-height: 68px;
    }
`
export const XSmallDisplayStyle = styled.div`
    ${(props) => commonStyles(props.theme, props.color)};
    font-size: 36px;
    line-height: 44px;
    @media screen and (min-width: 1367px) {
        font-size: 44px;
        line-height: 52px;
    }
    @media screen and (min-width: 481px) and (max-width: 768px) {
        font-size: 52px;
        line-height: 60px;
    }
`