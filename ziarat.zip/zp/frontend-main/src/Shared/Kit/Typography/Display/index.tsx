import {
    XXLargeDisplayStyle,
    XLargeDisplayStyle,
    LargeDisplayStyle,
    MediumDisplayStyle,
    SmallDisplayStyle,
    XSmallDisplayStyle
} from "./styles"; 

interface Props {
    children: React.ReactNode | string,
    className?: string,
    color?: string
}

export const XXLargeDisplay: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <XXLargeDisplayStyle
            className={`display-xxlg ${className}`}
            color={color}
        >
            {children}
        </XXLargeDisplayStyle>
    )
}

export const XLargeDisplay: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <XLargeDisplayStyle
            className={`display-xlg ${className}`}
            color={color}
        >
            {children}
        </XLargeDisplayStyle>
    )
}

export const LargeDisplay: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <LargeDisplayStyle
            className={`display-lg ${className}`}
            color={color}
        >
            {children}
        </LargeDisplayStyle>
    )
}

export const MediumDisplay: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <MediumDisplayStyle
            className={`display-md ${className}`}
            color={color}
        >
            {children}
        </MediumDisplayStyle>
    )
}

export const SmallDisplay: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <SmallDisplayStyle
            className={`display-sm ${className}`}
            color={color}
        >
            {children}
        </SmallDisplayStyle>
    )
}

export const XSmallDisplay: React.FC<Props> = (props) => {
    const {
        children,
        className = "",
        color
    } = props;

    return (
        <XSmallDisplayStyle
            className={`display-xs ${className}`}
            color={color}
        >
            {children}
        </XSmallDisplayStyle>
    )
}