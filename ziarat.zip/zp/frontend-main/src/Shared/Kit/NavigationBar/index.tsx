import React from 'react';
import {
    Wrapper,
    Container,
} from "./styles";
import MenuItem from './MenuItem';
import MenuIcon from '../Icons/MenuIcon';

export type menuItemProps = {
    id: number,
    title: string,
    url: string,
    subMenu: subMenuProps[],
    disabled: boolean
}

export type subMenuProps = {
    id: number,
    title: string,
    url: string,
    disabled: boolean
}

interface Props {
    menuItemConfig: menuItemProps[],
}

const NavigationBar: React.FC<Props> = (props) => {
    const {
        menuItemConfig,
    } = props;

    return (
        <Wrapper className="navigation-bar-wrapper hide-scroll-bar">
            <Container>
                <MenuIcon />
                {menuItemConfig?.map((each: any, index: number) => {
                    return (
                        <MenuItem
                            key={each.id}
                            menuItem={each}
                        />
                    )
                })}
            </Container>
        </Wrapper>
    )
}

export default NavigationBar;