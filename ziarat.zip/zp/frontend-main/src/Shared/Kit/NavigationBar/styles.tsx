import styled from "styled-components";
import Row from "../Row";
import Link from "next/link";

export const Wrapper = styled(Row)`
    height: 100%;
    align-items: flex-end;
    background-color: ${props => props.theme.gray50};
    padding: 0 25px;
    overflow-x: auto;
`

export const Container = styled(Row)`
    width: max-content;
    min-width: max-content;
    gap: 30px;
    svg {
        width: 14px;
        height: 14px;
        fill: ${props => props.theme.gray600};
        margin-top: -7px;
    }
    @media screen and (max-width: 480px) {
        gap: 20px;
    }
`

export const MenuItemStyle = styled(Link)`
    display: flex;
    align-items: center;
    justify-content: center;
    border-bottom: 2px solid transparent;
    padding: 0 2px 7px 2px;
    &.active {
        border-bottom: 2px solid ${props => props.theme.secondary600};
        p {
            font-weight: bold;
        }
    }
`