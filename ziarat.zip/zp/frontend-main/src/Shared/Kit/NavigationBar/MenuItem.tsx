import React from 'react';
import { useSelector } from 'react-redux';
import {
    MenuItemStyle
} from "./styles";
import { selectTheme } from '../../../Redux/App/Selectors';
import { XSmallParagraph } from '../Typography/Paragraph';
import { menuItemProps } from '.';

interface Props {
    menuItem: menuItemProps,
}

const MenuItem: React.FC<Props> = (props) => {
    const {
        menuItem
    } = props;

    const {
        id,
        title,
        url,
        subMenu, //بعدا اضافه می شود
        disabled,
    } = menuItem;

    const active = window.location.pathname === url

    const theme = useSelector(selectTheme)

    return (
        !disabled
            ? <MenuItemStyle
                className={active ? "active" : ""}
                href={url || "#"}
                target='_self'
            >
                <XSmallParagraph
                    color={
                        active
                            ? theme.secondary600
                            : theme.gray700
                    }
                >
                    {title}
                </XSmallParagraph>
            </MenuItemStyle>
            : <></>
    )
}

export default MenuItem;