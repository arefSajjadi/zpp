import styled from "styled-components";
import Col from "../Col";

export const ParentAndChildContainer = styled(Col)`
    &:first-child {
        /* border-bottom: 1px solid ${(props) => props.theme.gray100}; */
    }
    &:last-child {
        border-bottom: 1px solid ${(props) => props.theme.gray100};
    }
    .expand,
    .narrow {
        width: auto;
        margin-left: 10px;
        cursor: pointer;
        svg {
            width: 15px;
            height: 15px;
        }
    }
    .w-25 {
        /* width: 25px; */
        width: 32.5px;
    }
    .w-50 {
        /* width: 50px; */
        width: 65px;
    }
`