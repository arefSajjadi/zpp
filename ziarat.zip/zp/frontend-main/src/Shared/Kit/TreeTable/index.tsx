import React from 'react';
import {
    TableAndPaginationContainer,
    TablesContainer,
    HeadersAndBodiesContainer,
    HeadersContainer,
    OtherHeaderContainer,
    BodiesContainer,
    OtherBodyContainer,
    LoaderContainer,
    TblRow,
} from "../Table/styles";
import Row from '../Row';
import Col from '../Col';
import NoItem from '../NoItem';
import Loading from '../Loading';
import TableRow from './TableRow';
import Header from '../Table/Header';
import { tblConfigType } from '../Table';

export type TableProps = {
    tblConfig: tblConfigType,
    tblData: any[],
    childPropertyName?: string,
    loading?: boolean,
}

const TreeTable: React.FC<TableProps> = (props) => {
    const {
        tblConfig,
        tblData,
        childPropertyName = "child",
        loading,
    } = props;

    //change
    const height = "100%"
    const minHeight_mobile = "100%"
    const minWidth = "auto"
    const minWidth_tablet = "auto"
    const minWidth_mobile = "auto"
    const showCount = true
    const showPaging = false

    return (
        <TableAndPaginationContainer
            height={height}
            minHeight_mobile={minHeight_mobile}
            showCount={showCount}
        >
            <TablesContainer
                className="horizontal-custom-scroll-bar custom-scroll-bar"
                showPaging={showPaging}
                minHeight_mobile={minHeight_mobile}
            >
                <HeadersAndBodiesContainer
                    minWidth={minWidth}
                    minWidth_tablet={minWidth_tablet}
                    minWidth_mobile={minWidth_mobile}
                >
                    <HeadersContainer>
                        <OtherHeaderContainer
                            otherWidth={100}
                        >
                            <Header
                                showHeader={tblConfig.showHeader}
                                tblConfigRow={tblConfig.row}
                                mainArr={tblData}
                                setMainArr={() => { }}
                            />
                        </OtherHeaderContainer>
                    </HeadersContainer>
                    <BodiesContainer>
                        <OtherBodyContainer
                            otherWidth={100}
                            className="bict__tblBodyWrapper"
                        >
                            {loading
                                ? <LoaderContainer>
                                    <Loading />
                                </LoaderContainer>
                                : tblData && tblData.length !== 0
                                    ? tblData.map((each: any, index: number) => {
                                        return (
                                            <Row key={index}>
                                                <TableRow
                                                    tblConfig={tblConfig}
                                                    item={each}
                                                    index={index}
                                                    childPropertyName={childPropertyName}
                                                />
                                            </Row>
                                        );
                                    })
                                    : <TblRow className="bict__tblRow bict__noItem">
                                        <NoItem center />
                                    </TblRow>
                            }
                        </OtherBodyContainer>
                    </BodiesContainer>
                </HeadersAndBodiesContainer>
            </TablesContainer>
        </TableAndPaginationContainer>
    )
}

export default TreeTable;