import React, { useEffect, useState } from 'react';
import {
    TblRow,
    TblCol,
} from '../Table/styles';
import Col from '../Col';
import { XXSmallParagraph } from '../Typography/Paragraph';
import PlusIcon from '../Icons/PlusIcon';
import MinusIcon from '../Icons/MinusIcon';
import { ParentAndChildContainer } from './styles';
import { tblConfigRowType, tblConfigType } from '../Table';

// مثال item: {
//     "id": 588,
//     "uniqueId": "STYmm02",
//     "title": "مشتریان",
//     "isActive": true,
//     "parentId": null,
//     "child": [
//         {
//             "id": 589,
//             "uniqueId": "STYmm02sm01",
//             "title": "لیست مشتریان",
//             "isActive": true,
//             "parentId": 588,
//             "child": [
//                 {
//                     "id": 590,
//                     "uniqueId": "STYmm02sm01ac01",
//                     "title": "افزودن",
//                     "isActive": true,
//                     "parentId": 589
//                 },
//             ]
//         },
//         {
//             "id": 593,
//             "uniqueId": "STYmm02sm02",
//             "title": "مشتریان حقیقی",
//             "isActive": true,
//             "parentId": 588,
//             "child": []
//         },
//         {
//             "id": 597,
//             "uniqueId": "STYmm02sm03",
//             "title": "لیست احراز هویت",
//             "isActive": true,
//             "parentId": 588,
//             "child": []
//         }
//     ]
// }
export type TableProps = {
    tblConfig: tblConfigType,
    item: any,
    index: number,
    isChild?: boolean,
    childPropertyName: string,
}

const TableRow: React.FC<TableProps> = (props) => {
    const {
        tblConfig,
        item,
        index,
        isChild = false,
        childPropertyName,
    } = props;

    const child = item[childPropertyName || "child"];

    const [expand, setExpand] = useState(false);
    const [level, setLevel] = useState<any>(null);

    useEffect(() => {
        if (isChild) {
            // if (child && child.length !== 0) {
            if (child) {
                setLevel(2)
            } else {
                setLevel(3)
            }
        } else {
            setLevel(1)
        }
    }, [isChild, child])

    const toggle = () => {
        if (child && child.length !== 0) {
            setExpand(!expand)
        }
    }

    const PlusAndMinus = () => {
        return (
            <>
                {level === 1
                    ? ""
                    : level === 2
                        ? <Col className='w-25' />
                        : <Col className='w-50' />
                }
                {child && child.length !== 0
                    ? !expand
                        ? <Col className='expand' onClick={toggle}>
                            <PlusIcon />
                        </Col>
                        : <Col className='narrow' onClick={toggle}>
                            <MinusIcon />
                        </Col>
                    : null
                }
            </>
        )
    }

    return (
        <ParentAndChildContainer>
            <TblRow
                className={
                    `bict__tblRow 
                    ${(index + 1) % 2 === 0
                        ? `bict__tblRow__even`
                        : `bict__tblRow__odd`
                    }`
                }
            >
                {tblConfig?.row?.map((RowOfTable: tblConfigRowType, colIndex: number) => {
                    const {
                        element,
                        displayTitle,
                        size,
                        responsiveShow,
                        responsiveBreakPoint,
                        access
                    } = RowOfTable;
                    let Element = (props: any) => (
                        <>
                            {colIndex === 0 && PlusAndMinus()}
                            <RowOfTable.element
                                index={index}
                                row={item}
                            // rowIndex={skip ? skip - take + i + 1 : i + 1}
                            // DataLength={mainArr.length}
                            >
                                {props.children}
                            </RowOfTable.element>
                        </>
                    );
                    return (
                        <TblCol
                            key={index + colIndex}
                            className="bict__tblCol"
                            flex={size}
                            responsiveShow={responsiveShow !== undefined ? responsiveShow : true}
                            responsiveBreakPoint={responsiveBreakPoint || 768}
                        >
                            {access !== false
                                ? element
                                    ? <Element></Element>
                                    : <>
                                        {colIndex === 0 && PlusAndMinus()}
                                        <XXSmallParagraph>
                                            {item[displayTitle]}
                                        </XXSmallParagraph>
                                    </>
                                : <></>
                            }
                        </TblCol>
                    );
                })}
            </TblRow>
            {expand &&
                child?.map((each: any, i: number) => {
                    return (
                        <TableRow
                            key={i}
                            tblConfig={tblConfig}
                            item={each}
                            index={i}
                            isChild={true}
                            childPropertyName={childPropertyName}
                        />
                    )
                })
            }
        </ParentAndChildContainer>
    )
}

export default TableRow;