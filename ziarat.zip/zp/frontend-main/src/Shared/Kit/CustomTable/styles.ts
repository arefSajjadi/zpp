import styled from "styled-components";
import Row from "../Row";
import Col from "../Col";

const ActionsHeight = 40
const FilterMargin = 15
const FilterPadding = 15
const FilterInputHeight = 55

export const ActionsAndFilterConatiner = styled(Row)`
    > div:first-child {
        justify-content: space-between;
    }
`
export const FilterAndSelectionBtnContainer = styled(Row)`
    width: max-content;
    gap: 12px;
    .CustomTable_FilterButton {
        svg {
            width: 16px;
            height: 16px;
        }
    }
    .CustomTable_SelectButton {
        svg {
            width: 16px;
            height: 16px;
        }
    }
`
export const ActionBtnContainer = styled(Row)` 
    width: max-content;
    gap: 12px;
    .CustomTable_AddButton,
    .CustomTable_SampleExcelUploadButton {
        min-width: 110px;
    }
    .CustomTable_AddButton {
        padding: 0 15px;
        svg {
            width: 14px;
            height: 14px;
        }
    }
    .CustomTable_ExcelDownloadButton,
    .CustomTable_ExcelUploadButton,
    .CustomTable_SampleExcelUploadButton {
        padding: 0 15px;
        svg {
            width: 16px;
            height: 16px;
        }
    }
    .CustomTable_ExcelUpload {
        width: auto;
        .CustomTable_ExcelUpload_Input {
            position: relative;
            width: auto;
            input {
                position: absolute;
                width: 100%;
                height: 100%;
                opacity: 0;
                cursor: pointer;
            }
        }
        .CustomTable_ExcelUpload_CancelIcon {
            margin-right: 3px;
            padding: 0 10px;
        }
    }
    .CustomTable_FreezeColumnSelect,
    .CustomTable_ExcelColumnSelect {
        width: 190px;
    }
`;

interface FilterContainerProps {
    showFilter: boolean,
    filterRowNumber: number,
    hasActionsAndFilter: boolean
}
export const FilterContainer = styled(Row) <FilterContainerProps> `
    border-top: 1px solid ${props => props.theme.gray100};
    margin-top: ${(props) => props.hasActionsAndFilter ? `${FilterMargin}px` : 0};
    > div {
        padding-top: ${FilterPadding}px;
    }
    opacity: ${props => props.showFilter ? 1 : 0};
    height: ${props => props.showFilter ? (props.filterRowNumber * FilterInputHeight + FilterPadding) + "px" : "0px"};
    transition: all .3s ease;
    @media screen and (max-width: 768px) {
        height: 0;
        border-top: 0;
        > div {
            display: none;
        }
    }
`
interface FilterFormBodyProps {
    width?: string
}
export const FilterFormBody = styled(Row) <FilterFormBodyProps>`
    width: ${(props) => props.width || "100%"};
    margin-left: auto;
    .filter-row {
        align-items: flex-start;
        justify-content: space-between;
        > div {
            min-height: ${FilterInputHeight}px;
        }
    }
    &.right-calendar {
        .bict__CalenderWrapper {
            right: 0;
            left: auto;
            animation: shutter-in-right 1s ease both;
            @keyframes shutter-in-right {
                0% {
                    transform: rotateY(100deg);
                    transform-origin: right;
                    opacity: 0;
                }
                100% {
                    transform: rotateY(0);
                    transform-origin: right;
                    opacity: 1;
                }
            }
        } 
    }
    @media (max-width: ${props => props.theme.sm}) {
        .display-none {
            display: none;
        }
        .filter-row {
            > div {
                min-height: ${FilterInputHeight * 1.5}px;
            }
        }
    }
    @media (max-width: ${props => props.theme.xs}) {
        .filter-row {
            > div {
                min-height: ${FilterInputHeight}px;
            }
        }
    }
`;

interface TableConatinerProps {
    showFilter: boolean,
    filterRowNumber: number,
    hasActionsAndFilter: boolean
}
export const TableConatiner = styled(Col) <TableConatinerProps>`
    align-items: flex-start;
    justify-content: flex-start;
    height: ${(props) =>
        props.hasActionsAndFilter
            ? props.showFilter
                ? `calc(100% - ${(props.filterRowNumber * FilterInputHeight) + (ActionsHeight + FilterMargin + FilterPadding)}px)`
                : `calc(100% - ${ActionsHeight + FilterMargin + 1}px)`
            : "100%"
    };
    transition: all .3s ease;
    @media screen and (max-width: 768px) {
        height: auto;
    }
`
export const CountContainer = styled(Row)`
    justify-content: flex-end;
    label {
        margin-right: 5px;
    }
`

/////
export const IndexColumnStyle = styled(Row)`
    height: 100%;
`;
interface PriceColumnContainerProps {
    showDetails: boolean
}
export const PriceColumnContainer = styled(Row) <PriceColumnContainerProps>` 
    width: auto;
    position: relative;
    > div:first-child {
        cursor: ${(props) => props.showDetails && "pointer"};
        &:hover {
            font-weight: ${(props) => props.showDetails && "bold"};
        }
    }
    p {
        direction: ltr !important;
    }
`;
interface ImgProps {
    src: string
}
export const Img = styled(Row) <ImgProps>`
    width: 40px;
    height: 40px;
    background-image: url(${(props) => props.src});
    background-repeat: none;
    background-size: contain;
    background-position: center;
    border: ${(props) => !props.src ? `1px solid ${props.theme.gray200}` : "none"} !important;
    border-radius: 4px;
    cursor: pointer;
`

export const SlidingMenuContainer = styled(Row)`
    #sliding-menu-filter {
        > div:last-child {
            height: 100%;
            > form {
                height: 100%;
                > div {
                    height: 100%;
                    align-items: flex-start;
                    justify-content: flex-start;
                    padding-top: 10px;
                    overflow-y: auto;
                }
            }
        }
    }
    .tilte-and-icon {
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
        svg {
            scale: 0.9;
        }
    }
    .close-icon-container {
        width: auto;
        padding: 5px;
        svg {
            fill: ${(props) => props.theme.gray800};
        }
    }
`
export const TableCellTooltipContainer = styled(Row)`
    position: relative;
    width: auto;
    * {
        cursor: pointer;
    }
`