import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { selectTheme } from "../../../Redux/App/Selectors";
import {
  ActionsAndFilterConatiner,
  FilterAndSelectionBtnContainer,
  ActionBtnContainer,
  FilterContainer,
  TableConatiner,
  CountContainer,
  SlidingMenuContainer
} from "./styles";
import Row from "../Row";
import Col from "../Col";
import Table, { options, tblConfigRowType } from "../Table";
import { PrimaryButton } from "../Button/PrimaryButton";
import { GhostButton } from "../Button/GhostButton";
import { OutlineButton } from "../Button/OutlineButton";
import { SecondaryButton } from "../Button/SecondaryButton";
import { XXSmallParagraph } from "../Typography/Paragraph";
import { XSmallMonoLabel } from "../Typography/MonoLabel";
import { XSmallLabel } from "../Typography/Label";
import FilterIcon from "../Icons/FilterIcon";
import ChooseIcon from "../Icons/ChooseIcon";
import DeleteIcon from "../Icons/DeleteIcon";
import ExcelIcon from "../Icons/ExcelIcon";
import UploadIcon from "../Icons/UploadIcon";
import AddIcon from "../Icons/AddIcon";
import separator from "../../../Utils/Separator";
import TreeTable from "../TreeTable";
import Select from "../FromElements/Select";
import Toast from "../Toast";
import SlidingMenu, { closeMenu, openMenu } from "../SlidingMenu";
import useIsMobile from "../../../Utils/Responsive";
import CrossIcon from "../Icons/CrossIcon";
import RecordController from "../../../Utils/RecordController";
import { DownloadFile } from "../../../Utils/DownloadFile";

type func = (...args: any) => any

export type CustomTableProps = {
  display?: "flex" | "none"
  //filter
  showFilter?: boolean,
  FilterComponent?: any;
  filterState?: any;
  setFilterState?: any;
  filterRowNumber?: number;
  //selection
  showSelect?: boolean,
  selectionMode?: boolean,
  setSelectionMode?: any,
  selectionListIDs?: any[],
  setSelectionListIDs?: any,
  //add
  add?: boolean;
  onAddClick?: any;
  addButtonTitle?: string;
  addDisabled?: boolean;
  //excelDownload
  excelDownload?: boolean;
  onExcelDownloadClick?: any;
  excelDownloadColumns?: {
    fieldName: string,
    fieldTitle: string
  }[] | null,
  setExcelDownloadColumns?: any,
  downlaodButtonTitle?: string;
  //excelUpload
  excelUpload?: boolean;
  onExcelUploadClick?: any;
  sampleExcelFile?: any,
  uploadButtonTitle?: string;
  excelFile?: File;
  //
  AdditionalButton?: any[] | null;
  showCount?: boolean;
  count?: number;
  //table
  tblConfig?: any;
  tblData?: any[];
  loading?: boolean;
  showPaging?: boolean;
  skip?: number;
  take?: number;
  setTake?: any,
  showTakeInput?: boolean;
  pageHandler?: any;
  dragable?: boolean;
  onDrop?: func;
  keyOfid?: string;
  tblHeight?: string;
  tblMinHeight_mobile?: string;
  tblMinWidth?: string;
  tblMinWidth_tablet?: string;
  tblMinWidth_mobile?: string;
  tableType?: string; //normalTable - treeTable
  childPropertyName?: string,
  //برای client side paging -> چک شود
  clientPagination?: boolean,
  //برای  فریز جدول
  hasFixedColumns?: boolean,
  fixedColumns?: string[],
  setFixedColumns?: any
};

const CustomTable: React.FC<CustomTableProps> = (props) => {
  const theme = useSelector(selectTheme)
  const responsive = useIsMobile()

  const {
    display = "flex", //flex- none
    //filter
    showFilter = false,
    FilterComponent = null,
    filterState,
    setFilterState,
    filterRowNumber = 2,
    //selection
    showSelect = false,
    selectionMode = false,
    setSelectionMode,
    selectionListIDs,
    setSelectionListIDs,
    //table actions
    add = true,
    onAddClick,
    addButtonTitle = "افزودن",
    addDisabled = false,
    excelDownload = true,
    onExcelDownloadClick,
    excelDownloadColumns,
    setExcelDownloadColumns,
    downlaodButtonTitle = "", //"دانلود اکسل"
    excelUpload = true,
    onExcelUploadClick,
    sampleExcelFile,
    uploadButtonTitle = "", //"آپلود اکسل"
    excelFile,
    showCount = true,
    count = 0,
    AdditionalButton = null,
    //table
    tblConfig,
    tblData,
    loading = false,
    showPaging = true,
    skip = 0,
    take = options[0].title,
    setTake,
    showTakeInput = true,
    pageHandler,
    dragable = false,
    onDrop,
    keyOfid = "id",
    tblHeight = "100%",
    tblMinHeight_mobile = "",
    tblMinWidth = "auto",
    tblMinWidth_tablet = "",
    tblMinWidth_mobile = "",
    tableType = "normalTable",
    childPropertyName = "child",
    //برای client side paging -> چک شود
    clientPagination = false,
    //برای  فریز جدول
    hasFixedColumns = false,
    fixedColumns = [], //عنوان ستون های انتخاب شده برای فریز - آرایه از رشته ها
    setFixedColumns
  } = props;

  const hasActionsAndFilter =
    (
      showFilter || showSelect || hasFixedColumns ||
      excelDownload || excelUpload || add ||
      (AdditionalButton && AdditionalButton.length !== 0)
    )
      ? true
      : false

  //فیلتر
  const [showFilterDetails, setShowFilterDetails] = useState(false);
  const filterCallback = () => {
    setShowFilterDetails((perv) => !perv)
  }
  const onFilterClick = () => {
    if (responsive === "tablet" || responsive === "mobile") {
      if (!showFilterDetails) { //بسته بود
        openMenu("filter", filterCallback)
      } else {
        closeMenu("filter", filterCallback)
      }
    } else {
      filterCallback()
    }
  }

  //انتخاب
  const toggleSelectionMode = () => {
    if (selectionMode) {
      setSelectionListIDs([]);
    }
    setSelectionMode(!selectionMode);
  };

  //برای  فریز جدول
  const [listOfColumns, setListOfColumns] = useState<any[]>([]) //option برای DD
  //-> [{id: 'rowIndex', title: 'ردیف'}]
  const [selectValues, setSelectValues] = useState<string>("") //ستون های انتخاب شده برای فریز - رشته
  //-> rowIndex,fullName

  //fixedColumns -> ['rowIndex', 'fullName']

  useEffect(() => {
    let columns_object: any[] = [] //تمام ستون ها
    let fixed: string[] = [] //ستون های فریز شده
    tblConfig.row.map((col: tblConfigRowType) => {
      if (col.displayTitle && col.responsiveShow === true) {
        columns_object.push({
          id: col.displayTitle, //id - لاتین
          title: col.headerTitle, //title - فارسی
        })
      }
      if (col.fixed) {
        fixed.push(col.displayTitle)
      }
    })
    setListOfColumns(columns_object)

    if (fixed.length > 0 && hasFixedColumns) {
      setSelectValues(fixed.join(","))
      setFixedColumns([...fixed])
    }
  }, [])

  const onSelect_FixedColumn = (newListOfString: string[]) => {
    if (newListOfString?.length >= 5) {
      return Toast.warning("محدودیت در فریز ستون های جدول")
    }
    //آرایه برای انتخاب شده و نشده ی DD:
    setSelectValues(newListOfString.map((each: any) => each).join()) //تبدیل لیست به رشته
    setFixedColumns(newListOfString)
  }

  const onDeSelect_FixedColumn = (selectedItem: any) => {
    //آرایه برای انتخاب شده و نشده ی DD:

    //تبدیل رشته به آرایه ای از رشته ها
    let array: any = selectValues.split(',');
    //پیدا کردن ایندکس مورد انتخاب شده در لیست رشته ها
    let itemIndex = array.findIndex((each: any) => each === selectedItem.id);
    //حذف از لیست رشته ها
    array.splice(itemIndex, 1);
    //تبدیل لیست جدید به رشته
    array = array.join(',');
    //ست کردن رشته ی جدید
    setSelectValues(array)
    setFixedColumns([...array])
  }

  const onClear_FixedColumn = () => {
    //آرایه برای انتخاب شده و نشده DD:
    setSelectValues("")
    setFixedColumns([])
  }

  //ستون های انتخابی برای خروجی اکسل
  const [listOfColumns2, setListOfColumns2] = useState<any[]>([]) //option برای DD
  //[{id: 'rowIndex', title: 'ردیف'}]
  const [selectValues2, setSelectValues2] = useState<string>("") //ستون های انتخاب شده برای اکسل - رشته
  //rowIndex,fullName

  useEffect(() => {
    if (excelDownload && excelDownloadColumns !== undefined && setExcelDownloadColumns) {

      //---------------------------------------------------------------------------------
      //DD option:
      let columns_object: any[] = []
      tblConfig.row.map((col: tblConfigRowType) => {
        if (col.displayTitle && col.displayTitle !== "rowIndex") {
          columns_object.push({
            fieldName: col.displayTitle, //id - لاتین
            fieldTitle: col.headerTitle, //title - فارسی
          })
        }
      })
      setListOfColumns2(columns_object)
      //------------------------------------------------------------------------------------------------------------------------

      if (excelDownloadColumns === null || (excelDownloadColumns && excelDownloadColumns.length === 0)) { //مقدار پیشفرض نداشت 
        //آرایه برای انتخاب شده و نشده ی DD:
        let columns_string: string[] = []
        tblConfig.row.map((col: tblConfigRowType) => {
          if (col.displayTitle && col.displayTitle !== "rowIndex") {
            columns_string.push(col.displayTitle)
          }
        })
        setSelectValues2(columns_string.join(","))

        //آرایه برای api:
        setExcelDownloadColumns(columns_object)

      } else {
        //آرایه برای انتخاب شده و نشده ی DD:
        let columns_string: string[] = []
        excelDownloadColumns.map((each) => {
          columns_string.push(each.fieldName)
        })
        setSelectValues2(columns_string.join(","))

        //آرایه برای api:
        //-
      }
    }
  }, [])

  const onSelect_ExcelDownload = (newListOfString: string[]) => {
    //آرایه برای انتخاب شده و نشده ی DD:
    setSelectValues2(newListOfString.map((each: any) => each).join()) //تبدیل لیست به رشته

    //آرایه برای api:
    let array: any[] = []
    newListOfString.map((each: string) => {
      let i = listOfColumns2.find((option) => option.fieldName === each)
      array.push({
        fieldName: i?.fieldName || "",
        fieldTitle: i?.fieldTitle || "",
      })
    })
    setExcelDownloadColumns(array)
  }

  const onDeSelect_ExcelDownload = (selectedItem: any) => {
    //آرایه برای انتخاب شده و نشده ی DD:

    //تبدیل رشته به آرایه ای از رشته ها
    let array: any = selectValues2.split(',');
    //پیدا کردن ایندکس مورد انتخاب شده در لیست رشته ها
    let itemIndex = array.findIndex((each: any) => each === selectedItem.fieldName);
    //حذف از لیست رشته ها
    array.splice(itemIndex, 1);
    //تبدیل لیست جدید به رشته
    array = array.join(',');
    //ست کردن رشته ی جدید
    setSelectValues2(array)

    //آرایه برای api:
    setExcelDownloadColumns(RecordController.delete(excelDownloadColumns, selectedItem, "fieldName"))
  }

  const onClear_ExcelDownload = () => {
    //آرایه برای انتخاب شده و نشده DD:
    setSelectValues2("")
    //آرایه برای api:
    setExcelDownloadColumns(null)
  }

  return (
    display === "flex"
      ? <>
        <ActionsAndFilterConatiner className="CustomTable_ActionsAndFilterConatiner">
          <Row>
            <FilterAndSelectionBtnContainer className="CustomTable_FilterAndSelectionBtnContainer">
              {showFilter && (
                !showFilterDetails
                  ? <OutlineButton
                    className={"CustomTable_FilterButton"}
                    size="xs"
                    width="110px"
                    color="secondary"
                    icon={FilterIcon}
                    iconPosition="right"
                    title="فیلتر ها"
                    onClick={() => onFilterClick()}
                    type="button"
                  />
                  : <PrimaryButton
                    className={"CustomTable_FilterButton"}
                    size="xs"
                    width="110px"
                    color="secondary"
                    icon={FilterIcon}
                    iconPosition="right"
                    title="فیلتر ها"
                    onClick={() => onFilterClick()}
                    type="button"
                  />
              )}
              {showSelect &&
                <>
                  <OutlineButton
                    className={"CustomTable_SelectButton"}
                    size="xs"
                    width={selectionMode ? "160px" : "110px"}
                    color="primary"
                    icon={ChooseIcon}
                    iconPosition="right"
                    title={`انتخاب ${selectionMode ? `(${selectionListIDs?.length} مورد )` : ""}`}
                    onClick={toggleSelectionMode}
                    type="button"
                  />
                  {(selectionListIDs && selectionListIDs.length > 0) &&
                    <GhostButton
                      size="xs"
                      width="40px"
                      color="gray"
                      icon={DeleteIcon}
                      onClick={() => setSelectionListIDs([])}
                      type="button"
                    />
                  }
                </>
              }
            </FilterAndSelectionBtnContainer>
            <ActionBtnContainer className="CustomTable_ActionBtnContainer">
              {AdditionalButton && AdditionalButton.length !== 0 &&
                AdditionalButton.map((each: any) => { return each() })
              }
              {hasFixedColumns &&
                <Select
                  className="CustomTable_FreezeColumnSelect"
                  size="xs"
                  label={"فریز ستون ها"}
                  name="fixedList"
                  value={selectValues}
                  options={listOfColumns}
                  onSelect={onSelect_FixedColumn}
                  onDeSelect={onDeSelect_FixedColumn}
                  onClear={onClear_FixedColumn}
                  multi={true}
                />
              }
              {(
                excelDownload &&
                (excelDownloadColumns !== undefined) &&
                setExcelDownloadColumns
              ) &&
                <Select
                  className="CustomTable_ExcelColumnSelect"
                  size="xs"
                  label={"ستون های اکسل"}
                  name="fixedList"
                  value={selectValues2}
                  options={listOfColumns2}
                  displayTitle={"fieldTitle"}
                  displayId={"fieldName"}
                  columns={[{
                    size: 1,
                    headerTitle: "",
                    displayTitle: "fieldTitle",
                  }]}
                  onSelect={onSelect_ExcelDownload}
                  onDeSelect={onDeSelect_ExcelDownload}
                  onClear={onClear_ExcelDownload}
                  multi={true}
                />
              }
              {excelDownload &&
                <SecondaryButton
                  className={"CustomTable_ExcelDownloadButton"}
                  size={"xs"}
                  width={"max-content"}
                  color={"positive"}
                  icon={ExcelIcon}
                  iconPosition="right"
                  title={downlaodButtonTitle}
                  onClick={onExcelDownloadClick}
                  type={"button"}
                />
              }
              {excelUpload &&
                <OutlineButton
                  className={"CustomTable_SampleExcelUploadButton"}
                  size={"xs"}
                  width={"max-content"}
                  color={"positive"}
                  icon={ExcelIcon}
                  iconPosition="right"
                  title={'نمونه فایل'}
                  onClick={() => DownloadFile(sampleExcelFile, 'نمونه فایل اکسل', "xlsx")}
                />
              }
              {excelUpload &&
                <Row
                  className={"CustomTable_ExcelUpload"}
                >
                  <Row className="CustomTable_ExcelUpload_Input">
                    <SecondaryButton
                      className={"CustomTable_ExcelUploadButton"}
                      size={"xs"}
                      width={"max-content"}
                      color={"positive"}
                      icon={UploadIcon}
                      iconPosition="right"
                      title={excelFile ? excelFile.name : ""}
                      onClick={() => { }}
                      type={"button"}
                    />
                    <input
                      type="file"
                      value={""}
                      onChange={(e: any) => {
                        let file = e.target.files[0]
                        if (file) {
                          onExcelUploadClick(file)
                        } else {
                          onExcelUploadClick(null)
                        }
                      }}
                      accept={".xlsx"}
                    />
                  </Row>
                  {excelFile &&
                    <GhostButton
                      className="CustomTable_ExcelUpload_CancelIcon"
                      size={"xs"}
                      width={"max-content"}
                      color={"gray"}
                      icon={DeleteIcon}
                      type={"button"}
                      onClick={() => onExcelUploadClick(null)}
                    />
                  }
                </Row>
              }
              {add &&
                <PrimaryButton
                  className={"CustomTable_AddButton"}
                  size={"xs"}
                  width={"max-content"}
                  color={"primary"}
                  icon={AddIcon}
                  iconPosition="right"
                  title={addButtonTitle}
                  onClick={onAddClick}
                  type={"button"}
                  disabled={addDisabled}
                />
              }
            </ActionBtnContainer>
          </Row>
          <FilterContainer
            className="CustomTable_FilterContainer"
            showFilter={showFilterDetails}
            filterRowNumber={filterRowNumber}
            hasActionsAndFilter={hasActionsAndFilter}
          >
            {FilterComponent &&
              <Row>
                <FilterComponent
                  filterState={filterState}
                  setFilterState={setFilterState}
                  take={take}
                />
              </Row>
            }
          </FilterContainer>
        </ActionsAndFilterConatiner>
        <TableConatiner
          className="CustomTable_TableConatiner"
          showFilter={showFilterDetails}
          filterRowNumber={filterRowNumber}
          hasActionsAndFilter={hasActionsAndFilter}
        >
          {showCount &&
            <CountContainer className="CustomTable_CountContainer">
              <XXSmallParagraph color={theme.gray800}>
                تعداد رکورد:
              </XXSmallParagraph>
              <XSmallMonoLabel color={theme.gray900}>
                {separator(count)}
              </XSmallMonoLabel>
            </CountContainer>
          }
          {tableType === "normalTable"
            ? tblConfig && tblData &&
            <Table
              height={tblHeight}
              minHeight_mobile={tblMinHeight_mobile}
              minWidth={tblMinWidth}
              minWidth_tablet={tblMinWidth_tablet}
              minWidth_mobile={tblMinWidth_mobile}
              tblConfig={tblConfig}
              tblData={tblData}
              loading={loading}
              showPaging={showPaging}
              showCount={showCount}
              count={count}
              skip={skip}
              take={take}
              setTake={setTake}
              showTakeInput={showTakeInput}
              pageHandler={pageHandler}
              dragable={dragable}
              onDrop={onDrop}
              keyOfid={keyOfid}
              clientSidePagination={clientPagination}
              hasFixedColumns={hasFixedColumns}
              fixedColumns={fixedColumns}
            />
            : <TreeTable
              tblConfig={tblConfig}
              tblData={tblData || []}
              loading={loading}
              childPropertyName={childPropertyName}
            />
          }
        </TableConatiner>
        {/* mobile & tablet filter */}
        <SlidingMenuContainer className="CustomTable_SlidingMenuContainer">
          <SlidingMenu
            name="filter"
            hiddenBreakPoint={"769px"}
          >
            <Row className="tilte-and-icon">
              <XSmallLabel color={theme.gray800}>
                فیلتر ها
              </XSmallLabel>
              <Col
                className="close-icon-container"
                onClick={() => onFilterClick()}
              >
                <CrossIcon />
              </Col>
            </Row>
            {FilterComponent &&
              <FilterComponent
                filterState={filterState}
                setFilterState={setFilterState}
                take={take}
                filterCallback={filterCallback}
              />
            }
          </SlidingMenu>
        </SlidingMenuContainer>
      </>
      : <></>
  );
};

export default CustomTable;