import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { selectTheme } from "../../../Redux/App/Selectors";
import {
    IndexColumnStyle,
    PriceColumnContainer
} from "./styles";
import Row from "../Row";
import Col from "../Col";
import Checkbox from "../FromElements/Checkbox";
import { XXSmallParagraph } from "../Typography/Paragraph";
import PriceDetails from "../PriceDetails";
import NumberFormatter from "../../../Utils/NumberFormatter";
import DateTimeController from "../../../Utils/DateTimeController";


interface DateColumnProps {
    date: string,
    format?: string
}
export const DateColumn: React.FC<DateColumnProps> = (props) => {
    const {
        date,
        format,
    } = props;

    return (
        <XXSmallParagraph>
            {date
                ? DateTimeController.parseToJDate(date, format || "jYYYY/jMM/jDD")
                : "-"
            }
        </XXSmallParagraph>
    )
}

interface SelectableColumnProps {
    className?: string,
    title: string | number,
    enableSelection: boolean,
    checked: boolean,
    onClick: any,
}
export const SelectableColumn: React.FC<SelectableColumnProps> = (props) => {
    const {
        className,
        title,
        enableSelection,
        checked,
        onClick, //toggle
    } = props;

    return (
        <IndexColumnStyle className={className || ""}>
            {enableSelection &&
                <Checkbox
                    size="xs"
                    checked={checked}
                    text={""}
                    onClick={onClick}
                />
            }
            <XXSmallParagraph>
                {title}
            </XXSmallParagraph>
        </IndexColumnStyle>
    )
}

interface PriceColumnProps {
    price: string,
    //برای نمایش جزییات مبلغ
    showDetails?: boolean,
    name?: string,
    id?: number,
    detailsList?: any,
    displayTitleLabel?: string,
    displayTitleValue?: string,
    colored?: boolean,
    showBriefly?: boolean,
    showSign?: boolean
}
export const PriceColumn: React.FC<PriceColumnProps> = (props) => {
    const {
        price,
        showDetails = false,
        name,
        id,
        detailsList,
        displayTitleLabel,
        displayTitleValue,
        colored = false,
        showBriefly = false, //true -> نمایش با K, M, B 
        showSign = true //نمایش با علامت یا به صورت قدرمطلق
    } = props;

    const _price = Number(Number(price)?.toFixed(0))

    const theme = useSelector(selectTheme)

    const _id = `price-details-container-${name}-${id}`

    const onMouseEnter = () => {
        if (showDetails) {
            let element = document.getElementById(_id);
            let style = element?.style;
            if (style) {
                style.display = "flex";
                setTimeout(() => {
                    if (style) {
                        style.opacity = "1";
                    }
                }, 50)
            }
        }
    };

    const onMouseLeave = () => {
        if (showDetails) {
            let element = document.getElementById(_id);
            let style = element?.style
            if (style) {
                style.opacity = "0";
                setTimeout(() => {
                    if (style) {
                        style.display = "none";
                    }
                }, 50)
            }
        }
    };

    const textColor =
        colored
            ? _price > 0
                ? theme.positive600
                : _price < 0
                    ? theme.negative600
                    : theme.black
            : theme.black

    return (
        <PriceColumnContainer 
            showDetails={showDetails}
            onMouseEnter={onMouseEnter}
            onMouseLeave={onMouseLeave}
        >
            <Row>
                <XXSmallParagraph
                    color={textColor}
                >
                    {_price
                        ? showBriefly
                            ? NumberFormatter(_price)
                            : showSign
                                ? _price.toLocaleString()
                                : Math.abs(_price).toLocaleString()
                        : _price === 0
                            ? 0
                            : "-"
                    }
                </XXSmallParagraph>
            </Row>
            {showDetails &&
                <PriceDetails
                    id={_id}
                    list={detailsList}
                    displayTitleLabel={displayTitleLabel}
                    displayTitleValue={displayTitleValue}
                />
            }
        </PriceColumnContainer>
    )
}

interface NationalCodeColumnProps {
    customer: any,
    nationalCodeField?: string,
    personageIdField?: string,
}
export const CustomerNationalCodeColumn: React.FC<NationalCodeColumnProps> = (props) => {
    const dispatch = useDispatch();

    const {
        customer,
        nationalCodeField = "nationalCode",
        personageIdField = "personId",
    } = props;


    return (
        <Row className="operations">
            {customer
                ? <XXSmallParagraph>
                        {customer[nationalCodeField]}
                    </XXSmallParagraph>
                : <></>
            }
        </Row>
    )
}