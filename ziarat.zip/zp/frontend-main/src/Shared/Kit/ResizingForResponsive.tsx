export const ResizingForResponsive1920 = (
  size: "xl" | "lg" | "md" | "sm" | "xs"
) => {
  if (size === "xs") {
    return "xs";
  } else if (size === "sm") {
    return "md";
  } else if (size === "md") {
    return "lg";
  } else if (size === "lg") {
    return "lg";
  } else if (size === "xl") {
    return "xl";
  } else {
    return size;
  }
};

export const ResizingForResponsive768 = (
  size: "xl" | "lg" | "md" | "sm" | "xs"
) => {
  if (size === "xs") {
    return "xs";
  } else if (size === "sm") {
    return "lg";
  } else if (size === "md") {
    return "lg";
  } else if (size === "lg") {
    return "lg";
  } else if (size === "xl") {
    return "xl";
  } else {
    return size;
  }
};
