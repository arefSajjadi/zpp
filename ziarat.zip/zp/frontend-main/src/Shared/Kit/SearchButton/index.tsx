import {
    SearchFilterBtn
} from "./styles";
import { PrimaryButton } from "../Button/PrimaryButton";
import { GhostButton } from "../Button/GhostButton";

interface Props {
    clearFilters?: any,
    marginTop?: string,
}

const SearchButton: React.FC<Props> = (props) => {
    const {
        clearFilters,
        marginTop,
    } = props;

    return (
        <SearchFilterBtn
            marginTop={marginTop}
        >
            <PrimaryButton
                size='xs'
                width='90px'
                color='secondary'
                title={"جستجو"}
            />
            {clearFilters &&
                <GhostButton
                    className="clear-filter"
                    size='xs'
                    width='90px'
                    color='gray'
                    // color="negative"
                    title='حذف فیلترها'
                    type="button"
                    onClick={clearFilters}
                />
            }
        </SearchFilterBtn>
    )
}

export default SearchButton;