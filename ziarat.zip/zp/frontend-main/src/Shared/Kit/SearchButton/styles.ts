import styled from "styled-components";
import Col from "../Col";

interface SearchFilterBtnProps {
    marginTop?: string
}

export const SearchFilterBtn = styled(Col) <SearchFilterBtnProps>`
    width: max-content;
    gap: 3px;
    margin-top: ${(props) => props.marginTop || 0};
    .clear-filter {
        height: auto !important;
        * {
            scale: 0.8;
        }
    }
    .label {
        font-family: ${(props) => props.theme.fontFaNumRegular} !important;
    }
    @media screen and (max-width: 1366px) {
        margin-top: ${(props) => props.marginTop ? `calc(${props.marginTop} - 5px)` : 0};
    }
    @media screen and (max-width: 768px) {
        width: 100% !important;
        button {
            width: 100% !important;
        }
    }
`
