import styled from "styled-components";
import Row from "../Row";
import Col from "../Col";

export const DetailsContainer = styled(Row)`
    position: absolute;
    top: 0;
    bottom: auto;
    left: calc(100% - 5px);
    align-items: flex-start;
    justify-content: flex-start;
    width: 250px;
    padding: 0 10px;
    margin-left: 5px;
    background-color: ${(props) => props.theme.info50};
    border: 1px solid ${(props) => props.theme.info100};
    border-radius: 5px;
    z-index: 2;
    //motion
    display: none;
    opacity: 0;
    transition: all 300ms;
    > div {
        justify-content: space-between;
        padding: 5px 3px;
        border-bottom: 1px solid ${(props) => props.theme.info100};
        &:last-child {
            border-bottom: 0;
        }
    }
`;

export const IconContainer = styled(Col)`
    width: auto;
    margin-left: 8px;
    cursor: pointer;
    svg {
        width: 12px;
        height: 12px;
        fill:  ${(props) => props.theme.info600};
    }
`