import React from "react";
import { useSelector } from "react-redux";
import { selectTheme } from "../../../Redux/App/Selectors";
import {
    DetailsContainer,
    IconContainer
} from "./styles";
import Row from "../Row";
import { XXSmallMonoParagraph } from "../Typography/MonoParagraph";
import InfoIcon from "../Icons/InfoIcon";

interface Props {
    id: string
    list: any[]
    displayTitleLabel?: string
    displayTitleValue?: string
}

const PriceDetails: React.FC<Props> = (props) => {
    const theme = useSelector(selectTheme)

    const {
        id,
        list,
        displayTitleLabel = "title",
        displayTitleValue = "value",
    } = props;

    return (
        list && list.length !== 0
            ? <DetailsContainer
                id={id}
                className="price-details-container"
            >
                {list.map((item: any, index: number) => {
                    return (
                        <Row key={index}>
                            <XXSmallMonoParagraph color={theme.info600}>
                                {item[displayTitleLabel]}
                            </XXSmallMonoParagraph>
                            <XXSmallMonoParagraph color={theme.info600}>
                                {item[displayTitleValue]?.toLocaleString() || "-"}
                                {item.hasDetails &&
                                    <IconContainer onClick={() => item.onDetailsClick()}>
                                        <InfoIcon />
                                    </IconContainer>
                                }
                            </XXSmallMonoParagraph>
                        </Row>
                    );
                })}
            </DetailsContainer>
            : <></>
    )
}

export default PriceDetails;