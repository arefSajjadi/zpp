import HeaderItem from "./HeaderItem";
import {
    HeaderWrapper
} from "../styles";
import { tblConfigRowType } from "..";

interface Props {
    showHeader: boolean //tblConfig.showHeader
    tblConfigRow: tblConfigRowType[] //tblConfig.row
    mainArr: any[]
    setMainArr: any
}
const Header: React.FC<Props> = (props) => {
    const {
        showHeader,
        tblConfigRow,
        mainArr,
        setMainArr
    } = props;

    return (
        showHeader &&
        <HeaderWrapper>
            {tblConfigRow && tblConfigRow.map((RowOfTable: tblConfigRowType, i: number) => {
                return (
                    <HeaderItem
                        key={i}
                        RowOfTable={RowOfTable}
                        mainArr={mainArr}
                        setMainArr={setMainArr}
                    />
                )
            })}
        </HeaderWrapper>
    )
};

export default Header;