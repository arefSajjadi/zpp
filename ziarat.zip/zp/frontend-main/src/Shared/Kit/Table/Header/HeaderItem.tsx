import { useSelector } from "react-redux";
import { selectTheme } from "../../../../Redux/App/Selectors";
import {
    TblHeaderCol
} from "../styles";
import { GhostButton } from "../../Button/GhostButton";
import SortIcon from "../../Icons/SortIcon";
import { XXSmallParagraph } from "../../Typography/Paragraph";
import { SortOrderEnum } from "../../../../Utils/Enums";
import { tblConfigRowType } from "..";

interface Props {
    RowOfTable: tblConfigRowType
    mainArr: any[]
    setMainArr: any
}
const HeaderItem: React.FC<Props> = (props) => {
    const theme = useSelector(selectTheme)

    const {
        RowOfTable,
        mainArr,
        setMainArr
    } = props;

    const {
        headerTitle,
        headerElement,
        size,
        responsiveShow,
        responsiveBreakPoint,
        sort,
        sortOrder,
        headerCenter
    } = RowOfTable;

    //sort
    const sortHandler = (RowOfTable: any) => {
        const sortOrder = RowOfTable.sortOrder
        const setSortOrder = RowOfTable.setSortOrder
        let newOrder =
            !sortOrder
                ? SortOrderEnum.ASCENDING
                : sortOrder === SortOrderEnum.ASCENDING
                    ? SortOrderEnum.DESCENDING
                    : SortOrderEnum.ASCENDING
        setSortOrder(newOrder)
        const sortData = RowOfTable?.sort(mainArr, newOrder)
        setMainArr([...sortData])
    }

    let HeaderElement = (props: any) => (
        <RowOfTable.headerElement>
            {props.children}
        </RowOfTable.headerElement>
    );

    return (
        <TblHeaderCol
            flex={size}
            responsiveShow={responsiveShow !== undefined ? responsiveShow : true}
            responsiveBreakPoint={responsiveBreakPoint || 768}
            center={headerCenter}
        >
            {headerElement
                ? <HeaderElement></HeaderElement>
                : <>
                    {sort &&
                        <GhostButton
                            className={`sort-btn ${sortOrder}`}
                            size="xs"
                            width="16px"
                            color="gray"
                            icon={SortIcon}
                            onClick={() => {
                                sortHandler(RowOfTable)
                            }}
                            type="button"
                        />
                    }
                    <XXSmallParagraph
                        className={sort ? "sortable-header-cell-p" : ""}
                        color={theme.gray400}
                    >
                        {headerTitle}
                    </XXSmallParagraph>
                </>
            }
        </TblHeaderCol>
    )
};

export default HeaderItem;