import styled from "styled-components";
import Row from "../Row";
import Col from "../Col";
import { HexToRgba } from "../../../Utils/HexToRgba";

const HeaderHeight = "45px";
const FooterHeight = "70px";
const MobileFooterHeight = "150px";
const countHeight = "24px";
const TblRowHeight = "48px";

interface TableAndPaginationContainerProps {
  height: string;
  minHeight_mobile: string;
  showCount: boolean;
}
export const TableAndPaginationContainer = styled(Col) <TableAndPaginationContainerProps>`
  justify-content: flex-start;
  height: ${(props) =>
    props.height !== "auto"
      ? props.showCount
        ? `calc(${props.height} - ${countHeight})`
        : props.height
      : "auto"
  };
  min-height: ${(props) =>
    props.height !== "auto"
      ? props.showCount
        ? `calc(${props.height} - ${countHeight})`
        : props.height
      : "auto"
  };
  z-index: 1;
  @media screen and (max-width: 768px) {
    height: auto;
    min-height: ${(props) => props.minHeight_mobile || "auto"};
  } 
`
interface TablesContainerProps {
  showPaging: boolean
  minHeight_mobile: string
}
export const TablesContainer = styled(Col) <TablesContainerProps>`
  position: relative;
  align-items: flex-start;
  justify-content: flex-start;
  height: ${(props) => props.showPaging ? `calc(100% - ${FooterHeight})` : "100%"};
  min-height: ${(props) => props.showPaging ? `calc(100% - ${FooterHeight})` : "100%"};
  overflow-x: auto;
  overflow-y: auto;
  @media screen and (max-width: 768px) {
    height: auto;
    min-height: ${(props) => props.minHeight_mobile || "auto"};
  } 
`
interface HeaderAndBodyContainerProps {
  minWidth: string
  minWidth_tablet: string
  minWidth_mobile: string
}
export const HeadersAndBodiesContainer = styled(Col) <HeaderAndBodyContainerProps>`
  min-width: ${(props) => props.minWidth};
  @media screen and (max-width: 768px) {
    min-width: ${(props) => props.minWidth_tablet};
  }
  @media screen and (max-width: 480px) {
    min-width: ${(props) => props.minWidth_mobile};
  }
`
//Header-----------------------------------------------------------------
export const HeadersContainer = styled(Row)`
    position: sticky;
    top: 0;
    right: 0;
    z-index: 2;
`
interface FixHeaderContainerProps {
  fixedWidth: number,
}
export const FixHeaderContainer = styled(Row) <FixHeaderContainerProps>`
  position: sticky;
  top: 0;
  right: 0;
  width: ${(props) => props.fixedWidth}%;
  transition: all 300ms;
`
interface OtherHeaderContainerProps {
  otherWidth: number
}
export const OtherHeaderContainer = styled(Row) <OtherHeaderContainerProps>`
  width: ${(props) => props.otherWidth}%;
  transition: all 300ms;
`
export const HeaderWrapper = styled(Row)`
  height: ${HeaderHeight};
  min-height: ${HeaderHeight};
  background-color: ${(props) => props.theme.gray50};
`
interface TblHeaderColProps {
  flex: number;
  responsiveBreakPoint: number;
  responsiveShow: boolean;
  center?: boolean
}
export const TblHeaderCol = styled(Row) <TblHeaderColProps>`
  flex: ${(props) => props.flex};
  -webkit-flex: ${(props) => props.flex};
  padding-right: 10px;
  padding-left: 5px;
  border-right: 1px solid ${(props) => props.theme.gray200};
  justify-content: ${(props) => props.center ? "center" : "flex-start"};
  &:first-child {
    border-right: 0;
  }
  p {
    display: flex;
    overflow-wrap: anywhere;
    line-height: 1.4;
  }
  .sort-btn {
    height: 16px;
    margin-right: -5px;
    margin-left: 3px;
    margin-top: 1px;
    padding: 0;
    svg {
      width: 14px;
      height: 14px;
      fill: ${(props) => props.theme.black};
      opacity: 0.5;
    }
    &.ascending {
      svg {
        rotate: 180deg;
        opacity: 1;
      }
    }
    &.descending {
      svg {
        opacity: 1;
      }
    }
  }
  .sortable-header-cell-p {
    width: calc(100% - 14px);
  }
  ${(props) => {
    return `
      @media screen and (max-width: ${props.responsiveBreakPoint}px) {
        display: ${(props.responsiveShow === false) ? "none" : "flex"};
      }
    `;
  }}
`

//Body-----------------------------------------------------------------
export const BodiesContainer = styled(Row)`
  .draggableItem {
    width: 100%;
  }
  .droppableArea {
    width: 99%;
    height: 1px;
  }
  .drop {
    border-top: 1px dashed ${(props) => props.theme.gray600};
    border-bottom: 1px dashed ${(props) => props.theme.gray600};
    height: ${TblRowHeight} !important;
  }
  * {
    font-family: ${(props) => props.theme.fontStandardRegular} !important;
  }
  .operations {
    width: auto;
    gap: 5px;
    > div {
      width: auto;
      cursor: pointer;
    }
    .disabled {
      cursor: default;
      svg,
      svg path {
        fill: ${(props) => props.theme.gray400} !important;
      }
      &:hover {
        svg,
        svg path {
          fill: ${(props) => props.theme.gray400} !important;
        }
        * {
          background-color: transparent !important;
        }
      }
    }
    .w-26 {
      width: 26px;
    }
  }
  .underline {
    cursor: pointer;
    text-decoration-color: ${(props) => props.theme.white};
    text-underline-offset: 4px;
    color: ${(props) => props.theme.info800}; //x
    p {
      color: ${(props) => props.theme.info800};
    }
    &:hover {
      text-decoration: underline;
      text-decoration-color: ${(props) => props.theme.info600};
      color: ${(props) => props.theme.info600}; //x
      p {
        color: ${(props) => props.theme.info600};
      }
    }
    transition: all 300ms;
  }
`
interface FixBodyContainerProps {
  fixedWidth: number
}
export const FixBodyContainer = styled(Row) <FixBodyContainerProps>`
  position: sticky;
  top: 0 ;
  right: 0;
  width: ${(props) => props.fixedWidth}%;
  transition: all 300ms;
  .bict__tblCol {
    background-color: ${props => props.theme.info50};
  }
  z-index: 1;
`
interface OtherBodyContainerProps {
  otherWidth: number
}
export const OtherBodyContainer = styled(Col) <OtherBodyContainerProps>`
  width: ${(props) => props.otherWidth}%;
  transition: all 300ms;
`
export const TblRow = styled.div`
  display: flex;
  width: 100%;
  height: ${TblRowHeight};
  background-color: transparent;
  border-bottom: 1px solid ${props => props.theme.gray100};
  &:hover {
    background-color: ${(props) => HexToRgba(props.theme.gray50, 0.5)};
    transition: all 500ms;
  }
`
interface TblColProps {
  flex: number;
  responsiveBreakPoint: number;
  responsiveShow: boolean;
}
export const TblCol = styled(Row) <TblColProps>`
  flex: ${(props) => props.flex};
  -webkit-flex: ${(props) => props.flex};
  padding-right: 10px;
  padding-left: 5px;
  p {
    display: flex;
    overflow-wrap: anywhere;
    line-height: 1.4;
  }
  ${(props) => {
    return `
      @media screen and (max-width: ${props.responsiveBreakPoint}px) {
        display: ${(props.responsiveShow === false) ? "none" : "flex"};
      }
    `;
  }}
  @media screen and (max-width: 1366px) {
    svg {
      scale: 0.9;
    }
  }
`
export const LoaderContainer = styled(Col)`
`

//Footer-----------------------------------------------------------------
export const FooterContainer = styled(Row)`
  height: ${FooterHeight};
  justify-content: space-between;
  align-items: flex-end;
  @media screen and (max-width: 768px) {
    flex-direction: column;
    height: ${MobileFooterHeight};
    justify-content: flex-end;
    align-items: center;
    flex-wrap: nowrap;
  }
`;
export const RecordsPerPageContainer = styled(Row)`
  width: auto;
  gap: 5px;
  p {
    margin-left: 10px;
  }
  @media screen and (max-width: 768px) {
    width: 100%;
    margin-top: 20px;
    p {
      margin-left: auto;
    }
  }
`;
export const PaginationContainer = styled(Row)`
  width: auto;
  @media screen and (max-width: 768px) {
    width: 100%;
  }
`;
export const FromPageToPageContainer = styled(Row)`
  width: max-content;
  margin: 0 25px;
  gap: .5rem;
  label {
    min-width: 35px;
    text-align: center;
  }
  .pageNumber {
    width: 48px;
    input {
      text-align: center;
    }
  }
  /* Chrome, Safari, Edge, Opera */
  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
      -webkit-appearance: none;
  }
  /* Firefox */
  input[type=number] {
      -moz-appearance: textfield;
  }
  @media screen and (max-width: 768px) {
    margin: 0 auto;
  }
`