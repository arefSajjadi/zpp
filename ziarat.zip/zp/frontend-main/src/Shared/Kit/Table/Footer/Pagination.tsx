import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import { selectTheme } from "../../../../Redux/App/Selectors";
import {
  PaginationContainer,
  FromPageToPageContainer
} from "../styles";
import Input from "../../FromElements/Input";
import { OutlineButton } from "../../Button/OutlineButton";
import { XSmallLabel } from "../../Typography/Label";
import NextPageIcon from "../../Icons/NextPageIcon";
import PervPageIcon from "../../Icons/PervPageIcon";
import DoublePervIcon from "../../Icons/DoublePervIcon";
import DoubleNextIcon from "../../Icons/DoubleNextIcon";

export interface Props {
  skip: number,
  take: number,
  count: number,
  page: number,
  setPage: any,
  pageHandler: any
}
const Pagination: React.FC<Props> = (props) => {
  const theme = useSelector(selectTheme)

  const {
    skip,
    take,
    count,
    page,
    setPage,
    pageHandler
  } = props;

  let totalPage =
    count
      ? take === -1
        ? 1
        : Math.ceil(count / take)
      : 1;

  const _pageHandler = (skip: number) => {
    pageHandler(skip, take)
  }

  const goToFirstPage = () => {
    setPage(1)
    _pageHandler(0)
  }

  const goToLastPage = () => {
    setPage(totalPage)
    _pageHandler((totalPage - 1) * take)
  }

  const goToPrevPage = () => {
    if (page > 1) {
      setPage(page - 1)
      _pageHandler(skip - take - take)
    }
  }

  const goToNextPage = () => {
    if (page < totalPage) {
      setPage(page + 1)
      _pageHandler(skip)
    }
  }

  const changeHandler = (e: any) => {
    let value = e?.target?.value
    setPage(value)
  }

  useEffect(() => {
    const input = document.querySelector(".page-number-input")
    const keyDownHandler = (event: any) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        if (+page < 1) {
          goToFirstPage()
        } else if (+page > +totalPage) {
          goToLastPage()
        } else {
          _pageHandler((page - 1) * take)
        }
      }
    };
    input?.addEventListener('keydown', keyDownHandler);
    return () => {
      input?.removeEventListener('keydown', keyDownHandler);
    };
  }, [page]);

  return (
    <PaginationContainer>
      <OutlineButton
        className={"bict__paginationFirst"}
        size="xs"
        width="28px"
        color="gray"
        icon={DoublePervIcon}
        onClick={goToFirstPage}
        disabled={page === 1}
      />
      {/* -------------------------------------------------------------------------- */}
      <OutlineButton
        className={"bict__paginationPrevious"}
        size="xs"
        width="28px"
        color="gray"
        icon={PervPageIcon}
        onClick={goToPrevPage}
        disabled={page === 1}
      />
      {/* -------------------------------------------------------------------------- */}
      <FromPageToPageContainer>
        <Input
          className="pageNumber"
          inputClassName="page-number-input"
          size="xs"
          label=""
          name="pageNumber"
          value={page}
          onChange={changeHandler}
          onBlur={() => { }}
          disabled={count <= take ? true : false}
          type="number"
        />
        <XSmallLabel
          color={theme.gray800}
        >
          از
          {" "}
          {totalPage}
        </XSmallLabel>
      </FromPageToPageContainer>
      {/* -------------------------------------------------------------------------- */}
      <OutlineButton
        className={"bict__paginationNext"}
        size="xs"
        width="28px"
        color="gray"
        icon={NextPageIcon}
        onClick={goToNextPage}
        disabled={page === totalPage}
      />
      {/* -------------------------------------------------------------------------- */}
      <OutlineButton
        className={"bict__paginationLast"}
        size="xs"
        width="28px"
        color="gray"
        icon={DoubleNextIcon}
        onClick={goToLastPage}
        disabled={page === totalPage}
      />
    </PaginationContainer>
  );
};

export default Pagination;