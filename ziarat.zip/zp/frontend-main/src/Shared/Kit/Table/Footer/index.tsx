import {
    FooterContainer
} from "../styles";
import Pagination from "./Pagination";
import RecordsPerPage from "./RecordsPerPage";

export type optionType = {
    id: number,
    title: number
}
interface Props {
    showTakeInput: boolean
    options: optionType[]
    skip: number
    take: number
    setTake: any
    count: number
    page: number
    setPage: any
    pageHandler: any
    //برای client side paging 
    tblData: any[]
    setMainArr: any
    clientSidePagination: boolean
    clientSkip: number
    setClientSkip: any
}
const Footer: React.FC<Props> = (props) => {
    const {
        showTakeInput,
        options,
        skip,
        take,
        setTake,
        count,
        page,
        setPage,
        pageHandler,
        //برای client side paging 
        tblData,
        setMainArr,
        clientSidePagination,
        clientSkip,
        setClientSkip
    } = props;

    const clientPageHandler = (skip: any, take: any) => {
        setMainArr(tblData.slice(skip + 1, skip + take + 1)) //check
        setClientSkip(skip + take)
    }

    return (
        <FooterContainer>
            <Pagination
                skip={clientSidePagination ? clientSkip : skip}
                take={take}
                count={count}
                page={page}
                setPage={setPage}
                pageHandler={clientSidePagination ? clientPageHandler : pageHandler}
            />
            {showTakeInput &&
                <RecordsPerPage
                    options={options}
                    take={take}
                    setTake={setTake}
                    setPage={setPage}
                    pageHandler={clientSidePagination ? clientPageHandler : pageHandler}
                    count={count}
                />
            }
        </FooterContainer>
    )
};

export default Footer;