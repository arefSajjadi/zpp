import { useSelector } from "react-redux";
import { selectTheme } from "../../../../Redux/App/Selectors";
import {
    RecordsPerPageContainer
} from "../styles";
import { XSmallParagraph } from "../../Typography/Paragraph";
import { PrimaryButton } from "../../Button/PrimaryButton";
import { OutlineButton } from "../../Button/OutlineButton";
import { optionType } from ".";

interface Props {
    options: optionType[]
    take: number
    setTake: any
    setPage: any
    pageHandler: any
    count: number
}
const RecordsPerPage: React.FC<Props> = (props) => {
    const theme = useSelector(selectTheme)

    const {
        options,
        take,
        setTake,
        setPage,
        pageHandler,
        count
    } = props;

    const selectHandler = (e: any) => {
        setTake(e.title)
        pageHandler(0, e.title)
        setPage(1)
    }

    return (
        <RecordsPerPageContainer>
            <XSmallParagraph color={theme.gray600}>
                تعداد رکورد در هر صفحه:
            </XSmallParagraph>
            {options.map((each: optionType, index: number) => {
                let active = each.title === take
                let value = options[index].title
                let prvValue = index !== 0 ? options[index - 1].title : 0
                let disable = count < value ? true : false
                let prvDisable = count < prvValue ? true : false
                let d =
                    disable
                        ? prvDisable
                            ? true
                            : false
                        : false
                return (
                    active
                        ? <PrimaryButton
                            key={index + 1}
                            size={"xs"}
                            width={"36px"}
                            color={"secondary"}
                            title={(each.title).toString()}
                            type={"button"}
                            onClick={() => selectHandler(each)}
                        />
                        : <OutlineButton
                            key={index + 1}
                            size={"xs"}
                            width={"36px"}
                            color={"secondary"}
                            title={(each.title).toString()}
                            type={"button"}
                            onClick={() => selectHandler(each)}
                            disabled={d}
                        />
                )
            })}
        </RecordsPerPageContainer>
    )
};

export default RecordsPerPage;