import React, { useState, useEffect } from "react";
import {
  TableAndPaginationContainer,
  TablesContainer,
  HeadersAndBodiesContainer,
  HeadersContainer,
  FixHeaderContainer,
  OtherHeaderContainer,
  BodiesContainer,
  FixBodyContainer,
  OtherBodyContainer,
  LoaderContainer,
} from "./styles";
import Loading from "../Loading";
import Header from "./Header";
import Body from "./Body";
import Footer from "./Footer";

type onDropFunction = (
  oldIndex: number,
  newIndex: number,
  id: number,
  callback: any
) => any | void;

export type TableProps = {
  height?: string;
  minHeight_mobile?: string;
  minWidth?: string; //...-768px
  minWidth_tablet?: string; //768px-480px
  minWidth_mobile?: string; //480px-...
  tblConfig: tblConfigType;
  tblData: any[];
  loading?: boolean;
  showCount?: boolean;
  count?: number;
  skip?: number;
  take?: number;
  setTake?: any;
  showTakeInput?: boolean;
  showPaging?: boolean;
  pageHandler?: any;
  //برای drag
  dragable?: boolean;
  onDrop?: onDropFunction;
  keyOfid?: string;
  //برای client side paging -> چک شود
  clientSidePagination?: boolean;
  //برای فریز جدول
  hasFixedColumns?: boolean;
  fixedColumns?: string[];
};

export type tblConfigType = {
  showHeader: boolean;
  row: tblConfigRowType[];
};

export type tblConfigRowType = {
  headerTitle: string;
  headerElement?: any;
  headerCenter?: boolean;
  displayTitle: string;
  element?: any;
  size: number;
  responsiveShow?: boolean;
  responsiveBreakPoint: number;
  //برای سورت
  sort?: any;
  sortOrder?: string;
  setSortOrder?: any;
  //برای دسترسی
  access?: boolean;
  //برای فریز جدول
  fixed?: boolean;
};

//برای RecordsPerPage
export const options = [
  {
    id: 1,
    title: 15,
  },
  {
    id: 2,
    title: 30,
  },
  {
    id: 3,
    title: 60,
  },
];

const Table: React.FC<TableProps> = (props) => {
  const {
    height = "100%",
    minHeight_mobile = "", //tablet, mobile
    minWidth = "auto",
    minWidth_tablet = "",
    minWidth_mobile = "",
    tblConfig,
    tblData,
    loading = false,
    showCount = true,
    count = 0,
    skip = 0,
    take = options[0].title,
    setTake,
    showTakeInput = true,
    showPaging = true,
    pageHandler,
    //برای drag
    dragable,
    onDrop,
    keyOfid = "id",
    //برای client side paging
    clientSidePagination = false,
    //برای فریز جدول
    hasFixedColumns = false,
    fixedColumns = [], //ستون های انتخاب شده برای فریز - آرایه
  } = props;

  const [page, setPage] = useState(1);
  const [mainArr, setMainArr] = useState<any[]>([]); //به عنوان tblData
  const [clientSkip, setClientSkip] = useState(take); //برای client side paging

  useEffect(() => {
    if (skip === take) {
      setPage(1);
    }
  }, [skip]);

  useEffect(() => {
    if (tblData) {
      if (clientSidePagination) {
        setMainArr(tblData.slice(clientSkip, clientSkip + take + 1)); //check
      } else {
        setMainArr(tblData);
      }
    } else {
      setMainArr([]);
    }
  }, [tblData]);

  //برای فریز جدول
  const [fixedTblConfigRow, setFixedTblConfigRow] = useState<
    tblConfigRowType[]
  >([]);
  const [otherTblConfigRow, setOtherTblConfigRow] = useState<
    tblConfigRowType[]
  >([]);

  useEffect(() => {
    if (
      hasFixedColumns &&
      fixedColumns &&
      fixedColumns?.length >= 0 &&
      tblConfig?.row?.length >= 0
    ) {
      let fixed: tblConfigRowType[] = [];
      let other: tblConfigRowType[] = [];
      tblConfig.row.map((item) => {
        if (fixedColumns.includes(item.displayTitle)) {
          fixed.push(item);
        } else {
          other.push(item);
        }
      });
      setFixedTblConfigRow(fixed);
      setOtherTblConfigRow(other);
    } else {
      setFixedTblConfigRow([]);
      setOtherTblConfigRow(tblConfig.row);
    }
  }, [fixedColumns, tblConfig]);

  //اندازه هر جدول
  const [fixedColumnWidth, setFixedColumnWidth] = useState(0);
  useEffect(() => {
    if (fixedTblConfigRow) {
      let flex = 0;
      fixedTblConfigRow?.map((each) => {
        flex = flex + each.size;
      });
      setFixedColumnWidth(flex);
    } else {
      setFixedColumnWidth(0);
    }
  }, [fixedTblConfigRow]);

  const [otherColumnWidth, setOtherColumnWidth] = useState(0);
  useEffect(() => {
    if (otherTblConfigRow) {
      let flex = 0;
      otherTblConfigRow?.map((each) => {
        flex = flex + each.size;
      });
      setOtherColumnWidth(flex);
    } else {
      setOtherColumnWidth(0);
    }
  }, [otherTblConfigRow]);

  return (
    <TableAndPaginationContainer
      height={height}
      minHeight_mobile={minHeight_mobile}
      showCount={showCount}
    >
      <TablesContainer
        className="horizontal-custom-scroll-bar custom-scroll-bar"
        showPaging={showPaging}
        minHeight_mobile={minHeight_mobile}
      >
        <HeadersAndBodiesContainer
          minWidth={minWidth}
          minWidth_tablet={minWidth_tablet}
          minWidth_mobile={minWidth_mobile}
        >
          <HeadersContainer>
            {hasFixedColumns && fixedColumns && fixedColumns.length > 0 && (
              <FixHeaderContainer
                fixedWidth={
                  (fixedColumnWidth / (fixedColumnWidth + otherColumnWidth)) *
                  100
                }
              >
                <Header
                  showHeader={tblConfig?.showHeader}
                  tblConfigRow={fixedTblConfigRow}
                  mainArr={mainArr}
                  setMainArr={setMainArr}
                />
              </FixHeaderContainer>
            )}
            <OtherHeaderContainer
              otherWidth={
                (otherColumnWidth / (fixedColumnWidth + otherColumnWidth)) * 100
              }
            >
              <Header
                showHeader={tblConfig?.showHeader}
                tblConfigRow={otherTblConfigRow}
                mainArr={mainArr}
                setMainArr={setMainArr}
              />
            </OtherHeaderContainer>
          </HeadersContainer>
          <BodiesContainer>
            {hasFixedColumns && fixedColumns && fixedColumns.length > 0 && (
              <FixBodyContainer
                fixedWidth={
                  (fixedColumnWidth / (fixedColumnWidth + otherColumnWidth)) *
                  100
                }
                className="bict__tblBodyWrapper"
              >
                {loading ? (
                  <></>
                ) : (
                  <Body
                    mainArr={mainArr}
                    setMainArr={setMainArr}
                    tblConfigRow={fixedTblConfigRow}
                    skip={skip}
                    take={take}
                    clientSidePagination={clientSidePagination}
                    clientSkip={clientSkip}
                    dragable={dragable || false}
                    onDrop={onDrop}
                    keyOfid={keyOfid}
                  />
                )}
              </FixBodyContainer>
            )}
            <OtherBodyContainer
              otherWidth={
                (otherColumnWidth / (fixedColumnWidth + otherColumnWidth)) * 100
              }
              className="bict__tblBodyWrapper"
            >
              {loading ? (
                <LoaderContainer>
                  <Loading />
                </LoaderContainer>
              ) : (
                <Body
                  mainArr={mainArr}
                  setMainArr={setMainArr}
                  tblConfigRow={otherTblConfigRow}
                  skip={skip}
                  take={take}
                  clientSidePagination={clientSidePagination}
                  clientSkip={clientSkip}
                  dragable={dragable || false}
                  onDrop={onDrop}
                  keyOfid={keyOfid}
                />
              )}
            </OtherBodyContainer>
          </BodiesContainer>
        </HeadersAndBodiesContainer>
      </TablesContainer>
      {showPaging && (
        <Footer
          showTakeInput={showTakeInput}
          options={options}
          skip={skip}
          take={take}
          setTake={setTake}
          count={count}
          page={page}
          setPage={setPage}
          pageHandler={pageHandler}
          tblData={tblData}
          setMainArr={setMainArr}
          clientSidePagination={clientSidePagination}
          clientSkip={clientSkip}
          setClientSkip={setClientSkip}
        />
      )}
    </TableAndPaginationContainer>
  );
};

export default Table;
