import {
    TblCol,
} from "../styles";
import { XXSmallParagraph } from "../../Typography/Paragraph";
import { tblConfigRowType } from "..";

interface Props {
    each: any //یک رکورد دیتای جدول
    i: number
    RowOfTable: tblConfigRowType
    skip: number
    take: number
    //برای client side paging 
    clientSidePagination: boolean
    clientSkip: number
}
const BodyItem: React.FC<Props> = (props) => {
    const {
        each, //یک رکورد دیتای جدول
        i,
        RowOfTable,
        skip,
        take,
        //برای client side paging 
        clientSidePagination,
        clientSkip,
    } = props;

    const {
        element,
        displayTitle,
        size,
        responsiveShow,
        responsiveBreakPoint,
        fixed,
        access
    } = RowOfTable;

    const rowIndex =
        !clientSidePagination
            ? skip
                ? skip - take + i + 1
                : i + 1
            : clientSkip
                ? clientSkip - take + i + 1
                : i + 1

    let Element = (props: any) => (
        <RowOfTable.element
            index={i}
            row={each}
            rowIndex={rowIndex}
        // DataLength={mainArr.length} //?
        >
            {props.children}
        </RowOfTable.element>
    );

    return (
        <TblCol
            className={"bict__tblCol"}
            flex={size}
            responsiveShow={responsiveShow !== undefined ? responsiveShow : true}
            responsiveBreakPoint={responsiveBreakPoint || 768}
        >
            {access !== false
                ? element
                    ? <Element></Element>
                    : <XXSmallParagraph>
                        {displayTitle === "rowIndex"
                            ? rowIndex
                            : each[displayTitle]
                        }
                    </XXSmallParagraph>
                : <></>
            }
        </TblCol>
    )
};

export default BodyItem;