import { useState } from "react";
import {
    TblRow
} from "../styles";
import Row from "../../Row";
import BodyItem from "./BodyItem";
import DroppableArea from "./DroppableArea";
import DraggableItem from "./DraggableItem";
import NoItem from "../../NoItem";
import { tblConfigRowType } from "..";

interface Props {
    mainArr: any[]
    setMainArr: any
    tblConfigRow: tblConfigRowType[] //tblConfig.row
    skip: number
    take: number
    //برای client side paging 
    clientSidePagination: boolean
    clientSkip: number
    //برای drag
    dragable: boolean
    onDrop: any
    keyOfid: string
}
const Body: React.FC<Props> = (props) => {
    const {
        mainArr,
        setMainArr,
        tblConfigRow,
        skip,
        take,
        //برای client side paging 
        clientSidePagination,
        clientSkip,
        //برای drag
        dragable,
        onDrop,
        keyOfid,
    } = props;



    return (
        mainArr && mainArr.length !== 0
            ? mainArr.map((each: any, i: number) => {
                return (
                    <Row
                        key={
                            keyOfid === "index"
                                ? i
                                : (each[keyOfid] || i)
                        }
                    >
                
                            <TblRow
                                accessKey={`${i}`} //?
                                id={each[keyOfid]} //?
                                className={
                                    `bict__tblRow 
                                    ${(i + 1) % 2 === 0
                                        ? `bict__tblRow__even`
                                        : `bict__tblRow__odd`
                                    }`
                                }
                                draggable={dragable} //?
                            >
                                {tblConfigRow && tblConfigRow.map((Row: tblConfigRowType, colIndex: number) => {
                                    return (
                                        <BodyItem
                                            key={i + colIndex}
                                            each={each}
                                            i={i}
                                            RowOfTable={Row}
                                            skip={skip}
                                            take={take}
                                            clientSidePagination={clientSidePagination}
                                            clientSkip={clientSkip}
                                        />
                                    )
                                })}
                            </TblRow>
                       
                    </Row>
                );
            })
            : <TblRow className="bict__tblRow bict__noItem">
                <NoItem center />
            </TblRow>
    )
};

export default Body;