import React from 'react';

interface DraggableAreaProps {
  dragable: boolean,
  index: string,
  onDragStart: any,
  children: any,
}

const DraggableItem: React.FC<DraggableAreaProps> = ({
  dragable = false,
  index,
  onDragStart,
  children,
}) => {
  return (
    <div
      className='draggableItem'
      accessKey={index}
      draggable={dragable}
      onDragStart={(e: any) => onDragStart(e, index)}
    >
      {children}
    </div>
  );
};

export default DraggableItem;