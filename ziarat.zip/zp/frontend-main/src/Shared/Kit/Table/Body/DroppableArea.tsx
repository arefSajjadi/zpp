import React from 'react';

interface DroppableAreaProps {
  index: string,
  onDrop: any,
  onDragOver: any,
  onDragEnter: any,
  onDragLeave: any,
  onDragEnd: any,
}

const DroppableArea: React.FC<DroppableAreaProps> = ({
  index,
  onDrop,
  onDragOver,
  onDragEnter,
  onDragLeave,
  onDragEnd,
}) => {
  return (
    <div
      className="droppableArea"
      accessKey={index}
      onDrop={onDrop}
      onDragOver={onDragOver}
      onDragEnter={onDragEnter}
      onDragLeave={onDragLeave}
    //onDragEnd={onDragEnd}
    >
    </div>
  );
};

export default DroppableArea;