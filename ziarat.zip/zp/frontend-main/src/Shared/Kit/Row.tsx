import React, { forwardRef } from "react";
import styled from "styled-components";

const getWidthString = (span: number) => {
  if (span) {
    let width = (span / 24) * 100;
    return `width: ${width}%;`;
  }
};

interface StyledRowProps {
  xl?: number;
  lg?: number;
  md?: number;
  mi?: number;
  sm?: number;
  xs?: number;
}

const StyledRow = styled.div<StyledRowProps>`
  display: flex;
  direction: rtl;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  box-sizing: border-box;
  line-height: 1.6;
  flex-wrap: wrap;
  -webkit-flex-wrap : wrap;
  ${(props) => props.xl ? getWidthString(props.xl) : "width : 100%"};
  @media screen and (max-width: 1366px) {
    ${(props) =>
    (props.lg || props.xl) &&
    getWidthString(
      props.lg
        ? props.lg
        : props.xl
          ? props.xl
          : 24
    )
  }
  };
  @media screen and (max-width: 1287px) {
    ${(props) =>
    (props.md || props.lg || props.xl) &&
    getWidthString(
      props.md
        ? props.md
        : props.lg
          ? props.lg
          : props.xl
            ? props.xl
            : 24
    )
  }
  };
  @media screen and (max-width: 1024px) {
    ${(props) =>
    (props.mi || props.md || props.lg || props.xl) &&
    getWidthString(
      props.mi
        ? props.mi
        : props.md
          ? props.md
          : props.lg
            ? props.lg
            : props.xl
              ? props.xl
              : 24
    )
  }
  }
  @media screen and (max-width: 768px) {
    ${(props) =>
    (props.sm || props.md || props.lg || props.xl) &&
    getWidthString(
      props.sm
        ? props.sm
        : props.mi
          ? props.mi
          : props.md
            ? props.md
            : props.lg
              ? props.lg
              : props.xl
                ? props.xl
                : 24
    )
  }
  };
  @media screen and (max-width: 480px) {
    ${(props) =>
    (props.xs || props.sm || props.md || props.lg || props.xl) &&
    getWidthString(
      props.xs
        ? props.xs
        : props.sm
          ? props.sm
          : props.mi
            ? props.mi
            : props.md
              ? props.md
              : props.lg
                ? props.lg
                : props.xl
                  ? props.xl
                  : 24
    )
  }
  }
`;

interface Props {
  xl?: number;
  lg?: number;
  md?: number;
  mi?: number;
  sm?: number;
  xs?: number;
  children?: React.ReactNode;
  id?: string;
  className?: string;
  onClick?: (...args: any) => void;
  onMouseEnter?: () => void;
  onMouseLeave?: () => void;
  onScroll?: any;
}

const Row = forwardRef((props: Props, ref) => {
  return <StyledRow
    // ref={ref} 
    {...props}
  ></StyledRow>;
});

Row.displayName = "Row";

export default Row;