import React ,{useState ,useEffect} from 'react';
import { CircleContainer } from './styles';
import { XXSmallMonoLabel } from '../Typography/MonoLabel';

interface CircleColumnProps {
    content:string
} 
const CircleColumn:React.FC<CircleColumnProps> = ({content}) => {
    return ( 
        <CircleContainer>
            <XXSmallMonoLabel className='contentLabel' >
                {content}
            </XXSmallMonoLabel>
        </CircleContainer>
     );
}
 
export default CircleColumn;
