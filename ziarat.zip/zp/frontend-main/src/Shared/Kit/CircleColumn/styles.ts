import styled from "styled-components";
import Row from "../Row";


export const CircleContainer = styled(Row)`
    justify-content: center;
    align-items: center;
    width: 20px;
    height: 20px;
    /* padding: 4px 16px; */
    border-radius: 50%;
    background-color:${props => props.theme.info700};

    .contentLabel {
        color: ${props => props.theme.white};
    }
`