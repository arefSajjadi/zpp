import React, { useEffect, useState } from "react";
import moment from "moment-jalaali";
import ArrowDownIcon from "../Kit/Icons/ArrowDownIcon";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import Divider from "../Kit/Divider";
import { SmallParagraph, XXSmallParagraph } from "../Kit/Typography/Paragraph";
import { PrimaryButton } from "../Kit/Button/PrimaryButton";
import CalendarIcon from "@/Assets/Icons/CalendarIcon";

interface Props {
  isOpenCalendar: boolean;
  setIsOpenCalendar: (val: boolean) => void;
  dateRange: { from: string | null; to: string | null };
  setDateRange: (range: { from: string | null; to: string | null }) => void;
}

const DateRangeInput: React.FC<Props> = ({
  isOpenCalendar,
  setIsOpenCalendar,
  dateRange,
  setDateRange,
}) => {
  const theme = useSelector(selectTheme);

  const persianMonths = [
    "فروردین",
    "اردیبهشت",
    "خرداد",
    "تیر",
    "مرداد",
    "شهریور",
    "مهر",
    "آبان",
    "آذر",
    "دی",
    "بهمن",
    "اسفند",
  ];
  const weekDays = ["شنبه", "یک", "دو", "سه", "چهار", "پنج", "جمعه"];

  const [currentMonth, setCurrentMonth] = useState(() => {
    const now = moment();
    return { year: now.jYear(), month: now.jMonth() + 1 };
  });

  const [selectedRange, setSelectedRange] = useState<
    [string | null, string | null]
  >([dateRange.from || null, dateRange.to || null]);

  const [hoverDate, setHoverDate] = useState<string | null>(null);

  useEffect(() => {
    setSelectedRange([null, null]);
    setDateRange({ from: null, to: null });
  }, []);

  const getDaysInMonth = (year: number, month: number) => {
    return moment.jDaysInMonth(year, month - 1);
  };

  const getFirstDayOfMonth = (year: number, month: number) => {
    const firstDay = moment(`${year}/${month}/1`, "jYYYY/jM/jD");
    const dayOfWeek = firstDay.day();
    return dayOfWeek === 6 ? 0 : dayOfWeek + 1;
  };

  const generateCalendarDays = () => {
    const daysInMonth = getDaysInMonth(currentMonth.year, currentMonth.month);
    const firstDay = getFirstDayOfMonth(currentMonth.year, currentMonth.month);
    const days: (number | null)[] = [];

    for (let i = 0; i < firstDay; i++) days.push(null);
    for (let i = 1; i <= daysInMonth; i++) days.push(i);

    return days;
  };

  const formatDate = (year: number, month: number, day: number) => {
    return `${year}/${String(month).padStart(2, "0")}/${String(day).padStart(
      2,
      "0"
    )}`;
  };

  const parseDate = (
    dateStr: string | null
  ): { year: number; month: number; day: number } | null => {
    if (!dateStr) return null;
    const parts = dateStr.split("/");
    return {
      year: parseInt(parts[0]),
      month: parseInt(parts[1]),
      day: parseInt(parts[2]),
    };
  };

  const compareDates = (date1: string, date2: string) => {
    const d1 = parseDate(date1);
    const d2 = parseDate(date2);
    if (!d1 || !d2) return 0;
    const num1 = d1.year * 10000 + d1.month * 100 + d1.day;
    const num2 = d2.year * 10000 + d2.month * 100 + d2.day;
    return num1 - num2;
  };

  const isDateInRange = (dateStr: string) => {
    if (!selectedRange[0]) return false;
    const from = selectedRange[0];
    const to = selectedRange[1] || hoverDate;
    if (!to) return false;

    const compareFrom = compareDates(dateStr, from);
    const compareTo = compareDates(dateStr, to);

    if (compareDates(from, to) > 0) {
      return compareFrom <= 0 && compareTo >= 0;
    }
    return compareFrom >= 0 && compareTo <= 0;
  };

  const isDateDisabled = (year: number, month: number, day: number) => {
    const dateToCheck = moment(`${year}/${month}/${day}`, "jYYYY/jM/jD");
    const today = moment().startOf("day");
    return dateToCheck.isBefore(today);
  };

  const convertToGregorian = (jalaaliDate: string) => {
    const parsed = parseDate(jalaaliDate);
    if (!parsed) return null;
    moment.loadPersian({ usePersianDigits: false });
    const gregorianDate = moment(
      `${parsed.year}/${parsed.month}/${parsed.day}`,
      "jYYYY/jM/jD"
    );
    return gregorianDate.format("YYYY-MM-DD");
  };

  const handleDateClick = (day: number) => {
    const dateStr = formatDate(currentMonth.year, currentMonth.month, day);

    if (isDateDisabled(currentMonth.year, currentMonth.month, day)) return;

    if (!selectedRange[0] || (selectedRange[0] && selectedRange[1])) {
      const newRange: [string | null, string | null] = [dateStr, null];
      setSelectedRange(newRange);
      setDateRange({
        from: convertToGregorian(dateStr),
        to: null,
      });
    } else {
      if (compareDates(dateStr, selectedRange[0]) < 0) {
        const newRange: [string | null, string | null] = [dateStr, null];
        setSelectedRange(newRange);
        setDateRange({
          from: convertToGregorian(dateStr),
          to: null,
        });
      } else {
        const newRange: [string | null, string | null] = [
          selectedRange[0],
          dateStr,
        ];
        setSelectedRange(newRange);
        setDateRange({
          from: convertToGregorian(selectedRange[0]),
          to: convertToGregorian(dateStr),
        });
      }
    }
  };

  const getDisplayText = () => {
    if (selectedRange[0] && selectedRange[1]) {
      const from = parseDate(selectedRange[0]);
      const to = parseDate(selectedRange[1]);

      if (from && to) {
        return (
          <SmallParagraph color={theme.gray600}>
            {from.day} {persianMonths[from.month - 1]} - {to.day}{" "}
            {persianMonths[to.month - 1]}
          </SmallParagraph>
        );
      }
    } else if (selectedRange[0]) {
      const from = parseDate(selectedRange[0]);
      if (from)
        return (
          <SmallParagraph color={theme.gray600}>
            {from.day} {persianMonths[from.month - 1]} - انتخاب تاریخ پایان
          </SmallParagraph>
        );
    }
    return <SmallParagraph color={theme.gray600}>انتخاب کنید</SmallParagraph>;
  };

  const isPrevMonthDisabled = () => {
    const today = moment();
    const currentYear = today.jYear();
    const currentMonthNum = today.jMonth() + 1;

    if (currentMonth.year < currentYear) return true;
    if (
      currentMonth.year === currentYear &&
      currentMonth.month <= currentMonthNum
    )
      return true;

    return false;
  };

  const goToPrevMonth = () => {
    if (isPrevMonthDisabled()) return;

    if (currentMonth.month === 1) {
      setCurrentMonth({ year: currentMonth.year - 1, month: 12 });
    } else {
      setCurrentMonth({ ...currentMonth, month: currentMonth.month - 1 });
    }
  };

  const goToNextMonth = () => {
    if (currentMonth.month === 12) {
      setCurrentMonth({ year: currentMonth.year + 1, month: 1 });
    } else {
      setCurrentMonth({ ...currentMonth, month: currentMonth.month + 1 });
    }
  };

  const isFriday = (year: number, month: number, day: number) => {
    const date = moment(`${year}/${month}/${day}`, "jYYYY/jM/jD");
    return date.day() === 5;
  };

  return (
    <div style={{ width: "100%", direction: "rtl", fontFamily: "sans-serif" }}>
      <div
        style={{
          fontSize: "16px",
          color: selectedRange[0] ? theme.gray400 : "#999",
          display: "flex",
          gap: "7px",
          cursor: "pointer",
          alignItems: "center",
        }}
        onClick={() => setIsOpenCalendar(true)}
      >
        <CalendarIcon color={theme.gray600} />

        <SmallParagraph color={theme.gray600}>انتخاب بازه سفر</SmallParagraph>
        <Divider
          orientation="vertical"
          width="1px"
          height="30px"
          bgColor={theme.gray100}
        />
        {getDisplayText()}
      </div>

      {isOpenCalendar && (
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "15px",
            paddingBottom: "8px",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              margin: "16px 0",
              padding: "0 8px",
            }}
          >
            <div
              onClick={goToPrevMonth}
              style={{
                cursor: isPrevMonthDisabled() ? "not-allowed" : "pointer",
                padding: "8px",
                rotate: "-90deg",
                opacity: isPrevMonthDisabled() ? 0.3 : 1,
                transform: "scale(1.5)",
              }}
            >
              <ArrowDownIcon color={theme.primary500} />
            </div>
            <span
              style={{
                fontSize: "16px",
                fontWeight: "600",
                color: theme.primary500,
              }}
            >
              {persianMonths[currentMonth.month - 1]} {currentMonth.year}
            </span>
            <div
              onClick={goToNextMonth}
              style={{
                cursor: "pointer",
                padding: "8px",
                rotate: "90deg",
                transform: "scale(1.5)",
              }}
            >
              <ArrowDownIcon color={theme.primary500} />
            </div>
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(7, 1fr)",
              gap: "4px",
              marginBottom: "8px",
            }}
          >
            {weekDays.map((day) => (
              <div
                key={day}
                style={{
                  textAlign: "center",
                  fontSize: "14px",
                  color: theme.primary500,
                  padding: "8px 0",
                }}
              >
                {day}
              </div>
            ))}
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(7, 1fr)",
              rowGap: "5px",
            }}
          >
            {generateCalendarDays().map((day, idx) => {
              if (day === null) return <div key={idx} />;

              const dateStr = formatDate(
                currentMonth.year,
                currentMonth.month,
                day
              );
              const isSelected =
                dateStr === selectedRange[0] || dateStr === selectedRange[1];
              const isInRange = isDateInRange(dateStr);
              const isDisabled = isDateDisabled(
                currentMonth.year,
                currentMonth.month,
                day
              );
              const isStart = dateStr === selectedRange[0];
              const isEnd = dateStr === selectedRange[1];
              const isFridayDay = isFriday(
                currentMonth.year,
                currentMonth.month,
                day
              );
              return (
                <button
                  key={idx}
                  onClick={() => handleDateClick(day)}
                  onMouseEnter={() => !isDisabled && setHoverDate(dateStr)}
                  onMouseLeave={() => setHoverDate(null)}
                  disabled={isDisabled}
                  style={{
                    padding: "8px",
                    border: "none",
                    borderRadius:
                      isStart || isEnd ? "8px" : isInRange ? "0" : "8px",
                    cursor: isDisabled ? "not-allowed" : "pointer",
                    backgroundColor: isSelected
                      ? theme.primary400
                      : isInRange
                      ? "#e6f2ff"
                      : "transparent",
                    color: isSelected
                      ? "#fff"
                      : isInRange
                      ? theme.gray500
                      : isDisabled
                      ? "#ccc"
                      : isFridayDay
                      ? theme.negative300
                      : "#333",
                    fontSize: "14px",
                    transition: "all 0.2s",
                    opacity: isDisabled ? 0.4 : 1,
                    position: "relative",
                  }}
                >
                  {day}
                </button>
              );
            })}
          </div>
          {!(dateRange.from && dateRange.to) && (
            <XXSmallParagraph color={theme.negative500}>
              لطفا بازه زمانی مورد نظرتان را انتخاب کنید.
            </XXSmallParagraph>
          )}
          <PrimaryButton
            color="primary"
            size={"xs"}
            width={"100%"}
            className=""
            title="تایید"
            isCurve={true}
            onClick={() => setIsOpenCalendar(false)}
            disabled={!dateRange.from || !dateRange.to}
          />
        </div>
      )}
    </div>
  );
};

export default DateRangeInput;
