import DatePicker from "react-multi-date-picker";
import persian from "react-date-object/calendars/persian";
import persian_fa from "react-date-object/locales/persian_fa";
import Input from "@/Shared/Kit/FromElements/Input";
import "react-multi-date-picker/styles/layouts/mobile.css";
import FormHandlers from "@/Utils/FormHandlers";
import {
  InputContainer,
  SpecialPeriodTitle,
  SpecialPeriodWrapper,
  RowStyle,
  Box,
  Text,
} from "./styles";
import Row from "@/Shared/Kit/Row";
import CrossIcon from "@/Shared/Kit/Icons/CrossIcon";
import React, { useRef, useState, useEffect } from "react";
import useIsMobile from "@/Utils/Responsive";
import moment from "moment-jalaali";
import { DateObject } from "react-multi-date-picker";
import Api from "@/Requests/Api";
import persian_to_english_number from "@/Utils/persianToEnglishNumber";
import { useDispatch, useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import ArrowDownIcon from "@/Shared/Kit/Icons/ArrowDownIcon";
import CalendarIcon from "@/Assets/Icons/CalendarIcon";
import { fetchSpecialOccasions } from "@/Redux/Tour/ApiFunction";
import { AppDispatch } from "@/Redux/store";
import { selectTourState } from "@/Redux/Tour/Selectors";
import jmoment from "moment-jalaali";

interface TourDay {
  date: string;
  tour: boolean;
}

interface Props {
  formik: any;
  name: string;
  label: string;
  tourDays?: TourDay[];
  cityId?: number;
}

interface MyPluginProps {
  occasions?: { from_date: string; to_date: string; name: string }[];
  handleClick: (date: string) => void;
  position: "top" | "right" | "bottom" | "left";
}

function MyPlugin({ occasions, handleClick }: MyPluginProps) {
  jmoment.loadPersian({ dialect: "persian-modern", usePersianDigits: true });
  return (
    <SpecialPeriodWrapper>
      <SpecialPeriodTitle>بازه های پردرخواست</SpecialPeriodTitle>
      <Box>
        {occasions?.length !== 0 ? (
          occasions?.map((item, index: number) => (
            <RowStyle
              key={index}
              onClick={() =>
                handleClick(jmoment(item.from_date).format("jYYYY/jMM/jDD"))
              }
            >
              <span>{item.name}</span>
              <div>
                <span> {jmoment(item.from_date).format("jD jMMMM")} </span> تا
                <span> {jmoment(item.to_date).format("jD jMMMM")} </span>
              </div>
            </RowStyle>
          ))
        ) : (
          <Text>موردی وجود ندارد</Text>
        )}
      </Box>
    </SpecialPeriodWrapper>
  );
}

const DateInput: React.FC<Props> = (props) => {
  const { formik, label, name, cityId } = props;
  const theme = useSelector(selectTheme);
  const [tourDays, setTourDays] = useState<TourDay[]>([]);
  const [selectedDate, setSelectedDate] = useState<DateObject | null>(
    formik.values[name]
      ? new DateObject({ date: formik.values[name], calendar: persian })
      : null
  );

  const responsive = useIsMobile();
  const datePickerRef: any = useRef();
  const dispatch = useDispatch<AppDispatch>();
  const { specialOccasions } = useSelector(selectTourState);

  const onClickHandler = (openCalendar: any) => {
    openCalendar();
  };

  const onChangeHandler = (value: DateObject | null) => {
    if (!value) {
      setSelectedDate(null);
      formik.setFieldValue(name, "");
      return;
    }
    setSelectedDate(value);
    formik.setFieldValue(name, value.format("YYYY/MM/DD"));
    datePickerRef.current?.closeCalendar();
  };

  const handleClickSpecialPeriod = (date: string) => {
    const englishDate = persian_to_english_number(date);
    const value = new DateObject({ date: englishDate, calendar: persian });
    setSelectedDate(value);
    formik.setFieldValue(name, value.format("YYYY/MM/DD"));
    datePickerRef.current?.closeCalendar();
  };

  useEffect(() => {
    const currentDate = moment(Date.now());
    const persianDate = currentDate.format("jYYYY/jMM/jDD");
    handlerGetToursDays(persian_to_english_number(persianDate), true);
  }, [datePickerRef, cityId]);

  const getMonthBoundaries = (selectedDate: string) => {
    const jalaaliDate = moment(selectedDate, "jYYYY/jMM/jDD");

    const firstDay = jalaaliDate.clone().startOf("jMonth");
    const lastDay = jalaaliDate.clone().endOf("jMonth");
    return {
      firstDay: firstDay.format("YYYY-MM-DD"),
      lastDay: lastDay.format("YYYY-MM-DD"),
    };
  };
  const handlerChangeMonth = (date: DateObject) => {
    const _date = date.year + "/" + date.month.number + "/" + date.day;
    handlerGetToursDays(_date);
  };

  useEffect(() => {
    fetchSpecialOccasions(dispatch);
  }, []);

  useEffect(() => {
    if (responsive !== "mobile") return;

    const handleClickOutside = (event: MouseEvent) => {
      const calendarContainer = document.querySelector(
        ".rmdp-calendar-container-mobile"
      );

      if (!calendarContainer) return;

      const isInsideCalendar = calendarContainer.contains(event.target as Node);

      if (!isInsideCalendar) {
        try {
          datePickerRef.current?.closeCalendar();
        } catch (err) {
          console.warn("calendar not ready yet");
        }
      }
    };

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [responsive, datePickerRef]);

  const handlerGetToursDays = (date: string, newCity?: boolean) => {
    const boundaries = getMonthBoundaries(date);
    const _fromDate = persian_to_english_number(boundaries.firstDay);
    const _toDate = persian_to_english_number(boundaries.lastDay);

    if (cityId) {
      Api.Get(
        `/api/home/advance-date?from_date=${_fromDate}&to_date=${_toDate}&source_province_id=${cityId}`,
        false,
        "",
        true
      ).then((res) => {
        if (res.status === 200) {
          const days = res.data;
          if (newCity) {
            setTourDays(days);
          } else {
            setTourDays((prevState: TourDay[]) => {
              const newDays = days.filter(
                (day: TourDay) =>
                  !prevState.some(
                    (prevDay: TourDay) => prevDay.date === day.date
                  )
              );
              return [...prevState, ...newDays];
            });
          }
        } else {
        }
      });
    }
  };
  const onFocusedDateChangeHandler = (value: DateObject) => {
    if (!value) {
      setSelectedDate(null);
      formik.setFieldValue(name, "");
      return;
    }
    setSelectedDate(value);
    formik.setFieldValue(name, value.format("YYYY/MM/DD"));
    datePickerRef.current?.closeCalendar();
  };
  return (
    <DatePicker
      weekDays={["شنبه", "یک", "دو", "سه‌", "چهار", "پنج", "جمعه"]}
      onMonthChange={handlerChangeMonth}
      render={(value, openCalendar, onChange) => (
        <InputContainer>
          <Input
            value={value}
            onClick={() => onClickHandler(openCalendar)}
            label={label}
            name={name}
            onChange={() => {}}
            error={formik.touched[name] ? formik.errors[name] : null}
            onBlur={(e: React.ChangeEvent<HTMLInputElement>) =>
              FormHandlers.onBlur(e, formik)
            }
            size="sm"
            InputIcon={CalendarIcon}
            iconProps={{ color: "#767676" }}
          />
          {value && (
            <Row
              onClick={(e: any) => {
                onChange(e);
                formik.setFieldValue(name, "");
                setSelectedDate(null);
              }}
              className="clearContainer"
            >
              <CrossIcon />
            </Row>
          )}
        </InputContainer>
      )}
      ref={datePickerRef}
      onChange={onChangeHandler}
      onFocusedDateChange={onFocusedDateChangeHandler}
      containerStyle={{ width: "100%" }}
      onOpenPickNewDate={false}
      calendar={persian}
      locale={persian_fa}
      format="YYYY/MM/DD"
      highlightToday={false}
      plugins={[
        <MyPlugin
          key={1}
          position={responsive === "mobile" ? "bottom" : "right"}
          occasions={specialOccasions}
          handleClick={handleClickSpecialPeriod}
        />,
      ]}
      minDate={Date.now()}
      value={selectedDate ?? undefined}
      className={responsive === "mobile" ? "rmdp-mobile" : ""}
      mapDays={({ date }) => {
        const gregorianDate = date.format("YYYY-MM-DD");
        const today = moment().format("jYYYY-jMM-jDD");

        let isSpecialDay = false;
        if (tourDays) {
          isSpecialDay = tourDays.some(
            (day) =>
              moment(day.date).format("jYYYY-jMM-jDD") == gregorianDate &&
              day.tour
          );
        }

        let props: any = {};

        if (gregorianDate === today) {
          props.style = {
            ...props.style,
            backgroundColor: theme.primary100,
          };
          props.disabled = true;
        }

        if (isSpecialDay) {
          props.children = (
            <div
              style={{
                position: "relative",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                width: "28px",
                height: "28px",
              }}
            >
              {date.day}
              <span
                style={{
                  position: "absolute",
                  top: "80%",
                  left: "50%",
                  right: "50%",
                  width: "4px",
                  height: "4px",
                  backgroundColor: "#1E8C3D",
                  borderRadius: "50%",
                  justifySelf: "center",
                }}
              />
            </div>
          );
        }

        let isWeekend = date.weekDay.index === 6; // جمعه‌ها
        if (isWeekend) {
          props.style = {
            ...props.style,
            color: "red",
          };
        }

        return props;
      }}
      mobileButtons={[
        {
          label: (<CrossIcon />) as any,
          className: "close-btn",
          onClick: () => datePickerRef.current?.closeCalendar(),
        },
      ]}
      renderButton={(direction: "right" | "left", handleClick: () => void) => (
        <div
          style={{
            width: "36px",
            height: "36px",
            borderRadius: "10px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: "pointer",
          }}
          onClick={handleClick}
        >
          {direction === "right" ? (
            <div style={{ rotate: "90deg" }}>
              <ArrowDownIcon color={theme.primary500} />
            </div>
          ) : (
            <div style={{ rotate: "-90deg" }}>
              <ArrowDownIcon color={theme.primary500} />
            </div>
          )}
        </div>
      )}
      mobileLabels={{ OK: "", CANCEL: "" }}
    />
  );
};

export default DateInput;
