import Row from "@/Shared/Kit/Row";
import styled from "styled-components";

export const InputContainer = styled(Row)`
  position: relative;

  .clearContainer {
    position: absolute;
    left: 10px;
    width: max-content;
    svg {
      cursor: pointer;
      fill: ${(props) => props.theme.gray700};
      z-index: 2;
    }
    &:hover {
      background-color: ${(props) => props.theme.gray50};
    }
  }
`;
export const SpecialPeriodWrapper = styled.div`
  margin: 20px 0px;
  min-width: 137px;
  @media (max-width: ${(props) => props.theme.xs}) {
    border-top: 1px solid ${(props) => props.theme.gray100};
    margin: 10px 0px 0;
    padding-top: 15px;
  }
`;
export const SpecialPeriodTitle = styled.span`
  color: #206692;
  margin-bottom: 10px;
  display: block;
`;

export const Box = styled.div`
  display: flex;
  flex-direction: column;
  overflow-y: auto;
  max-height: 210px;
  // height:100%;

  &::-webkit-scrollbar {
    width: 3px;
  }
  &::-webkit-scrollbar-track {
    box-shadow: inset 0 0 3px white;
  }
  &::-webkit-scrollbar-thumb {
    background-color: #c0c0bf;
    border-radius: 4px;
  }
  @media (max-width: ${(props) => props.theme.xs}) {
    max-height: 230px;
  }
`;

export const RowStyle = styled.div`
  gap: 10px;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  font-size: 14px;
  border-bottom: 1px solid ${(props) => props.theme.gray100};
  padding: 10px;
  transition: all 0.5s ease;

  > div {
    direction: rtl;
    unicode-bidi: isolate;
  }

  &:hover {
    background: #dee8ef;
  }
  > :first-child {
    color: ${(props) => props.theme.primary300};
  }
  > :last-child {
    color: ${(props) => props.theme.gray400};
  }
  &:last-child {
    border: none;
  }
  @media (max-width: ${(props) => props.theme.xs}) {
    justify-content: space-between;
    padding: 15px 0;
  }
`;
export const Text = styled.span`
  display: flex;
  justify-content: center;
  align-item: center;
  font-size: 14px;
`;
