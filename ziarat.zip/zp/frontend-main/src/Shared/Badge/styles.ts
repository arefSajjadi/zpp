import styled from "styled-components";
import Row from "../Kit/Row";


interface MainContainerProps {
    type: 'fail' | 'success'
}
export const MainContainer = styled(Row)<MainContainerProps>`
    background-color: ${props => props.type == 'fail' ? props.theme.negative50 : props.theme.positive50};
    p {
        color: ${props => props.type == 'fail' ? props.theme.negative300 : props.theme.positive300}
    }

    height: 27px;
    gap: 5px;
    width: max-content;
    border-radius: 5px;

    >div {
        gap: 5px;
        padding: 0 5px;
        svg {
            path {

                stroke: ${props => props.type == 'success' ? props.theme.positive300 : props.theme.negative300};
            }
        }
    }
    
`