import React from "react";
import { MainContainer } from "./styles";
import Row from "../Kit/Row";
import { XSmallParagraph } from "../Kit/Typography/Paragraph";
import TikIcon from "@/Assets/Icons/TikIcon";
import { useSelector } from "react-redux";
import { selectTheme } from "@/Redux/App/Selectors";
import CheckIcon from "../Kit/Icons/CheckIcon2";
import CrossIcon3 from "@/Assets/Icons/CrossIcon3";


interface Props {
    type: 'fail' | 'success'
}
const Badge:React.FC<Props> = (props) => {
    const {type} = props;
    const theme = useSelector(selectTheme)
    return ( 
        <MainContainer type={type}>
            {
                type === 'fail' ?
                <Row>
                    <CrossIcon3 />
                    <XSmallParagraph>
                        عدم تایید
                    </XSmallParagraph>
                </Row>
                :
                <Row>
                    <CheckIcon />
                    <XSmallParagraph color={theme.positive400} >
                        تایید
                    </XSmallParagraph>
                </Row>
            }
        </MainContainer>
     );
}
 
export default Badge;