import styled from "styled-components";
import Row from "../Kit/Row";
import Col from "../Kit/Col";

interface LayoutContainerProps {
    height?: string;
    padding?: string;
}

export const LayoutContainer = styled(Col)<LayoutContainerProps>`
  
    min-height: 100vh;
    justify-content: flex-start;
    height: ${props => props.height};
    padding: ${props => props.padding};
    background-color: ${props => props.theme.white2};
`