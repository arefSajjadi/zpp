import React, { useEffect, useState } from "react";
import { LayoutContainer } from "./styles";
import Header from "../Header";
import Footer from "../Footer";
import Script from "next/script";
import { usePathname } from "next/navigation";
import useIsMobile from "@/Utils/Responsive";

interface Props {
  children: React.ReactNode;
  padding?: string;
  height?: string;
}

const Layout: React.FC<Props> = (props) => {
  const { children, padding, height } = props;
  const pathname = usePathname();
  const responsive = useIsMobile();

  const [notification, setNotification] = useState<string | null | undefined>(
    ""
  );
  const [phoneNumber, setPhoneNumber] = useState<string | null | undefined>(
    null
  );

  useEffect(() => {
    const fetchNotification = async () => {
      try {
        const { default: Api } = await import("@/Requests/Api");

        const res = await Api.Get("/api/home/announcement");
        setNotification(res?.data?.description || null);
        setPhoneNumber(res?.data?.title || null);
      } catch (err) {
        setNotification(null);
      }
    };

    fetchNotification();
  }, []);

  const shouldHideFooter = ["/tours/reserve"].some((route) =>
    pathname?.includes(route)
  );

  return (
    <>
      <noscript
        dangerouslySetInnerHTML={{
          __html: `
            <iframe
              src="https://www.googletagmanager.com/ns.html?id=GTM-5QKX2KRS"
              height="0"
              width="0"
             style={{display:"none" ,visibility:"hidden"}}
            ></iframe>
          `,
        }}
      />

      {/* <Script
        id="gtm"
        strategy="worker"
        dangerouslySetInnerHTML={{
          __html: `
          (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
          new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
          j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
          'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
          })(window,document,'script','dataLayer','GTM-5QKX2KRS');
        `,
        }}
      /> */}

      <Script
        async
        strategy="lazyOnload"
        id="google-analytics"
        dangerouslySetInnerHTML={{
          __html: `
             window.dataLayer = window.dataLayer || [];
             function gtag(){dataLayer.push(arguments)};
             gtag('js', new Date());
             gtag('config', '_xR56PLHxUBANNiIgNDlL_ugl-E1841atTTiV1oacKk');
          `,
        }}
      />

      <LayoutContainer padding={padding} height={height}>
        {/* <FloatingButton /> */}

        <Header
          notification={notification}
          setNotification={setNotification}
          phoneNumber={phoneNumber}
        />

        {children}

        {!(shouldHideFooter && responsive === "mobile") && <Footer />}
      </LayoutContainer>
    </>
  );
};

export default Layout;
