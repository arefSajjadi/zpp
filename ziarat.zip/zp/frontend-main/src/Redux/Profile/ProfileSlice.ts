import { createSlice } from "@reduxjs/toolkit";
import { ProfileState } from "./Interface";

const initialState: ProfileState = {
  profileOrderData: [],
  orderData: { amount: 0, description: "", order_id: 0 },

  profileRequestData: {
    current_page: 1,
    data: [],
    first_page_url: "",
    from: 0,
    last_page: 1,
    last_page_url: "",
    links: [],
    next_page_url: "",
    path: "",
    per_page: 0,
    prev_page_url: "",
    to: 0,
    total: 0,
  },
  requestData: {
    admin: {
      id: 0,
      username: "",
    },
    payment_link: "",
    admin_id: 0,
    created_at: "",
    deleted_at: "",
    id: 0,
    method: "",
    package_id: 0,
    status: "",
    updated_at: "",
    user_id: 0,
    total: 0,
    files: [
      {
        mime_type: "",
        src: "",
        file_name: "",
      },
    ],
    passengers: [],
    package: {
      id: 0,
      created_at: "",
      updated_at: "",
      deleted_at: "",
      source_province_id: 0,
      source_province: { name: "" },
      destination_province: { name: "" },
      destination_province_id: 0,
      went_vehicle_id: 0,
      return_vehicle_id: 0,
      status: "active",
      travel_type: "",
      went_time: "",
      airport: "",
      broker: "",
      adult_cost: 0,
      child_cost: 0,
      baby_cost: 0,
      adult_promotion_cost: null,
      child_promotion_cost: null,
      baby_promotion_cost: null,
      active_until_day: 0,
      staying_night: 0,
      staying_night_margin: 0,
      staying_description: "",
      provider: "",
      date: "",
      capacity: 0,
      sorting_province_ids: [],
      descriptions: [],
      properties: [],
      services: [],
      order: null,
      admin_id: 0,
      sorting_province_names: [],
      user: {},
    },
  },
  requestLoading: false,
  profileOrderLoading: false,
  orderLoading: false,
  profileRequestLoading: false,
  orderPageStatus: 1,
  contractData: null,
  contractLoading: false,
};

export const profileSlice = createSlice({
  name: "profile",
  initialState,
  reducers: {
    setOrderPageStatus: (state, action) => {
      return {
        ...state,
        orderPageStatus: action.payload,
      };
    },
    setOrders: (state, action) => {
      return {
        ...state,
        profileOrderData: action.payload.data,
        profileOrderLoading: action.payload.loading,
      };
    },
    setOrder: (state, action) => {
      return {
        ...state,
        orderData: action.payload.data,
        orderLoading: action.payload.loading,
      };
    },

    setRequests: (state, action) => {
      return {
        ...state,
        profileRequestData: action.payload.data,
        profileRequestLoading: action.payload.loading,
      };
    },
    setRequest: (state, action) => {
      return {
        ...state,
        requestData: action.payload.data,
        requestLoading: action.payload.loading,
      };
    },
    setContract: (state, action) => {
      return {
        ...state,
        contractData: action.payload.data,
        contractLoading: action.payload.loading,
      };
    },
  },
});

export const {
  setOrderPageStatus,
  setOrders,
  setOrder,
  setRequests,
  setRequest,
  setContract,
} = profileSlice.actions;

export default profileSlice.reducer;
