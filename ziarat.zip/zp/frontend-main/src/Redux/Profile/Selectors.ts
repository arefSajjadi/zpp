
import { ProfileState } from "./Interface";
interface stateType {
    Profile: ProfileState
}
export const selectProfile = (state: stateType) => state.Profile;

