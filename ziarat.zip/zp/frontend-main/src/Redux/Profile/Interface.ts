export interface OrderType {
  id: number;
  created_at: string;
  updated_at: string;
  user_id: number;
  package_id: number;
  total: number;
  status: "unpaid" | "paid";
  supply_status: "pending" | "done" | "change";
  package: {
    id: number;
    created_at: string;
    updated_at: string;
    deleted_at: null | string;
    source_province_id: number;
    destination_province_id: number;
    went_vehicle_id: number;
    return_vehicle_id: number;
    status: "deactive" | "active";
    travel_type: string;
    went_time: string;
    airport: string;
    broker: string;
    adult_cost: number;
    child_cost: number;
    baby_cost: number;
    adult_promotion_cost: null | number;
    child_promotion_cost: null | number;
    baby_promotion_cost: null | number;
    active_until_day: number;
    staying_night: number;
    staying_night_margin: number;
    staying_description: string;
    provider: string;
    date: string;
    capacity: number;
    sorting_province_ids: string[];
    descriptions: string[];
    properties: string[];
    services: string[];
    order: null | string;
    admin_id: number;
    comments: Comment[];
    sorting_province_names: {
      id: number;
      name: string;
    }[];

    paid_order_count: number;
    passengers: [];
    source_province: {
      id: number;
      name: string;
      slug: string;
    };
    destination_province: {
      id: number;
      name: string;
      slug: string;
    };
    went_vehicle: {
      id: number;
      name: string;
      type: string;
    };
    return_vehicle: {
      id: number;
      name: string;
      type: string;
    };
    hotels: {
      id: number;
      created_at: string;
      updated_at: string;
      deleted_at: null | string;
      province_id: number;
      room_only: number;
      full_board: number;
      lat: string;
      lang: string;
      name: string;
      name_en: string;
      address: string;
      star: number;
      description: string;
      pivot: {
        package_id: number;
        hotel_id: number;
        staying_night: number;
      };
      province: {
        id: number;
        name: string;
        slug: string;
      };
    }[];
  };
  passengers: {
    id: number;
    created_at: string;
    updated_at: string;
    deleted_at: null | string;
    user_id: number;
    order_id: number;
    mobile: string;
    full_name: string;
    birth_date: string;
    national_code: string;
    passport_expire_date: string | null;
    passport_number: string | null;
    gender: string;
    age_level: string;
  }[];
}

export interface Comment {
  rate: number;
  description: string;
  negative_points: [];
  positive_points: [];
  id: number;
}

export interface RequestsType {
  current_page: number;
  data: RequestList[];
  first_page_url: string;
  from: number;
  last_page: number;
  last_page_url: string;
  links: Link[];
  next_page_url: string;
  path: string;
  per_page: number;
  prev_page_url: string;
  to: number;
  total: number;
}
export interface RequestList {
  admin: {
    id: number;
    username: string;
  };
  admin_id: number;
  created_at: string;
  deleted_at: string;
  id: number;
  method: string;
  package_id: number;
  status: string;
  updated_at: string;
  user_id: number;
  total: number;
  files: [
    {
      mime_type: string;
      src: string;
      file_name: string;
    }
  ];
  payment_link: string;
  passengers: {
    id: number;
    created_at: string;
    updated_at: string;
    deleted_at: null | string;
    user_id: number;
    order_id: number;
    mobile: string;
    full_name: string;
    birth_date: string;
    national_code: string;
    passport_expire_date: string | null;
    passport_number: string | null;
    gender: string;
    age_level: string;
  }[];
  package: {
    id: number;
    created_at: string;
    updated_at: string;
    deleted_at: null | string;
    source_province_id: number;
    source_province: { name: string };
    destination_province: { name: string };
    destination_province_id: number;
    went_vehicle_id: number;
    return_vehicle_id: number;
    status: "deactive" | "active";
    travel_type: string;
    went_time: string;
    airport: string;
    broker: string;
    adult_cost: number;
    child_cost: number;
    baby_cost: number;
    adult_promotion_cost: null | number;
    child_promotion_cost: null | number;
    baby_promotion_cost: null | number;
    active_until_day: number;
    staying_night: number;
    staying_night_margin: number;
    staying_description: string;
    provider: string;
    date: string;
    capacity: number;
    sorting_province_ids: string[];
    descriptions: string[];
    properties: string[];
    services: string[];
    order: null | string;
    admin_id: number;
    sorting_province_names: {
      id: number;
      name: string;
    }[];
    user: {};
  };
}
export interface Link {}
export interface ContractType {
  src: string;
  mime_type: string;
  type: string;
  file_name: string;
  alt: string;
  fileable_id: number;
  fileable_type: string;
  updated_at: string;
  created_at: string;
  id: number;
}

export interface ProfileState {
  profileOrderData: OrderType[];
  orderLoading: boolean;
  orderData: { amount: number; description: string; order_id: number };
  profileRequestData: RequestsType;
  profileOrderLoading: boolean;
  profileRequestLoading: boolean;
  orderPageStatus: 1 | 2 | 3;
  contractData: ContractType | null;
  contractLoading: boolean;
  requestLoading: boolean;
  requestData: RequestList;
}
