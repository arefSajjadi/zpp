import Api from "@/Requests/Api";
import { AppDispatch } from "../store";
import Toast from "@/Shared/Kit/Toast";
import {
  setContract,
  setOrders,
  setOrder,
  setRequests,
  setRequest,
} from "./ProfileSlice";
import { AxiosError } from "axios";

export const GetOrders = async (dispatch: AppDispatch) => {
  const resetRes = () => {
    dispatch(setOrders({ data: [], loading: false }));
  };
  const waitForRes = () => {
    dispatch(setOrders({ data: [], loading: true }));
  };

  waitForRes();
  Api.Get("/api/user/profile/order", true)
    .then((res) => {
      if (res.status === 200 || res.status === 201) {
        dispatch(
          setOrders({
            data: res?.data,
            loading: false,
          })
        );
      } else {
        Toast.error("خطا در دریافت سفارش ها");
        resetRes();
      }
    })
    .catch((err) => {
      resetRes();
      console.log(err);
      Toast.error("خطا در دریافت سفارش ها");
    });
};

export const GetOrder = async (id: number, dispatch: AppDispatch) => {
  const resetRes = () => {
    dispatch(setOrder({ data: [], loading: false }));
  };
  const waitForRes = () => {
    dispatch(setOrder({ data: [], loading: true }));
  };

  waitForRes();
  Api.Get(`/api/user/transaction/${id}`, true)
    .then((res) => {
      if (res.status === 200 || res.status === 201) {
        dispatch(
          setOrder({
            data: res?.data,
            loading: false,
          })
        );
      } else {
        Toast.error("خطا در دریافت سفارش");
        resetRes();
      }
    })
    .catch((err) => {
      resetRes();
      console.log(err);
      Toast.error("خطا در دریافت سفارش");
    });
};

export const GetRequests = async (dispatch: AppDispatch) => {
  const resetRes = () => {
    dispatch(setRequests({ data: [], loading: false }));
  };
  const waitForRes = () => {
    dispatch(setRequests({ data: [], loading: true }));
  };

  waitForRes();
  Api.Get("/api/user/reserve", true)
    .then((res) => {
      if (res.status === 200 || res.status === 201) {
        dispatch(
          setRequests({
            data: res?.data,
            loading: false,
          })
        );
      } else {
        Toast.error("خطا در دریافت درخواست ها");
        resetRes();
      }
    })
    .catch((err) => {
      resetRes();
      console.log(err);
      Toast.error("خطا در دریافت درخواست ها");
    });
};

export const GetRequest = async (
  id: number,
  dispatch: AppDispatch,
  failCallback?: (...args: any) => void
) => {
  const resetRes = () => {
    dispatch(setRequest({ data: [], loading: false }));
  };
  const waitForRes = () => {
    dispatch(setRequest({ data: [], loading: true }));
  };

  waitForRes();
  Api.Get(`/api/reserve/${id}`, true)
    .then((res) => {
      if (res.status === 200 || res.status === 201) {
        dispatch(
          setRequest({
            data: res?.data,
            loading: false,
          })
        );
      } else {
        Toast.error("خطا در دریافت درخواست ها");
        failCallback && failCallback();
        resetRes();
      }
    })
    .catch((err) => {
      failCallback && failCallback();
      resetRes();
      console.log(err);
      Toast.error("خطا در دریافت درخواست ها");
    });
};

export const CloseRequest = async (
  id: number,
  successCallback: (path: string, ...args: any) => void,
  failCallback?: (...args: any) => void
) => {
  try {
    const res = await Api.Post(`/api/user/reserve/${id}/close`, null);

    if (res.status === 200 || res.status == 201) {
      return successCallback(res.data);
    }

    failCallback && failCallback();
  } catch (err) {
    const error = err as AxiosError;

    Toast.error("خطا در ثبت درخواست");

    console.log(error);
    failCallback && failCallback();
  }
};

export const NoticeAlarm = async (
  data: {
    source_province_id: number;
    from_date: string;
    to_date: string;
    travel_types: string[];
  },
  successCallback: (path: string, ...args: any) => void,
  failCallback?: (...args: any) => void
) => {
  try {
    const body = data;

    const res = await Api.Post("/api/user/backin", body);

    if (res.status === 200 || res.status == 201) {
      return successCallback(res.data);
    } else {
      Toast.error("خطا در ثبت اطلاعیه");

      failCallback && failCallback();
    }
  } catch (err) {
    const error = err as AxiosError;

    Toast.error("خطا در ثبت اطلاعیه");

    console.log("Error:", error);
    failCallback && failCallback();
  }
};

export const CancelNoticeAlarm = async (
  id: number,
  successCallback: (path: string, ...args: any) => void,
  failCallback?: (...args: any) => void
) => {
  try {
    const res = await Api.Delete(`/api/user/backin/${id}`, null);

    if (res.status === 200 || res.status == 201) {
      return successCallback(res.data);
    }

    failCallback && failCallback();
  } catch (err) {
    const error = err as AxiosError;

    Toast.error("خطا در لغو اطلاعیه");

    console.log("Error:", error);
    failCallback && failCallback();
  }
};

export const ReserveTour = async (
  id: number,
  successCallback: (path: string, ...args: any) => void,
  failCallback?: (...args: any) => void
) => {
  try {
    const body = { package_id: +id };

    const res = await Api.Post("/api/user/reserve", body);

    if (res.status === 200 || res.status == 201) {
      return successCallback(res.data);
    }

    failCallback && failCallback();
  } catch (err) {
    const error = err as AxiosError;

    if (error.response?.status === 500) {
      Toast.error("یک درخواست کاروان در فرآیند پیگیری می‌باشد.");
    } else {
      Toast.error("خطا در ثبت درخواست");
    }

    console.log("ReserveTour Error:", error);
    failCallback && failCallback();
  }
};
export const postReserveData = async (
  id: number,
  method: string,
  passengers: any,
  successCallback: (path: string, ...args: any) => void,
  failCallback?: (...args: any) => void
) => {
  try {
    const body = {
      passengers,
    };

    const res = await Api.Post(`/api/reserve/${id}/passenger`, body);
    if (res.status === 200 || res.status == 201) {
      if (method === "haj") Toast.success("اطلاعات با موفقیت ثبت شد");

      return successCallback(res.data);
    }
    failCallback && failCallback();
  } catch (err) {
    const error = err as AxiosError;
    if (error.response?.status === 500) {
      Toast.error("خطا در ثبت درخواست");
    }
    console.log(err);
    failCallback && failCallback();
    Toast.error("خطای نامشخص");
  }
};

export const GetContract = async (
  dispatch: AppDispatch,
  contractId: number,
  successCallback?: (...args: any) => void,
  failCallback?: (...args: any) => void
) => {
  const resetRes = () => {
    dispatch(setContract({ data: null, loading: false }));
  };
  const waitForRes = () => {
    dispatch(setContract({ data: null, loading: true }));
  };

  waitForRes();
  Api.Get(`/api/user/order/${contractId}/contract`, true)
    .then((res) => {
      if (res.status === 200 || res.status === 201) {
        dispatch(
          setContract({
            data: res?.data,
            loading: false,
          })
        );
        successCallback && successCallback(res?.data);
      } else {
        Toast.error("خطا در دریافت قرارداد ");
        resetRes();
        failCallback && failCallback();
      }
    })
    .catch((err) => {
      resetRes();
      console.log(err);
      failCallback && failCallback();
      Toast.error("خطا در دریافت قرارداد ");
    });
};

export const PostComment = async (
  package_id: number,
  rate: number,
  selectedGoodPoints: string[],
  selectedBadPoints: string[],
  description: string,
  successCallback: (path: string, ...args: any) => void,
  failCallback?: (...args: any) => void
) => {
  try {
    const body = {
      package_id,
      rate,
      positive_points: selectedGoodPoints,
      negative_points: selectedBadPoints,
      description,
    };

    console.log("PostComment -> SENDING BODY", body);

    const res = await Api.Post("/api/user/comment", body);

    console.log("PostComment -> RESPONSE STATUS", res.status, res.data);

    if (res.status === 200 || res.status == 201) {
      Toast.success("نظر شما با موفقیت ثبت شد");
      return successCallback(res.data);
    }

    console.log("PostComment -> UNEXPECTED STATUS", res.status);
    failCallback && failCallback();
  } catch (err) {
    const error = err as AxiosError;

    console.log("PostComment -> CATCH BLOCK", error);
    Toast.error("خطا در ثبت نظر");
    failCallback && failCallback();
  }
};

 