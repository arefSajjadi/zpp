import Api from "@/Requests/Api";
import { AppDispatch, AppStore } from "../store";
import { fetchHome } from "./HomeSlice";
import { SrcOrDesProvince } from "@/Utils/FindSrcOrDesProvince";

export const fetchHomeData = async (store: AppStore) => {
  store.dispatch(fetchHome({ data: [], loading: true }));
  await Api.Get("/api/landing/home")
    .then((res) => {
      const srcOrDesProvince = SrcOrDesProvince(res?.data?.province);
      store.dispatch(
        fetchHome({
          sourceProvince: srcOrDesProvince.srcProvince,
          destinationProvince: srcOrDesProvince.desProvince,
          loading: false,
          slider: res?.data?.slider,
        })
      );
    })
    .catch((err) => {
      //handleErr
      store.dispatch(fetchHome({ province: [], loading: false, slider: [] }));
    })
    .then(() => {
      //handleFinally
    });
};

export const fetchHomeDataCsr = async (
  dispatch: AppDispatch,
  successCallback?: (...args: any) => void,
  failCallback?: (...args: any) => void
) => {
  await Api.Get("/api/landing/home")
    .then((res) => {
      const srcOrDesProvince = SrcOrDesProvince(res?.data?.province);
      dispatch(
        fetchHome({
          sourceProvince: srcOrDesProvince.srcProvince,
          destinationProvince: srcOrDesProvince.desProvince,
          loading: false,
          slider: res?.data?.slider,
        })
      );
      successCallback && successCallback();
    })
    .catch(() => {
      failCallback && failCallback();
    });
};
