
import { HomeState } from "./Interfaces";
interface stateType {
    Home: HomeState
}
export const selectHome = (state: stateType) => state.Home;
