import { createSlice } from "@reduxjs/toolkit";
import { HomeState } from "./Interfaces";

const initialState: HomeState = {
  sourceProvince: [],
  destinationProvince: [],
  popularProvince: [],
  slider: [],
  loading: false,

  adultCount: 1,
  childCount: 0,
  babyCount: 0,

  fields: [],
};

export const homeSlice = createSlice({
  name: "home",
  initialState,
  reducers: {
    fetchHome: (state, action) => {
        return {
          ...state,
          slider:action.payload.slider,
          popularProvince:action.payload.popularProvince,
          loading:action.payload.loading,
          sourceProvince:action.payload?.sourceProvince,
          destinationProvince: action.payload?.destinationProvince || []
        }
      },

    setPassengersCount: (state ,action) => {
      return {
        ...state,
        adultCount: action.payload.adultCount || action.payload.adultCount === 0 ? action.payload.adultCount : state.adultCount ,
        childCount: action.payload.childCount || action.payload.childCount === 0 ? action.payload.childCount : state.childCount,
        babyCount: action.payload.babyCount || action.payload.babyCount === 0 ? action.payload.babyCount : state.babyCount
      }
    },
  },
});

export const {
  fetchHome,
  setPassengersCount
} = homeSlice.actions;

export default homeSlice.reducer;
