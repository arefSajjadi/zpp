import {TourType} from "../Tour/Interface";

export interface SliderType {
    id: number,
    created_at: string,
    updated_at: string,
    deleted_at: string | null,
    sliderable_type: string,
    sliderable_id: number,
    sliderable: TourType
}


export interface ProvinceType {
    id: number,
    created_at: string,
    updated_at: string,
    name: string,
    slug: string,
    src: number
}

export interface popularType {
    cost: number
    created_at: string
    id: number
    name: string
    popularity: string
    slug: string
    src: number
    updated_at: string
}


export interface HomeState {
    slider: SliderType[];
    popularProvince: popularType[]
    sourceProvince: ProvinceType[];
    destinationProvince: ProvinceType[];
    loading: boolean;

    adultCount: number;
    childCount: number;
    babyCount: number;

    fields: {
        full_name: string,
        mobile: string,
        birth_date: string,
        national_code: string,
        passport_expire_date: string,
        passport_number: string,
        gender: string,
        age_level: string,
    }[],
}