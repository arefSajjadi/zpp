import { createSlice } from "@reduxjs/toolkit";
import { OrderState } from "./Interface";

const initialState: OrderState = {
  melatClubOtpTimer: 0,
  orderValidation: true,
};

export const orderSlice = createSlice({
  name: "order",
  initialState,
  reducers: {
    setMelatClubOtpTimer: (state, action) => {
      return {
        ...state,
        melatClubOtpTimer: action.payload,
      };
    },
    setOrderValidation: (state, action) => {
      return {
        ...state,
        orderValidation: action.payload,
      };
    },
  },
});

export const { setMelatClubOtpTimer, setOrderValidation } = orderSlice.actions;

export default orderSlice.reducer;
