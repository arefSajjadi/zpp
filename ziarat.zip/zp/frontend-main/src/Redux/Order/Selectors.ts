
import { OrderState } from "./Interface";
interface stateType {
    Order: OrderState
}
export const selectOrder = (state: stateType) => state.Order;

