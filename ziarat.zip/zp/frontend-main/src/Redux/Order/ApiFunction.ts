import Api from "@/Requests/Api";
import Toast from "@/Shared/Kit/Toast";
import { AppRouterInstance } from "next/dist/shared/lib/app-router-context.shared-runtime";
import { NextRouter } from "next/router";
import { AppDispatch } from "../store";
import { setMelatClubOtpTimer } from "./OrderSlice";

export const postOrderData = async (
  id: number,
  passengers: any,
  successCallback: (path: string, ...args: any) => void,
  failCallback?: (...args: any) => void
) => {
  try {
    const body = {
      package_id: +id,
      passengers,
    };

    Api.Post("/api/user/order/store", body).then((res) => {
      if (res.status === 200 || res.status == 201) {
        return successCallback(res.data);
      }
      failCallback && failCallback();
    });
  } catch (err) {
    console.log(err);
    failCallback && failCallback();
    Toast.error("خطای نامشخص");
  }
};

export const Payment = async (
  router: NextRouter,
  orderId: string,
  successCallback?: (...args: any) => void,
  failCallback?: (...args: any) => void
) => {
  try {
    Api.Post(`/api/user/order/${orderId}/pay`, {})
      .then((res) => {
        if (res.status === 200 || res.status == 201) {
          successCallback && successCallback();
          return router.push(res.data?.path);
        } else {
          failCallback && failCallback();
        }
      })
      .catch((err) => {
        failCallback && failCallback();
        Toast.error("خطای نامشخص");
      });
  } catch (err) {
    console.log(err);
    failCallback && failCallback();
    Toast.error("خطای نامشخص");
  }
};

export const MelatClubInquiry = async (
  orderId: number,
  mobile: string,
  successCallback: (valid: boolean, credit: number) => void,
  failCallback?: (...args: any) => void
) => {
  try {
    const body = {
      mobile,
    };

    Api.Post(`/api/user/order/${orderId}/melat-customer-club/inquiry`, body)
      .then((res) => {
        if (res.status === 200 || res.status == 201) {
          return successCallback(res.data?.valid, res.data?.credit);
        }
        failCallback && failCallback();
      })
      .catch((err) => {
        console.log(err);
        failCallback && failCallback();
        Toast.error("خطای نامشخص");
      });
  } catch (err) {
    console.log(err);
    failCallback && failCallback();
    Toast.error("خطای نامشخص");
  }
};

export const MelatClubSendOtp = async (
  dispatch: AppDispatch,
  orderId: number,
  mobile: string,
  successCallback?: (send: boolean, code: number) => void,
  failCallback?: (...args: any) => void
) => {
  try {
    const body = {
      mobile,
    };

    Api.Post(
      `/api/user/order/${orderId}/melat-customer-club/send-otp`,
      body
    ).then((res) => {
      if (res.status === 200 || res.status == 201) {
        dispatch(setMelatClubOtpTimer(300));
        return (
          successCallback && successCallback(res.data?.send, res.data?.code)
        );
      }
      failCallback && failCallback();
    }).catch((err) => {
      console.log(err);
      failCallback && failCallback();
      Toast.error("خطای نامشخص");
    });
  } catch (err) {
    console.log(err);
    failCallback && failCallback();
    Toast.error("خطای نامشخص");
  }
};

export const MelatClubReducsCredit = async (
  orderId: number,
  mobile: string,
  credit: number,
  otp: string,
  successCallback?: (path: string, ...args: any) => void,
  failCallback?: (...args: any) => void
) => {
  try {
    const body = {
      mobile,
      credit,
      otp,
    };

    Api.Post(
      `/api/user/order/${orderId}/melat-customer-club/reduce-credit`,
      body
    )
      .then((res) => {
        if (res.status === 200 || res.status == 201) {
          return successCallback && successCallback(res.data);
        }
        failCallback && failCallback();
      })
      .catch((err) => {
        failCallback && failCallback();
        Toast.error("خطای نامشخص");
      });
  } catch (err) {
    console.log(err);
    failCallback && failCallback();
    Toast.error("خطای نامشخص");
  }
};
export const MelatClubReducsTransactionCredit = async (
  transactionId: number,
  mobile: string,
  credit: number,
  otp: string,
  successCallback?: (path: string, ...args: any) => void,
  failCallback?: (...args: any) => void
) => {
  try {
    const body = {
      mobile,
      credit,
      otp,
    };

    Api.Post(
      `/api/user/transaction/${transactionId}/melat-customer-club/reduce-credit`,
      body
    )
      .then((res) => {
        if (res.status === 200 || res.status == 201) {
          return successCallback && successCallback(res.data);
        }
        failCallback && failCallback();
      })
      .catch((err) => {
        failCallback && failCallback();
        Toast.error("خطای نامشخص");
      });
  } catch (err) {
    console.log(err);
    failCallback && failCallback();
    Toast.error("خطای نامشخص");
  }
};


export const getOrderData = async (orderId: string) => {
  const result = await Api.Get(`/api/user/order/${orderId}`);
  if (result.status == 200 || result?.status === 201) {
    return result.data;
  } else {
    return undefined;
  }
};
