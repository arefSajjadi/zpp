export interface OrderState {
    melatClubOtpTimer: number
    orderValidation: boolean
}