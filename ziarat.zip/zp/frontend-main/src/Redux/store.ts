
    import { configureStore } from '@reduxjs/toolkit'
    import AuthReducer from "./Auth/AuthSlice";
    import AppReducer from './App/AppSlice';
    import TourReducer from './Tour/TourSlice';
    import HotelReducer from './Hotel/HotelSlice';
    import HomeReducer from "./Home/HomeSlice";
    import OrderReducer from "./Order/OrderSlice";
    import ProfileReducer from "./Profile/ProfileSlice";
    
    export const store = configureStore({
      reducer: {
        Auth: AuthReducer,
        App: AppReducer,
        Tour: TourReducer,
        Hotel: HotelReducer,
        Home: HomeReducer,
        Order: OrderReducer,
        Profile: ProfileReducer,
      },
    })

    export type AppStore = typeof store
    export type RootState = ReturnType<typeof store.getState>
    export type AppDispatch = typeof store.dispatch
    
