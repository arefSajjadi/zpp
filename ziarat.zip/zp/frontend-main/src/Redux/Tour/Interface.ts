export interface TourHotelType {
  id: number;
  created_at: string;
  updated_at: string;
  deleted_at: null;
  province_id: number;
  room_only: number;
  full_board: number;
  lat: string;
  lang: string;
  name: string;
  name_en: string;
  address: string;
  star: number;
  search: string;
  description: string;
  pivot: {
    package_id: number;
    hotel_id: number;
    staying_night: number;
  };
  files: {
    id: number;
    created_at: string | null;
    updated_at: string | null;
    deleted_at: string | null;
    src: string;
    file_name: string;
    mime_type: string;
    type: string;
    fileable_type: string;
    fileable_id: number;
    alt: string;
  }[];
  province?: {
    id: number;
    name: string;
    slug: string;
  };
}

export interface TourType {
  id: number;
  created_at: string;
  updated_at: string;
  status: string;
  source_province_id: number;
  destination_province_id: number;
  went_vehicle_id: number;
  return_vehicle_id: number;
  travel_type: string;
  went_time: string;
  airport: string;
  broker: string;
  adult_cost: number;
  adult_promotion_cost: number;
  child_promotion_cost: number;
  baby_promotion_cost: number;
  vip?: string;
  child_cost: number;
  baby_cost: number;
  active_until_day: number;
  staying_night: number;
  staying_night_margin: number;
  staying_description: string;
  friday_night_karbala?: string;
  provider: string;
  sorting_province_ids: string[];
  summaries: Summary[];
  comments: Comment[];
  rate: number;
  sorting_province_names: {
    id: number;
    name: string;
  }[];
  travel_options?: {
    value: string;
  }[];
  date: string;
  capacity: number;
  descriptions: string[];
  properties: string[];
  services: string[];
  paid_order_count: number;
  admin_id: number;
  passengers: any[];
  hotels: TourHotelType[];
  kadhimiya_samera: string;
  files: {
    id: number;
    created_at: string | null;
    updated_at: string | null;
    deleted_at: string | null;
    src: string;
    file_name: string;
    mime_type: string;
    type: string;
    fileable_type: string;
    fileable_id: number;
    alt: string;
  }[];
  source_province: {
    id: number;
    name: string;
    slug: string;
  };
  destination_province: {
    id: number;
    name: string;
    slug: string;
  };

  went_vehicle: {
    id: number;
    name: string;
    type: "bus" | "train" | "airplane" | "";
  };
  return_vehicle: {
    id: number;
    name: string;
    type: "bus" | "train" | "airplane" | "";
  };
}

export interface Summary {
  class_id: number;
  id: number;
  province: { name: string };
  summery: string;
  file: { id: number; src: string };
}

export interface Comment {
  rate: number;
  description: string;
  negative_points: [];
  positive_points: [];
  id: number;
}
export interface DaysType {
  date: string;
  tour: boolean;
}

export interface TourExistType {
  date: string;
  tour: boolean;
}

export interface TourState {
  toursList: TourType[];
  toursLoading: boolean;
  moreToursLoading: boolean;
  toursCount: number;
  toursPage: number;
  specialOccasions: [];

  tourDetails: TourType;
  tourDetailsLoading: boolean;

  days: DaysType[];
  daysLoading: boolean;

  orderBy: {
    id: number;
    title: string;
    value: string | null;
  }[];

  hotelTypeList: {
    id: number;
    title: string;
  }[];

  stayingNightList: {
    id: number;
    title: string;
  }[];

  travelTypeList: {
    id: number;
    title: string;
  }[];

  stayingNight: number | null;
  travelType: string[] | null;
  sort: string | null;
  hotelLevel: string | null;
  hotelName: string | null;
  haveFridayNight: boolean;
  haveVip: boolean;

  orderHistory: {
    firstName: string;
    lastName: string;
    nationalCode: string;
    mobile: string;
    birthMonth: string;
    birthDay: string;
    birthYear: string;
    mobileNumber?: string;
    birthDate?: string;
    ageLevel: "adult" | "child" | "baby";
  }[];

  tourExist: TourExistType[];
  tourExistLoading: boolean;
}
