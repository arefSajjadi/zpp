import { createSlice } from "@reduxjs/toolkit";
import { TourState } from "./Interface";

const initialState: TourState = {
  toursList: [],
  toursCount: 0,
  toursLoading: false,
  moreToursLoading: false,
  toursPage: 1,

  specialOccasions: [],

  tourDetails: {
    id: 0,
    created_at: "",
    updated_at: "",
    status: "",
    source_province_id: 0,
    destination_province_id: 0,
    went_vehicle_id: 0,
    return_vehicle_id: 0,
    travel_type: "",
    went_time: "",
    airport: "",
    broker: "",
    adult_cost: 0,
    adult_promotion_cost: 0,
    child_promotion_cost: 0,
    baby_promotion_cost: 0,
    child_cost: 0,
    baby_cost: 0,
    active_until_day: 0,
    staying_night: 0,
    staying_night_margin: 0,
    staying_description: "",
    provider: "",
    sorting_province_ids: [],
    sorting_province_names: [],
    date: "",
    capacity: 20,
    descriptions: [],
    properties: [],
    services: [],
    paid_order_count: 0,
    admin_id: 0,
    passengers: [],
    hotels: [],
    files: [],
    summaries: [],
    comments: [],
    rate: 0,
    kadhimiya_samera: "",
    source_province: {
      id: 0,
      name: "",
      slug: "",
    },
    destination_province: {
      id: 0,
      name: "",
      slug: "",
    },
    return_vehicle: {
      id: 0,
      name: "",
      type: "",
    },
    went_vehicle: {
      id: 0,
      name: "",
      type: "",
    },
  },
  tourDetailsLoading: false,

  days: [],
  daysLoading: false,

  orderBy: [
    {
      id: 1,
      title: "پیشنهاد رسم زیارت",
      value: null,
    },
    {
      id: 2,
      title: "نزدیک ترین کاروان",
      value: "date:asc",
    },
    {
      id: 3,
      title: "ارزان ترین کاروان",
      value: "adult_cost:asc",
    },
  ],

  hotelTypeList: [
    {
      id: 5,
      title: "الف ویژه",
    },
    {
      id: 4,
      title: "الف",
    },
    {
      id: 3,
      title: "ب",
    },
    {
      id: 2,
      title: "ج",
    },
  ],

  stayingNightList: [
    {
      id: 6,
      title: "6 شب",
    },
    {
      id: 7,
      title: "7 شب",
    },
  ],
  travelTypeList: [
    {
      id: 1,
      title: "هوایی",
    },
    {
      id: 2,
      title: "زمینی",
    },
  ],

  haveFridayNight: false,
  haveVip: false,
  hotelLevel: null,
  hotelName: null,
  sort: null,
  stayingNight: null,
  travelType: null,

  orderHistory: [],

  tourExist: [],
  tourExistLoading: false,
};

export const tourSlice = createSlice({
  name: "tour",
  initialState,
  reducers: {
    getTours: (state, action) => {
      return {
        ...state,
        toursList: action.payload.data || state.toursList,
        toursLoading: action.payload.loading,
        toursCount:
          action.payload.count || action.payload.count === 0
            ? action.payload.count
            : state.toursCount,
        toursPage: action.payload.page,
      };
    },

    getSpecialOccasions: (state, action) => {
      return {
        ...state,
        specialOccasions: action.payload.data ?? state.specialOccasions,
      };
    },

    addTours: (state, action) => {
      return {
        ...state,
        toursList: [...state.toursList, ...action.payload.data],
        moreToursLoading: action.payload.loading,
        toursCount: action.payload.count
          ? action.payload.count
          : state.toursCount,
        toursPage: action.payload.page,
      };
    },

    getTourDetail: (state, action) => {
      return {
        ...state,
        tourDetails: action.payload.data
          ? action.payload.data
          : state.tourDetails,
        tourDetailsLoading: action.payload.loading,
      };
    },

    setFilterProperties: (state, action) => {
      return {
        ...state,
        stayingNight: action.payload.stayingNight
          ? action.payload.stayingNight
          : action.payload.stayingNight === null
          ? null
          : state.stayingNight,
        travelType: action.payload.travelType
          ? action.payload.travelType
          : action.payload.travelType === null
          ? null
          : state.travelType,
        haveFridayNight:
          action.payload.haveFridayNight || state.haveFridayNight,
        haveVip: action.payload.haveVip || state.haveVip,
        hotelLevel: action.payload.hotelLevel
          ? action.payload.hotelLevel
          : action.payload.hotelLevel === null
          ? null
          : state.hotelLevel,
        hotelName: action.payload.hotelName
          ? action.payload.hotelName
          : action.payload.hotelName === null
          ? null
          : state.hotelName,
        sort: action.payload.sort
          ? action.payload.sort
          : action.payload.sort === null
          ? null
          : state.sort,
      };
    },
    setDays: (state, action) => {
      return {
        ...state,
        days: action.payload.data,
      };
    },
    setOrderHistory: (state, action) => {
      return {
        ...state,
        orderHistory: action.payload.data,
      };
    },

    getTourExist: (state, action) => {
      return {
        ...state,
        tourExist: action.payload.data ?? state.tourExist,
        tourExistLoading: action.payload.loading,
      };
    },
  },
});

export const {
  getTourDetail,
  getTours,
  setFilterProperties,
  addTours,
  setDays,
  setOrderHistory,
  getTourExist,
  getSpecialOccasions,
} = tourSlice.actions;

export default tourSlice.reducer;
