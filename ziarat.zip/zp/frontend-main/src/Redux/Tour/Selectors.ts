
import { TourState } from "./Interface";
interface stateType {
    Tour: TourState
}
export const selectTourState = (state: stateType) => state.Tour;
