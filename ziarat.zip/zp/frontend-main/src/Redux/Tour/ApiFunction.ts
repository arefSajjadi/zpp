import Toast from "@/Shared/Kit/Toast";
import { AppDispatch, AppStore } from "../store";
import Api from "@/Requests/Api";
import {
  addTours,
  getSpecialOccasions,
  getTourDetail,
  getTourExist,
  getTours,
} from "./TourSlice";
import DateTimeController from "@/Utils/DateTimeController";

export const GetTours = async (
  dispatch: AppDispatch,
  query: {
    source?: string;
    date?: string;
    from?: string;
    to?: string;
    total?: number;
    travel_type?: string[] | null;
    staying_night?: number | null;
    sort?: string | null;
    star?: string | null;
    friday_night_karbala?: string | null;
    vip?: string | null;
  },
  take: number,
  page: number,
  mode: "add" | "replace" = "replace",
  successCallback?: (...args: any) => void,
  failCallback?: (...args: any) => void
) => {
  try {
    const getRangeValue = (value?: string | string[]) => {
      if (!value) return "";
      return Array.isArray(value) ? value[0] : value;
    };

    const fromStr = getRangeValue(query.from);
    const toStr = getRangeValue(query.to);

    const fromDate =
      fromStr && fromStr.length
        ? DateTimeController.parseToMDate(fromStr, "YYYY-MM-DD")
        : undefined;

    const toDate =
      toStr && toStr.length
        ? DateTimeController.parseToMDate(toStr, "YYYY-MM-DD")
        : undefined;
    const params = {
      type: "package",
      src_province_slug: query?.source?.split("-")[1],
      dst_province_slug: "karbala",
      date:
        !fromDate && !toDate && query?.date && query.date.length
          ? DateTimeController.parseToMDate(query?.date, "YYYY-MM-DD")
          : undefined,
      from_date: fromDate,
      to_date: toDate,
      passenger: query?.total ? query?.total : 0,
      travel_type:
        query?.travel_type && query.travel_type.length > 0
          ? query.travel_type
          : undefined,
      staying_night: query?.staying_night
        ? String(query?.staying_night)
        : undefined,
      star: query.star,
      per_page: take,
      page: page,
      sort: query.sort ? query.sort : "order:asc",
      friday_night_karbala: query.friday_night_karbala,
      vip: query.vip,
    };
    
    const resetRes = () => {
      dispatch(
        getTours({
          data: [],
          count: 0,
          loading: false,
          page: 1,
        })
      );
    };

    const waitForRes = () => {
      if (mode === "replace") {
        dispatch(
          getTours({
            data: null,
            count: 0,
            loading: true,
          })
        );
      } else {
        dispatch(
          addTours({
            data: [],
            count: null,
            loading: true,
          })
        );
      }
    };

    waitForRes();

    await Api.Get(`/api/home/filter`, false, "", true, params).then((res) => {
      if (res.status === 200 || res.status === 201) {
        const tours = res.data?.data;
        if (mode === "replace") {
          dispatch(
            getTours({
              data: tours,
              count: res.data?.total,
              loading: false,
              page: page,
            })
          );
        } else {
          dispatch(
            addTours({
              data: tours,
              count: res.data?.total,
              loading: false,
              page: page,
            })
          );
        }
        successCallback && successCallback();
      } else {
        resetRes();
        failCallback && failCallback();
      }
    });
  } catch (err) {
    console.log(err);
    failCallback && failCallback();
    Toast.error("خطای ناشناخته");
  }
};

export const GetTour = (dispatch: AppDispatch, name: string) => {
  const resetRes = () => {
    dispatch(
      getTourDetail({
        data: null,
        loading: false,
      })
    );
  };

  const waitForRes = () => {
    dispatch(
      getTourDetail({
        data: null,
        loading: true,
      })
    );
  };
  waitForRes();
  try {
    Api.Get(`/api/landing/package/${name}`, false).then((res) => {
      if (res.status === 200 || res.status === 201) {
        const tour = res.data;
        dispatch(
          getTourDetail({
            data: tour,
            loading: false,
          })
        );
      } else {
        resetRes();
        Toast.error("خطا در دریافت اطلاعات هتل");
      }
    });
  } catch (err) {
    console.log(err);
    resetRes();
    Toast.error("خطای ناشناخته");
  }
};

// ssr
export const fetchToursListData = async (
  store: AppStore,
  query: any,
  source: string
) => {
  const params = {
    type: "package",
    src_province_slug: source?.split("-")[1],
    dst_province_slug: "karbala",
    date:
      query?.date?.length > 0
        ? DateTimeController.parseToMDate(query?.date, "YYYY-MM-DD")
        : "",
    passenger: query?.total?.length ? query?.total : 0,
    travel_type: query?.travel_type?.length > 0 ? query?.travel_type : "",
    staying_night: query?.staying_night?.length > 0 ? query?.staying_night : "",
    per_page: query?.per_page ? query?.per_page : 10,
    page: 1,
    sort: "order:asc",
  };
  store.dispatch(getTours({ data: [], loading: true }));
  await Api.Get("/api/home/filter", false, "", true, params)
    .then((res) => {
      store.dispatch(
        getTours({
          data: res?.data?.data,
          loading: false,
          total: res?.data?.total,
        })
      );
    })
    .catch((err) => {
      //handleErr
      store.dispatch(getTours({ data: [], loading: false }));
    })
    .then(() => {
      //handleFinally
    });
};

//ssr
export const fetchTourItemData = async (store: AppStore, id: number) => {
  store.dispatch(getTourDetail({ data: {}, loading: true }));
  await Api.Get(`/api/landing/package/${id}`)
    .then((res) => {
      store.dispatch(getTourDetail({ data: res?.data, loading: false }));
    })
    .catch((err) => {
      //handleErr
      store.dispatch(getTourDetail({ data: {}, loading: false }));
    });
};

// get tour existance

export const GetTourExistance = (
  sourceId: number,
  dispatch: AppDispatch,
  fromDate: string,
  toDate: string,
  swiper?: boolean,
  successCallback?: (...args: any) => void,
  failCallback?: (...args: any) => void
) => {
  const resetRes = () => {
    dispatch(
      getTourExist({
        data: [],
        loading: false,
      })
    );
  };

  const waitForRes = () => {
    dispatch(
      getTourExist({
        loading: true,
      })
    );
  };
  waitForRes();

  const params = {
    from_date: fromDate,
    to_date: toDate,
    source_province_id: sourceId,
    swiper: swiper,
  };
  try {
    Api.Get(`/api/home/advance-date`, false, "", true, params).then((res) => {
      if (res.status === 200 || res.status === 201) {
        const tourExistance = res.data;
        dispatch(
          getTourExist({
            data: tourExistance,
            loading: false,
          })
        );
        successCallback && successCallback();
      } else {
        resetRes();
        failCallback && failCallback();
        Toast.error("خطا در دریافت تاریخ تور ها");
      }
    });
  } catch (err) {
    console.log(err);
    resetRes();
    failCallback && failCallback();
    Toast.error("خطای ناشناخته");
  }
};

export const fetchSpecialOccasions = (dispatch: AppDispatch) => {
  try {
    Api.Get(`/api/home/event`, false, "", true).then((res) => {
      if (res.status === 200) {
        const data = res.data;
        dispatch(
          getSpecialOccasions({
            data,
            loading: false,
          })
        );
      }
    });
  } catch (err) {
    console.log(err);
  }
};
