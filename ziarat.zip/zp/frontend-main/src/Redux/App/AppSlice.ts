import { createSlice } from '@reduxjs/toolkit'
    import type { PayloadAction } from '@reduxjs/toolkit'
    import { ThemeType, theme } from '../../Utils/theme'

    export interface AppState {
      theme: ThemeType,
      lang: "fa" | "en",
    }

    const initialState: AppState = {
      theme: theme,
      lang: "fa",
    }

    export const appSlice = createSlice({
      name: 'app',
      initialState,
      reducers: {
        
      },
    })

    export const {
    } = appSlice.actions

    export default appSlice.reducer