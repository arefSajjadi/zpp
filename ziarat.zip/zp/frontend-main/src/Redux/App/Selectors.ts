
    import { AppState } from "./AppSlice";
    interface stateType {
        App: AppState
    }
    export const selectTheme = (state: stateType) => state.App.theme;
    export const selectLang = (state: stateType) => state.App.lang;
    