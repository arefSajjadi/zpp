
import { AuthState } from "./AuthSlice";
interface stateType {
    Auth: AuthState
}
export const selectAuth = (state: stateType) => state.Auth;

