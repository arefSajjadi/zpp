import Api from "@/Requests/Api";
import Toast from "@/Shared/Kit/Toast";
import { setCookie } from "cookies-next";
import { AppDispatch } from "../store";
import { setAuth, setLoginTimer } from "./AuthSlice";
import NameSpace from "@/Storage/NameSpace";
import persian_to_english_number from "@/Utils/persianToEnglishNumber";

export const SendOtp = async (
  dispatch: AppDispatch,
  mobile: string,
  successCallback?: (...args: any) => void,
  failCallback?: (errorMessage?: string) => void
) => {
  try {
    const normalizedMobile = persian_to_english_number(mobile);

    const res = await Api.Post(
      "/api/auth/send-otp",
      { mobile: normalizedMobile },
      false
    );

    if (res.status === 200 || res.status === 201 || res.status === 202) {
      dispatch(setLoginTimer(60));
      successCallback && successCallback(res.data);
    } else {
      failCallback && failCallback();
      Toast.error("خطا در ارسال شماره تماس");
    }
  } catch (err: any) {
    console.log(err);
    failCallback && failCallback();
    Toast.error("خطا در ارسال شماره تماس");
  }
};

export const VerifyOtp = async (
  dispatch: AppDispatch,
  mobile: string,
  otp: string,
  successCallback?: (...args: any) => void,
  failCallback?: (errorMessage?: string) => void
) => {
  const normalizedMobile = persian_to_english_number(mobile);
  const normalizedOtp = persian_to_english_number(otp);

  const data = { mobile: normalizedMobile, otp: normalizedOtp };

  try {
    const res = await Api.Post("/api/auth/login", data, false);

    if (res.status === 200 || res.status === 201 || res.status === 202) {
      setCookie(NameSpace.mobileNumber, normalizedMobile, {
        maxAge: 60 * 60 * 24 * 30,
      });
      setCookie(NameSpace.token, res?.data?.token, {
        maxAge: 60 * 60 * 24 * 30,
      });
      dispatch(setAuth(true));
      successCallback && successCallback(res.data);
    }
  } catch (err: any) {
    if (err.response.status === 401) {
      failCallback && failCallback();
      Toast.error("کد وارد شده اشتباه است");
    } else {
      console.log(err);
      failCallback && failCallback();
      Toast.error("خطا در انجام عملیات");
    }
  }
};
