import { createSlice } from '@reduxjs/toolkit'
    import type { PayloadAction } from '@reduxjs/toolkit'
    import { ThemeType, theme } from '../../Utils/theme'
    import { getCookie, hasCookie } from 'cookies-next';
import NameSpace from '@/Storage/NameSpace';

    export interface AuthState {
      isAuthenticated: boolean;
      mobileNumber?: string;
      showLoginModal: boolean; 
      loginTimer: number
      nextUrl: string,
    }

    const initialState: AuthState = {
      isAuthenticated: hasCookie(NameSpace.token),
      mobileNumber: getCookie(NameSpace.mobileNumber) ? getCookie(NameSpace.mobileNumber) : "",
      showLoginModal: false,
      loginTimer: 60,
      nextUrl:""
    }

    export const appSlice = createSlice({
      name: 'app',
      initialState,
      reducers: {
        setAuth: (state ,action) => {
            return {
                ...state,
                isAuthenticated: action.payload
            }
        },
        setMobileNumber: (state ,action) => {
            return {
                ...state, 
                mobileNumber: action.payload
            }
        },
        setShowLoginModal: (state ,action) => {
            return {
                ...state,
                showLoginModal: action.payload
            }
        },
        setLoginTimer: (state ,action) => {
            return {
                ...state,
                loginTimer: action.payload
            }
        },
        setNextUrl: (state ,action) => {
            return {
                ...state,
                nextUrl: action.payload
            }
        },
      },
    })

    export const {
        setAuth,
        setShowLoginModal,
        setLoginTimer,
        setMobileNumber,
        setNextUrl
    } = appSlice.actions

    export default appSlice.reducer