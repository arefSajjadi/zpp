export interface HotelType {
  id: number;
  created_at: string;
  updated_at: string;
  deleted_at: null;
  province_id: number;
  room_only: number;
  full_board: number;
  lat: string;
  lang: string;
  name: string;
  name_en: string;
  address: string;
  star: number;
  search: string;
  description: string;
  attributes: {
    name: string;
    pivot: {
      hotel_id: number;
      attribute_id: number;
    };
  }[];
  rules?: {
    rule: string;
    pivot: {
      hotel_id: number;
      rule_id: number;
    };
  }[];
  province: {
    id: number;
    name: string;
  };
  distances: {
    hotel_id: number;
    name: string;
    car: string;
    walk: string;
    distance: string;
  }[];
  files: {
    id: number;
    created_at: string;
    updated_at: string;
    deleted_at: null;
    src: string;
    file_name: string;
    mime_type: string;
    type: string;
    fileable_type: string;
    fileable_id: number;
    alt: string;
  }[];
}

export interface HotelState {
  hotelList: HotelType[];
  hotelLoading: boolean;
  hotelCount: number;
  moreHotelsLoading: boolean;
  hotelPage: number;

  hotelDetail: HotelType | null;
  hotelDetailLoading: boolean;
}
