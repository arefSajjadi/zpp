import { createSlice } from '@reduxjs/toolkit'
import { HotelState } from './Interface'

  

    const initialState: HotelState = {
        hotelCount: 0,
        hotelList: [],
        moreHotelsLoading: false,
        hotelPage: 0,

        hotelDetailLoading: false,
        hotelDetail: null,
        hotelLoading: false,
    }

    export const hotelSlice = createSlice({
      name: 'hotel',
      initialState,
      reducers: {
        getHotels: (state ,action) => {
          return {
            ...state,
            hotelList: action.payload.data,
            hotelLoading: action.payload.loading,
            hotelCount: action.payload.count,
            hotelPage: action.payload.skip
          }
        },

        addHotels: (state ,action) => {
            return {
              ...state,
              hotelList: [...state.hotelList ,...action.payload.data],
              moreHotelsLoading: action.payload.loading,
              hotelCount: action.payload.count ? action.payload.count : state.hotelCount,
              hotelPage: action.payload.page
            }
          },

        getHotelDetail: (state ,action) => {
          return {
            ...state,
            hotelDetail: action.payload.data,
            hotelDetailLoading: action.payload.loading,
          }
        }
      },
    })

    export const {
      getHotels,
      addHotels,
      getHotelDetail
    } = hotelSlice.actions

    export default hotelSlice.reducer