import Toast from "@/Shared/Kit/Toast";
import { AppDispatch, AppStore } from "../store";
import Api from "@/Requests/Api";
import { addHotels, getHotelDetail, getHotels } from "./HotelSlice";

export const GetHotels = (
  dispatch: AppDispatch,
  hotelCity: string,
  take: number,
  page: number,
  mode: "add" | "replace" = "replace",
  star?: string | null,
  hotelName?: string | null
) => {
  try {
    const params = {
      type: "hotel",
      src_province_slug: hotelCity?.split("-")[0],
      per_page: take,
      page: page,
      star: star,
      search: hotelName,
    };

    const resetRes = () => {
      dispatch(
        getHotels({
          data: [],
          count: 0,
          loading: false,
          skip: 0,
        })
      );
    };

    const waitForRes = () => {
      if (mode === "replace") {
        dispatch(
          getHotels({
            data: [],
            count: 0,
            loading: true,
            skip: 0,
          })
        );
      } else {
        dispatch(
          addHotels({
            data: [],
            count: null,
            loading: true,
            page: page,
          })
        );
      }
    };

    waitForRes();
    Api.Get(`/api/home/filter`, false, "", true, params).then((res) => {
      if (res.status === 200 || res.status === 201) {
        const hotels = res.data?.data;
        if (mode === "replace") {
          dispatch(
            getHotels({
              data: hotels,
              count: res.data?.total,
              loading: false,
              skip: page,
            })
          );
        } else {
          dispatch(
            addHotels({
              data: hotels,
              count: res.data?.total,
              loading: false,
              page: page,
            })
          );
        }
      } else {
        resetRes();
      }
    });
  } catch (err) {
    console.log(err);
    Toast.error("خطای ناشناخته");
  }
};

export const GetHotelDetail = (dispatch: AppDispatch, name: string) => {
  try {
    Api.Get(`/api/landing/hotel/${name}`, false).then((res) => {
      if (res.status === 200 || res.status === 201) {
        const hotel = res.data?.data;
        dispatch(
          getHotelDetail({
            data: hotel,
            loading: false,
          })
        );
      } else {
        Toast.error("خطا در دریافت اطلاعات هتل");
      }
    });
  } catch (err) {
    console.log(err);
    Toast.error("خطای ناشناخته");
  }
};

export const fetchHotelsListData = async (
  store: AppStore,
  hotelcity: string
) => {
  const params = {
    type: "hotel",
    src_province_slug: hotelcity?.split("-")[0],
  };
  store.dispatch(getHotels({ data: [], loading: true }));
  await Api.Get("/home/filter", false, "", true, params)
    .then((res) => {
      store.dispatch(getHotels({ data: res?.data?.data, loading: false }));
    })
    .catch((err) => {
      //handleErr
      store.dispatch(getHotels({ data: [], loading: false }));
    })
    .then(() => {
      //handleFinally
    });
};

export const fetchHotelItemData = async (store: AppStore, name: string) => {
  // store.dispatch(fetchHotelItem({data:{},loading:true}))
  const res = await Api.Get(`/landing/hotel/${name}`);
  return res.data?.name || "";
};
