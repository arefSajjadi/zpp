import { HotelState } from "./Interface";
interface stateType {
    Hotel: HotelState
}
export const selectHotelState = (state: stateType) => state.Hotel;
