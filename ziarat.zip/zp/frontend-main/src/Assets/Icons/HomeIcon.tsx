const HomeIcon = () => {
  return (
    <svg
      width="22"
      height="22"
      viewBox="0 0 22 22"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M8.0791 15.1367H13.8941"
        stroke="#206692"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M1.40039 12.713C1.40039 7.082 2.01439 7.475 5.31939 4.41C6.76539 3.246 9.01539 1 10.9584 1C12.9004 1 15.1954 3.235 16.6544 4.41C19.9594 7.475 20.5724 7.082 20.5724 12.713C20.5724 21 18.6134 21 10.9864 21C3.35939 21 1.40039 21 1.40039 12.713Z"
        stroke="#206692"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default HomeIcon;
