import { selectTheme } from "@/Redux/App/Selectors";
import React from "react";
import { useSelector } from "react-redux";

const BellIcon = () => {
const theme = useSelector(selectTheme)
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M17.9066 12.3557C17.9094 12.9369 18.1649 13.488 18.6066 13.8657C20.1166 15.2157 19.0466 17.5257 16.9066 17.5257H13.1066C12.614 18.8701 11.3383 19.7671 9.90657 19.7757C8.47017 19.7819 7.18678 18.8795 6.70657 17.5257H2.90657C0.766568 17.5257 -0.303432 15.2157 1.20657 13.8657C1.6482 13.488 1.90369 12.9369 1.90657 12.3557V7.52574C1.90657 3.58574 5.48657 0.385742 9.90657 0.385742C14.3266 0.385742 17.9066 3.58574 17.9066 7.52574V12.3557ZM8.38657 17.5257C8.75048 17.9968 9.31136 18.2735 9.90657 18.2757C10.4877 18.2614 11.0314 17.9859 11.3866 17.5257H8.38657Z"
        fill={theme.secondary600}
      />
    </svg>
  );
};

export default BellIcon;
