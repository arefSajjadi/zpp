import React from "react";

const Location2Icon = () => {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 26 26"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M14.0733 23.727C16.4417 21.6744 21.9094 16.2882 21.9094 10.3014C21.9094 5.38118 17.9208 1.39258 13.0006 1.39258C8.0804 1.39258 4.0918 5.38118 4.0918 10.3014C4.0918 16.2882 9.55945 21.6744 11.9279 23.727C12.5503 24.2663 13.4509 24.2663 14.0733 23.727Z"
        stroke="#206692"
        stroke-width="1.71415"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <circle
        cx="12.9996"
        cy="10.484"
        r="4.6129"
        stroke="#206692"
        stroke-width="1.71415"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default Location2Icon;
