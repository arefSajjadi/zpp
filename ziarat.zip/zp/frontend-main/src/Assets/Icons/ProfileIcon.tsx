import React from "react";

const ProfileIcon = () => {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M11.8445 21.6618C8.15273 21.6618 5 21.0873 5 18.7865C5 16.4858 8.13273 14.3618 11.8445 14.3618C15.5364 14.3618 18.6891 16.4652 18.6891 18.766C18.6891 21.0658 15.5564 21.6618 11.8445 21.6618Z"
        fill="white"
        fill-opacity="0.46"
        stroke="white"
        stroke-linejoin="round"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M11.8365 11.1735C14.2592 11.1735 16.2229 9.2099 16.2229 6.78718C16.2229 4.36445 14.2592 2.3999 11.8365 2.3999C9.41379 2.3999 7.44924 4.36445 7.44924 6.78718C7.44106 9.20172 9.39106 11.1654 11.8056 11.1735C11.8165 11.1735 11.8265 11.1735 11.8365 11.1735Z"
        fill="white"
        fill-opacity="0.46"
        stroke="white"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default ProfileIcon;
