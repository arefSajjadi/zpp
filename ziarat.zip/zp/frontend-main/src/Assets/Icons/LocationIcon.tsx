import React from "react";
interface Props {
  color?: string;
}
const LocationIcon = ({color="#101010"}:Props): React.ReactElement => {
  return (
    <svg
      width="17"
      height="21"
      viewBox="0 0 17 21"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M11.0098 9.09621C11.0098 7.71494 9.89053 6.5957 8.50926 6.5957C7.129 6.5957 6.00977 7.71494 6.00977 9.09621C6.00977 10.4765 7.129 11.5957 8.50926 11.5957C9.89053 11.5957 11.0098 10.4765 11.0098 9.09621Z"
        stroke={color}
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M8.49951 19.3857C5.60148 19.3857 1 14.3444 1 8.98438C1 4.78821 4.3571 1.38574 8.49951 1.38574C12.6419 1.38574 16 4.78821 16 8.98438C16 14.3444 11.3985 19.3857 8.49951 19.3857Z"
        stroke={color}
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default LocationIcon;
