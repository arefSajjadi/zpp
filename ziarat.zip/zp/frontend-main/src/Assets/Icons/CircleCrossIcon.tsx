const CircleCrossIcon = () => {
  return (
    <svg
      width="51"
      height="51"
      viewBox="0 0 51 51"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle
        cx="25.5007"
        cy="25.5007"
        r="22.9167"
        stroke="#FF0033"
        stroke-width="4"
        stroke-linecap="round"
      />
      <path
        d="M18.625 18.625L32.375 32.375"
        stroke="#FF0033"
        stroke-width="4"
        stroke-linecap="round"
      />
      <path
        d="M32.375 18.625L18.625 32.375"
        stroke="#FF0033"
        stroke-width="4"
        stroke-linecap="round"
      />
    </svg>
  );
};

export default CircleCrossIcon;
