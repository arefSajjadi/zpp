const SquareMinusIcon = () => {
  return (
    <svg
      width="28"
      height="28"
      viewBox="0 0 28 28"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M18.5834 13.9881H9.41675"
        stroke="#767676"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M19.8571 1.5H8.14286C4.05952 1.5 1.5 4.3901 1.5 8.48145V19.5186C1.5 23.6099 4.04762 26.5 8.14286 26.5H19.8571C23.9524 26.5 26.5 23.6099 26.5 19.5186V8.48145C26.5 4.3901 23.9524 1.5 19.8571 1.5Z"
        stroke="#767676"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default SquareMinusIcon;
