import React from "react";

const SendIcon = () => {
  return (
    <svg
      width="15"
      height="15"
      viewBox="0 0 15 15"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M4.94502 4.8355L8.76064 8.69187L13.1004 5.97752C13.7222 5.5885 13.5928 4.64403 12.8895 4.43836L2.58585 1.42092C1.94183 1.23216 1.34496 1.8343 1.53628 2.48041L4.58461 12.7769C4.79344 13.4812 5.73253 13.607 6.11786 12.9826L8.76266 8.69254"
        stroke="#101010"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default SendIcon;
