import React from "react";

const TelephonIcon = () => {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M6.20049 13.799C-0.697496 6.90022 0.283381 3.74115 1.01055 2.72316C1.10396 2.55862 3.40647 -0.88812 5.87459 1.13407C12.0008 6.17945 4.2451 5.46611 9.3894 10.6113C14.5348 15.7554 13.8214 7.99995 18.8659 14.1249C20.8882 16.594 17.4413 18.8964 17.2778 18.9888C16.2598 19.717 13.0995 20.6978 6.20049 13.799Z"
        fill="#3676F5"
        fill-opacity="0.2"
        stroke="#206692"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default TelephonIcon;
