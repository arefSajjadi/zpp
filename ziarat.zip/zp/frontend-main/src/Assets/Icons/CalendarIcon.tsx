import React from "react";

interface Props {
    color?: string;
}
const CalendarIcon = ({color="#206692"}:Props) => {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 26 26"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g clip-path="url(#clip0_1082_1812)">
        <path
          d="M8.82812 1.39258V6.10776"
          stroke={color}
          stroke-width="1.71415"
          stroke-linecap="round"
        />
        <path
          d="M17.1602 1.39258V6.10776"
          stroke={color}
          stroke-width="1.71415"
          stroke-linecap="round"
        />
        <path
          d="M2.02747 19.5462C2.3271 22.2192 4.49985 24.3417 7.18661 24.4712C9.04366 24.5605 10.9407 24.6069 12.9996 24.6069C15.0585 24.6069 16.9556 24.5605 18.8126 24.4712C21.4993 24.3417 23.6722 22.2192 23.9717 19.5462C24.1736 17.746 24.3391 15.9004 24.3391 14.0203C24.3391 12.1402 24.1736 10.2946 23.9717 8.49448C23.6722 5.82134 21.4993 3.69891 18.8126 3.56952C16.9556 3.48008 15.0585 3.43359 12.9996 3.43359C10.9407 3.43359 9.04366 3.48008 7.18661 3.56952C4.49985 3.69891 2.3271 5.82134 2.02747 8.49448C1.8257 10.2946 1.66016 12.1402 1.66016 14.0203C1.66016 15.9004 1.8257 17.746 2.02747 19.5462Z"
          stroke={color}
          stroke-width="1.71415"
        />
        <path
          d="M7.42871 11.2344H8.35651"
          stroke={color}
          stroke-width="1.71415"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M7.42871 16.8057H8.35651"
          stroke={color}
          stroke-width="1.71415"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M12.5361 11.2344H13.4639"
          stroke={color}
          stroke-width="1.71415"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M17.6426 11.2344H18.5704"
          stroke={color}
          stroke-width="1.71415"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M12.5361 16.8057H13.4639"
          stroke={color}
          stroke-width="1.71415"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <defs>
        <clipPath id="clip0_1082_1812">
          <rect width="26" height="26" fill="white" />
        </clipPath>
      </defs>
    </svg>
  );
};

export default CalendarIcon;
