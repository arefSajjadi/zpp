const FilterIcon = () => {
  return (
    <svg
      width="17"
      height="16"
      viewBox="0 0 17 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M7.9283 11.9223H3.61328"
        stroke="#206692"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M10.6367 11.9229C10.6367 13.2841 11.0906 13.7375 12.4512 13.7375C13.8118 13.7375 14.2658 13.2841 14.2658 11.9229C14.2658 10.5617 13.8118 10.1084 12.4512 10.1084C11.0906 10.1084 10.6367 10.5617 10.6367 11.9229Z"
        stroke="#206692"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M9.95117 4.93008H14.2656"
        stroke="#206692"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M7.24293 4.92878C7.24293 3.56819 6.789 3.11426 5.4284 3.11426C4.06721 3.11426 3.61328 3.56819 3.61328 4.92878C3.61328 6.28998 4.06721 6.74331 5.4284 6.74331C6.789 6.74331 7.24293 6.28998 7.24293 4.92878Z"
        stroke="#206692"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default FilterIcon;
