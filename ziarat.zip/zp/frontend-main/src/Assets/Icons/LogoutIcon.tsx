const LogoutIcon = () => {
  return (
    <svg
      width="21"
      height="21"
      viewBox="0 0 21 21"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M13.0165 5.39144V4.45844C13.0165 2.42344 11.3665 0.773438 9.33146 0.773438H4.45646C2.42246 0.773438 0.772461 2.42344 0.772461 4.45844V15.5884C0.772461 17.6234 2.42246 19.2734 4.45646 19.2734H9.34146C11.3705 19.2734 13.0165 17.6284 13.0165 15.5994V14.6564"
        stroke="#FF0033"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M19.8096 10.0234H7.76855"
        stroke="#FF0033"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M16.8818 7.10938L19.8098 10.0244L16.8818 12.9404"
        stroke="#FF0033"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default LogoutIcon;
