const StarIcon = () => {
  return (
    <svg
      width="25"
      height="24"
      viewBox="0 0 25 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M5.71 8.61003L8.52999 7.20006C8.91999 7.01006 9.28999 6.50006 9.36999 6.07006L9.78999 3.52004C10.06 1.89004 11.24 1.51004 12.42 2.68004L14.41 4.67006C14.74 5.00006 15.39 5.19004 15.86 5.08004L18.32 4.51006C20.26 4.06006 21.02 5.10005 20 6.81005L18.58 9.20006C18.32 9.63006 18.32 10.35 18.58 10.78L20 13.1701C21.01 14.8801 20.26 15.92 18.32 15.47L15.86 14.9C15.4 14.79 14.75 14.98 14.41 15.31L12.42 17.3C11.25 18.47 10.07 18.09 9.78999 16.46L9.36999 13.9101C9.29999 13.4801 8.91999 12.97 8.52999 12.78L5.71 11.37C4.18 10.62 4.18 9.38003 5.71 8.61003Z"
        stroke="white"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M5.5 16L5.5 22"
        stroke="white"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M19.5 19L19.5 22"
        stroke="white"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M12.5 21L12.5 22"
        stroke="white"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default StarIcon;
