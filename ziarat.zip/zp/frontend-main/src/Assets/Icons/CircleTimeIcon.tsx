const CircleTimeIcon = () => {
  return (
    <svg
      width="35"
      height="35"
      viewBox="0 0 35 35"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M32.9329 17.4836C32.9329 25.9969 26.0313 32.9002 17.5163 32.9002C9.00294 32.9002 2.09961 25.9969 2.09961 17.4836C2.09961 8.96856 9.00294 2.06689 17.5163 2.06689C26.0313 2.06689 32.9329 8.96856 32.9329 17.4836Z"
        stroke="#206692"
        stroke-width="3"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M24.5012 18.7622L16.9512 18.6389V10.5605"
        stroke="#206692"
        stroke-width="3"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default CircleTimeIcon;
