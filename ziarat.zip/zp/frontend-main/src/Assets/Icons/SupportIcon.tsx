const SupportIcon = () => {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M5.00576 10C5.00576 10 4.53947 3 12 3C19.4605 3 18.9942 10 18.9942 10"
        stroke="#434343"
        stroke-width="1.5"
        stroke-linecap="round"
      />
      <rect
        x="3"
        y="10"
        width="5"
        height="10"
        rx="2.5"
        stroke="#434343"
        stroke-width="1.5"
      />
      <rect
        x="16"
        y="10"
        width="5"
        height="10"
        rx="2.5"
        stroke="#434343"
        stroke-width="1.5"
      />
    </svg>
  );
};

export default SupportIcon;
