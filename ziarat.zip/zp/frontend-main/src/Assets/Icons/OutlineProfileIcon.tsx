import React from "react";

const OutlineProfileIcon = () => {
  return (
    <svg
      width="16"
      height="22"
      viewBox="0 0 16 22"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M7.84455 20.6613C4.15273 20.6613 1 20.0868 1 17.7861C1 15.4853 4.13273 13.3613 7.84455 13.3613C11.5364 13.3613 14.6891 15.4647 14.6891 17.7655C14.6891 20.0653 11.5564 20.6613 7.84455 20.6613Z"
        stroke="#206692"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M7.83652 10.174C10.2592 10.174 12.2229 8.21039 12.2229 5.78766C12.2229 3.36494 10.2592 1.40039 7.83652 1.40039C5.41379 1.40039 3.44924 3.36494 3.44924 5.78766C3.44106 8.20221 5.39106 10.1658 7.80561 10.174C7.81652 10.174 7.82652 10.174 7.83652 10.174Z"
        stroke="#206692"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default OutlineProfileIcon;
