import React from "react";

interface Props {
    stroke?: string
}
const TikIcon:React.FC<Props> = (props) => {

  return (
    <svg
      width="21"
      height="17"
      viewBox="0 0 21 17"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M2.6582 9.93145L6.92723 14.2005L18.3113 2.81641"
        stroke={props.stroke ? props.stroke : "white"}
        stroke-width="4.26903"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default TikIcon;
