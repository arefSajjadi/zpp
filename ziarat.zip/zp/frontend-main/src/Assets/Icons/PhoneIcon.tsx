import React from "react";

interface props {
    color?: string
}

const PhoneIcon = ({color}: props) => {
    return (
        <svg
            width="21"
            height="21"
            viewBox="0 0 21 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
        >
            <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M6.70049 14.1848C-0.197496 7.28596 0.783381 4.12689 1.51055 3.1089C1.60396 2.94436 3.90647 -0.502378 6.37459 1.51981C12.5008 6.5652 4.7451 5.85186 9.8894 10.997C15.0348 16.1411 14.3214 8.3857 19.3659 14.5106C21.3882 16.9797 17.9413 19.2822 17.7778 19.3745C16.7598 20.1027 13.5995 21.0835 6.70049 14.1848Z"
                stroke={color ?? "#101010"}
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
            />
        </svg>
    );
};

export default PhoneIcon;
