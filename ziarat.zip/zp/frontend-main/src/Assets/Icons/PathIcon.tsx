import React from "react";

const PathIcon = () => {
  return (
    <svg
      width="25"
      height="25"
      viewBox="0 0 25 25"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M5.9707 9.09961C7.9037 9.09961 9.4707 7.53261 9.4707 5.59961C9.4707 3.66661 7.9037 2.09961 5.9707 2.09961C4.03771 2.09961 2.4707 3.66661 2.4707 5.59961C2.4707 7.53261 4.03771 9.09961 5.9707 9.09961Z"
        stroke="#292D32"
        stroke-width="1.5"
      />
      <path
        d="M17.4707 15.0996H20.4707C21.5707 15.0996 22.4707 15.9996 22.4707 17.0996V20.0996C22.4707 21.1996 21.5707 22.0996 20.4707 22.0996H17.4707C16.3707 22.0996 15.4707 21.1996 15.4707 20.0996V17.0996C15.4707 15.9996 16.3707 15.0996 17.4707 15.0996Z"
        stroke="#292D32"
        stroke-width="1.5"
      />
      <path
        d="M12.4997 5.09961H15.1797C17.0297 5.09961 17.8897 7.38961 16.4997 8.60961L8.5097 15.5996C7.1197 16.8096 7.9797 19.0996 9.8197 19.0996H12.4997"
        stroke="#292D32"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M5.98573 5.59961H5.99728"
        stroke="#292D32"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M18.9857 18.5996H18.9973"
        stroke="#292D32"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default PathIcon;
