import React from "react";

const ArrowUpDownIcon = () => {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 16 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M4.65365 3.06738V11.4794"
        stroke="#4b5259"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M1.93359 5.79974C1.93359 5.79974 3.37959 3.06641 4.65226 3.06641C5.92426 3.06641 7.37093 5.79974 7.37093 5.79974"
        stroke="#4b5259"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M11.2708 12.9511V4.53906"
        stroke="#4b5259"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M13.9901 10.2188C13.9901 10.2188 12.5434 12.9521 11.2714 12.9521C9.9994 12.9521 8.55273 10.2188 8.55273 10.2188"
        stroke="#4b5259"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default ArrowUpDownIcon;
