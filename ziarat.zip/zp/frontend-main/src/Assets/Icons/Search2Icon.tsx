const Search2Icon = () => {
  return (
    <svg
      width="21"
      height="20"
      viewBox="0 0 21 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M9.75065 17.5003C14.1229 17.5003 17.6673 13.9559 17.6673 9.58366C17.6673 5.2114 14.1229 1.66699 9.75065 1.66699C5.3784 1.66699 1.83398 5.2114 1.83398 9.58366C1.83398 13.9559 5.3784 17.5003 9.75065 17.5003Z"
        stroke="#292D32"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M18.5007 18.3337L16.834 16.667"
        stroke="#292D32"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default Search2Icon;
