interface Props {
    color?: string;
}
const TwoUserIcon = ({color="#767676"}:Props) => {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 20 22"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M7.55802 20.4562C3.88602 20.4562 0.749023 19.9012 0.749023 17.6772C0.749023 15.4532 3.86602 13.4492 7.55802 13.4492C11.23 13.4492 14.366 15.4342 14.366 17.6572C14.366 19.8802 11.25 20.4562 7.55802 20.4562Z"
        stroke={color}
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M7.55837 10.2778C9.96837 10.2778 11.9224 8.3238 11.9224 5.9138C11.9224 3.5038 9.96837 1.5498 7.55837 1.5498C5.14837 1.5498 3.19437 3.5038 3.19437 5.9138C3.18537 8.3158 5.12637 10.2698 7.52737 10.2778H7.55837Z"
        stroke={color}
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M14.8003 9.07864C16.2033 8.70364 17.2373 7.42464 17.2373 5.90264C17.2383 4.31464 16.1113 2.98864 14.6133 2.68164"
        stroke={color}
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M15.46 12.6533C17.448 12.6533 19.146 14.0013 19.146 15.2043C19.146 15.9133 18.561 16.6413 17.671 16.8503"
        stroke={color}
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default TwoUserIcon;
