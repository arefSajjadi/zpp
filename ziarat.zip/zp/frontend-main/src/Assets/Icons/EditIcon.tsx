const EditIcon = () => {
  return (
    <svg
      width="18"
      height="18"
      viewBox="0 0 18 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M10.002 14.6309H14.7847"
        stroke="#206692"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M12.0435 3.64408V3.64408C11.0355 2.88808 9.60603 3.09208 8.85003 4.09933C8.85003 4.09933 5.09028 9.10783 3.78603 10.8456C2.48178 12.5841 3.71553 14.7381 3.71553 14.7381C3.71553 14.7381 6.14853 15.2976 7.43403 13.5838C8.72028 11.8708 12.498 6.83758 12.498 6.83758C13.254 5.83033 13.0508 4.40008 12.0435 3.64408Z"
        stroke="#206692"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M7.87891 5.4082L11.5269 8.14645"
        stroke="#206692"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default EditIcon;
