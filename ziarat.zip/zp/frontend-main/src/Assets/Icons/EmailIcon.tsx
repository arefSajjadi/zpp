const EmailIcon = () => {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 41 41"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M29.7586 15.4487C29.7586 15.4487 24.4086 21.8698 20.4955 21.8698C16.584 21.8698 11.1738 15.4487 11.1738 15.4487"
        stroke="#206692"
        stroke-width="3"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M4.60352 20.3651C4.60352 8.96824 8.57177 5.17041 20.4765 5.17041C32.3813 5.17041 36.3495 8.96824 36.3495 20.3651C36.3495 31.7602 32.3813 35.5597 20.4765 35.5597C8.57177 35.5597 4.60352 31.7602 4.60352 20.3651Z"
        stroke="#206692"
        stroke-width="3"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default EmailIcon;
