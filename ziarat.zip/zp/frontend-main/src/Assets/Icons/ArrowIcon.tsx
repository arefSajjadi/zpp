import React from "react";

const ArrowIcon = () => {
  return (
    <svg
      width="10"
      height="16"
      viewBox="0 0 10 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M1.5 1C1.5 1 8.5 5.144 8.5 8C8.5 10.855 1.5 15 1.5 15"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
        fill="transparent"
      />
    </svg>
  );
};

export default ArrowIcon;
