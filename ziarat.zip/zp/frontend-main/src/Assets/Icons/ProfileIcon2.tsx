import React from "react";

const ProfileIcon2 = () => {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M11.8445 21.6613C8.15273 21.6613 5 21.0868 5 18.7861C5 16.4853 8.13273 14.3613 11.8445 14.3613C15.5364 14.3613 18.6891 16.4647 18.6891 18.7655C18.6891 21.0653 15.5564 21.6613 11.8445 21.6613Z"
        stroke="#206692"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M11.8365 11.174C14.2592 11.174 16.2229 9.21039 16.2229 6.78766C16.2229 4.36494 14.2592 2.40039 11.8365 2.40039C9.41379 2.40039 7.44924 4.36494 7.44924 6.78766C7.44106 9.20221 9.39106 11.1658 11.8056 11.174C11.8165 11.174 11.8265 11.174 11.8365 11.174Z"
        stroke="#206692"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};

export default ProfileIcon2;
