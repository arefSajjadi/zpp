import React from "react";

const DiscountIcon = () => {
  return (
    <svg
      width="22"
      height="22"
      viewBox="0 0 22 22"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M3.875 3.875L18.125 18.125"
        stroke="white"
        stroke-width="2"
        stroke-linecap="round"
      />
      <circle
        cx="16.9375"
        cy="5.0625"
        r="3.5625"
        transform="rotate(90 16.9375 5.0625)"
        stroke="white"
        stroke-width="2"
      />
      <circle
        cx="5.0625"
        cy="16.9375"
        r="3.5625"
        transform="rotate(90 5.0625 16.9375)"
        stroke="white"
        stroke-width="2"
      />
    </svg>
  );
};

export default DiscountIcon;
